package com.simibubi.create.infrastructure.ponder.scenes.highLogistics;

import com.simibubi.create.content.logistics.box.PackageEntity;
import com.simibubi.create.content.logistics.packager.PackagerBlockEntity;
import com.simibubi.create.content.logistics.packagerLink.WiFiParticle;
import com.simibubi.create.foundation.ponder.CreateSceneBuilder;

import net.createmod.ponder.api.element.ElementLink;
import net.createmod.ponder.api.element.EntityElement;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;

public class PonderHilo {

	public static void packagerCreate(CreateSceneBuilder scene, class_2338 pos, class_1799 box) {
		scene.world()
			.modifyBlockEntity(pos, PackagerBlockEntity.class, be -> {
				be.animationTicks = PackagerBlockEntity.CYCLE;
				be.animationInward = false;
				be.heldBox = box;
			});
	}

	public static void packagerUnpack(CreateSceneBuilder scene, class_2338 pos, class_1799 box) {
		scene.world()
			.modifyBlockEntity(pos, PackagerBlockEntity.class, be -> {
				be.animationTicks = PackagerBlockEntity.CYCLE;
				be.animationInward = true;
				be.previouslyUnwrapped = box;
			});
	}

	public static void packagerClear(CreateSceneBuilder scene, class_2338 pos) {
		scene.world()
			.modifyBlockEntity(pos, PackagerBlockEntity.class, be -> be.heldBox = class_1799.field_8037);
	}

	public static ElementLink<EntityElement> packageHopsOffBelt(CreateSceneBuilder scene, class_2338 beltPos,
		class_2350 side, class_1799 box) {
		scene.world()
			.removeItemsFromBelt(beltPos);
		return scene.world()
			.createEntity(l -> {
				PackageEntity packageEntity = new PackageEntity(l, beltPos.method_10263() + 0.5 + side.method_10148() * 0.675,
					beltPos.method_10264() + 0.875, beltPos.method_10260() + 0.5 + side.method_10165() * 0.675);
				packageEntity.method_18799(new class_243(side.method_10148(), 1f, side.method_10165()).method_1021(0.125f));
				packageEntity.box = box;
				return packageEntity;
			});
	}

	public static void linkEffect(CreateSceneBuilder scene, class_2338 pos) {
		scene.world()
			.flashDisplayLink(pos);
		scene.addInstruction(s -> {
			class_243 vec3 = class_243.method_24953(pos);
			s.getWorld()
				.method_8406(new WiFiParticle.Data(), vec3.field_1352, vec3.field_1351, vec3.field_1350, 1, 1, 1);
		});
	}

	public static void requesterEffect(CreateSceneBuilder scene, class_2338 pos) {
		scene.addInstruction(s -> {
			class_243 vec3 = class_243.method_24953(pos);
			s.getWorld()
				.method_8406(new WiFiParticle.Data(), vec3.field_1352, vec3.field_1351, vec3.field_1350, 1, 1, 1);
		});
	}

}
