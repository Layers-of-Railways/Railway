package com.simibubi.create.foundation.data;

import static com.simibubi.create.api.behaviour.interaction.MovingInteractionBehaviour.interactionBehaviour;
import static com.simibubi.create.api.behaviour.movement.MovementBehaviour.movementBehaviour;
import static com.simibubi.create.foundation.data.BlockStateGen.axisBlock;
import static com.simibubi.create.foundation.data.CreateRegistrate.casingConnectivity;
import static com.simibubi.create.foundation.data.CreateRegistrate.connectedTextures;
import static com.simibubi.create.foundation.data.TagGen.axeOrPickaxe;
import static com.simibubi.create.foundation.data.TagGen.pickaxeOnly;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.function.Supplier;

import javax.annotation.Nullable;

import com.simibubi.create.AllBlocks;
import com.simibubi.create.AllTags.AllBlockTags;
import com.simibubi.create.AllTags.AllItemTags;
import com.simibubi.create.Create;
import com.simibubi.create.api.stress.BlockStressValues;
import com.simibubi.create.content.contraptions.behaviour.DoorMovingInteraction;
import com.simibubi.create.content.contraptions.behaviour.TrapdoorMovingInteraction;
import com.simibubi.create.content.contraptions.piston.MechanicalPistonGenerator;
import com.simibubi.create.content.decoration.MetalScaffoldingBlock;
import com.simibubi.create.content.decoration.MetalScaffoldingBlockItem;
import com.simibubi.create.content.decoration.MetalScaffoldingCTBehaviour;
import com.simibubi.create.content.decoration.copycat.CopycatBlock;
import com.simibubi.create.content.decoration.encasing.CasingBlock;
import com.simibubi.create.content.decoration.encasing.EncasedCTBehaviour;
import com.simibubi.create.content.decoration.slidingDoor.SlidingDoorBlock;
import com.simibubi.create.content.decoration.slidingDoor.SlidingDoorMovementBehaviour;
import com.simibubi.create.content.kinetics.base.RotatedPillarKineticBlock;
import com.simibubi.create.content.kinetics.crank.ValveHandleBlock;
import com.simibubi.create.content.kinetics.simpleRelays.encased.EncasedCogCTBehaviour;
import com.simibubi.create.content.kinetics.simpleRelays.encased.EncasedCogwheelBlock;
import com.simibubi.create.content.kinetics.simpleRelays.encased.EncasedShaftBlock;
import com.simibubi.create.content.logistics.box.PackageItem;
import com.simibubi.create.content.logistics.box.PackageStyles.PackageStyle;
import com.simibubi.create.content.logistics.packager.PackagerGenerator;
import com.simibubi.create.content.logistics.tableCloth.TableClothBlockItem;
import com.simibubi.create.content.logistics.tunnel.BeltTunnelBlock;
import com.simibubi.create.content.logistics.tunnel.BeltTunnelBlock.Shape;
import com.simibubi.create.content.logistics.tunnel.BeltTunnelItem;
import com.simibubi.create.content.trains.bogey.AbstractBogeyBlock;
import com.simibubi.create.content.trains.bogey.StandardBogeyBlock;
import com.simibubi.create.foundation.block.ItemUseOverrides;
import com.simibubi.create.foundation.block.connected.CTSpriteShiftEntry;
import com.simibubi.create.foundation.block.connected.HorizontalCTBehaviour;
import com.simibubi.create.foundation.item.ItemDescription;
import com.simibubi.create.infrastructure.config.CStress;
import com.tterrag.registrate.builders.BlockBuilder;
import com.tterrag.registrate.builders.ItemBuilder;
import com.tterrag.registrate.providers.RegistrateRecipeProvider;
import com.tterrag.registrate.util.DataIngredient;
import com.tterrag.registrate.util.nullness.NonNullSupplier;
import com.tterrag.registrate.util.nullness.NonNullUnaryOperator;

import net.createmod.catnip.platform.CatnipServices;
import net.fabricmc.fabric.api.tag.convention.v1.ConventionalItemTags;
import net.minecraft.class_1767;
import net.minecraft.class_1814;
import net.minecraft.class_1921;
import net.minecraft.class_1935;
import net.minecraft.class_201;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2350.class_2351;
import net.minecraft.class_2350.class_2352;
import net.minecraft.class_2450;
import net.minecraft.class_2498;
import net.minecraft.class_2533;
import net.minecraft.class_2741;
import net.minecraft.class_2764;
import net.minecraft.class_2960;
import net.minecraft.class_3481;
import net.minecraft.class_3489;
import net.minecraft.class_3620;
import net.minecraft.class_3837;
import net.minecraft.class_44;
import net.minecraft.class_4970;
import net.minecraft.class_52;
import net.minecraft.class_52.class_53;
import net.minecraft.class_5341;
import net.minecraft.class_55;
import net.minecraft.class_5646;
import net.minecraft.class_6862;
import net.minecraft.class_77;
import net.minecraft.class_7800;
import net.minecraft.class_7924;
import io.github.fabricators_of_create.porting_lib.models.generators.ConfiguredModel;
import io.github.fabricators_of_create.porting_lib.models.generators.ModelFile;

public class BuilderTransformers {
	public static <B extends EncasedShaftBlock, P> NonNullUnaryOperator<BlockBuilder<B, P>> encasedShaft(String casing,
																										 Supplier<CTSpriteShiftEntry> casingShift) {
		return builder -> encasedBase(builder, () -> AllBlocks.SHAFT.get())
			.onRegister(CreateRegistrate.connectedTextures(() -> new EncasedCTBehaviour(casingShift.get())))
			.onRegister(CreateRegistrate.casingConnectivity((block, cc) -> cc.make(block, casingShift.get(),
				(s, f) -> f.method_10166() != s.method_11654(EncasedShaftBlock.AXIS))))
			.blockstate((c, p) -> axisBlock(c, p, blockState -> p.models()
				.getExistingFile(p.modLoc("block/encased_shaft/block_" + casing)), true))
			.item()
			.model(AssetLookup.customBlockItemModel("encased_shaft", "item_" + casing))
			.build();
	}

	public static <B extends StandardBogeyBlock, P> NonNullUnaryOperator<BlockBuilder<B, P>> bogey() {
		return b -> b.initialProperties(SharedProperties::softMetal)
			.properties(p -> p.method_9626(class_2498.field_22150))
			.properties(p -> p.method_22488())
			.transform(pickaxeOnly())
			.blockstate((c, p) -> BlockStateGen.horizontalAxisBlock(c, p, s -> p.models()
				.getExistingFile(p.modLoc("block/track/bogey/top"))))
			.loot((p, l) -> p.method_46006(l, AllBlocks.RAILWAY_CASING.get()))
			.onRegister(
				block -> AbstractBogeyBlock.registerStandardBogey(CatnipServices.REGISTRIES.getKeyOrThrow(block)));
	}

	public static <B extends CopycatBlock, P> NonNullUnaryOperator<BlockBuilder<B, P>> copycat() {
		return b -> b.initialProperties(SharedProperties::softMetal)
			.blockstate((c, p) -> p.simpleBlock(c.get(), p.models()
				.getExistingFile(p.mcLoc("air"))))
			.initialProperties(SharedProperties::softMetal)
			.properties(p -> p.method_22488()
				.method_31710(class_3620.field_16008))
			// fabric: only render base model on cutout. When rendering the wrapped model's material is copied.
			.addLayer(() -> class_1921::method_23581)
			.color(() -> CopycatBlock::wrappedColor)
			.transform(TagGen.axeOrPickaxe());
	}

	public static <B extends class_2533, P> NonNullUnaryOperator<BlockBuilder<B, P>> trapdoor(boolean orientable) {
		return b -> b.blockstate((c, p) -> {
				ModelFile bottom = AssetLookup.partialBaseModel(c, p, "bottom");
				ModelFile top = AssetLookup.partialBaseModel(c, p, "top");
				ModelFile open = AssetLookup.partialBaseModel(c, p, "open");
				if (orientable)
					p.trapdoorBlock(c.get(), bottom, top, open, orientable);
				else
					BlockStateGen.uvLockedTrapdoorBlock(c.get(), bottom, top, open)
						.accept(c, p);
			})
			.transform(pickaxeOnly())
			.tag(class_3481.field_15487)
			.onRegister(interactionBehaviour(new TrapdoorMovingInteraction()))
			.item()
			.tag(class_3489.field_15548)
			.build();
	}

	public static <B extends SlidingDoorBlock, P> NonNullUnaryOperator<BlockBuilder<B, P>> slidingDoor(String type) {
		return b -> b.initialProperties(() -> class_2246.field_9973)
			.properties(p -> p.method_29292()
				.method_9629(3.0F, 6.0F))
			.blockstate((c, p) -> {
				ModelFile bottom = AssetLookup.partialBaseModel(c, p, "bottom");
				ModelFile top = AssetLookup.partialBaseModel(c, p, "top");
				p.doorBlock(c.get(), bottom, bottom, bottom, bottom, top, top, top, top);
			})
			.addLayer(() -> class_1921::method_23579)
			.transform(pickaxeOnly())
			.onRegister(interactionBehaviour(new DoorMovingInteraction()))
			.onRegister(movementBehaviour(new SlidingDoorMovementBehaviour()))
			.tag(class_3481.field_15495)
			.tag(class_3481.field_15494) // for villager AI
			.tag(AllBlockTags.NON_DOUBLE_DOOR.tag)
			.loot((lr, block) -> lr.method_45988(block, lr.method_46022(block)))
			.item()
			.tag(class_3489.field_15553)
			.tag(AllItemTags.CONTRAPTION_CONTROLLED.tag)
			.model((c, p) -> p.blockSprite(c, p.modLoc("item/" + type + "_door")))
			.build();
	}

	public static <B extends EncasedCogwheelBlock, P> NonNullUnaryOperator<BlockBuilder<B, P>> encasedCogwheel(
		String casing, Supplier<CTSpriteShiftEntry> casingShift) {
		return b -> encasedCogwheelBase(b, casing, casingShift, () -> AllBlocks.COGWHEEL.get(), false);
	}

	public static <B extends EncasedCogwheelBlock, P> NonNullUnaryOperator<BlockBuilder<B, P>> encasedLargeCogwheel(
		String casing, Supplier<CTSpriteShiftEntry> casingShift) {
		return b -> encasedCogwheelBase(b, casing, casingShift, () -> AllBlocks.LARGE_COGWHEEL.get(), true)
			.onRegister(CreateRegistrate.connectedTextures(() -> new EncasedCogCTBehaviour(casingShift.get())));
	}

	private static <B extends EncasedCogwheelBlock, P> BlockBuilder<B, P> encasedCogwheelBase(BlockBuilder<B, P> b,
																							  String casing, Supplier<CTSpriteShiftEntry> casingShift, Supplier<class_1935> drop, boolean large) {
		String encasedSuffix = "_encased_cogwheel_side" + (large ? "_connected" : "");
		String blockFolder = large ? "encased_large_cogwheel" : "encased_cogwheel";
		String wood = casing.equals("brass") ? "dark_oak" : "spruce";
		String gearbox = casing.equals("brass") ? "brass_gearbox" : "gearbox";
		return encasedBase(b, drop).addLayer(() -> class_1921::method_23579)
			.onRegister(CreateRegistrate.casingConnectivity((block, cc) -> cc.make(block, casingShift.get(),
				(s, f) -> f.method_10166() == s.method_11654(EncasedCogwheelBlock.AXIS)
					&& !s.method_11654(f.method_10171() == class_2352.field_11056 ? EncasedCogwheelBlock.TOP_SHAFT
					: EncasedCogwheelBlock.BOTTOM_SHAFT))))
			.blockstate((c, p) -> axisBlock(c, p, blockState -> {
				String suffix = (blockState.method_11654(EncasedCogwheelBlock.TOP_SHAFT) ? "_top" : "")
					+ (blockState.method_11654(EncasedCogwheelBlock.BOTTOM_SHAFT) ? "_bottom" : "");
				String modelName = c.getName() + suffix;
				return p.models()
					.withExistingParent(modelName, p.modLoc("block/" + blockFolder + "/block" + suffix))
					.texture("casing", Create.asResource("block/" + casing + "_casing"))
					.texture("particle", Create.asResource("block/" + casing + "_casing"))
					.texture("4", Create.asResource("block/" + gearbox))
					.texture("1", new class_2960("block/stripped_" + wood + "_log_top"))
					.texture("side", Create.asResource("block/" + casing + encasedSuffix));
			}, false))
			.item()
			.model((c, p) -> p.withExistingParent(c.getName(), p.modLoc("block/" + blockFolder + "/item"))
				.texture("casing", Create.asResource("block/" + casing + "_casing"))
				.texture("particle", Create.asResource("block/" + casing + "_casing"))
				.texture("1", new class_2960("block/stripped_" + wood + "_log_top"))
				.texture("side", Create.asResource("block/" + casing + encasedSuffix)))
			.build();
	}

	private static <B extends RotatedPillarKineticBlock, P> BlockBuilder<B, P> encasedBase(BlockBuilder<B, P> b,
																						   Supplier<class_1935> drop) {
		return b.initialProperties(SharedProperties::stone)
			.properties(class_4970.class_2251::method_22488)
			.transform(CStress.setNoImpact())
			.loot((p, lb) -> p.method_46006(lb, drop.get()));
	}

	public static <B extends class_2248, P> NonNullUnaryOperator<BlockBuilder<B, P>> cuckooClock() {
		return b -> b.initialProperties(SharedProperties::wooden)
			.blockstate((c, p) -> p.horizontalBlock(c.get(), p.models()
				.getExistingFile(p.modLoc("block/cuckoo_clock/block"))))
			.addLayer(() -> class_1921::method_23579)
			.transform(CStress.setImpact(1))
			.item()
			.transform(ModelGen.customItemModel("cuckoo_clock", "item"));
	}

	public static <B extends class_2248, P> NonNullUnaryOperator<BlockBuilder<B, P>> ladder(String name,
																					   Supplier<DataIngredient> ingredient, class_3620 color) {
		return b -> b.initialProperties(() -> class_2246.field_9983)
			.properties(p -> p.method_31710(color))
			.addLayer(() -> class_1921::method_23581)
			.blockstate((c, p) -> p.horizontalBlock(c.get(), p.models()
				.withExistingParent(c.getName(), p.modLoc("block/ladder"))
				.texture("0", p.modLoc("block/ladder_" + name + "_hoop"))
				.texture("1", p.modLoc("block/ladder_" + name))
				.texture("particle", p.modLoc("block/ladder_" + name))))
			.properties(p -> p.method_9626(class_2498.field_27204))
			.transform(pickaxeOnly())
			.tag(class_3481.field_22414)
			.item()
			.recipe((c, p) -> p.stonecutting(ingredient.get(), class_7800.field_40635, c::get, 2))
			.model((c, p) -> p.blockSprite(c::get, p.modLoc("block/ladder_" + name)))
			.build();
	}

	public static <B extends class_2248, P> NonNullUnaryOperator<BlockBuilder<B, P>> scaffold(String name,
																						 Supplier<DataIngredient> ingredient, class_3620 color, CTSpriteShiftEntry scaffoldShift,
																						 CTSpriteShiftEntry scaffoldInsideShift, CTSpriteShiftEntry casingShift) {
		return b -> b.initialProperties(() -> class_2246.field_16492)
			.properties(p -> p.method_9626(class_2498.field_27204)
				.method_31710(color))
			.addLayer(() -> class_1921::method_23581)
			.blockstate((c, p) -> p.getVariantBuilder(c.get())
				.forAllStatesExcept(s -> {
					String suffix = s.method_11654(MetalScaffoldingBlock.field_16547) ? "_horizontal" : "";
					return ConfiguredModel.builder()
						.modelFile(p.models()
							.withExistingParent(c.getName() + suffix, p.modLoc("block/scaffold/block" + suffix))
							.texture("top", p.modLoc("block/funnel/" + name + "_funnel_frame"))
							.texture("inside", p.modLoc("block/scaffold/" + name + "_scaffold_inside"))
							.texture("side", p.modLoc("block/scaffold/" + name + "_scaffold"))
							.texture("casing", p.modLoc("block/" + name + "_casing"))
							.texture("particle", p.modLoc("block/scaffold/" + name + "_scaffold")))
						.build();
				}, MetalScaffoldingBlock.field_16496, MetalScaffoldingBlock.field_16495))
			.onRegister(connectedTextures(
				() -> new MetalScaffoldingCTBehaviour(scaffoldShift, scaffoldInsideShift, casingShift)))
			.transform(pickaxeOnly())
			.tag(class_3481.field_22414)
			.item(MetalScaffoldingBlockItem::new)
			.recipe((c, p) -> p.stonecutting(ingredient.get(), class_7800.field_40635, c::get, 2))
			.model((c, p) -> p.withExistingParent(c.getName(), p.modLoc("block/" + c.getName())))
			.build();
	}

	public static <B extends ValveHandleBlock> NonNullUnaryOperator<BlockBuilder<B, CreateRegistrate>> valveHandle(
		@Nullable class_1767 color) {
		return b -> b.initialProperties(SharedProperties::copperMetal)
			.blockstate((c, p) -> {
				String variant = color == null ? "copper" : color.method_15434();
				p.directionalBlock(c.get(), p.models()
					.withExistingParent(variant + "_valve_handle", p.modLoc("block/valve_handle"))
					.texture("3", p.modLoc("block/valve_handle/valve_handle_" + variant)));
			})
			.tag(AllBlockTags.BRITTLE.tag, AllBlockTags.VALVE_HANDLES.tag)
			.onRegister(BlockStressValues.setGeneratorSpeed(32))
			.onRegister(ItemUseOverrides::addBlock)
			.item()
			.tag(AllItemTags.VALVE_HANDLES.tag)
			.build();
	}

	public static <B extends CasingBlock> NonNullUnaryOperator<BlockBuilder<B, CreateRegistrate>> casing(
		Supplier<CTSpriteShiftEntry> ct) {
		return b -> b.initialProperties(SharedProperties::stone)
			.properties(p -> p.method_9626(class_2498.field_11547))
			.transform(axeOrPickaxe())
			.blockstate((c, p) -> p.simpleBlock(c.get()))
			.onRegister(connectedTextures(() -> new EncasedCTBehaviour(ct.get())))
			.onRegister(casingConnectivity((block, cc) -> cc.makeCasing(block, ct.get())))
			.tag(AllBlockTags.CASING.tag)
			.item()
			.tag(AllItemTags.CASING.tag)
			.build();
	}

	public static <B extends CasingBlock> NonNullUnaryOperator<BlockBuilder<B, CreateRegistrate>> layeredCasing(
		Supplier<CTSpriteShiftEntry> ct, Supplier<CTSpriteShiftEntry> ct2) {
		return b -> b.initialProperties(SharedProperties::stone)
			.transform(axeOrPickaxe())
			.blockstate((c, p) -> p.simpleBlock(c.get(), p.models()
				.cubeColumn(c.getName(), ct.get()
						.getOriginalResourceLocation(),
					ct2.get()
						.getOriginalResourceLocation())))
			.onRegister(connectedTextures(() -> new HorizontalCTBehaviour(ct.get(), ct2.get())))
			.onRegister(casingConnectivity((block, cc) -> cc.makeCasing(block, ct.get())))
			.tag(AllBlockTags.CASING.tag)
			.item()
			.tag(AllItemTags.CASING.tag)
			.build();
	}

	public static <B extends BeltTunnelBlock> NonNullUnaryOperator<BlockBuilder<B, CreateRegistrate>> beltTunnel(
		String type, class_2960 particleTexture) {
		String prefix = "block/tunnel/" + type + "_tunnel";
		String funnel_prefix = "block/funnel/" + type + "_funnel";
		return b -> b.initialProperties(SharedProperties::stone)
			.addLayer(() -> class_1921::method_23579)
			.properties(class_4970.class_2251::method_22488)
			.transform(pickaxeOnly())
			.blockstate((c, p) -> p.getVariantBuilder(c.get())
				.forAllStates(state -> {
					Shape shape = state.method_11654(BeltTunnelBlock.SHAPE);
					String window = shape == Shape.WINDOW ? "_window" : "";
					if (shape == BeltTunnelBlock.Shape.CLOSED)
						shape = BeltTunnelBlock.Shape.STRAIGHT;
					String shapeName = shape.method_15434();
					return ConfiguredModel.builder()
						.modelFile(p.models()
							.withExistingParent(prefix + "/" + shapeName, p.modLoc("block/belt_tunnel/" + shapeName))
							.texture("top", p.modLoc(prefix + "_top" + window))
							.texture("tunnel", p.modLoc(prefix))
							.texture("direction", p.modLoc(funnel_prefix + "_neutral"))
							.texture("frame", p.modLoc(funnel_prefix + "_frame"))
							.texture("particle", particleTexture))
						.rotationY(state.method_11654(BeltTunnelBlock.HORIZONTAL_AXIS) == class_2351.field_11048 ? 0 : 90)
						.build();
				}))
			.item(BeltTunnelItem::new)
			.model((c, p) -> {
				p.withExistingParent("item/" + type + "_tunnel", p.modLoc("block/belt_tunnel/item"))
					.texture("top", p.modLoc(prefix + "_top"))
					.texture("tunnel", p.modLoc(prefix))
					.texture("direction", p.modLoc(funnel_prefix + "_neutral"))
					.texture("frame", p.modLoc(funnel_prefix + "_frame"))
					.texture("particle", particleTexture);
			})
			.build();
	}

	public static <B extends class_2248, P> NonNullUnaryOperator<BlockBuilder<B, P>> mechanicalPiston(class_2764 type) {
		return b -> b.initialProperties(SharedProperties::stone)
			.properties(p -> p.method_22488())
			.blockstate(new MechanicalPistonGenerator(type)::generate)
			.addLayer(() -> class_1921::method_23579)
			.transform(CStress.setImpact(4.0))
			.item()
			.transform(ModelGen.customItemModel("mechanical_piston", type.method_15434(), "item"));
	}

	public static <B extends class_2248, P> NonNullUnaryOperator<BlockBuilder<B, P>> bearing(String prefix,
																						String backTexture) {
		class_2960 baseBlockModelLocation = Create.asResource("block/bearing/block");
		class_2960 baseItemModelLocation = Create.asResource("block/bearing/item");
		class_2960 topTextureLocation = Create.asResource("block/bearing_top");
		class_2960 sideTextureLocation = Create.asResource("block/" + prefix + "_bearing_side");
		class_2960 backTextureLocation = Create.asResource("block/" + backTexture);
		return b -> b.initialProperties(SharedProperties::stone)
			.properties(p -> p.method_22488())
			.blockstate((c, p) -> p.directionalBlock(c.get(), p.models()
				.withExistingParent(c.getName(), baseBlockModelLocation)
				.texture("side", sideTextureLocation)
				.texture("back", backTextureLocation)))
			.item()
			.model((c, p) -> p.withExistingParent(c.getName(), baseItemModelLocation)
				.texture("top", topTextureLocation)
				.texture("side", sideTextureLocation)
				.texture("back", backTextureLocation))
			.build();
	}

	public static <B extends class_2248, P> NonNullUnaryOperator<BlockBuilder<B, P>> crate(String type) {
		return b -> b.initialProperties(SharedProperties::stone)
			.transform(axeOrPickaxe())
			.blockstate((c, p) -> {
				String[] variants = {"single", "top", "bottom", "left", "right"};
				Map<String, ModelFile> models = new HashMap<>();

				class_2960 crate = p.modLoc("block/crate_" + type);
				class_2960 side = p.modLoc("block/crate_" + type + "_side");
				class_2960 casing = p.modLoc("block/" + type + "_casing");

				for (String variant : variants)
					models.put(variant, p.models()
						.withExistingParent("block/crate/" + type + "/" + variant, p.modLoc("block/crate/" + variant))
						.texture("crate", crate)
						.texture("side", side)
						.texture("casing", casing));

				p.getVariantBuilder(c.get())
					.forAllStates(state -> {
						String variant = "single";
						return ConfiguredModel.builder()
							.modelFile(models.get(variant))
							.build();
					});
			})
			.item()
			.properties(p -> type.equals("creative") ? p.method_7894(class_1814.field_8904) : p)
			.transform(ModelGen.customItemModel("crate", type, "single"));
	}

	public static <B extends class_2248, P> NonNullUnaryOperator<BlockBuilder<B, P>> backtank(Supplier<class_1935> drop) {
		return b -> b.blockstate((c, p) -> p.horizontalBlock(c.getEntry(), AssetLookup.partialBaseModel(c, p)))
			.transform(pickaxeOnly())
			.addLayer(() -> class_1921::method_23579)
			.transform(CStress.setImpact(4.0))
			.loot((lt, block) -> {
				class_53 builder = class_52.method_324();
				class_5341.class_210 survivesExplosion = class_201.method_871();
				lt.method_45988(block, builder.method_336(class_55.method_347()
					.method_356(survivesExplosion)
					.method_352(class_44.method_32448(1))
					.method_351(class_77.method_411(drop.get())
						.method_438(class_3837.method_16848(class_5646.field_27914)
							.method_16857("VanillaTag", "{}", class_3837.class_3841.field_17034))
						.method_438(class_3837.method_16848(class_5646.field_27914)
							.method_16856("Air", "Air")))));
			});
	}

	public static <B extends class_2248, P> NonNullUnaryOperator<BlockBuilder<B, P>> bell() {
		return b -> b.initialProperties(SharedProperties::softMetal)
			.properties(p -> p.method_22488()
				.method_9626(class_2498.field_11531))
			.transform(pickaxeOnly())
			.addLayer(() -> class_1921::method_23579)
			.tag(AllBlockTags.BRITTLE.tag)
			.blockstate((c, p) -> p.horizontalBlock(c.getEntry(), state -> {
				String variant = state.method_11654(class_2741.field_17104)
					.method_15434();
				return p.models()
					.withExistingParent(c.getName() + "_" + variant, p.modLoc("block/bell_base/block_" + variant));
			}))
			.item()
			.model((c, p) -> p.withExistingParent(c.getName(), p.modLoc("block/" + c.getName())))
			.tag(AllItemTags.CONTRAPTION_CONTROLLED.tag)
			.build();
	}

	public static ItemBuilder<PackageItem, CreateRegistrate> packageItem(PackageStyle style) {
		String size = "_" + style.width() + "x" + style.height();
		return Create.registrate().item(style.getItemId()
				.method_12832(), p -> new PackageItem(p, style))
			.properties(p -> p.method_7889(1))
			.tag(AllItemTags.PACKAGES.tag)
			.model((c, p) -> {
				if (style.rare())
					p.withExistingParent(c.getName(), p.modLoc("item/package/custom" + size))
						.texture("2", p.modLoc("item/package/" + style.type()));
				else
					p.withExistingParent(c.getName(), p.modLoc("item/package/" + style.type() + size));
			})
			.lang((style.rare() ? "Rare"
				: style.type()
				.substring(0, 1)
				.toUpperCase(Locale.ROOT)
				+ style.type()
				.substring(1))
				+ " Package");
	}

	public static <B extends class_2248, P> NonNullUnaryOperator<BlockBuilder<B, P>> tableCloth(String name,
																						   NonNullSupplier<? extends class_2248> initialProps, boolean dyed) {
		return b -> {
			class_6862<class_2248> soundTag = dyed ? class_3481.field_43170 : class_3481.field_28040;

			ItemBuilder<TableClothBlockItem, BlockBuilder<B, P>> item = b.initialProperties(initialProps)
				.addLayer(() -> class_1921::method_23579)
				.blockstate((c, p) -> p.simpleBlock(c.get(), p.models()
					.withExistingParent(name + "_table_cloth", p.modLoc("block/table_cloth/block"))
					.texture("0", p.modLoc("block/table_cloth/" + name))))
//				.onRegister(CreateRegistrate.blockModel(() -> TableClothModel::new))
				.tag(AllBlockTags.TABLE_CLOTHS.tag, soundTag)
				.onRegisterAfter(class_7924.field_41197, v -> ItemDescription.useKey(v, "block.create.table_cloth"))
				.item(TableClothBlockItem::new);

			if (dyed)
				item.tag(AllItemTags.DYED_TABLE_CLOTHS.tag);

			return item.model((c, p) -> p.withExistingParent(name + "_table_cloth", p.modLoc("block/table_cloth/item"))
					.texture("0", p.modLoc("block/table_cloth/" + name)))
				.tag(AllItemTags.TABLE_CLOTHS.tag)
				.recipe((c, p) -> class_2450.method_10447(class_7800.field_40642, c.get())
					.method_10454(c.get())
					.method_10442("has_" + c.getName(), RegistrateRecipeProvider.method_10426(c.get()))
					.method_17972(p, Create.asResource("crafting/logistics/" + c.getName() + "_clear")))
				.build();
		};
	}

	public static <B extends class_2248, P> NonNullUnaryOperator<BlockBuilder<B, P>> packager() {
		return b -> b.initialProperties(SharedProperties::softMetal)
			.properties(p -> p.method_22488())
			.properties(p -> p.method_26236(($1, $2, $3) -> false))
			.properties(p -> p.method_31710(class_3620.field_16015)
				.method_9626(class_2498.field_22150))
			.transform(pickaxeOnly())
			.addLayer(() -> class_1921::method_23579)
			.blockstate(new PackagerGenerator()::generate)
			.item()
			.model(AssetLookup::customItemModel)
			.build();
	}

	public static <B extends class_2248, P> NonNullUnaryOperator<BlockBuilder<B, P>> palettesIronBlock() {
		return b -> b.initialProperties(SharedProperties::softMetal)
			.properties(p -> p.method_31710(class_3620.field_15978)
				.method_9626(class_2498.field_22150)
				.method_29292())
			.transform(pickaxeOnly())
			.blockstate((c, p) -> p.simpleBlock(c.get(), p.models()
				.cubeColumn(c.getName(), p.modLoc("block/" + c.getName()), p.modLoc("block/" + c.getName() + "_top"))))
			.tag(AllBlockTags.WRENCH_PICKUP.tag)
			.recipe((c, p) -> p.stonecutting(DataIngredient.tag(ConventionalItemTags.IRON_INGOTS), class_7800.field_40634,
				c::get, 2))
			.simpleItem();
	}
}
