package com.simibubi.create.api.contraption.storage.fluid;

import java.util.Objects;

import org.jetbrains.annotations.Nullable;

import com.mojang.serialization.Codec;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariant;
import net.fabricmc.fabric.api.transfer.v1.storage.Storage;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2680;

public abstract class MountedFluidStorage implements Storage<FluidVariant> {
	public static final Codec<MountedFluidStorage> CODEC = MountedFluidStorageType.CODEC.dispatch(
		storage -> storage.type, type -> type.codec
	);

	public final MountedFluidStorageType<? extends MountedFluidStorage> type;

	protected MountedFluidStorage(MountedFluidStorageType<?> type) {
		this.type = Objects.requireNonNull(type);
	}

	/**
	 * Un-mount this storage back into the world. The expected storage type of the target
	 * block has already been checked to make sure it matches this storage's type.
	 */
	public abstract void unmount(class_1937 level, class_2680 state, class_2338 pos, @Nullable class_2586 be);
}
