package com.simibubi.create.foundation.gui;

import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL30;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4587;

public interface ScreenWithStencils {

	default void startStencil(class_332 graphics, float x, float y, float w, float h) {
		RenderSystem.clear(GL30.GL_STENCIL_BUFFER_BIT | GL30.GL_DEPTH_BUFFER_BIT, class_310.field_1703);

		GL11.glDisable(GL11.GL_STENCIL_TEST);
		RenderSystem.stencilMask(~0);
		RenderSystem.clear(GL11.GL_STENCIL_BUFFER_BIT, class_310.field_1703);
		GL11.glEnable(GL11.GL_STENCIL_TEST);
		RenderSystem.stencilOp(GL11.GL_REPLACE, GL11.GL_KEEP, GL11.GL_KEEP);
		RenderSystem.stencilMask(0xFF);
		RenderSystem.stencilFunc(GL11.GL_NEVER, 1, 0xFF);

		class_4587 matrixStack = graphics.method_51448();
		matrixStack.method_22903();
		matrixStack.method_46416(x, y, 0);
		matrixStack.method_22905(w, h, 1);
		graphics.method_33284(0, 0, 1, 1, -100, 0xff000000, 0xff000000);
		matrixStack.method_22909();

		GL11.glEnable(GL11.GL_STENCIL_TEST);
		RenderSystem.stencilOp(GL11.GL_KEEP, GL11.GL_KEEP, GL11.GL_KEEP);
		RenderSystem.stencilFunc(GL11.GL_EQUAL, 1, 0xFF);
	}

	default void endStencil() {
		GL11.glDisable(GL11.GL_STENCIL_TEST);
	}
	
}
