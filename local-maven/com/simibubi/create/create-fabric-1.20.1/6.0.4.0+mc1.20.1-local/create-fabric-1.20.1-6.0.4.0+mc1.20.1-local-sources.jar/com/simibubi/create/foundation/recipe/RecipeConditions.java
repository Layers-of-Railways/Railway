package com.simibubi.create.foundation.recipe;

import java.util.function.Predicate;
import net.minecraft.class_1799;
import net.minecraft.class_1860;
import net.minecraft.class_3956;
import com.simibubi.create.foundation.blockEntity.behaviour.filtering.FilteringBehaviour;

/**
 * Commonly used Predicates for searching through recipe collections.
 * 
 * @author simibubi
 *
 */
public class RecipeConditions {

	public static Predicate<class_1860<?>> isOfType(class_3956<?>... otherTypes) {
		return recipe -> {
			class_3956<?> recipeType = recipe.method_17716();
			for (class_3956<?> other : otherTypes)
				if (recipeType == other)
					return true;
			return false;
		};
	}

	public static Predicate<class_1860<?>> firstIngredientMatches(class_1799 stack) {
		return r -> !r.method_8117().isEmpty() && r.method_8117().get(0).method_8093(stack);
	}

	public static Predicate<class_1860<?>> outputMatchesFilter(FilteringBehaviour filtering) {
		return r -> filtering.test(r.method_8110(filtering.getWorld().method_30349()));

	}

}
