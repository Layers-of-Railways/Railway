package com.simibubi.create.foundation.block.connected;

import net.minecraft.class_1920;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2350.class_2352;
import net.minecraft.class_2680;

public class GlassPaneCTBehaviour extends SimpleCTBehaviour {

	public GlassPaneCTBehaviour(CTSpriteShiftEntry shift) {
		super(shift);
	}
	
	@Override
	public boolean buildContextForOccludedDirections() {
		return true;
	}

	@Override
	public boolean connectsTo(class_2680 state, class_2680 other, class_1920 reader, class_2338 pos, class_2338 otherPos,
		class_2350 face) {
		return state.method_26204() == other.method_26204();
	}

	@Override
	protected boolean reverseUVsHorizontally(class_2680 state, net.minecraft.class_2350 face) {
		if (face.method_10171() == class_2352.field_11060)
			return true;
		return super.reverseUVsHorizontally(state, face);
	}
}
