package com.simibubi.create.foundation.data.recipe;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.function.Consumer;

import com.simibubi.create.AllBlocks;
import com.simibubi.create.AllItems;
import com.simibubi.create.AllTags;

import com.simibubi.create.api.data.recipe.ProcessingRecipeGen;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricRecipeProvider;
import net.minecraft.class_1792;
import net.minecraft.class_1856;
import net.minecraft.class_1935;
import net.minecraft.class_2405;
import net.minecraft.class_2444;
import net.minecraft.class_3489;
import net.minecraft.class_6862;
import net.minecraft.class_7403;
import io.github.fabricators_of_create.porting_lib.tags.Tags;

/**
 * The class that handles gathering Create's generated recipes for most types.
 * Data here is only generated when running server dategen
 * @see com.simibubi.create.infrastructure.data.CreateDatagen
 */
public final class CreateRecipeProvider extends FabricRecipeProvider {

	static final List<ProcessingRecipeGen> GENERATORS = new ArrayList<>();

	public CreateRecipeProvider(FabricDataOutput output) {
		super(output);
	}

	@Override
	public void method_10419(Consumer<class_2444> writer) {}

	public static class_2405 registerAllProcessing(FabricDataOutput output) {
		GENERATORS.add(new CreateCrushingRecipeGen(output));
		GENERATORS.add(new CreateMillingRecipeGen(output));
		GENERATORS.add(new CreateCuttingRecipeGen(output));
		GENERATORS.add(new CreateWashingRecipeGen(output));
		GENERATORS.add(new CreatePolishingRecipeGen(output));
		GENERATORS.add(new CreateDeployingRecipeGen(output));
		GENERATORS.add(new CreateMixingRecipeGen(output));
		GENERATORS.add(new CreateCompactingRecipeGen(output));
		GENERATORS.add(new CreatePressingRecipeGen(output));
		GENERATORS.add(new CreateFillingRecipeGen(output));
		GENERATORS.add(new CreateEmptyingRecipeGen(output));
		GENERATORS.add(new CreateHauntingRecipeGen(output));
		GENERATORS.add(new CreateItemApplicationRecipeGen(output));

		return new class_2405() {

			@Override
			public String method_10321() {
				return "Create's Processing Recipes";
			}

			@Override
			public CompletableFuture<?> method_10319(class_7403 dc) {
				return CompletableFuture.allOf(GENERATORS.stream()
					.map(gen -> gen.method_10319(dc))
					.toArray(CompletableFuture[]::new));
			}
		};
	}

	protected static class I {

		static class_6862<class_1792> redstone() {
			return Tags.Items.DUSTS_REDSTONE;
		}

		static class_6862<class_1792> planks() {
			return class_3489.field_15537;
		}

		static class_6862<class_1792> woodSlab() {
			return class_3489.field_15534;
		}

		static class_6862<class_1792> gold() {
			return Tags.Items.INGOTS_GOLD;
		}

		static class_6862<class_1792> goldSheet() {
			return AllTags.forgeItemTag("gold_plates");
		}

		static class_6862<class_1792> stone() {
			return Tags.Items.STONE;
		}

		static class_1935 andesiteAlloy() {
			return AllItems.ANDESITE_ALLOY.get();
		}

		static class_1935 shaft() {
			return AllBlocks.SHAFT.get();
		}

		static class_1935 cog() {
			return AllBlocks.COGWHEEL.get();
		}

		static class_1935 largeCog() {
			return AllBlocks.LARGE_COGWHEEL.get();
		}

		static class_1935 andesiteCasing() {
			return AllBlocks.ANDESITE_CASING.get();
		}

		static class_1935 vault() {
			return AllBlocks.ITEM_VAULT.get();
		}

		static class_1935 stockLink() {
			return AllBlocks.STOCK_LINK.get();
		}

		static class_6862<class_1792> brass() {
			return AllTags.forgeItemTag("brass_ingots");
		}

		static class_6862<class_1792> brassSheet() {
			return AllTags.forgeItemTag("brass_plates");
		}

		static class_6862<class_1792> iron() {
			return Tags.Items.INGOTS_IRON;
		}

		static class_6862<class_1792> ironNugget() {
			return Tags.Items.NUGGETS_IRON;
		}

		static class_6862<class_1792> zinc() {
			return AllTags.forgeItemTag("zinc_ingots");
		}

		static class_6862<class_1792> ironSheet() {
			return AllTags.forgeItemTag("iron_plates");
		}

		static class_6862<class_1792> sturdySheet() {
			return AllTags.forgeItemTag("obsidian_plates");
		}

		static class_1935 brassCasing() {
			return AllBlocks.BRASS_CASING.get();
		}

		static class_1935 cardboard() {
			return AllItems.CARDBOARD.get();
		}

		static class_1935 railwayCasing() {
			return AllBlocks.RAILWAY_CASING.get();
		}

		static class_1935 electronTube() {
			return AllItems.ELECTRON_TUBE.get();
		}

		static class_1935 precisionMechanism() {
			return AllItems.PRECISION_MECHANISM.get();
		}

		static class_6862<class_1792> brassBlock() {
			return AllTags.forgeItemTag("brass_blocks");
		}

		static class_6862<class_1792> zincBlock() {
			return AllTags.forgeItemTag("zinc_blocks");
		}

		static class_6862<class_1792> wheatFlour() {
			return AllTags.forgeItemTag("wheat_flour");
		}

		static class_6862<class_1792> copper() {
			return Tags.Items.INGOTS_COPPER;
		}

		static class_6862<class_1792> copperNugget() {
			return AllTags.forgeItemTag("copper_nuggets");
		}

		static class_6862<class_1792> copperBlock() {
			return Tags.Items.STORAGE_BLOCKS_COPPER;
		}

		static class_6862<class_1792> copperSheet() {
			return AllTags.forgeItemTag("copper_plates");
		}

		static class_6862<class_1792> brassNugget() {
			return AllTags.forgeItemTag("brass_nuggets");
		}

		static class_6862<class_1792> zincNugget() {
			return AllTags.forgeItemTag("zinc_nuggets");
		}

		static class_1935 copperCasing() {
			return AllBlocks.COPPER_CASING.get();
		}

		static class_1935 refinedRadiance() {
			return AllItems.REFINED_RADIANCE.get();
		}

		static class_1935 shadowSteel() {
			return AllItems.SHADOW_STEEL.get();
		}

		static class_1856 netherite() {
			return class_1856.method_8106(Tags.Items.INGOTS_NETHERITE);
		}

	}
}
