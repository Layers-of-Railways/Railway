package com.simibubi.create.foundation.mixin.accessor;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import it.unimi.dsi.fastutil.Hash.Strategy;
import net.minecraft.class_1799;
import net.minecraft.class_7708;

@Mixin(class_7708.class)
public interface ItemStackLinkedSetAccessor {
	@Accessor
	static Strategy<? super class_1799> getTYPE_AND_TAG() {
		throw new AbstractMethodError();
	}
}
