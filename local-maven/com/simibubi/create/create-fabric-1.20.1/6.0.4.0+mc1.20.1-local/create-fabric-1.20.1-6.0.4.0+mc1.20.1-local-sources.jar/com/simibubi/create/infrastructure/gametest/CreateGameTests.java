package com.simibubi.create.infrastructure.gametest;

import java.util.Collection;
import net.minecraft.class_4529;
import net.minecraft.class_6303;
import com.simibubi.create.infrastructure.gametest.tests.TestContraptions;
import com.simibubi.create.infrastructure.gametest.tests.TestFluids;
import com.simibubi.create.infrastructure.gametest.tests.TestItems;
import com.simibubi.create.infrastructure.gametest.tests.TestMisc;
import com.simibubi.create.infrastructure.gametest.tests.TestProcessing;

public class CreateGameTests {
	private static final Class<?>[] testHolders = {
			TestContraptions.class,
			TestFluids.class,
			TestItems.class,
			TestMisc.class,
			TestProcessing.class
	};

	@class_6303
	public static Collection<class_4529> generateTests() {
		return CreateTestFunction.getTestsFrom(testHolders);
	}
}
