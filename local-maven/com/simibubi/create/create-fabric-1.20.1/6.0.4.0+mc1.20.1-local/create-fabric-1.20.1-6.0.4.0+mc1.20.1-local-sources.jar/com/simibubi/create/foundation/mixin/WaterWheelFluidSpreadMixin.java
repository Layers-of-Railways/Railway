package com.simibubi.create.foundation.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import com.simibubi.create.AllBlocks;
import com.simibubi.create.content.kinetics.base.IRotate;
import com.simibubi.create.content.kinetics.waterwheel.WaterWheelStructuralBlock;
import net.minecraft.class_1922;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2350.class_2351;
import net.minecraft.class_2680;
import net.minecraft.class_3609;
import net.minecraft.class_3610;
import net.minecraft.class_3611;

@Mixin(class_3609.class)
public class WaterWheelFluidSpreadMixin {
	@Inject(method = "canPassThrough(Lnet/minecraft/world/level/BlockGetter;Lnet/minecraft/world/level/material/Fluid;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/core/Direction;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/material/FluidState;)Z", at = @At("HEAD"), cancellable = true)
	protected void create$canPassThroughOnWaterWheel(class_1922 pLevel, class_3611 pFluid, class_2338 pFromPos, class_2680 p_75967_,
		class_2350 pDirection, class_2338 p_75969_, class_2680 p_75970_, class_3610 p_75971_,
		CallbackInfoReturnable<Boolean> cir) {

		if (pDirection.method_10166() == class_2351.field_11052)
			return;

		class_2338 belowPos = pFromPos.method_10074();
		class_2680 belowState = pLevel.method_8320(belowPos);

		if (AllBlocks.WATER_WHEEL_STRUCTURAL.has(belowState)) {
			if (AllBlocks.WATER_WHEEL_STRUCTURAL.get()
				.stillValid(pLevel, belowPos, belowState, false))
				belowState = pLevel.method_8320(WaterWheelStructuralBlock.getMaster(pLevel, belowPos, belowState));
		} else if (!AllBlocks.WATER_WHEEL.has(belowState))
			return;

		if (belowState.method_26204() instanceof IRotate irotate
			&& irotate.getRotationAxis(belowState) == pDirection.method_10166())
			cir.setReturnValue(false);
	}
}
