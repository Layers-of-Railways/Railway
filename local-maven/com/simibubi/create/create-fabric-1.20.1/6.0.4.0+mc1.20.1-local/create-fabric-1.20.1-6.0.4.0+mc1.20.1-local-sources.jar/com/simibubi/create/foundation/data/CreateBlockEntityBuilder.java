package com.simibubi.create.foundation.data;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Objects;
import java.util.function.Predicate;
import java.util.function.Supplier;

import javax.annotation.Nullable;

import com.simibubi.create.api.behaviour.display.DisplaySource;
import com.simibubi.create.api.behaviour.display.DisplayTarget;
import com.simibubi.create.api.registry.CreateRegistries;
import com.tterrag.registrate.AbstractRegistrate;
import com.tterrag.registrate.builders.BlockEntityBuilder;
import com.tterrag.registrate.builders.BuilderCallback;
import com.tterrag.registrate.fabric.EnvExecutor;
import com.tterrag.registrate.util.entry.RegistryEntry;
import com.tterrag.registrate.util.nullness.NonNullSupplier;

import dev.engine_room.flywheel.lib.visualization.SimpleBlockEntityVisualizer;
import net.fabricmc.api.EnvType;
import net.minecraft.class_2248;
import net.minecraft.class_2586;
import net.minecraft.class_2591;

public class CreateBlockEntityBuilder<T extends class_2586, P> extends BlockEntityBuilder<T, P> {

	@Nullable
	private NonNullSupplier<SimpleBlockEntityVisualizer.Factory<T>> visualFactory;
	private Predicate<T> renderNormally;

	private Collection<NonNullSupplier<? extends Collection<NonNullSupplier<? extends class_2248>>>> deferredValidBlocks =
		new ArrayList<>();

	public static <T extends class_2586, P> BlockEntityBuilder<T, P> create(AbstractRegistrate<?> owner, P parent,
																			 String name, BuilderCallback callback, BlockEntityFactory<T> factory) {
		return new CreateBlockEntityBuilder<>(owner, parent, name, callback, factory);
	}

	protected CreateBlockEntityBuilder(AbstractRegistrate<?> owner, P parent, String name, BuilderCallback callback,
									   BlockEntityFactory<T> factory) {
		super(owner, parent, name, callback, factory);
	}

	public CreateBlockEntityBuilder<T, P> validBlocksDeferred(
		NonNullSupplier<? extends Collection<NonNullSupplier<? extends class_2248>>> blocks) {
		deferredValidBlocks.add(blocks);
		return this;
	}

	@Override
	protected class_2591<T> createEntry() {
		deferredValidBlocks.stream()
			.map(Supplier::get)
			.flatMap(Collection::stream)
			.forEach(this::validBlock);
		return super.createEntry();
	}

	public CreateBlockEntityBuilder<T, P> displaySource(RegistryEntry<? extends DisplaySource> source) {
		this.onRegisterAfter(
			CreateRegistries.DISPLAY_SOURCE,
			type -> DisplaySource.BY_BLOCK_ENTITY.add(type, source.get())
		);
		return this;
	}

	public CreateBlockEntityBuilder<T, P> displayTarget(RegistryEntry<? extends DisplayTarget> target) {
		this.onRegisterAfter(
			CreateRegistries.DISPLAY_TARGET,
			type -> DisplayTarget.BY_BLOCK_ENTITY.register(type, target.get())
		);
		return this;
	}

	public CreateBlockEntityBuilder<T, P> visual(
		NonNullSupplier<SimpleBlockEntityVisualizer.Factory<T>> visualFactory) {
		return visual(visualFactory, true);
	}

	public CreateBlockEntityBuilder<T, P> visual(
		NonNullSupplier<SimpleBlockEntityVisualizer.Factory<T>> visualFactory,
		boolean renderNormally) {
		return visual(visualFactory, be -> renderNormally);
	}

	public CreateBlockEntityBuilder<T, P> visual(
		NonNullSupplier<SimpleBlockEntityVisualizer.Factory<T>> visualFactory,
		Predicate<T> renderNormally) {
		if (this.visualFactory == null) {
			EnvExecutor.runWhenOn(EnvType.CLIENT, () -> this::registerVisualizer);
		}

		this.visualFactory = visualFactory;
		this.renderNormally = renderNormally;

		return this;
	}

	protected void registerVisualizer() {
		this.onRegister((entry) -> {
			Objects.requireNonNull(this.visualFactory);
			Predicate<T> renderNormally = this.renderNormally;
			SimpleBlockEntityVisualizer.builder(this.getEntry())
				.factory(this.visualFactory.get())
				.skipVanillaRender(be -> !renderNormally.test(be))
				.apply();
		});
	}
}
