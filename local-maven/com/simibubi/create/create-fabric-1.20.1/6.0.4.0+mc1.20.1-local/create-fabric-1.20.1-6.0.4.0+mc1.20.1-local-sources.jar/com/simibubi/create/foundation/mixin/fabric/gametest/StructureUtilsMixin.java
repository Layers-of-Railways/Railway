package com.simibubi.create.foundation.mixin.fabric.gametest;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import com.llamalad7.mixinextras.injector.ModifyReceiver;
import com.simibubi.create.foundation.utility.fabric.StructureBlockEntityExtensions;
import net.minecraft.class_2633;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3499;
import net.minecraft.class_4525;

@Mixin(value = class_4525.class, priority = 900) // apply before FAPI, run earlier
public class StructureUtilsMixin {
	/**
	 * this is what vanilla and forge do, but FAPI forces a different system
	 * @see StructureTestUtilMixin
 	 */
	@Inject(method = "getStructureTemplate", at = @At("HEAD"), cancellable = true)
	private static void useStructureManager(String name, class_3218 level, CallbackInfoReturnable<class_3499> cir) {
		class_2960 id = new class_2960(name);
		level.method_14183().method_15094(id).ifPresent(cir::setReturnValue);
	}

	@ModifyReceiver(
		method = "createStructureBlock",
		at = @At(
			value = "INVOKE",
			target = "Lnet/minecraft/world/level/block/entity/StructureBlockEntity;setIgnoreEntities(Z)V"
		)
	)
	private static class_2633 markGameTest(class_2633 instance, boolean ignoreEntities) {
		((StructureBlockEntityExtensions) instance).create$markGameTest();
		return instance;
	}
}
