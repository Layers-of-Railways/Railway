package com.simibubi.create.foundation.blockEntity.behaviour;

import org.joml.Matrix3f;
import com.simibubi.create.content.kinetics.simpleRelays.AbstractSimpleShaftBlock;

import dev.engine_room.flywheel.lib.transform.TransformStack;
import net.minecraft.class_1087;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2354;
import net.minecraft.class_310;
import net.minecraft.class_3481;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_811;
import net.minecraft.class_918;

public class ValueBoxRenderer {

	public static void renderItemIntoValueBox(class_1799 filter, class_4587 ms, class_4597 buffer, int light,
		int overlay) {
		class_310 mc = class_310.method_1551();
		class_918 itemRenderer = mc.method_1480();
		class_1087 modelWithOverrides = itemRenderer.method_4019(filter, null, null, 0);
		boolean blockItem = modelWithOverrides.method_4712();
		float scale = (!blockItem ? .5f : 1f) + 1 / 64f;
		float zOffset = (!blockItem ? -.15f : 0) + customZOffset(filter.method_7909());
		ms.method_22905(scale, scale, scale);
		ms.method_46416(0, 0, zOffset);
		itemRenderer.method_23179(filter, class_811.field_4319, false, ms, buffer, light, overlay, modelWithOverrides);
	}

	public static void renderFlatItemIntoValueBox(class_1799 filter, class_4587 ms, class_4597 buffer, int light,
		int overlay) {
		if (filter.method_7960())
			return;

		int bl = light >> 4 & 0xf;
		int sl = light >> 20 & 0xf;
		int itemLight = class_3532.method_15357(sl + .5) << 20 | (class_3532.method_15357(bl + .5) & 0xf) << 4;

		ms.method_22903();
		TransformStack.of(ms)
			.rotateXDegrees(230);
		Matrix3f copy = new Matrix3f(ms.method_23760()
			.method_23762());
		ms.method_22909();

		ms.method_22903();
		TransformStack.of(ms)
			.translate(0, 0, -1 / 4f)
			.translate(0, 0, 1 / 32f + .001)
			.rotateYDegrees(180);

		class_4587 squashedMS = new class_4587();
		squashedMS.method_23760()
			.method_23761()
			.mul(ms.method_23760()
				.method_23761());
		squashedMS.method_22905(.5f, .5f, 1 / 1024f);
		squashedMS.method_23760()
			.method_23762()
			.set(copy);
		class_310 mc = class_310.method_1551();
		mc.method_1480()
			.method_23178(filter, class_811.field_4317, itemLight, class_4608.field_21444, squashedMS, buffer, mc.field_1687, 0);

		ms.method_22909();
	}

	@SuppressWarnings("deprecation")
	private static float customZOffset(class_1792 item) {
		float nudge = -.1f;
		if (item instanceof class_1747) {
			class_2248 block = ((class_1747) item).method_7711();
			if (block instanceof AbstractSimpleShaftBlock)
				return nudge;
			if (block instanceof class_2354)
				return nudge;
			if (block.method_40142()
				.method_40220(class_3481.field_15493))
				return nudge;
			if (block == class_2246.field_10455)
				return nudge;
		}
		return 0;
	}

}
