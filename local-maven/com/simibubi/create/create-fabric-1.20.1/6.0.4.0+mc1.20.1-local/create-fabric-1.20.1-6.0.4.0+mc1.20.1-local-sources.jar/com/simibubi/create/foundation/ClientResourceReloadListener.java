package com.simibubi.create.foundation;

import java.util.Collection;
import java.util.Set;

import com.simibubi.create.Create;
import com.simibubi.create.CreateClient;
import com.simibubi.create.content.kinetics.belt.BeltHelper;
import com.simibubi.create.foundation.sound.SoundScapes;
import net.fabricmc.fabric.api.resource.IdentifiableResourceReloadListener;
import net.fabricmc.fabric.api.resource.ResourceReloadListenerKeys;
import net.minecraft.class_2960;
import net.minecraft.class_3300;
import net.minecraft.class_4013;

public class ClientResourceReloadListener implements class_4013, IdentifiableResourceReloadListener {
	public static final class_2960 ID = Create.asResource("client_reload_listener");
	// fabric: make sure number format is updated after languages load
	public static final Set<class_2960> DEPENDENCIES = Set.of(ResourceReloadListenerKeys.LANGUAGES);

	@Override
	public void method_14491(class_3300 resourceManager) {
		CreateClient.invalidateRenderers();
		SoundScapes.invalidateAll();
		BeltHelper.uprightCache.clear();
//		TableClothModel.reload();
	}

	@Override
	public class_2960 getFabricId() {
		return ID;
	}

	@Override
	public Collection<class_2960> getFabricDependencies() {
		return DEPENDENCIES;
	}
}
