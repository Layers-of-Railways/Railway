package com.simibubi.create.foundation.mixin.accessor;

import net.minecraft.class_3218;
import net.minecraft.class_5574;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_3218.class)
public interface ServerLevelAccessor {
	@Accessor("entityTickList")
	class_5574 create$getEntityTickList();
}
