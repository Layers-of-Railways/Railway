package com.simibubi.create.foundation.gui.widget;

import com.google.common.collect.ImmutableList;
import com.simibubi.create.foundation.gui.AllGuiTextures;

import net.createmod.catnip.gui.widget.AbstractSimiWidget;
import net.minecraft.class_2561;
import net.minecraft.class_332;

public class Indicator extends AbstractSimiWidget {

	public State state;

	public Indicator(int x, int y, class_2561 tooltip) {
		super(x, y, AllGuiTextures.INDICATOR.getWidth(), AllGuiTextures.INDICATOR.getHeight());
		this.toolTip = toolTip.isEmpty() ? ImmutableList.of() : ImmutableList.of(tooltip);
		this.state = State.OFF;
	}

	@Override
	public void method_25394(class_332 graphics, int mouseX, int mouseY, float partialTicks ) {
		if (!field_22764)
			return;
		AllGuiTextures toDraw;
		switch (state) {
			case ON: toDraw = AllGuiTextures.INDICATOR_WHITE; break;
			case OFF: toDraw = AllGuiTextures.INDICATOR; break;
			case RED: toDraw = AllGuiTextures.INDICATOR_RED; break;
			case YELLOW: toDraw = AllGuiTextures.INDICATOR_YELLOW; break;
			case GREEN: toDraw = AllGuiTextures.INDICATOR_GREEN; break;
			default: toDraw = AllGuiTextures.INDICATOR; break;
		}
		toDraw.render(graphics, method_46426(), method_46427());
	}

	public enum State {
		OFF, ON,
		RED, YELLOW, GREEN;
	}

}
