package com.simibubi.create.foundation.mixin.client;

import java.util.Set;
import net.minecraft.class_2338;
import net.minecraft.class_3191;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

import com.simibubi.create.foundation.block.render.BlockDestructionProgressExtension;

@Mixin(class_3191.class)
public class BlockDestructionProgressMixin implements BlockDestructionProgressExtension {
	@Unique
	private Set<class_2338> create$extraPositions;

	@Override
	public Set<class_2338> create$getExtraPositions() {
		return create$extraPositions;
	}

	@Override
	public void create$setExtraPositions(Set<class_2338> positions) {
		create$extraPositions = positions;
	}
}
