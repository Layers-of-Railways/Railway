package com.simibubi.create.foundation.blockEntity.behaviour.animatedContainer;

import java.util.function.Consumer;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_238;
import net.minecraft.class_2487;
import com.simibubi.create.foundation.blockEntity.SmartBlockEntity;
import com.simibubi.create.foundation.blockEntity.behaviour.BehaviourType;
import com.simibubi.create.foundation.blockEntity.behaviour.BlockEntityBehaviour;
import com.simibubi.create.foundation.gui.menu.MenuBase;

public class AnimatedContainerBehaviour<M extends MenuBase<? extends SmartBlockEntity>> extends BlockEntityBehaviour {

	public static final BehaviourType<AnimatedContainerBehaviour<?>> TYPE = new BehaviourType<>();

	public int openCount;

	private Class<M> menuClass;
	private Consumer<Boolean> openChanged;

	public AnimatedContainerBehaviour(SmartBlockEntity be, Class<M> menuClass) {
		super(be);
		this.menuClass = menuClass;
		openCount = 0;
	}

	public void onOpenChanged(Consumer<Boolean> openChanged) {
		this.openChanged = openChanged;
	}

	@Override
	public void read(class_2487 compound, boolean clientPacket) {
		super.read(compound, clientPacket);
		if (clientPacket)
			openCount = compound.method_10550("OpenCount");
	}

	@Override
	public void write(class_2487 compound, boolean clientPacket) {
		super.write(compound, clientPacket);
		if (clientPacket)
			compound.method_10569("OpenCount", openCount);
	}

	@Override
	public void lazyTick() {
		updateOpenCount();
		super.lazyTick();
	}

	void updateOpenCount() {
		class_1937 level = getWorld();
		if (level.field_9236)
			return;
		if (openCount == 0)
			return;

		int prevOpenCount = openCount;
		openCount = 0;

		for (class_1657 playerentity : level.method_18467(class_1657.class, new class_238(getPos()).method_1014(8)))
			if (menuClass.isInstance(playerentity.field_7512)
				&& menuClass.cast(playerentity.field_7512).contentHolder == blockEntity)
				openCount++;

		if (prevOpenCount != openCount) {
			if (openChanged != null && prevOpenCount == 0 && openCount > 0)
				openChanged.accept(true);
			if (openChanged != null && prevOpenCount > 0 && openCount == 0)
				openChanged.accept(false);
			blockEntity.sendData();
		}
	}

	public void startOpen(class_1657 player) {
		if (player.method_7325())
			return;
		if (getWorld().field_9236)
			return;
		if (openCount < 0)
			openCount = 0;
		openCount++;
		if (openCount == 1 && openChanged != null)
			openChanged.accept(true);
		blockEntity.sendData();
	}

	public void stopOpen(class_1657 player) {
		if (player.method_7325())
			return;
		if (getWorld().field_9236)
			return;
		openCount--;
		if (openCount == 0 && openChanged != null)
			openChanged.accept(false);
		blockEntity.sendData();
	}

	@Override
	public BehaviourType<?> getType() {
		return TYPE;
	}

}
