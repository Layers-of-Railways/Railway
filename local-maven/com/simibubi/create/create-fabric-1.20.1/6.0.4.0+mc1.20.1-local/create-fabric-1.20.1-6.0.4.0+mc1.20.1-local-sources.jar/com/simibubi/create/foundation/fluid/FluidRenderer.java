package com.simibubi.create.foundation.fluid;

import dev.engine_room.flywheel.lib.transform.TransformStack;
import net.createmod.catnip.math.AngleHelper;
import net.createmod.catnip.render.FluidRenderHelper;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.transfer.v1.client.fluid.FluidVariantRendering;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariant;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariantAttributes;
import net.minecraft.class_1058;
import net.minecraft.class_2350;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import io.github.fabricators_of_create.porting_lib.fluids.FluidStack;

@Environment(EnvType.CLIENT)
public class FluidRenderer {
	public static void renderFluidStream(FluidStack fluidStack, class_2350 direction, float radius, float progress,
		boolean inbound, class_4597 buffer, class_4587 ms, int light) {
		renderFluidStream(fluidStack, direction, radius, progress, inbound, FluidRenderHelper.getFluidBuilder(buffer), ms, light);
	}

	public static void renderFluidStream(FluidStack fluidStack, class_2350 direction, float radius, float progress,
		boolean inbound, class_4588 builder, class_4587 ms, int light) {
		FluidVariant fluidVariant = fluidStack.getType();
		class_1058[] sprites = FluidVariantRendering.getSprites(fluidVariant);
		if (sprites == null) {
			return;
		}
		class_1058 flowTexture = sprites[1];
		class_1058 stillTexture = sprites[0];

		int color = FluidVariantRendering.getColor(fluidVariant);
		int blockLightIn = (light >> 4) & 0xF;
		int luminosity = Math.max(blockLightIn, FluidVariantAttributes.getLuminance(fluidVariant));
		light = (light & 0xF00000) | luminosity << 4;

		if (inbound)
			direction = direction.method_10153();

		var msr = TransformStack.of(ms);
		ms.method_22903();
		msr.center()
			.rotateYDegrees(AngleHelper.horizontalAngle(direction))
			.rotateXDegrees(direction == class_2350.field_11036 ? 180 : direction == class_2350.field_11033 ? 0 : 270)
			.uncenter();
		ms.method_22904(.5, 0, .5);

		float h = radius;
		float hMin = -radius;
		float hMax = radius;
		float y = inbound ? 1 : .5f;
		float yMin = y - class_3532.method_15363(progress * .5f, 0, 1);
		float yMax = y;

		for (int i = 0; i < 4; i++) {
			ms.method_22903();
			renderFlowingTiledFace(class_2350.field_11035, hMin, yMin, hMax, yMax, h, builder, ms, light, color, flowTexture);
			ms.method_22909();
			msr.rotateYDegrees(90);
		}

		if (progress != 1)
			FluidRenderHelper.renderStillTiledFace(class_2350.field_11033, hMin, hMin, hMax, hMax, yMin, builder, ms, light, color, stillTexture);

		ms.method_22909();
	}

	public static void renderFlowingTiledFace(class_2350 dir, float left, float down, float right, float up,
		float depth, class_4588 builder, class_4587 ms, int light, int color, class_1058 texture) {
		FluidRenderHelper.renderTiledFace(dir, left, down, right, up, depth, builder, ms, light, color, texture, 0.5f);
	}

}
