package com.simibubi.create.foundation.data.recipe;

import java.util.ArrayList;
import java.util.List;

import org.jetbrains.annotations.Nullable;

import com.simibubi.create.content.kinetics.deployer.ManualApplicationRecipe;
import com.simibubi.create.content.processing.recipe.ProcessingRecipeBuilder;
import com.simibubi.create.foundation.utility.CreateLang;
import com.simibubi.create.infrastructure.config.AllConfigs;

import net.createmod.catnip.platform.CatnipServices;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1799.class_5422;
import net.minecraft.class_1802;
import net.minecraft.class_1856;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3489;
import net.minecraft.class_7923;
import io.github.fabricators_of_create.porting_lib.mixin.accessors.common.accessor.AxeItemAccessor;

/**
 * Just in case players don't know about that vanilla feature
 */
public class LogStrippingFakeRecipes {

	public static List<ManualApplicationRecipe> createRecipes() {
		List<ManualApplicationRecipe> recipes = new ArrayList<>();
		if (!AllConfigs.server().recipes.displayLogStrippingRecipes.get())
			return recipes;

		class_1799 axe = new class_1799(class_1802.field_8475);
		axe.method_30268(class_5422.field_25769);
		axe.method_7977(CreateLang.translateDirect("recipe.item_application.any_axe")
			.method_27694(style -> style.method_10978(false)));
		// fabric: tag may not exist yet with JEI, #773
		class_7923.field_41178.method_40286(class_3489.field_15539)
			.forEach(stack -> process(stack.comp_349(), recipes, axe));
		return recipes;
	}

	private static void process(class_1792 item, List<ManualApplicationRecipe> list, class_1799 axe) {
		if (!(item instanceof class_1747 blockItem))
			return;
		class_2680 state = blockItem.method_7711()
			.method_9564();
		class_2680 strippedState = getStrippedState(state);
		if (strippedState == null)
			return;
		class_1792 resultItem = strippedState.method_26204()
			.method_8389();
		if (resultItem == null)
			return;
		list.add(create(item, resultItem, axe));
	}

	private static ManualApplicationRecipe create(class_1792 fromItem, class_1792 toItem, class_1799 axe) {
		class_2960 rn = CatnipServices.REGISTRIES.getKeyOrThrow(toItem);
		return new ProcessingRecipeBuilder<>(ManualApplicationRecipe::new,
			new class_2960(rn.method_12836(), rn.method_12832() + "_via_vanilla_stripping")).require(fromItem)
				.require(class_1856.method_8101(axe))
				.output(toItem)
				.build();
	}

	@Nullable
	public static class_2680 getStrippedState(class_2680 state) {
		if (class_1802.field_8475 instanceof AxeItemAccessor axe) {
			return axe.porting_lib$getStripped(state).orElse(null);
		}
		return null;
	}
}
