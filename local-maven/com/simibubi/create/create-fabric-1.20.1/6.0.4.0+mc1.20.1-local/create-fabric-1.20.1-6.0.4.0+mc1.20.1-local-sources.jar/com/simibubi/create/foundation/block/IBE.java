package com.simibubi.create.foundation.block;

import java.util.Optional;
import java.util.function.Consumer;
import java.util.function.Function;

import javax.annotation.Nullable;
import net.minecraft.class_1269;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_5558;
import com.simibubi.create.foundation.blockEntity.SmartBlockEntity;
import com.simibubi.create.foundation.blockEntity.SmartBlockEntityTicker;

public interface IBE<T extends class_2586> extends class_2343 {

	Class<T> getBlockEntityClass();

	class_2591<? extends T> getBlockEntityType();

	default void withBlockEntityDo(class_1922 world, class_2338 pos, Consumer<T> action) {
		getBlockEntityOptional(world, pos).ifPresent(action);
	}

	default class_1269 onBlockEntityUse(class_1922 world, class_2338 pos, Function<T, class_1269> action) {
		return getBlockEntityOptional(world, pos).map(action)
			.orElse(class_1269.field_5811);
	}

	/**
	 * if the IBE is bound to a SmartBlockEntity, which implements destroy(),<br>
	 * call this method in BlockBehaviour::onRemove (replace super call)
	 */
	static void onRemove(class_2680 blockState, class_1937 level, class_2338 pos, class_2680 newBlockState) {
		if (!blockState.method_31709())
			return;
		if (blockState.method_27852(newBlockState.method_26204()) && newBlockState.method_31709())
			return;
		class_2586 blockEntity = level.method_8321(pos);
		if (blockEntity instanceof SmartBlockEntity sbe)
			sbe.destroy();
		level.method_8544(pos);
	}

	default Optional<T> getBlockEntityOptional(class_1922 world, class_2338 pos) {
		return Optional.ofNullable(getBlockEntity(world, pos));
	}

	@Override
	default class_2586 method_10123(class_2338 p_153215_, class_2680 p_153216_) {
		return getBlockEntityType().method_11032(p_153215_, p_153216_);
	}

	@Override
	default <S extends class_2586> class_5558<S> method_31645(class_1937 p_153212_, class_2680 p_153213_,
		class_2591<S> p_153214_) {
		if (SmartBlockEntity.class.isAssignableFrom(getBlockEntityClass()))
			return new SmartBlockEntityTicker<>();
		return null;
	}

	@Nullable
	@SuppressWarnings("unchecked")
	default T getBlockEntity(class_1922 worldIn, class_2338 pos) {
		class_2586 blockEntity = worldIn.method_8321(pos);
		Class<T> expectedClass = getBlockEntityClass();

		if (blockEntity == null)
			return null;
		if (!expectedClass.isInstance(blockEntity))
			return null;

		return (T) blockEntity;
	}

}
