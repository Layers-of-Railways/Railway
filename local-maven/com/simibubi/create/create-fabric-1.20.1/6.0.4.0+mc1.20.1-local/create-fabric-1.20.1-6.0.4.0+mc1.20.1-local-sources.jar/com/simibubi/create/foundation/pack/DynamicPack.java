package com.simibubi.create.foundation.pack;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import net.minecraft.class_155;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3262;
import net.minecraft.class_3264;
import net.minecraft.class_3270;
import net.minecraft.class_3272;
import net.minecraft.class_7367;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import com.google.gson.JsonElement;
import com.simibubi.create.Create;

// TODO - Move into catnip
public class DynamicPack implements class_3262 {
	private final Map<String, class_7367<InputStream>> files = new HashMap<>();

	private final String packId;
	private final class_3264 packType;
	private final class_3272 metadata;

	public DynamicPack(String packId, class_3264 packType) {
		this.packId = packId;
		this.packType = packType;

		metadata = new class_3272(class_2561.method_43473(), class_155.method_16673().method_48017(packType));
	}

	private static String getPath(class_3264 packType, class_2960 resourceLocation) {
		return packType.method_14413() + "/" + resourceLocation.method_12836() + "/" + resourceLocation.method_12832();
	}

	public DynamicPack put(class_2960 location, class_7367<InputStream> stream) {
		files.put(getPath(packType, location), stream);
		return this;
	}

	public DynamicPack put(class_2960 location, byte[] bytes) {
		return put(location, () -> new ByteArrayInputStream(bytes));
	}

	public DynamicPack put(class_2960 location, String string) {
		return put(location, string.getBytes(StandardCharsets.UTF_8));
	}

	// Automatically suffixes the ResourceLocation with .json
	public DynamicPack put(class_2960 location, JsonElement json) {
		return put(location.method_48331(".json"), Create.GSON.toJson(json));
	}

	@Override
	public @Nullable class_7367<InputStream> method_14410(String @NotNull ... elements) {
		return files.getOrDefault(String.join("/", elements), null);
	}

	@Override
	public @Nullable class_7367<InputStream> method_14405(@NotNull class_3264 packType, @NotNull class_2960 resourceLocation) {
		return files.getOrDefault(getPath(packType, resourceLocation), null);
	}

	@Override
	public void method_14408(@NotNull class_3264 packType, @NotNull String namespace, @NotNull String path, @NotNull class_7664 resourceOutput) {
		class_2960 resourceLocation = new class_2960(namespace, path);
		String directoryAndNamespace = packType.method_14413() + "/" + namespace + "/";
		String prefix = directoryAndNamespace + path + "/";
		files.forEach((filePath, streamSupplier) -> {
			if (filePath.startsWith(prefix))
				resourceOutput.accept(resourceLocation.method_45136(filePath.substring(directoryAndNamespace.length())), streamSupplier);
		});
	}

	@Override
	public @NotNull Set<String> method_14406(class_3264 packType) {
		Set<String> namespaces = new HashSet<>();
		String dir = packType.method_14413() + "/";

		for (String path : files.keySet()) {
			if (path.startsWith(dir)) {
				String relative = path.substring(dir.length());
				if (relative.contains("/")) {
					namespaces.add(relative.substring(0, relative.indexOf("/")));
				}
			}
		}

		return namespaces;
	}

	@SuppressWarnings("unchecked")
	@Override
	public @Nullable <T> T method_14407(@NotNull class_3270<T> deserializer) throws IOException {
		return deserializer == class_3272.field_14202 ? (T) metadata : null;
	}

	@Override
	public @NotNull String method_14409() {
		return packId;
	}

	@Override
	public void close() {
	} // NO-OP
}
