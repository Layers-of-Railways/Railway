package com.simibubi.create.foundation.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.sugar.Local;
import com.simibubi.create.content.kinetics.deployer.DeployerFakePlayer;
import net.minecraft.class_1657;
import net.minecraft.class_4481;

@Mixin(class_4481.class)
public class BeehiveBlockMixin {
	@ModifyExpressionValue(method = "use", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/block/CampfireBlock;isSmokeyPos(Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;)Z"))
	private static boolean create$dontGetAngryAtDeployers(boolean original, @Local(argsOnly = true) class_1657 player) {
		return original || player instanceof DeployerFakePlayer;
	}
}
