package com.simibubi.create.foundation.recipe;

import net.minecraft.class_1865;
import net.minecraft.class_2960;
import net.minecraft.class_3956;

public interface IRecipeTypeInfo {

	class_2960 getId();

	<T extends class_1865<?>> T getSerializer();

	<T extends class_3956<?>> T getType();

}
