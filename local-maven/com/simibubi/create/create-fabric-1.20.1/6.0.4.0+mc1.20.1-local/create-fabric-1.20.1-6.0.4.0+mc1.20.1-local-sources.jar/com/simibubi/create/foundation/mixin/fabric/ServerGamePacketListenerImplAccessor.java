package com.simibubi.create.foundation.mixin.fabric;

import net.minecraft.class_3244;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_3244.class)
public interface ServerGamePacketListenerImplAccessor {
	@Accessor("aboveGroundTickCount")
	void create$setAboveGroundTickCount(int ticks);

	@Accessor("aboveGroundVehicleTickCount")
	void create$setAboveGroundVehicleTickCount(int ticks);
}
