package com.simibubi.create;

import com.simibubi.create.api.behaviour.movement.MovementBehaviour;
import com.simibubi.create.content.contraptions.behaviour.BellMovementBehaviour;
import com.simibubi.create.content.contraptions.behaviour.CampfireMovementBehaviour;
import com.simibubi.create.content.contraptions.behaviour.dispenser.DispenserMovementBehaviour;
import com.simibubi.create.content.contraptions.behaviour.dispenser.DropperMovementBehaviour;
import net.minecraft.class_2246;

public class AllMovementBehaviours {
	static void registerDefaults() {
		MovementBehaviour.REGISTRY.register(class_2246.field_16332, new BellMovementBehaviour());
		MovementBehaviour.REGISTRY.register(class_2246.field_17350, new CampfireMovementBehaviour());
		MovementBehaviour.REGISTRY.register(class_2246.field_23860, new CampfireMovementBehaviour());
		MovementBehaviour.REGISTRY.register(class_2246.field_10200, new DispenserMovementBehaviour());
		MovementBehaviour.REGISTRY.register(class_2246.field_10228, new DropperMovementBehaviour());
	}
}
