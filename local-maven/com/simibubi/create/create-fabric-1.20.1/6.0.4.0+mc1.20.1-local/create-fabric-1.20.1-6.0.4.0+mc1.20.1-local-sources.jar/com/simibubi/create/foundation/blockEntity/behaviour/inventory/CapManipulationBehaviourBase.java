package com.simibubi.create.foundation.blockEntity.behaviour.inventory;

import javax.annotation.Nullable;

import com.simibubi.create.foundation.blockEntity.SmartBlockEntity;
import com.simibubi.create.foundation.blockEntity.behaviour.BlockEntityBehaviour;
import com.simibubi.create.foundation.blockEntity.behaviour.filtering.FilteringBehaviour;
import com.simibubi.create.foundation.item.ItemHelper.ExtractionCountMode;

import net.createmod.catnip.math.BlockFace;
import net.fabricmc.fabric.api.lookup.v1.block.BlockApiLookup;
import net.fabricmc.fabric.api.transfer.v1.storage.Storage;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import io.github.fabricators_of_create.porting_lib.util.StorageProvider;

public abstract class CapManipulationBehaviourBase<T, S extends CapManipulationBehaviourBase<?, ?>>
	extends BlockEntityBehaviour {

	// fabric: move to StorageProvider, big changes

	protected InterfaceProvider target;
	protected StorageProvider<T> targetStorageProvider;
	protected Filter<T> filter;
	protected boolean simulateNext;
	protected boolean bypassSided;
	protected class_2350 side;
	private boolean findNewNextTick;

	public CapManipulationBehaviourBase(SmartBlockEntity be, InterfaceProvider target) {
		super(be);
		setLazyTickRate(5);
		this.target = target;
		targetStorageProvider = null;
		simulateNext = false;
		bypassSided = false;
		filter = (storage, provider) -> true;
	}

	protected abstract StorageProvider<T> getProvider(class_2338 pos, boolean bypassSided);

	@Override
	public void initialize() {
		super.initialize();
		findNewNextTick = true;
	}

	@Override
	public void onNeighborChanged(class_2338 neighborPos) {
		if (this.getTarget().getConnectedPos().equals(neighborPos))
			onHandlerInvalidated();
	}

	@SuppressWarnings("unchecked")
	public S bypassSidedness() {
		bypassSided = true;
		return (S) this;
	}

	/**
	 * Only simulate the upcoming operation
	 */
	@SuppressWarnings("unchecked")
	public S simulate() {
		simulateNext = true;
		return (S) this;
	}

	@SuppressWarnings("unchecked")
	public S withFilter(Filter<T> filter) {
		this.filter = filter;
		return (S) this;
	}

	public boolean hasInventory() {
		return getInventory() != null;
	}

	@Nullable
	public Storage<T> getInventory() {
		if (targetStorageProvider == null || side == null)
			return null;
		Storage<T> storage = targetStorageProvider.get(side);
		return this.filter.test(storage, this.targetStorageProvider) ? storage : null;
	}

	/**
	 * Get the target of this is behavior, which is the face of the owner BlockEntity that acts as the interface.
	 * To get the BlockFace to use for capability lookup, call getOpposite on the result.
	 */
	public BlockFace getTarget() {
		return this.target.getTarget(this.getWorld(), this.blockEntity.method_11016(), this.blockEntity.method_11010());
	}

	protected void onHandlerInvalidated() {
		findNewNextTick = true;
		this.setProvider(null, null);
	}

	@Override
	public void lazyTick() {
		super.lazyTick();
		if (targetStorageProvider == null)
			findNewCapability();
	}

	@Override
	public void tick() {
		super.tick();
		if (findNewNextTick || getWorld().method_8510() % 64 == 0) {
			findNewNextTick = false;
			findNewCapability();
		}
	}

	public int getAmountFromFilter() {
		int amount = -1;
		FilteringBehaviour filter = blockEntity.getBehaviour(FilteringBehaviour.TYPE);
		if (filter != null && !filter.anyAmount())
			amount = filter.getAmount();
		return amount;
	}

	public ExtractionCountMode getModeFromFilter() {
		ExtractionCountMode mode = ExtractionCountMode.UPTO;
		FilteringBehaviour filter = blockEntity.getBehaviour(FilteringBehaviour.TYPE);
		if (filter != null && !filter.upTo)
			mode = ExtractionCountMode.EXACTLY;
		return mode;
	}

	public void findNewCapability() {
		class_1937 world = getWorld();
		BlockFace targetBlockFace = this.getTarget().getOpposite();
		class_2338 pos = targetBlockFace.getPos();
		this.setProvider(null, null);
		if (!world.method_8477(pos))
			return;
		StorageProvider<T> provider = this.getProvider(pos, this.bypassSided);
		class_2350 side = targetBlockFace.getFace();
		this.setProvider(provider, side);
	}

	private void setProvider(StorageProvider<T> provider, class_2350 side) {
		this.targetStorageProvider = provider;
		this.side = side;
	}

	@FunctionalInterface
	public interface InterfaceProvider {

		public static InterfaceProvider towardBlockFacing() {
			return (w, p, s) -> new BlockFace(p,
				s.method_28498(class_2741.field_12525) ? s.method_11654(class_2741.field_12525)
					: s.method_11654(class_2741.field_12481));
		}

		public static InterfaceProvider oppositeOfBlockFacing() {
			return (w, p, s) -> new BlockFace(p,
				(s.method_28498(class_2741.field_12525) ? s.method_11654(class_2741.field_12525)
					: s.method_11654(class_2741.field_12481)).method_10153());
		}

		public BlockFace getTarget(class_1937 world, class_2338 pos, class_2680 blockState);
	}

	@FunctionalInterface
	public interface Filter<T> {
		boolean test(Storage<T> storage, StorageProvider<T> provider);
	}

	public abstract static class UnsidedStorageProvider<T> extends StorageProvider<T> {
		protected UnsidedStorageProvider(BlockApiLookup<Storage<T>, class_2350> lookup, class_1937 level, class_2338 pos) {
			super(lookup, level, pos);
		}

		@Override
		@Nullable
		public Storage<T> get(class_2350 direction) {
			return get();
		}

		@Nullable
		public abstract Storage<T> get();
	}

}
