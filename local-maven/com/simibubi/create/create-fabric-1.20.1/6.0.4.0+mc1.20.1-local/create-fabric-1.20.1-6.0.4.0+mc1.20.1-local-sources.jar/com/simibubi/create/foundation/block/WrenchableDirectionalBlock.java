package com.simibubi.create.foundation.block;

import com.simibubi.create.content.equipment.wrench.IWrenchable;
import net.minecraft.class_1750;
import net.minecraft.class_2248;
import net.minecraft.class_2318;
import net.minecraft.class_2350;
import net.minecraft.class_2415;
import net.minecraft.class_2470;
import net.minecraft.class_2680;
import net.minecraft.class_2689.class_2690;

public class WrenchableDirectionalBlock extends class_2318 implements IWrenchable {

	public WrenchableDirectionalBlock(class_2251 properties) {
		super(properties);
	}

	@Override
	protected void method_9515(class_2690<class_2248, class_2680> builder) {
		builder.method_11667(field_10927);
		super.method_9515(builder);
	}

	@Override
	public class_2680 getRotatedBlockState(class_2680 originalState, class_2350 targetedFace) {
		class_2350 facing = originalState.method_11654(field_10927);

		if (facing.method_10166() == targetedFace.method_10166())
			return originalState;

		class_2350 newFacing = facing.method_35833(targetedFace.method_10166());

		return originalState.method_11657(field_10927, newFacing);
	}

	@Override
	public class_2680 method_9605(class_1750 context) {
		return method_9564().method_11657(field_10927, context.method_7715());
	}

	@Override
	public class_2680 method_9598(class_2680 state, class_2470 rot) {
		return state.method_11657(field_10927, rot.method_10503(state.method_11654(field_10927)));
	}

	@Override
	@SuppressWarnings("deprecation")
	public class_2680 method_9569(class_2680 state, class_2415 mirrorIn) {
		return state.method_26186(mirrorIn.method_10345(state.method_11654(field_10927)));
	}

}
