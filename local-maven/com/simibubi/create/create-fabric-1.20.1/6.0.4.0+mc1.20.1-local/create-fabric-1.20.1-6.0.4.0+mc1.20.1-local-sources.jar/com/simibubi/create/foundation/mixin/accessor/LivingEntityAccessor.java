package com.simibubi.create.foundation.mixin.accessor;

import net.minecraft.class_1309;
import net.minecraft.class_1799;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_1309.class)
public interface LivingEntityAccessor {
	@Invoker("spawnItemParticles")
	void create$callSpawnItemParticles(class_1799 stack, int count);
}
