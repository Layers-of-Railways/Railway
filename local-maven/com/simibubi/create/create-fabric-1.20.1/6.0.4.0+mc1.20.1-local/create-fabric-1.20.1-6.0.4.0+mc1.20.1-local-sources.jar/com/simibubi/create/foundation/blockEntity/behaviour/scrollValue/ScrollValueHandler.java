package com.simibubi.create.foundation.blockEntity.behaviour.scrollValue;


import net.createmod.catnip.animation.PhysicalFloat;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_310;
import net.minecraft.class_3532;

public class ScrollValueHandler {

	private static float lastPassiveScroll = 0.0f;
	private static float passiveScroll = 0.0f;
	private static float passiveScrollDirection = 1f;
	public static final PhysicalFloat wrenchCog = PhysicalFloat.create()
		.withDrag(0.3);

	public static float getScroll(float partialTicks) {
		return wrenchCog.getValue(partialTicks) + class_3532.method_16439(partialTicks, lastPassiveScroll, passiveScroll);
	}

	@Environment(EnvType.CLIENT)
	public static void tick() {
		if (!class_310.method_1551()
			.method_1493()) {
			lastPassiveScroll = passiveScroll;
			wrenchCog.tick();
			passiveScroll += passiveScrollDirection * 0.5;
		}
	}

}
