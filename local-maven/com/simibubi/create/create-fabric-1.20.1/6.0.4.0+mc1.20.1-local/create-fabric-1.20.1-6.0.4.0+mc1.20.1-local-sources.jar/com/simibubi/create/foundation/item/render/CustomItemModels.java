package com.simibubi.create.foundation.item.render;

import java.util.IdentityHashMap;
import java.util.Map;
import net.minecraft.class_1087;
import net.minecraft.class_1792;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import com.google.common.collect.Multimap;
import com.google.common.collect.MultimapBuilder;
import com.tterrag.registrate.util.nullness.NonNullBiConsumer;
import com.tterrag.registrate.util.nullness.NonNullFunction;

public class CustomItemModels {

	private final Multimap<class_2960, NonNullFunction<class_1087, ? extends class_1087>> modelFuncs = MultimapBuilder.hashKeys().arrayListValues().build();
	private final Map<class_1792, NonNullFunction<class_1087, ? extends class_1087>> finalModelFuncs = new IdentityHashMap<>();
	private boolean funcsLoaded = false;

	public void register(class_2960 item, NonNullFunction<class_1087, ? extends class_1087> func) {
		modelFuncs.put(item, func);
	}

	public void forEach(NonNullBiConsumer<class_1792, NonNullFunction<class_1087, ? extends class_1087>> consumer) {
		loadEntriesIfMissing();
		finalModelFuncs.forEach(consumer);
	}

	private void loadEntriesIfMissing() {
		if (!funcsLoaded) {
			loadEntries();
			funcsLoaded = true;
		}
	}

	private void loadEntries() {
		finalModelFuncs.clear();
		modelFuncs.asMap().forEach((location, funcList) -> {
			class_1792 item = class_7923.field_41178.method_10223(location);

			NonNullFunction<class_1087, ? extends class_1087> finalFunc = null;
			for (NonNullFunction<class_1087, ? extends class_1087> func : funcList) {
				if (finalFunc == null) {
					finalFunc = func;
				} else {
					finalFunc = finalFunc.andThen(func);
				}
			}

			finalModelFuncs.put(item, finalFunc);
		});
	}

}
