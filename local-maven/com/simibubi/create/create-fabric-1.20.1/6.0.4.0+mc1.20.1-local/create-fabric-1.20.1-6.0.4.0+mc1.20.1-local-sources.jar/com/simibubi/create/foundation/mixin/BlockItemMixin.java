package com.simibubi.create.foundation.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import com.simibubi.create.content.kinetics.deployer.DeployerFakePlayer;
import com.simibubi.create.foundation.mixin.accessor.UseOnContextAccessor;
import net.minecraft.class_1269;
import net.minecraft.class_1747;
import net.minecraft.class_1750;
import net.minecraft.class_2680;

@Mixin(class_1747.class)
public class BlockItemMixin {
	@Inject(method = "place", at = @At("HEAD"), cancellable = true)
	private void create$fixDeployerPlacement(class_1750 pContext, CallbackInfoReturnable<class_1269> cir) {
		class_2680 state = pContext.method_8045().method_8320(((UseOnContextAccessor) pContext).create$getHitResult().method_17777());
		if (!state.method_45474() && pContext.method_8036() instanceof DeployerFakePlayer) {
			cir.setReturnValue(class_1269.field_5811);
		}
	}
}
