package com.simibubi.create.foundation.data;

import static com.simibubi.create.foundation.data.TagGen.pickaxeOnly;

import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.Map;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;

import org.jetbrains.annotations.Nullable;

import com.simibubi.create.CreateClient;
import com.simibubi.create.api.behaviour.display.DisplaySource;
import com.simibubi.create.api.behaviour.display.DisplayTarget;
import com.simibubi.create.api.contraption.storage.fluid.MountedFluidStorageType;
import com.simibubi.create.api.contraption.storage.item.MountedItemStorageType;
import com.simibubi.create.api.registry.CreateRegistries;
import com.simibubi.create.api.registry.registrate.SimpleBuilder;
import com.simibubi.create.content.decoration.encasing.CasingConnectivity;
import com.simibubi.create.content.fluids.VirtualFluid;
import com.simibubi.create.foundation.block.connected.CTModel;
import com.simibubi.create.foundation.block.connected.ConnectedTextureBehaviour;
import com.simibubi.create.foundation.item.TooltipModifier;
import com.simibubi.create.foundation.item.render.CustomRenderedItemModelRenderer;
import com.simibubi.create.foundation.item.render.CustomRenderedItems;
import com.simibubi.create.impl.registrate.CreateRegistrateRegistrationCallbackImpl;
import com.simibubi.create.impl.registrate.CreateRegistrateRegistrationCallbackImpl.CallbackImpl;
import com.tterrag.registrate.AbstractRegistrate;
import com.tterrag.registrate.builders.BlockBuilder;
import com.tterrag.registrate.builders.BlockEntityBuilder.BlockEntityFactory;
import com.tterrag.registrate.builders.Builder;
import com.tterrag.registrate.builders.FluidBuilder;
import com.tterrag.registrate.builders.ItemBuilder;
import com.tterrag.registrate.fabric.EnvExecutor;
import com.tterrag.registrate.fabric.RegistryObject;
import com.tterrag.registrate.fabric.SimpleFlowableFluid;
import com.tterrag.registrate.util.entry.RegistryEntry;
import com.tterrag.registrate.util.nullness.NonNullConsumer;
import com.tterrag.registrate.util.nullness.NonNullFunction;
import com.tterrag.registrate.util.nullness.NonNullSupplier;
import com.tterrag.registrate.util.nullness.NonNullUnaryOperator;

import net.createmod.catnip.platform.CatnipServices;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.rendering.v1.BuiltinItemRendererRegistry;
import net.minecraft.class_1087;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2586;
import net.minecraft.class_2960;
import net.minecraft.class_3481;
import net.minecraft.class_4970.class_2251;
import net.minecraft.class_5321;
import net.minecraft.class_7924;

public class CreateRegistrate extends AbstractRegistrate<CreateRegistrate> {
	private static final Map<RegistryEntry<?>, class_5321<class_1761>> TAB_LOOKUP = Collections.synchronizedMap(new IdentityHashMap<>());

	@Nullable
	protected Function<class_1792, TooltipModifier> currentTooltipModifierFactory;
	@Nullable
	protected class_5321<class_1761> currentTab;

	protected CreateRegistrate(String modid) {
		super(modid);
	}

	public static CreateRegistrate create(String modid) {
		return new CreateRegistrate(modid);
	}

	public static boolean isInCreativeTab(RegistryEntry<?> entry, class_5321<class_1761> tab) {
		return TAB_LOOKUP.get(entry) == tab;
	}

	public CreateRegistrate setTooltipModifierFactory(@Nullable Function<class_1792, TooltipModifier> factory) {
		currentTooltipModifierFactory = factory;
		return self();
	}

	@Nullable
	public Function<class_1792, TooltipModifier> getTooltipModifierFactory() {
		return currentTooltipModifierFactory;
	}

	public CreateRegistrate setCreativeTab(class_5321<class_1761> tab) {
		this.currentTab = tab;
		return this;
	}

	@Override
	protected <R, T extends R> RegistryEntry<T> accept(String name, class_5321<? extends class_2378<R>> type,
													   Builder<R, T, ?, ?> builder, NonNullSupplier<? extends T> creator,
													   NonNullFunction<RegistryObject<T>, ? extends RegistryEntry<T>> entryFactory) {
		RegistryEntry<T> entry = super.accept(name, type, builder, creator, entryFactory);
		if (type.equals(class_7924.field_41197) && currentTooltipModifierFactory != null) {
			// grab the factory here for the lambda, it can change between now and registration
			Function<class_1792, TooltipModifier> factory = currentTooltipModifierFactory;
			this.addRegisterCallback(name, class_7924.field_41197, item -> {
				TooltipModifier modifier = factory.apply(item);
				TooltipModifier.REGISTRY.register(item, modifier);
			});
		}
		if (currentTab != null)
			TAB_LOOKUP.put(entry, currentTab);

		for (CallbackImpl<?> callback : CreateRegistrateRegistrationCallbackImpl.CALLBACKS_VIEW) {
			String modId = callback.id().method_12836();
			String entryId = callback.id().method_12832();
			if (callback.registry().equals(type) && getModid().equals(modId) && name.equals(entryId)) {
				//noinspection unchecked
				((Consumer<T>) callback.callback()).accept(entry.get());
			}
		}

		return entry;
	}

	@Override
	public <T extends class_2586> CreateBlockEntityBuilder<T, CreateRegistrate> blockEntity(String name,
																							 BlockEntityFactory<T> factory) {
		return blockEntity(self(), name, factory);
	}

	@Override
	public <T extends class_2586, P> CreateBlockEntityBuilder<T, P> blockEntity(P parent, String name,
																				 BlockEntityFactory<T> factory) {
		return (CreateBlockEntityBuilder<T, P>) entry(name,
			(callback) -> CreateBlockEntityBuilder.create(this, parent, name, callback, factory));
	}

	@Override
	public <T extends class_1297> CreateEntityBuilder<T, CreateRegistrate> entity(String name,
																			  class_1299.class_4049<T> factory, class_1311 classification) {
		return this.entity(self(), name, factory, classification);
	}

	@Override
	public <T extends class_1297, P> CreateEntityBuilder<T,  P> entity(P parent, String name,
																  class_1299.class_4049<T> factory, class_1311 classification) {
		return (CreateEntityBuilder<T, P>) this.entry(name, (callback) -> {
			return CreateEntityBuilder.create(this, parent, name, callback, factory, classification);
		});
	}

	// custom types

	public <T extends MountedItemStorageType<?>> SimpleBuilder<MountedItemStorageType<?>, T, CreateRegistrate> mountedItemStorage(String name, Supplier<T> supplier) {
		return this.entry(name, callback -> new SimpleBuilder<>(
			this, this, name, callback, CreateRegistries.MOUNTED_ITEM_STORAGE_TYPE, supplier
		).byBlock(MountedItemStorageType.REGISTRY));
	}

	public <T extends MountedFluidStorageType<?>> SimpleBuilder<MountedFluidStorageType<?>, T, CreateRegistrate> mountedFluidStorage(String name, Supplier<T> supplier) {
		return this.entry(name, callback -> new SimpleBuilder<>(
			this, this, name, callback, CreateRegistries.MOUNTED_FLUID_STORAGE_TYPE, supplier
		).byBlock(MountedFluidStorageType.REGISTRY));
	}

	public <T extends DisplaySource> SimpleBuilder<DisplaySource, T, CreateRegistrate> displaySource(String name, Supplier<T> supplier) {
		return this.entry(name, callback -> new SimpleBuilder<>(
			this, this, name, callback, CreateRegistries.DISPLAY_SOURCE, supplier
		).byBlock(DisplaySource.BY_BLOCK).byBlockEntity(DisplaySource.BY_BLOCK_ENTITY));
	}

	public <T extends DisplayTarget> SimpleBuilder<DisplayTarget, T, CreateRegistrate> displayTarget(String name, Supplier<T> supplier) {
		return this.entry(name, callback -> new SimpleBuilder<>(
			this, this, name, callback, CreateRegistries.DISPLAY_TARGET, supplier
		).byBlock(DisplayTarget.BY_BLOCK).byBlockEntity(DisplayTarget.BY_BLOCK_ENTITY));
	}

	/* Palettes */

	public <T extends class_2248> BlockBuilder<T, CreateRegistrate> paletteStoneBlock(String name,
																				 NonNullFunction<class_2251, T> factory, NonNullSupplier<class_2248> propertiesFrom, boolean worldGenStone,
																				 boolean hasNaturalVariants) {
		BlockBuilder<T, CreateRegistrate> builder = super.block(name, factory).initialProperties(propertiesFrom)
			.transform(pickaxeOnly())
			.blockstate(hasNaturalVariants ? BlockStateGen.naturalStoneTypeBlock(name) : (c, p) -> {
				final String location = "block/palettes/stone_types/" + c.getName();
				p.simpleBlock(c.get(), p.models()
					.cubeAll(c.getName(), p.modLoc(location)));
			})
			.tag(class_3481.field_28089)
			.tag(class_3481.field_36268)
			.tag(class_3481.field_28622)
			.tag(class_3481.field_29196)
			.item()
			.model((c, p) -> p.cubeAll(c.getName(),
				p.modLoc(hasNaturalVariants ? "block/palettes/stone_types/natural/" + name + "_1"
					: "block/palettes/stone_types/" + c.getName())))
			.build();
		return builder;
	}

	public BlockBuilder<class_2248, CreateRegistrate> paletteStoneBlock(String name, NonNullSupplier<class_2248> propertiesFrom,
																   boolean worldGenStone, boolean hasNaturalVariants) {
		return paletteStoneBlock(name, class_2248::new, propertiesFrom, worldGenStone, hasNaturalVariants);
	}

	/* Fluids */

	public <T extends SimpleFlowableFluid> FluidBuilder<T, CreateRegistrate> virtualFluid(String name,
//		BiFunction<FluidAttributes.Builder, Fluid, FluidAttributes> attributesFactory,
		NonNullFunction<SimpleFlowableFluid.Properties, T> sourceFactory,
																						NonNullFunction<SimpleFlowableFluid.Properties, T> flowingFactory) {
		return entry(name,
			c -> new VirtualFluidBuilder<>(self(), self(), name, c, new class_2960(getModid(), "fluid/" + name + "_still"),
				new class_2960(getModid(), "fluid/" + name + "_flow"), sourceFactory, flowingFactory));
	}

	public <T extends SimpleFlowableFluid> FluidBuilder<T, CreateRegistrate> virtualFluid(String name,
																						class_2960 still, class_2960 flow,
																						NonNullFunction<SimpleFlowableFluid.Properties, T> sourceFactory, NonNullFunction<SimpleFlowableFluid.Properties, T> flowingFactory) {
		return entry(name, c -> new VirtualFluidBuilder<>(self(), self(), name, c, still, flow, sourceFactory, flowingFactory));
	}

	public FluidBuilder<VirtualFluid, CreateRegistrate> virtualFluid(String name) {
		return entry(name,
			c -> new VirtualFluidBuilder<>(self(), self(), name, c, new class_2960(getModid(), "fluid/" + name + "_still"),
				new class_2960(getModid(), "fluid/" + name + "_flow"), /*null, */VirtualFluid::createSource, VirtualFluid::createFlowing));
	}

	public FluidBuilder<VirtualFluid, CreateRegistrate> virtualFluid(String name, class_2960 still, class_2960 flow) {
		return entry(name,
				c -> new VirtualFluidBuilder<>(self(), self(), name, c, still,
						flow, VirtualFluid::createSource, VirtualFluid::createFlowing));
	}

	public FluidBuilder<SimpleFlowableFluid.Flowing, CreateRegistrate> standardFluid(String name) {
		return fluid(name, new class_2960(getModid(), "fluid/" + name + "_still"), new class_2960(getModid(), "fluid/" + name + "_flow"));
	}

/*
	public FluidBuilder<ForgeFlowingFluid.Flowing, CreateRegistrate> standardFluid(String name,
																				   FluidBuilder.FluidTypeFactory typeFactory) {
		return fluid(name, new ResourceLocation(getModid(), "fluid/" + name + "_still"), new ResourceLocation(getModid(), "fluid/" + name + "_flow"),
			typeFactory);
	}

	public static FluidType defaultFluidType(FluidType.Properties properties, ResourceLocation stillTexture,
											 ResourceLocation flowingTexture) {
		return new FluidType(properties) {
			@Override
			public void initializeClient(Consumer<IClientFluidTypeExtensions> consumer) {
				consumer.accept(new IClientFluidTypeExtensions() {
					@Override
					public ResourceLocation getStillTexture() {
						return stillTexture;
					}

					@Override
					public ResourceLocation getFlowingTexture() {
						return flowingTexture;
					}
				});
			}
		};
	}
*/
	/* Util */

	public static <T extends class_2248> NonNullConsumer<? super T> casingConnectivity(
		BiConsumer<T, CasingConnectivity> consumer) {
		return entry -> onClient(() -> () -> registerCasingConnectivity(entry, consumer));
	}

	public static <T extends class_2248> NonNullConsumer<? super T> blockModel(
		Supplier<NonNullFunction<class_1087, ? extends class_1087>> func) {
		return entry -> onClient(() -> () -> registerBlockModel(entry, func));
	}

	public static <T extends class_1792> NonNullConsumer<? super T> itemModel(
		Supplier<NonNullFunction<class_1087, ? extends class_1087>> func) {
		return entry -> onClient(() -> () -> registerItemModel(entry, func));
	}

	public static <T extends class_2248> NonNullConsumer<T> connectedTextures(
			Supplier<ConnectedTextureBehaviour> behavior) {
		return entry -> onClient(() -> () -> registerCTBehviour(entry, behavior));
	}

	public static <T extends class_1792, P> NonNullUnaryOperator<ItemBuilder<T, P>> customRenderedItem(
			Supplier<Supplier<CustomRenderedItemModelRenderer>> supplier) {
		return b -> {
			onClient(() -> () -> customRenderedItem(b, supplier));
			return b;
		};
	}

	protected static void onClient(Supplier<Runnable> toRun) {
		EnvExecutor.runWhenOn(EnvType.CLIENT, toRun);
	}

	@Environment(EnvType.CLIENT)
	private static <T extends class_2248> void registerCasingConnectivity(T entry,
																	 BiConsumer<T, CasingConnectivity> consumer) {
		consumer.accept(entry, CreateClient.CASING_CONNECTIVITY);
	}

	@Environment(EnvType.CLIENT)
	private static void registerBlockModel(class_2248 entry,
										   Supplier<NonNullFunction<class_1087, ? extends class_1087>> func) {
		CreateClient.MODEL_SWAPPER.getCustomBlockModels()
			.register(CatnipServices.REGISTRIES.getKeyOrThrow(entry), func.get());
	}

	@Environment(EnvType.CLIENT)
	private static void registerItemModel(class_1792 entry,
										  Supplier<NonNullFunction<class_1087, ? extends class_1087>> func) {
		CreateClient.MODEL_SWAPPER.getCustomItemModels()
			.register(CatnipServices.REGISTRIES.getKeyOrThrow(entry), func.get());
	}

	@Environment(EnvType.CLIENT)
	private static void registerCTBehviour(class_2248 entry, Supplier<ConnectedTextureBehaviour> behaviorSupplier) {
		ConnectedTextureBehaviour behavior = behaviorSupplier.get();
		CreateClient.MODEL_SWAPPER.getCustomBlockModels()
			.register(CatnipServices.REGISTRIES.getKeyOrThrow(entry), new CTModelProvider(behavior));
	}



	@Environment(EnvType.CLIENT)
	private static <T extends class_1792, P> void customRenderedItem(ItemBuilder<T, P> b,
															   Supplier<Supplier<CustomRenderedItemModelRenderer>> supplier) {
		b.onRegister(new CustomRendererRegistrationHelper(supplier));
	}

	// fabric: these records are required jank since @Environment doesn't strip lambdas

	@Environment(EnvType.CLIENT)
	private record CTModelProvider(ConnectedTextureBehaviour behavior) implements NonNullFunction<class_1087, class_1087> {
		@Override
		public class_1087 apply(class_1087 bakedModel) {
			return new CTModel(bakedModel, behavior);
		}
	}

	@Environment(EnvType.CLIENT)
	private record CustomRendererRegistrationHelper(Supplier<Supplier<CustomRenderedItemModelRenderer>> supplier) implements NonNullConsumer<class_1792> {
		@Override
		public void accept(class_1792 entry) {
			CustomRenderedItemModelRenderer renderer = supplier.get().get();
			BuiltinItemRendererRegistry.INSTANCE.register(entry, renderer);
			CustomRenderedItems.register(entry);
		}
	}
}
