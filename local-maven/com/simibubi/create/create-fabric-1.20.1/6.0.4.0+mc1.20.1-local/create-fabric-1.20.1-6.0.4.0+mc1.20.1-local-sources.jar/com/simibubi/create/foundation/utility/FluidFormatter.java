package com.simibubi.create.foundation.utility;

import net.createmod.catnip.data.Couple;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidConstants;
import net.minecraft.class_2561;
import net.minecraft.class_5250;
import io.github.fabricators_of_create.porting_lib.util.FluidTextUtil;
import io.github.fabricators_of_create.porting_lib.util.FluidUnit;

public class FluidFormatter {

	public static String asString(long amount, boolean shorten, FluidUnit unit) {
		Couple<class_5250> couple = asComponents(amount, shorten, unit);
		return couple.getFirst().getString() + " " + couple.getSecond().getString();
	}

	public static Couple<class_5250> asComponents(long amount, boolean shorten, FluidUnit unit) {
		if (shorten && amount >= FluidConstants.BUCKET && unit == FluidUnit.MILLIBUCKETS) {
			return Couple.create(
					class_2561.method_43470(String.format("%.1f" , amount / (double) FluidConstants.BUCKET)),
					CreateLang.translateDirect("generic.unit.buckets")
			);
		}

		String amountToDisplay = FluidTextUtil.getUnicodeMillibuckets(amount, unit, true);
		return Couple.create(
				class_2561.method_43470(amountToDisplay),
				CreateLang.translateDirect(unit.getTranslationKey())
		);
	}

}
