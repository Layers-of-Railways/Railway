package com.simibubi.create.foundation.item.render;

import net.fabricmc.fabric.api.renderer.v1.model.ForwardingBakedModel;
import net.minecraft.class_1087;
import net.minecraft.class_4587;
import net.minecraft.class_811;
import io.github.fabricators_of_create.porting_lib.models.TransformTypeDependentItemBakedModel;

public class CustomRenderedItemModel extends ForwardingBakedModel implements TransformTypeDependentItemBakedModel {

	public CustomRenderedItemModel(class_1087 originalModel) {
		this.wrapped = originalModel;
	}

	@Override
	public boolean method_4713() {
		return true;
	}

	@Override
	public class_1087 applyTransform(class_811 cameraItemDisplayContext, class_4587 mat,
									 boolean leftHand, DefaultTransform defaultTransform) {
		// fabric: apply the wrapped model transforms, but render this model
		defaultTransform.apply(wrapped);
		return this;
	}

	public class_1087 getOriginalModel() {
		return wrapped;
	}

}
