package com.simibubi.create.api.equipment.potatoCannon;

import java.util.function.Function;
import net.minecraft.class_1799;
import net.minecraft.class_1936;
import net.minecraft.class_3965;
import com.mojang.serialization.Codec;
import com.simibubi.create.api.registry.CreateBuiltInRegistries;

public interface PotatoProjectileBlockHitAction {
	Codec<PotatoProjectileBlockHitAction> CODEC = CreateBuiltInRegistries.POTATO_PROJECTILE_BLOCK_HIT_ACTION.method_39673()
		.dispatch(PotatoProjectileBlockHitAction::codec, Function.identity());

	boolean execute(class_1936 level, class_1799 projectile, class_3965 ray);

	Codec<? extends PotatoProjectileBlockHitAction> codec();
}
