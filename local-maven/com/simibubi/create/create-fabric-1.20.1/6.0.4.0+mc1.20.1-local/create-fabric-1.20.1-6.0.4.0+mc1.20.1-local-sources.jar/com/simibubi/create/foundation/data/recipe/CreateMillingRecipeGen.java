package com.simibubi.create.foundation.data.recipe;

import java.util.List;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2960;
import net.minecraft.class_3489;
import net.minecraft.class_7784;
import net.minecraft.class_7923;
import com.simibubi.create.AllItems;
import com.simibubi.create.AllTags;
import com.simibubi.create.Create;
import com.simibubi.create.api.data.recipe.MillingRecipeGen;
import io.github.fabricators_of_create.porting_lib.tags.Tags;

/**
 * Create's own Data Generation for Milling recipes
 * @see MillingRecipeGen
 */
@SuppressWarnings("unused")
public final class CreateMillingRecipeGen extends MillingRecipeGen {

	GeneratedRecipe

	GRANITE = create(() -> class_2246.field_10474, b -> b.duration(200)
		.output(class_2246.field_10534)),

	WOOL = create("wool", b -> b.duration(100)
		.require(class_3489.field_15544)
		.output(class_1802.field_8276)),

	CLAY = create(() -> class_2246.field_10460, b -> b.duration(50)
		.output(class_1802.field_8696, 3)
		.output(.5f, class_1802.field_8696)),

	CALCITE = create(() -> class_1802.field_27020, b -> b.duration(250)
		.output(.75f, class_1802.field_8324, 1)),
		DRIPSTONE = create(() -> class_1802.field_28043, b -> b.duration(250)
			.output(class_1802.field_8696, 1)),

	TERRACOTTA = create(() -> class_2246.field_10415, b -> b.duration(200)
		.output(class_2246.field_10534)),
		ANDESITE = create(() -> class_2246.field_10115, b -> b.duration(200)
			.output(class_2246.field_10445)),
		COBBLESTONE = create(() -> class_2246.field_10445, b -> b.duration(250)
			.output(class_2246.field_10255)),
		GRAVEL = create(() -> class_2246.field_10255, b -> b.duration(250)
			.output(class_1802.field_8145)),
		SANDSTONE = create(() -> class_2246.field_9979, b -> b.duration(150)
			.output(class_2246.field_10102)),

	WHEAT = create(() -> class_1802.field_8861, b -> b.duration(150)
		.output(AllItems.WHEAT_FLOUR.get())
		.output(.25f, AllItems.WHEAT_FLOUR.get(), 2)
		.output(.25f, class_1802.field_8317)),

	BONE = create(() -> class_1802.field_8606, b -> b.duration(100)
		.output(class_1802.field_8324, 3)
		.output(.25f, class_1802.field_8446, 1)
		.output(.25f, class_1802.field_8324, 3)),

	CACTUS = create(() -> class_2246.field_10029, b -> b.duration(50)
		.output(class_1802.field_8408, 2)
		.output(.1f, class_1802.field_8408, 1)),

	SEA_PICKLE = create(() -> class_2246.field_10476, b -> b.duration(50)
		.output(class_1802.field_8131, 2)
		.output(.1f, class_1802.field_8408)),

	BONE_MEAL = create(() -> class_1802.field_8324, b -> b.duration(70)
		.output(class_1802.field_8446, 2)
		.output(.1f, class_1802.field_8851, 1)),

	COCOA_BEANS = create(() -> class_1802.field_8116, b -> b.duration(70)
		.output(class_1802.field_8099, 2)
		.output(.1f, class_1802.field_8099, 1)),

	SADDLE = create(() -> class_1802.field_8175, b -> b.duration(200)
		.output(class_1802.field_8745, 2)
		.output(.5f, class_1802.field_8745, 2)),

	SUGAR_CANE = create(() -> class_1802.field_17531, b -> b.duration(50)
		.output(class_1802.field_8479, 2)
		.output(.1f, class_1802.field_8479)),

	BEETROOT = create(() -> class_1802.field_8186, b -> b.duration(70)
		.output(class_1802.field_8264, 2)
		.output(.1f, class_1802.field_8309)),

	INK_SAC = create(() -> class_1802.field_8794, b -> b.duration(100)
		.output(class_1802.field_8226, 2)
		.output(.1f, class_1802.field_8298)),

	CHARCOAL = create(() -> class_1802.field_8665, b -> b.duration(100)
		.output(class_1802.field_8226, 1)
		.output(.1f, class_1802.field_8298, 2)),

	COAL = create(() -> class_1802.field_8713, b -> b.duration(100)
		.output(class_1802.field_8226, 2)
		.output(.1f, class_1802.field_8298, 1)),

	LAPIS_LAZULI = create(() -> class_1802.field_8759, b -> b.duration(100)
		.output(class_1802.field_8345, 2)
		.output(.1f, class_1802.field_8345)),

	AZURE_BLUET = create(() -> class_2246.field_10573, b -> b.duration(50)
		.output(class_1802.field_8851, 2)
		.output(.1f, class_1802.field_8446, 2)),

	BLUE_ORCHID = create(() -> class_2246.field_10086, b -> b.duration(50)
		.output(class_1802.field_8273, 2)
		.output(.05f, class_1802.field_8851, 1)),

	FERN = create(() -> class_2246.field_10112, b -> b.duration(50)
		.output(class_1802.field_8408)
		.output(.1f, class_1802.field_8317)),

	LARGE_FERN = create(() -> class_2246.field_10313, b -> b.duration(50)
		.output(class_1802.field_8408, 2)
		.output(.5f, class_1802.field_8408)
		.output(.1f, class_1802.field_8317)),

	LILAC = create(() -> class_2246.field_10378, b -> b.duration(100)
		.output(class_1802.field_8669, 3)
		.output(.25f, class_1802.field_8669)
		.output(.25f, class_1802.field_8296)),

	PEONY = create(() -> class_2246.field_10003, b -> b.duration(100)
		.output(class_1802.field_8330, 3)
		.output(.25f, class_1802.field_8669)
		.output(.25f, class_1802.field_8330)),

	ALLIUM = create(() -> class_2246.field_10226, b -> b.duration(50)
		.output(class_1802.field_8669, 2)
		.output(.1f, class_1802.field_8296, 2)
		.output(.1f, class_1802.field_8330)),

	LILY_OF_THE_VALLEY = create(() -> class_2246.field_10548, b -> b.duration(50)
		.output(class_1802.field_8446, 2)
		.output(.1f, class_1802.field_8131)
		.output(.1f, class_1802.field_8446)),

	ROSE_BUSH = create(() -> class_2246.field_10430, b -> b.duration(50)
		.output(class_1802.field_8264, 3)
		.output(.05f, class_1802.field_8408, 2)
		.output(.25f, class_1802.field_8264, 2)),

	SUNFLOWER = create(() -> class_2246.field_10583, b -> b.duration(100)
		.output(class_1802.field_8192, 3)
		.output(.25f, class_1802.field_8492)
		.output(.25f, class_1802.field_8192)),

	OXEYE_DAISY = create(() -> class_2246.field_10554, b -> b.duration(50)
		.output(class_1802.field_8851, 2)
		.output(.2f, class_1802.field_8446)
		.output(.05f, class_1802.field_8192)),

	POPPY = create(() -> class_2246.field_10449, b -> b.duration(50)
		.output(class_1802.field_8264, 2)
		.output(.05f, class_1802.field_8408)),

	DANDELION = create(() -> class_2246.field_10182, b -> b.duration(50)
		.output(class_1802.field_8192, 2)
		.output(.05f, class_1802.field_8192)),

	CORNFLOWER = create(() -> class_2246.field_9995, b -> b.duration(50)
		.output(class_1802.field_8345, 2)),

	WITHER_ROSE = create(() -> class_2246.field_10606, b -> b.duration(50)
		.output(class_1802.field_8226, 2)
		.output(.1f, class_1802.field_8226)),

	ORANGE_TULIP = create(() -> class_2246.field_10048, b -> b.duration(50)
		.output(class_1802.field_8492, 2)
		.output(.1f, class_1802.field_8131)),

	RED_TULIP = create(() -> class_2246.field_10270, b -> b.duration(50)
		.output(class_1802.field_8264, 2)
		.output(.1f, class_1802.field_8131)),

	WHITE_TULIP = create(() -> class_2246.field_10156, b -> b.duration(50)
		.output(class_1802.field_8446, 2)
		.output(.1f, class_1802.field_8131)),

	PINK_TULIP = create(() -> class_2246.field_10315, b -> b.duration(50)
		.output(class_1802.field_8330, 2)
		.output(.1f, class_1802.field_8131)),

	TALL_GRASS = create(() -> class_2246.field_10214, b -> b.duration(100)
		.output(.5f, class_1802.field_8317)),
		GRASS = create(() -> class_2246.field_10479, b -> b.duration(50)
			.output(.25f, class_1802.field_8317)),

	// AE2

	AE2_CERTUS = create(Mods.AE2.recipeId("certus_quartz"), b -> b.duration(200)
		.require(AllTags.forgeItemTag("gems/certus_quartz"))
		.output(Mods.AE2, "certus_quartz_dust")
		.whenModLoaded(Mods.AE2.getId())),

	AE2_ENDER = create(Mods.AE2.recipeId("ender_pearl"), b -> b.duration(100)
		.require(Tags.Items.ENDER_PEARLS)
		.output(Mods.AE2, "ender_dust")
		.whenModLoaded(Mods.AE2.getId())),

	AE2_FLUIX = create(Mods.AE2.recipeId("fluix_crystal"), b -> b.duration(200)
		.require(Mods.AE2, "fluix_crystal")
		.output(Mods.AE2, "fluix_dust")
		.whenModLoaded(Mods.AE2.getId())),

	AE2_SKY_STONE = create(Mods.AE2.recipeId("sky_stone_block"), b -> b.duration(300)
		.require(Mods.AE2, "sky_stone_block")
		.output(Mods.AE2, "sky_dust")
		.whenModLoaded(Mods.AE2.getId())),

	// Atmospheric

	ATMO_GILIA = create(Mods.ATM.recipeId("gilia"), b -> b.duration(50)
		.require(Mods.ATM, "gilia")
		.output(class_1802.field_8296, 2)
		.output(.1f, class_1802.field_8669, 2)
		.output(.1f, class_1802.field_8330)
		.whenModLoaded(Mods.ATM.getId())),

	ATMO_HOT_BRUSH = create(Mods.ATM.recipeId("hot_monkey_brush"), b -> b.duration(50)
		.require(Mods.ATM, "hot_monkey_brush")
		.output(class_1802.field_8492, 2)
		.output(.05f, class_1802.field_8264)
		.output(.05f, class_1802.field_8192)
		.whenModLoaded(Mods.ATM.getId())),

	ATMO_SCALDING_BRUSH = create(Mods.ATM.recipeId("scalding_monkey_brush"), b -> b.duration(50)
		.require(Mods.ATM, "scalding_monkey_brush")
		.output(class_1802.field_8264, 2)
		.output(.1f, class_1802.field_8264, 2)
		.output(.1f, class_1802.field_8492)
		.whenModLoaded(Mods.ATM.getId())),

	ATMO_WARM_BRUSH = create(Mods.ATM.recipeId("warm_monkey_brush"), b -> b.duration(50)
		.require(Mods.ATM, "scalding_monkey_brush")
		.output(class_1802.field_8192, 2)
		.output(.1f, class_1802.field_8192, 2)
		.output(.1f, class_1802.field_8492)
		.whenModLoaded(Mods.ATM.getId())),

	ATMO_YUCCA_FLOWER = create(Mods.ATM.recipeId("yucca_flower"), b -> b.duration(50)
		.require(Mods.ATM, "yucca_flower")
		.output(class_1802.field_8851, 2)
		.output(.05f, class_1802.field_8446)
		.whenModLoaded(Mods.ATM.getId())),

	// Autumnity

	AUTUM_CROCUS = create(Mods.AUTUM.recipeId("autumn_crocus"), b -> b.duration(50)
		.require(Mods.AUTUM, "autumn_crocus")
		.output(class_1802.field_8669, 2)
		.output(.1f, class_1802.field_8330, 2)
		.output(.1f, class_1802.field_8296)
		.whenModLoaded(Mods.AUTUM.getId())),

	// Biomes O' Plenty
	BOP_HYDRANGEA = bopFlower("blue_hydrangea", List.of(1f, .05f, .25f),
		List.of(class_1802.field_8273, class_1802.field_8408, class_1802.field_8273), List.of(3,2,2)),

	BOP_BLOSSOM = bopFlower("burning_blossom", List.of(1f,.1f),
		List.of(class_1802.field_8492, class_1802.field_8131), List.of(2,1)),

	BOP_GLOWFLOWER = bopFlower("glowflower", List.of(1f, .1f),
		List.of(class_1802.field_8632, class_1802.field_8446), List.of(2,1)),

	BOP_LAVENDER = bopFlower("lavender", List.of(1f, .05f),
		List.of(class_1802.field_8296, class_1802.field_8408), List.of(2,1)),

	BOP_COSMOS = bopFlower("orange_cosmos", List.of(1f, .1f),
		List.of(class_1802.field_8492, class_1802.field_8131), List.of(2,1)),

	BOP_DAFFODIL = bopFlower("pink_daffodil", List.of(1f, .25f, .05f),
		List.of(class_1802.field_8330, class_1802.field_8669, class_1802.field_8632), List.of(2,1,1)),

	BOP_HIBISCUS = bopFlower("pink_hibiscus", List.of(1f, .25f, .1f),
		List.of(class_1802.field_8330, class_1802.field_8192, class_1802.field_8408), List.of(2,1,1)),

	BOP_ROSE = bopFlower("rose", List.of(1f, .05f),
		List.of(class_1802.field_8264, class_1802.field_8408), List.of(2,1)),

	BOP_VIOLET = bopFlower("violet", 1f, class_1802.field_8296,2),

	BOP_WILDFLOWER = bopFlower("wildflower", List.of(1f, .1f),
		List.of(class_1802.field_8669, class_1802.field_8131), List.of(2,1)),

	BOP_LILY = bopFlower("wilted_lily", 1f, class_1802.field_8298,2),

	// Botania
	BTN_PETALS = botaniaPetals("black", "blue", "brown", "cyan", "gray", "green", "light_blue",
		"light_gray", "lime", "magenta", "orange", "pink", "purple", "red", "white", "yellow"),

	// Buzzier Bees

	BB_BUTTERCUP = create(Mods.BB.recipeId("buttercup"), b -> b.duration(50)
		.require(Mods.BB, "buttercup")
		.output(class_1802.field_8192, 2)
		.output(.1f, class_1802.field_8131)
		.whenModLoaded(Mods.BB.getId())),

	BB_PINK_CLOVER = create(Mods.BB.recipeId("pink_clover"), b -> b.duration(50)
        .require(Mods.BB, "pink_clover")
		.output(class_1802.field_8330, 2)
		.output(.1f, class_1802.field_8131)
		.whenModLoaded(Mods.BB.getId())),

	BB_WHITE_CLOVER = create(Mods.BB.recipeId("white_clover"), b -> b.duration(50)
        .require(Mods.BB, "white_clover")
		.output(class_1802.field_8446, 2)
		.output(.1f, class_1802.field_8131)
		.whenModLoaded(Mods.BB.getId())),

	// Oh The Biomes You'll Go

	BYG_ALLIUM_BUSH = bygFlower("allium_flower_bush", List.of(1f,.05f,.25f),
		List.of(class_1802.field_8296, class_1802.field_8408, class_1802.field_8669), List.of(3,2,2)),

	BYG_BELLFLOWER = bygFlower("alpine_bellflower", List.of(1f,.1f,.1f),
		List.of(class_1802.field_8296, class_1802.field_8345, class_1802.field_8408), List.of(2,2,1)),

	BYG_AMARANTH = bygFlower("amaranth", List.of(1f,.05f,.25f),
		List.of(class_1802.field_8264, class_1802.field_8408, class_1802.field_8264), List.of(3,2,2)),

	BYG_ANGELICA = bygFlower("angelica", List.of(1f,.1f),
		List.of(class_1802.field_8446, class_1802.field_8408), List.of(2,1)),

	BYG_BEGONIA = bygFlower("begonia", List.of(1f,.1f),
		List.of(class_1802.field_8264, class_1802.field_8408), List.of(2,1)),

	BYG_BISTORT = bygFlower("bistort", List.of(1f,.1f,.1f),
		List.of(class_1802.field_8330, class_1802.field_8264, class_1802.field_8408), List.of(2,2,1)),

	BYG_BLACK_ROSE = bygFlower("black_rose", List.of(1f,.1f),
		List.of(class_1802.field_8226, class_1802.field_8226), List.of(2,1)),

	BYG_BLUE_SAGE = bygFlower("blue_sage", List.of(1f,.1f,.1f),
		List.of(class_1802.field_8345, class_1802.field_8632, class_1802.field_8408), List.of(2,2,1)),

	BYG_CALIFORNIA_POPPY = bygFlower("california_poppy", List.of(1f,.05f),
		List.of(class_1802.field_8492, class_1802.field_8408), List.of(2,1)),

	BYG_CROCUS = bygFlower("crocus", List.of(1f,.1f,.1f),
		List.of(class_1802.field_8296, class_1802.field_8345, class_1802.field_8408), List.of(2,2,1)),

	BYG_CYAN_AMARANTH = bygFlower("cyan_amaranth", List.of(1f,.05f,.25f),
		List.of(class_1802.field_8264, class_1802.field_8408, class_1802.field_8264), List.of(3,2,2)),

	BYG_CYAN_ROSE = bygFlower("cyan_rose", List.of(1f,.1f),
		List.of(class_1802.field_8632, class_1802.field_8408), List.of(2,1)),

	BYG_CYAN_TULIP = bygFlower("cyan_tulip", List.of(1f,.1f),
		List.of(class_1802.field_8632, class_1802.field_8131), List.of(2,1)),

	BYG_DAFFODIL = bygFlower("daffodil", List.of(1f,.1f,.1f),
		List.of(class_1802.field_8330, class_1802.field_8408, class_1802.field_8669), List.of(2,1,1)),

	BYG_DELPHINIUM = bygFlower("delphinium", List.of(1f,.1f),
		List.of(class_1802.field_8345, class_1802.field_8345), List.of(3,1)),

	BYG_FAIRY_SLIPPER = bygFlower("fairy_slipper", List.of(1f,.1f,.1f),
		List.of(class_1802.field_8669, class_1802.field_8330, class_1802.field_8192), List.of(2,2,1)),

	BYG_FIRECRACKER_BUSH = bygFlower("firecracker_flower_bush", List.of(1f,.05f,.25f),
		List.of(class_1802.field_8330, class_1802.field_8408, class_1802.field_8264), List.of(3,2,2)),

	BYG_FOXGLOVE = bygFlower("foxglove", List.of(1f,.25f,.25f),
		List.of(class_1802.field_8669, class_1802.field_8330, class_1802.field_8192), List.of(2,1,1)),

	BYG_GREEN_TULIP = bygFlower("green_tulip", List.of(1f,.1f),
		List.of(class_1802.field_8131, class_1802.field_8408), List.of(2,1)),

	BYG_GUZMANIA = bygFlower("guzmania", List.of(1f,.25f,.25f),
		List.of(class_1802.field_8669, class_1802.field_8330, class_1802.field_8192), List.of(2,1,1)),

	BYG_HYDRANGEA = bygFlower("hydrangea_bush", List.of(1f,.1f,.1f),
		List.of(class_1802.field_8296, class_1802.field_8345, class_1802.field_8446), List.of(2,2,1)),

	BYG_INCAN_LILY = bygFlower("incan_lily", List.of(1f,.1f,.1f),
		List.of(class_1802.field_8492, class_1802.field_8408, class_1802.field_8264), List.of(2,1,1)),

	BYG_IRIS = bygFlower("iris", List.of(1f,.05f),
		List.of(class_1802.field_8296, class_1802.field_8408), List.of(2,1)),

	BYG_ORCHID = bygFlower("orchid", List.of(1f,.05f),
		List.of(class_1802.field_8330, class_1802.field_8446), List.of(2,1)),

	BYG_KOVAN = bygFlower("kovan_flower", List.of(1f,.2f,.05f),
		List.of(class_1802.field_8264, class_1802.field_8131, class_1802.field_8408), List.of(2,1,1)),

	BYG_LAZARUS_BELLFLOWER = bygFlower("lazarus_bellflower", List.of(1f,.1f),
		List.of(class_1802.field_8669, class_1802.field_8408), List.of(2,1)),

	BYG_LOLIPOP = bygFlower("lolipop_flower", List.of(1f,.25f,.05f),
		List.of(class_1802.field_8192, class_1802.field_8192, class_1802.field_8408), List.of(2,1,1)),

	BYG_MAGENTA_AMARANTH = bygFlower("magenta_amaranth", List.of(1f,.05f,.25f),
		List.of(class_1802.field_8669, class_1802.field_8408, class_1802.field_8669), List.of(3,2,2)),

	BYG_MAGENTA_TULIP = bygFlower("magenta_tulip", List.of(1f,.1f),
		List.of(class_1802.field_8669, class_1802.field_8131), List.of(2,1)),

	BYG_ORANGE_AMARANTH = bygFlower("orange_amaranth", List.of(1f,.05f,.25f),
		List.of(class_1802.field_8264, class_1802.field_8408, class_1802.field_8264), List.of(3,2,2)),

	BYG_DAISY = bygFlower("orange_daisy", List.of(1f,.2f,.05f),
		List.of(class_1802.field_8492, class_1802.field_8192, class_1802.field_8131), List.of(2,1,1)),

	BYG_OSIRIA_ROSE = bygFlower("osiria_rose", List.of(1f,.1f),
		List.of(class_1802.field_8226, class_1802.field_8226), List.of(2,1)),

	BYG_PEACH_LEATHER = bygFlower("peach_leather_flower", List.of(1f,.25f),
		List.of(class_1802.field_8330, class_1802.field_8408), List.of(2,1)),

	BYG_PINK_ALLIUM = bygFlower("pink_allium", List.of(1f,.1f,.1f),
		List.of(class_1802.field_8669, class_1802.field_8330, class_1802.field_8296), List.of(2,2,1)),

	BYG_PINK_ALLIUM_BUSH = bygFlower("pink_allium_flower_bush", List.of(1f,.05f,.25f),
		List.of(class_1802.field_8296, class_1802.field_8408, class_1802.field_8669), List.of(3,2,2)),

	BYG_PINK_ANEMONE = bygFlower("pink_anemone", List.of(1f,.1f),
		List.of(class_1802.field_8330, class_1802.field_8296), List.of(2,2)),

	BYG_PINK_DAFODIL = bygFlower("pink_daffodil", List.of(1f,.1f,.1f),
		List.of(class_1802.field_8330, class_1802.field_8408, class_1802.field_8446), List.of(2,1,1)),

	BYG_PROTEA = bygFlower("protea_flower", List.of(1f,.1f,.05f),
		List.of(class_1802.field_8669, class_1802.field_8131, class_1802.field_8296), List.of(2,1,1)),

	BYG_PURPLE_AMARANTH = bygFlower("purple_amaranth", List.of(1f,.05f,.25f),
		List.of(class_1802.field_8296, class_1802.field_8408, class_1802.field_8296), List.of(3,2,2)),

	BYG_PURPLE_SAGE = bygFlower("purple_rose", List.of(1f,.1f),
		List.of(class_1802.field_8296, class_1802.field_8669), List.of(2,1)),

	BYG_PURPLE_TULIP = bygFlower("purple_tulip", List.of(1f,.1f),
		List.of(class_1802.field_8296, class_1802.field_8131), List.of(2,1)),

	BYG_RICHEA = bygFlower("richea", List.of(1f,.1f,.05f),
		List.of(class_1802.field_8669, class_1802.field_8330, class_1802.field_8192), List.of(2,1,1)),

	BYG_ROSE = bygFlower("rose", List.of(1f,.1f),
		List.of(class_1802.field_8264, class_1802.field_8408), List.of(2,1)),

	BYG_SILVER_VASE = bygFlower("silver_vase_flower", List.of(1f,.1f,.05f),
		List.of(class_1802.field_8330, class_1802.field_8408, class_1802.field_8446), List.of(2,1,1)),

	BYG_SNOWDROPS = bygFlower("snowdrops", List.of(1f,.1f,.1f),
		List.of(class_1802.field_8446, class_1802.field_8131, class_1802.field_8446), List.of(2,1,1)),

	BYG_TALL_ALLIUM = bygFlower("tall_allium", List.of(1f,.05f,.25f),
		List.of(class_1802.field_8296, class_1802.field_8296, class_1802.field_8669), List.of(3,2,2)),

	BYG_TALL_PINK_ALLIUM = bygFlower("tall_pink_allium", List.of(1f,.05f,.25f),
		List.of(class_1802.field_8330, class_1802.field_8330, class_1802.field_8669), List.of(3,2,2)),

	BYG_TORCH_GINGER = bygFlower("torch_ginger", List.of(1f,.1f),
		List.of(class_1802.field_8264, class_1802.field_8408), List.of(2,1)),

	BYG_VIOLET_LEATHER = bygFlower("violet_leather_flower", List.of(1f,.25f),
		List.of(class_1802.field_8345, class_1802.field_8408), List.of(2,1)),

	BYG_WHITE_ANEMONE = bygFlower("white_anemone", List.of(1f,.1f),
		List.of(class_1802.field_8446, class_1802.field_8851), List.of(2,2)),

	BYG_PUFFBALL = create(Mods.BYG.recipeId("white_puffball_cap"), b -> b.duration(150)
		.require(Mods.BYG, "white_puffball_cap")
		.output(.25f, Mods.BYG, "white_puffball_spores", 1)
		.whenModLoaded(Mods.BYG.getId())),

	BYG_WHITE_SAGE = bygFlower(Mods.BYG.recipeId("white_sage"), List.of(1f, .1f),
		List.of(class_1802.field_8446, class_1802.field_8298), List.of(2,1)),

	BYG_WINTER_CYCLAMEN = bygFlower(Mods.BYG.recipeId("winter_cyclamen"), List.of(1f, .1f),
		List.of(class_1802.field_8632, class_1802.field_8408), List.of(2,1)),

	BYG_WINTER_ROSE = bygFlower("winter_rose", List.of(1f,.1f),
		List.of(class_1802.field_8446, class_1802.field_8408), List.of(2,1)),

	BYG_WINTER_SCILLA = bygFlower("winter_scilla", List.of(1f,.1f),
		List.of(class_1802.field_8273, class_1802.field_8408), List.of(2,1)),

	BYG_YELLOW_DAFFODIL = bygFlower("yellow_daffodil", List.of(1f,.1f,.1f),
		List.of(class_1802.field_8192, class_1802.field_8408, class_1802.field_8330), List.of(2,1,1)),

	BYG_YELLOW_TULIP = bygFlower("yellow_tulip", List.of(1f,.1f),
		List.of(class_1802.field_8192, class_1802.field_8131), List.of(2,1)),

	// Environmental

	ENV_BIRD_OF_PARADISE = envFlower("bird_of_paradise", List.of(1f,.25f,.25f),
		List.of(class_1802.field_8492, class_1802.field_8345, class_1802.field_8264), List.of(3,1,1)),

	ENV_BLUE_DELPHINIUM = envFlower("blue_delphinium", List.of(1f,.1f),
		List.of(class_1802.field_8345, class_1802.field_8345), List.of(3,1)),

	ENV_BLUEBELL = envFlower("bluebell", List.of(1f),
		List.of(class_1802.field_8345), List.of(2)),

	ENV_CARTWHEEL = envFlower("cartwheel", List.of(1f,.1f),
		List.of(class_1802.field_8330, class_1802.field_8492), List.of(2,1)),

	ENV_DIANTHUS = envFlower("dianthus", List.of(1f,.1f),
		List.of(class_1802.field_8408, class_1802.field_8408), List.of(2,1)),

	ENV_MAGENTA_HIBISCUS = envFlower("magenta_hibiscus", List.of(1f,.1f),
		List.of(class_1802.field_8669, class_1802.field_8669), List.of(2,1)),

	ENV_ORANGE_HIBISCUS = envFlower("orange_hibiscus", List.of(1f,.1f),
		List.of(class_1802.field_8492, class_1802.field_8492), List.of(2,1)),

	ENV_PINK_DELPHINIUM = envFlower("pink_delphinium", List.of(1f,.1f),
		List.of(class_1802.field_8330, class_1802.field_8330), List.of(3,1)),

	ENV_PINK_HIBISCUS = envFlower("pink_hibiscus", List.of(1f,.1f),
		List.of(class_1802.field_8330, class_1802.field_8330), List.of(2,1)),

	ENV_PURPLE_DELPHINIUM = envFlower("purple_delphinium", List.of(1f,.1f),
		List.of(class_1802.field_8296, class_1802.field_8296), List.of(3,1)),

	ENV_PURPLE_HIBISCUS = envFlower("purple_hibiscus", List.of(1f,.1f),
		List.of(class_1802.field_8296, class_1802.field_8296), List.of(2,1)),

	ENV_RED_HIBISCUS = envFlower("red_hibiscus", List.of(1f,.1f),
		List.of(class_1802.field_8264, class_1802.field_8264), List.of(2,1)),

	ENV_RED_LOTUS = envFlower("red_lotus_flower", List.of(1f,.1f),
		List.of(class_1802.field_8264, class_1802.field_8264), List.of(2,1)),

	ENV_VIOLET = envFlower("violet", List.of(1f,.1f),
		List.of(class_1802.field_8296, class_1802.field_8296), List.of(2,1)),

	ENV_WHITE_DELPHINIUM = envFlower("white_delphinium", List.of(1f,.1f),
		List.of(class_1802.field_8446, class_1802.field_8446), List.of(3,1)),

	ENV_WHITE_LOTUS_FLOWER = envFlower("white_lotus_flower", List.of(1f,.1f),
		List.of(class_1802.field_8446, class_1802.field_8131), List.of(2,1)),

	ENV_YELLOW_HIBISCUS = envFlower("yellow_hibiscus", List.of(1f,.1f),
		List.of(class_1802.field_8192, class_1802.field_8192), List.of(2,1)),

	// Duidcraft
	DC_LAVENDER = create(Mods.DRUIDCRAFT.recipeId("lavender"), b -> b.duration(50)
		.require(Mods.DRUIDCRAFT, "lavender")
		.output(class_1802.field_8296, 2)
		.output(.1f, class_1802.field_8296)
		.whenModLoaded(Mods.DRUIDCRAFT.getId())),

	// Supplementaries
	SUP_FLAX = create(Mods.SUP.recipeId("flax"), b -> b.duration(150)
		.require(Mods.SUP, "flax")
		.output(class_1802.field_8276)
		.output(.25f, class_1802.field_8276, 2)
		.output(.25f, Mods.SUP, "flax_seeds", 1)
		.whenModLoaded(Mods.SUP.getId())),

	// Tinkers' Construct
	TIC_NERCOTIC_BONE = create(Mods.TIC.recipeId("nercotic_bone"), b -> b.duration(100)
		.require(Mods.TIC, "necrotic_bone")
		.output(class_1802.field_8324, 3)
		.output(.25f, class_1802.field_8226)
		.output(.25f, class_1802.field_8324, 3)
		.whenModLoaded(Mods.TIC.getId())),

	// Upgrade Aquatic

	UA_FLOWERING_RUSH = create(Mods.UA.recipeId("flowering_rush"), b -> b.duration(50)
		.require(Mods.UA, "flowering_rush")
		.output(class_1802.field_8330, 3)
		.output(.25f, class_1802.field_8330, 2)
		.whenModLoaded(Mods.UA.getId())),

	UA_PINK_SEAROCKET = create(Mods.UA.recipeId("pink_searocket"), b -> b.duration(50)
		.require(Mods.UA, "pink_searocket")
		.output(class_1802.field_8330, 2)
		.output(.1f, class_1802.field_8408)
		.whenModLoaded(Mods.UA.getId())),

	UA_WHITE_SEAROCKET = create(Mods.UA.recipeId("white_searocket"), b -> b.duration(50)
		.require(Mods.UA, "white_searocket")
		.output(class_1802.field_8446, 2)
		.output(.1f, class_1802.field_8408)
		.whenModLoaded(Mods.UA.getId())),

	// Regions Unexplored

	RU_ALPHA_DANDELION = ruFlower("alpha_dandelion", List.of(1f, 0.05f),
		List.of(class_1802.field_8192, class_1802.field_8192), List.of(2, 1)),

	RU_ALPHA_ROSE = ruFlower("alpha_rose", List.of(1f, 0.05f),
		List.of(class_1802.field_8264, class_1802.field_8264), List.of(2, 1)),

	RU_ASTER = ruFlower("aster", List.of(1f, 0.2f, 0.05f),
		List.of(class_1802.field_8273, class_1802.field_8446, class_1802.field_8851), List.of(2, 1, 1)),

	RU_BLACK_SNOWBELLE = ruFlower("black_snowbelle", List.of(1f),
		List.of(class_1802.field_8226), List.of(2)),

	RU_BLEEDING_HEART = ruFlower("bleeding_heart", List.of(1f, 0.1f),
		List.of(class_1802.field_8669, class_1802.field_8330), List.of(2, 1)),

	RU_BLUE_LUPINE = ruFlower("blue_lupine", List.of(1f),
		List.of(class_1802.field_8345), List.of(2)),

	RU_BLUE_SNOWBELLE = ruFlower("blue_snowbelle", List.of(1f),
		List.of(class_1802.field_8345), List.of(2)),

	RU_BROWN_SNOWBELLE = ruFlower("brown_snowbelle", List.of(1f),
		List.of(class_1802.field_8099), List.of(2)),

	RU_CACTUS_FLOWER = ruFlower("cactus_flower", List.of(1f, 0.2f, 0.1f),
		List.of(class_1802.field_8669, class_1802.field_8296, class_1802.field_8408), List.of(2, 1, 1)),

	RU_CYAN_SNOWBELLE = ruFlower("cyan_snowbelle", List.of(1f),
		List.of(class_1802.field_8632), List.of(2)),

	RU_DAISY = ruFlower("daisy", List.of(1f, 0.2f, 0.05f),
		List.of(class_1802.field_8851, class_1802.field_8446, class_1802.field_8192), List.of(2, 1, 1)),

	RU_DAY_LILY = ruFlower("day_lily", List.of(1f, 0.1f, 0.1f),
		List.of(class_1802.field_8492, class_1802.field_8131, class_1802.field_8264), List.of(2, 1, 1)),

	RU_DORCEL = ruFlower("dorcel", List.of(1f, 0.1f),
		List.of(class_1802.field_8226, class_1802.field_8099), List.of(2, 1)),

	RU_FELICIA_DAISY = ruFlower("felicia_daisy", List.of(1f, 0.2f, 0.05f),
		List.of(class_1802.field_8273, class_1802.field_8345, class_1802.field_8446), List.of(2, 1, 1)),

	RU_FIREWEED = ruFlower("fireweed", List.of(1f),
		List.of(class_1802.field_8669), List.of(2)),

	RU_GLITERING_BLOOM = ruFlower("glistering_bloom", List.of(1f, 0.25f, 0.25f),
		List.of(class_1802.field_8330, class_1802.field_8669, class_1802.field_8273), List.of(2, 1, 1)),

	RU_GRAY_SNOWBELLE = ruFlower("gray_snowbelle", List.of(1f),
		List.of(class_1802.field_8298), List.of(2)),

	RU_GREEN_SNOWBELLE = ruFlower("green_snowbelle", List.of(1f),
		List.of(class_1802.field_8408), List.of(2)),

	RU_HIBISCUS = ruFlower("hibiscus", List.of(1f, 0.2f),
		List.of(class_1802.field_8192, class_1802.field_8264), List.of(2, 1)),

	RU_HYSSOP = ruFlower("hyssop", List.of(1f, 0.1f, 0.1f),
		List.of(class_1802.field_8296, class_1802.field_8669, class_1802.field_8408), List.of(2, 1, 1)),

	RU_LIGHT_BLUE_SNOWBELLE = ruFlower("light_blue_snowbelle", List.of(1f),
		List.of(class_1802.field_8273), List.of(2)),

	RU_LIGHT_GRAY_SNOWBELLE = ruFlower("light_gray_snowbelle", List.of(1f),
		List.of(class_1802.field_8851), List.of(2)),

	RU_LIME_SNOWBELLE = ruFlower("lime_snowbelle", List.of(1f),
		List.of(class_1802.field_8131), List.of(2)),

	RU_MAGENTA_SNOWBELLE = ruFlower("magenta_snowbelle", List.of(1f),
		List.of(class_1802.field_8669), List.of(2)),

	RU_MALLOW = ruFlower("mallow", List.of(1f, 0.1f),
		List.of(class_1802.field_8492, class_1802.field_8131), List.of(2, 1)),

	RU_ORANGE_CONEFLOWER = ruFlower("orange_coneflower", List.of(1f),
		List.of(class_1802.field_8492), List.of(2)),

	RU_ORANGE_SNOWBELLE = ruFlower("orange_snowbelle", List.of(1f),
		List.of(class_1802.field_8492), List.of(2)),

	RU_PINK_LUPINE = ruFlower("pink_lupine", List.of(1f),
		List.of(class_1802.field_8330), List.of(2)),

	RU_PINK_SNOWBELLE = ruFlower("pink_snowbelle", List.of(1f),
		List.of(class_1802.field_8330), List.of(2)),

	RU_POPPY_BUSH = ruFlower("poppy_bush", List.of(1f, 0.1f),
		List.of(class_1802.field_8264, class_1802.field_8408), List.of(2, 1)),

	RU_PURPLE_CONEFLOWER = ruFlower("purple_coneflower", List.of(1f),
		List.of(class_1802.field_8296), List.of(2)),

	RU_PURPLE_LUPINE = ruFlower("purple_lupine", List.of(1f),
		List.of(class_1802.field_8296), List.of(2)),

	RU_PURPLE_SNOWBELLE = ruFlower("purple_snowbelle", List.of(1f),
		List.of(class_1802.field_8296), List.of(2)),

	RU_RED_LUPINE = ruFlower("red_lupine", List.of(1f),
		List.of(class_1802.field_8264), List.of(2)),

	RU_RED_SNOWBELLE = ruFlower("red_snowbelle", List.of(1f),
		List.of(class_1802.field_8264), List.of(2)),

	RU_SALMON_POPPY_BUSH = ruFlower("salmon_poppy_bush", List.of(1f, 0.1f),
		List.of(class_1802.field_8330, class_1802.field_8408), List.of(2, 1)),

	RU_TASSEL = ruFlower("tassel", List.of(1f, 0.2f, 0.05f),
		List.of(class_1802.field_8851, class_1802.field_8446, class_1802.field_8192), List.of(2, 1, 1)),

	RU_TSUBAKI = ruFlower("tsubaki", List.of(1f, 0.1f),
		List.of(class_1802.field_8264, class_1802.field_8408), List.of(2, 1)),

	RU_WARATAH = ruFlower("waratah", List.of(1f, 0.2f, 0.1f),
		List.of(class_1802.field_8264, class_1802.field_8264, class_1802.field_8408), List.of(2, 1, 1)),

	RU_WHITE_SNOWBELLE = ruFlower("white_snowbelle", List.of(1f),
		List.of(class_1802.field_8446), List.of(2)),

	RU_WHITE_TRILLIUM = ruFlower("white_trillium", List.of(1f, 0.2f, 0.05f),
		List.of(class_1802.field_8851, class_1802.field_8446, class_1802.field_8192), List.of(2, 1, 1)),

	RU_WILTING_TRILLIUM = ruFlower("wilting_trillium", List.of(1f, 0.1f),
		List.of(class_1802.field_8099, class_1802.field_8851), List.of(2, 1)),

	RU_YELLOW_LUPINE = ruFlower("yellow_lupine", List.of(1f),
		List.of(class_1802.field_8192), List.of(2)),

	RU_YELLOW_SNOWBELLE = ruFlower("yellow_snowbelle", List.of(1f),
		List.of(class_1802.field_8192), List.of(2))

		;

	GeneratedRecipe bopFlower(String input, List<Float> chances,
																   List<class_1792> dyes, List<Integer> amounts) {
		if (chances.size() == 2) {
			return create(Mods.BOP.recipeId(input), b -> b.duration(50)
					.require(Mods.BOP, input)
					.output(chances.get(0), dyes.get(0), amounts.get(0))
					.output(chances.get(1), dyes.get(1), amounts.get(1))
					.whenModLoaded(Mods.BOP.getId()));
		} else if (chances.size() == 3) {
			return create(Mods.BOP.recipeId(input), b -> b.duration(50)
					.require(Mods.BOP, input)
					.output(chances.get(0), dyes.get(0), amounts.get(0))
					.output(chances.get(1), dyes.get(1), amounts.get(1))
					.output(chances.get(2), dyes.get(2), amounts.get(2))
					.whenModLoaded(Mods.BOP.getId()));
		} else if (chances.size() == 1) {
			return create(Mods.BOP.recipeId(input), b -> b.duration(50)
					.require(Mods.BOP, input)
					.output(chances.get(0), dyes.get(0), amounts.get(0))
					.whenModLoaded(Mods.BOP.getId()));
		} else {
			return null;
		}
	}

	GeneratedRecipe bygFlower(String input, List<Float> chances,
																   List<class_1792> dyes, List<Integer> amounts) {
		if (chances.size() == 2) {
			return create(Mods.BYG.recipeId(input), b -> b.duration(50)
					.require(Mods.BYG, input)
					.output(chances.get(0), dyes.get(0), amounts.get(0))
					.output(chances.get(1), dyes.get(1), amounts.get(1))
					.whenModLoaded(Mods.BYG.getId()));
		} else if (chances.size() == 3) {
			return create(Mods.BYG.recipeId(input), b -> b.duration(50)
					.require(Mods.BYG, input)
					.output(chances.get(0), dyes.get(0), amounts.get(0))
					.output(chances.get(1), dyes.get(1), amounts.get(1))
					.output(chances.get(2), dyes.get(2), amounts.get(2))
					.whenModLoaded(Mods.BYG.getId()));
		} else if (chances.size() == 1) {
			return create(Mods.BYG.recipeId(input), b -> b.duration(50)
					.require(Mods.BYG, input)
					.output(chances.get(0), dyes.get(0), amounts.get(0))
					.whenModLoaded(Mods.BYG.getId()));
		} else {
			return null;
		}
	}

	GeneratedRecipe envFlower(String input, List<Float> chances,
																   List<class_1792> dyes, List<Integer> amounts) {
		if (chances.size() == 2) {
			return create(Mods.ENV.recipeId(input), b -> b.duration(50)
					.require(Mods.ENV, input)
					.output(chances.get(0), dyes.get(0), amounts.get(0))
					.output(chances.get(1), dyes.get(1), amounts.get(1))
					.whenModLoaded(Mods.ENV.getId()));
		} else if (chances.size() == 3) {
			return create(Mods.ENV.recipeId(input), b -> b.duration(50)
					.require(Mods.ENV, input)
					.output(chances.get(0), dyes.get(0), amounts.get(0))
					.output(chances.get(1), dyes.get(1), amounts.get(1))
					.output(chances.get(2), dyes.get(2), amounts.get(2))
					.whenModLoaded(Mods.ENV.getId()));
		} else if (chances.size() == 1) {
			return create(Mods.ENV.recipeId(input), b -> b.duration(50)
					.require(Mods.ENV, input)
					.output(chances.get(0), dyes.get(0), amounts.get(0))
					.whenModLoaded(Mods.ENV.getId()));
		} else {
			return null;
		}
	}

	GeneratedRecipe bopFlower(String input, Float chance, class_1792 dye, int amount) {
		return create(Mods.BOP.recipeId(input), b -> b.duration(50)
				.require(Mods.BOP, input)
				.output(chance, dye, amount)
				.whenModLoaded(Mods.BOP.getId()));
	}

	GeneratedRecipe botaniaPetals(String... colors) {
		for (String color : colors) {
			create(Mods.BTN.recipeId(color + "_petal"), b -> b.duration(50)
					.require(AllTags.optionalTag(class_7923.field_41178,
							new class_2960(Mods.BTN.getId(), "petals/" + color)))
					.output(Mods.MC, color + "_dye")
					.whenModLoaded(Mods.BTN.getId()));
		}
		return null;
	}

	GeneratedRecipe ruFlower(String input, List<Float> chances,
																  List<class_1792> dyes, List<Integer> amounts) {
		if (chances.size() == 2) {
			return create(Mods.RU.recipeId(input), b -> b.duration(50)
					.require(Mods.RU, input)
					.output(chances.get(0), dyes.get(0), amounts.get(0))
					.output(chances.get(1), dyes.get(1), amounts.get(1))
					.whenModLoaded(Mods.RU.getId()));
		} else if (chances.size() == 3) {
			return create(Mods.RU.recipeId(input), b -> b.duration(50)
					.require(Mods.RU, input)
					.output(chances.get(0), dyes.get(0), amounts.get(0))
					.output(chances.get(1), dyes.get(1), amounts.get(1))
					.output(chances.get(2), dyes.get(2), amounts.get(2))
					.whenModLoaded(Mods.RU.getId()));
		} else if (chances.size() == 1) {
			return create(Mods.RU.recipeId(input), b -> b.duration(50)
					.require(Mods.RU, input)
					.output(chances.get(0), dyes.get(0), amounts.get(0))
					.whenModLoaded(Mods.RU.getId()));
		} else {
			return null;
		}
	}

	public CreateMillingRecipeGen(class_7784 output) {
		super(output, Create.ID);
	}
}
