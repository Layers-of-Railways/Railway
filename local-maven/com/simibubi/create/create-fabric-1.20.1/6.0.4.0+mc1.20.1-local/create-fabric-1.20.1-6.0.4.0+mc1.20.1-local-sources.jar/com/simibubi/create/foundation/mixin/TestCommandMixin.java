package com.simibubi.create.foundation.mixin;

import javax.annotation.Nullable;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2520;
import net.minecraft.class_2633;
import net.minecraft.class_3218;
import net.minecraft.class_4519;
import net.minecraft.class_4524;
import net.minecraft.class_4527;
import net.minecraft.class_4529;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

import com.simibubi.create.infrastructure.gametest.CreateTestFunction;

@Mixin(class_4527.class)
public class TestCommandMixin {
	@Redirect(
			method = "runTest(Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/core/BlockPos;Lnet/minecraft/gametest/framework/MultipleTestTracker;)V",
			at = @At(
					value = "INVOKE",
					target = "Lnet/minecraft/gametest/framework/GameTestRegistry;getTestFunction(Ljava/lang/String;)Lnet/minecraft/gametest/framework/TestFunction;"
			),
			require = 0 // don't crash if this fails. non-critical
	)
	private static class_4529 create$getCorrectTestFunction(String testName,
															  class_3218 level, class_2338 pos, @Nullable class_4524 tracker) {
		class_2633 be = (class_2633) level.method_8321(pos);
		class_2487 data = be.getCustomData();
		if (!data.method_10573("CreateTestFunction", class_2520.field_33258))
			return class_4519.method_22200(testName);
		String name = data.method_10558("CreateTestFunction");
		CreateTestFunction function = CreateTestFunction.NAMES_TO_FUNCTIONS.get(name);
		if (function == null)
			throw new IllegalStateException("Structure block has CreateTestFunction attached, but test [" + name + "] doesn't exist");
		return function;
	}
}
