package com.simibubi.create.foundation.gui.menu;

import java.util.Collection;
import java.util.Collections;
import java.util.List;

import javax.annotation.ParametersAreNonnullByDefault;

import org.lwjgl.glfw.GLFW;

import com.simibubi.create.foundation.gui.AllGuiTextures;

import net.createmod.catnip.gui.TickableGuiEventListener;
import net.createmod.catnip.gui.widget.AbstractSimiWidget;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_1109;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_3414;
import net.minecraft.class_342;
import net.minecraft.class_364;
import net.minecraft.class_4068;
import net.minecraft.class_465;
import net.minecraft.class_476;
import net.minecraft.class_6379;
import net.minecraft.class_768;
import io.github.fabricators_of_create.porting_lib.mixin.accessors.client.accessor.ScreenAccessor;

@Environment(EnvType.CLIENT)
@ParametersAreNonnullByDefault
public abstract class AbstractSimiContainerScreen<T extends class_1703> extends class_465<T> {

	protected int windowXOffset, windowYOffset;

	public AbstractSimiContainerScreen(T container, class_1661 inv, class_2561 title) {
		super(container, inv, title);
	}

	/**
	 * This method must be called before {@code super.init()}!
	 */
	protected void setWindowSize(int width, int height) {
		field_2792 = width;
		field_2779 = height;
	}

	/**
	 * This method must be called before {@code super.init()}!
	 */
	protected void setWindowOffset(int xOffset, int yOffset) {
		windowXOffset = xOffset;
		windowYOffset = yOffset;
	}

	@Override
	protected void method_25426() {
		super.method_25426();
		field_2776 += windowXOffset;
		field_2800 += windowYOffset;
	}

	@Override
	protected void method_37432() {
		for (class_364 listener : method_25396()) {
			if (listener instanceof TickableGuiEventListener tickable) {
				tickable.tick();
			}
		}
	}

	@SuppressWarnings("unchecked")
	protected <W extends class_364 & class_4068 & class_6379> void addRenderableWidgets(W... widgets) {
		for (W widget : widgets) {
			method_37063(widget);
		}
	}

	protected <W extends class_364 & class_4068 & class_6379> void addRenderableWidgets(Collection<W> widgets) {
		for (W widget : widgets) {
			method_37063(widget);
		}
	}

	protected void removeWidgets(class_364... widgets) {
		for (class_364 widget : widgets) {
			method_37066(widget);
		}
	}

	protected void removeWidgets(Collection<? extends class_364> widgets) {
		for (class_364 widget : widgets) {
			method_37066(widget);
		}
	}

	@Override
	public void method_25394(class_332 graphics, int mouseX, int mouseY, float partialTicks) {
		partialTicks = field_22787.method_1488();

		method_25420(graphics);

		super.method_25394(graphics, mouseX, mouseY, partialTicks);

		renderForeground(graphics, mouseX, mouseY, partialTicks);
	}

	@Override
	protected void method_2388(class_332 graphics, int mouseX, int mouseY) {
		// no-op to prevent screen- and inventory-title from being rendered at incorrect
		// location
		// could also set this.titleX/Y and this.playerInventoryTitleX/Y to the proper
		// values instead
	}

	protected void renderForeground(class_332 graphics, int mouseX, int mouseY, float partialTicks) {
		method_2380(graphics, mouseX, mouseY);
		for (class_4068 widget : ((ScreenAccessor) this).port_lib$getRenderables()) {
			if (widget instanceof AbstractSimiWidget simiWidget && simiWidget.method_25405(mouseX, mouseY)) {
				List<class_2561> tooltip = simiWidget.getToolTip();
				if (tooltip.isEmpty())
					continue;
				int ttx = simiWidget.lockedTooltipX == -1 ? mouseX : simiWidget.lockedTooltipX + simiWidget.method_46426();
				int tty = simiWidget.lockedTooltipY == -1 ? mouseY : simiWidget.lockedTooltipY + simiWidget.method_46427();
				graphics.method_51434(field_22793, tooltip, ttx, tty);
			}
		}
	}

	public int getLeftOfCentered(int textureWidth) {
		return field_2776 - windowXOffset + (field_2792 - textureWidth) / 2;
	}

	public void renderPlayerInventory(class_332 graphics, int x, int y) {
		AllGuiTextures.PLAYER_INVENTORY.render(graphics, x, y);
		graphics.method_51439(field_22793, field_29347, x + 8, y + 6, 0x404040, false);
	}

	@Override
	public boolean method_25404(int pKeyCode, int pScanCode, int pModifiers) {
		if (method_25399() instanceof class_342 && pKeyCode != GLFW.GLFW_KEY_ESCAPE)
			return method_25399().method_25404(pKeyCode, pScanCode, pModifiers);
		return super.method_25404(pKeyCode, pScanCode, pModifiers);
	}
@Override
	public boolean method_25402(double pMouseX, double pMouseY, int pButton) {
		if (method_25399() != null && !method_25399().method_25405(pMouseX, pMouseY))
			method_25395(null);
		return super.method_25402(pMouseX, pMouseY, pButton);
	}

	@Override
	public class_364 method_25399() {
		class_364 focused = super.method_25399();
		if (focused instanceof class_339 && !((class_339) focused).method_25370())
			focused = null;
		method_25395(focused);
		return focused;
	}

	/**
	 * Used for moving JEI out of the way of extra things like block renders.
	 *
	 * @return the space that the GUI takes up outside the normal rectangle defined
	 *         by {@link class_476}.
	 */
	public List<class_768> getExtraAreas() {
		return Collections.emptyList();
	}

	@Deprecated
	protected void debugWindowArea(class_332 graphics) {
		graphics.method_25294(field_2776 + field_2792, field_2800 + field_2779, field_2776, field_2800, 0xD3D3D3D3);
	}

	@Deprecated
	protected void debugExtraAreas(class_332 graphics) {
		for (class_768 area : getExtraAreas()) {
			graphics.method_25294(area.method_3321() + area.method_3319(), area.method_3322() + area.method_3320(), area.method_3321(), area.method_3322(),
				0xD3D3D3D3);
		}
	}

	protected void playUiSound(class_3414 sound, float volume, float pitch) {
		class_310.method_1551()
			.method_1483()
			.method_4873(class_1109.method_4757(sound, pitch, volume * 0.25f));
	}

}
