package com.simibubi.create.foundation.utility.fabric;

import com.jamieswhiteshirt.reachentityattributes.ReachEntityAttributes;
import net.minecraft.class_1309;
import net.minecraft.class_1657;

public class ReachUtil {
	public static double reach(class_1309 entity) {
		boolean creative = entity instanceof class_1657 p && p.method_7337();
		return ReachEntityAttributes.getReachDistance(entity, creative ? 5 : 4.5);
	}
}
