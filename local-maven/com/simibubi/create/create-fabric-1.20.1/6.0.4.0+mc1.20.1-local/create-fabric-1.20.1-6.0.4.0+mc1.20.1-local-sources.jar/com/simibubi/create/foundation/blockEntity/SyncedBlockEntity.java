package com.simibubi.create.foundation.blockEntity;

import javax.annotation.ParametersAreNonnullByDefault;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2535;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2622;
import net.minecraft.class_2680;
import net.minecraft.class_2818;
import net.minecraft.class_3218;
import net.minecraft.class_6328;
import net.minecraft.class_7871;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import io.github.fabricators_of_create.porting_lib.block.CustomDataPacketHandlingBlockEntity;
import io.github.fabricators_of_create.porting_lib.block.CustomUpdateTagHandlingBlockEntity;

@class_6328
@ParametersAreNonnullByDefault
public abstract class SyncedBlockEntity extends class_2586 implements CustomDataPacketHandlingBlockEntity, CustomUpdateTagHandlingBlockEntity {

	public SyncedBlockEntity(class_2591<?> type, class_2338 pos, class_2680 state) {
		super(type, pos, state);
	}

	@Override
	public class_2487 method_16887() {
		return writeClient(new class_2487());
	}

	@Override
	public class_2622 method_38235() {
		return class_2622.method_38585(this);
	}

	@Override
	public void handleUpdateTag(class_2487 tag) {
		readClient(tag);
	}

	@Override
	public void onDataPacket(class_2535 connection, class_2622 packet) {
		class_2487 tag = packet.method_11290();
		readClient(tag == null ? new class_2487() : tag);
	}

	// Special handling for client update packets
	public void readClient(class_2487 tag) {
		method_11014(tag);
	}

	// Special handling for client update packets
	public class_2487 writeClient(class_2487 tag) {
		method_11007(tag);
		return tag;
	}

	public void sendData() {
		if (field_11863 instanceof class_3218 serverLevel)
			serverLevel.method_14178().method_14128(method_11016());
	}

	public void notifyUpdate() {
		method_5431();
		sendData();
	}

//	public PacketDistributor.PacketTarget packetTarget() {
//		return PacketDistributor.TRACKING_CHUNK.with(this::containedChunk);
//	}

	public class_2818 containedChunk() {
		return field_11863.method_8500(field_11867);
	}

	@Override
	public void deserializeNBT(class_2680 state, class_2487 nbt) {
		this.method_11014(nbt);
	}

	@SuppressWarnings("deprecation")
	public class_7871<class_2248> blockHolderGetter() {
		return (class_7871<class_2248>) (field_11863 != null ? field_11863.method_45448(class_7924.field_41254)
			: class_7923.field_41175.method_46771());
	}

}
