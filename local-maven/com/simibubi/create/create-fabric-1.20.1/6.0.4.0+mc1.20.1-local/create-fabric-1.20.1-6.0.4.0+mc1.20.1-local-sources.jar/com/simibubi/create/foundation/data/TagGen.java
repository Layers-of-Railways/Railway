package com.simibubi.create.foundation.data;

import java.util.List;
import java.util.function.Function;
import java.util.stream.Stream;

import org.jetbrains.annotations.NotNull;

import com.simibubi.create.AllTags;
import com.simibubi.create.foundation.data.recipe.Mods;
import com.simibubi.create.foundation.mixin.fabric.TagAppenderAccessor;
import com.tterrag.registrate.builders.BlockBuilder;
import com.tterrag.registrate.builders.ItemBuilder;
import com.tterrag.registrate.providers.RegistrateTagsProvider;
import com.tterrag.registrate.util.nullness.NonNullFunction;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricTagProvider;
import net.minecraft.class_1747;
import net.minecraft.class_2248;
import net.minecraft.class_2474;
import net.minecraft.class_2474.class_5124;
import net.minecraft.class_3481;
import net.minecraft.class_3495;
import net.minecraft.class_5321;
import net.minecraft.class_6862;
import net.minecraft.class_6880;

public class TagGen {
	public static <T extends class_2248, P> NonNullFunction<BlockBuilder<T, P>, BlockBuilder<T, P>> axeOrPickaxe() {
		return b -> b.tag(class_3481.field_33713)
			.tag(class_3481.field_33715);
	}

	public static <T extends class_2248, P> NonNullFunction<BlockBuilder<T, P>, BlockBuilder<T, P>> axeOnly() {
		return b -> b.tag(class_3481.field_33713);
	}

	public static <T extends class_2248, P> NonNullFunction<BlockBuilder<T, P>, BlockBuilder<T, P>> pickaxeOnly() {
		return b -> b.tag(class_3481.field_33715);
	}

	public static <T extends class_2248, P> NonNullFunction<BlockBuilder<T, P>, ItemBuilder<class_1747, BlockBuilder<T, P>>> tagBlockAndItem(
		String... path) {
		return b -> {
			for (String p : path)
				b.tag(AllTags.forgeBlockTag(p));
			ItemBuilder<class_1747, BlockBuilder<T, P>> item = b.item();
			for (String p : path)
				item.tag(AllTags.forgeItemTag(p));
			return item;
		};
	}

	public static <T extends class_5124<?>> T addOptional(T appender, Mods mod, String id) {
		appender.method_35922(mod.asResource(id));
		return appender;
	}

	public static <T extends class_5124<?>> T addOptional(T appender, Mods mod, List<String> ids) {
		for (String id : ids) {
			appender.method_35922(mod.asResource(id));
		}
		return appender;
	}

	public static class CreateTagsProvider<T> {

		private RegistrateTagsProvider<T> provider;
		private Function<T, class_5321<T>> keyExtractor;

		public CreateTagsProvider(RegistrateTagsProvider<T> provider, Function<T, class_6880.class_6883<T>> refExtractor) {
			this.provider = provider;
			this.keyExtractor = refExtractor.andThen(class_6880.class_6883::method_40237);
		}

		public CreateTagAppender<T> tag(class_6862<T> tag) {
			return new CreateTagAppender<>(provider.addTag(tag), keyExtractor);
		}

		// fabric: this is just used to force datagen of tags
		public void getOrCreateRawBuilder(class_6862<T> tag) {
			this.tag(tag);
		}
	}

	public static class CreateTagAppender<T> extends class_2474.class_5124<T> {

		private Function<T, class_5321<T>> keyExtractor;
		// fabric: take the fabric builder, use it to call forceAddTag instead of addTag
		private final FabricTagProvider<T>.FabricTagBuilder fabricBuilder;

		public CreateTagAppender(FabricTagProvider<T>.FabricTagBuilder fabricBuilder, Function<T, class_5321<T>> pKeyExtractor) {
			super(getBuilder(fabricBuilder));
			this.keyExtractor = pKeyExtractor;
			this.fabricBuilder = fabricBuilder;
		}

		private static class_3495 getBuilder(class_5124<?> appender) {
			return ((TagAppenderAccessor) appender).getBuilder();
		}

		public CreateTagAppender<T> add(T entry) {
			this.method_46835(this.keyExtractor.apply(entry));
			return this;
		}

		@SafeVarargs
		public final CreateTagAppender<T> add(T... entries) {
			Stream.<T>of(entries)
				.map(this.keyExtractor)
				.forEach(this::method_46835);
			return this;
		}

		@Override
		@NotNull
		public class_5124<T> method_26792(@NotNull class_6862<T> tag) {
			this.fabricBuilder.forceAddTag(tag);
			return this;
		}
	}
}
