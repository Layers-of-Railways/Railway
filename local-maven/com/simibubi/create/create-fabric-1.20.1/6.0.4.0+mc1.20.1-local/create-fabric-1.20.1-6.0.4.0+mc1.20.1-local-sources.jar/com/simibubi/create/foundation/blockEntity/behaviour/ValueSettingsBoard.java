package com.simibubi.create.foundation.blockEntity.behaviour;

import java.util.List;
import net.minecraft.class_2561;

public record ValueSettingsBoard(class_2561 title, int maxValue, int milestoneInterval, List<class_2561> rows,
	ValueSettingsFormatter formatter) {
}
