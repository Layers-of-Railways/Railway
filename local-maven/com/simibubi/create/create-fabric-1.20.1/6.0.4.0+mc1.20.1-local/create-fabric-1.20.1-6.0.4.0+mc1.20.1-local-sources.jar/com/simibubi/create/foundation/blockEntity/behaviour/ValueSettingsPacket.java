package com.simibubi.create.foundation.blockEntity.behaviour;

import javax.annotation.Nullable;
import net.minecraft.class_1268;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2540;
import net.minecraft.class_3222;
import net.minecraft.class_3965;
import com.simibubi.create.foundation.blockEntity.SmartBlockEntity;
import com.simibubi.create.foundation.blockEntity.behaviour.ValueSettingsBehaviour.ValueSettings;
import com.simibubi.create.foundation.networking.BlockEntityConfigurationPacket;

public class ValueSettingsPacket extends BlockEntityConfigurationPacket<SmartBlockEntity> {

	private int row;
	private int value;
	private class_1268 interactHand;
	private class_2350 side;
	private boolean ctrlDown;
	private int behaviourIndex;
	private class_3965 hitResult;

	public ValueSettingsPacket(class_2338 pos, int row, int value, @Nullable class_1268 interactHand,
		@Nullable class_3965 hitResult, class_2350 side, boolean ctrlDown, int behaviourIndex) {
		super(pos);
		this.row = row;
		this.value = value;
		this.interactHand = interactHand;
		this.hitResult = hitResult;
		this.side = side;
		this.ctrlDown = ctrlDown;
		this.behaviourIndex = behaviourIndex;
	}

	public ValueSettingsPacket(class_2540 buffer) {
		super(buffer);
	}

	@Override
	protected void writeSettings(class_2540 buffer) {
		buffer.method_10804(value);
		buffer.method_10804(row);
		buffer.writeBoolean(interactHand != null);
		if (interactHand != null) {
			buffer.writeBoolean(interactHand == class_1268.field_5808);
			buffer.method_17813(hitResult);
		}
		buffer.method_10804(side.ordinal());
		buffer.writeBoolean(ctrlDown);
		buffer.method_10804(behaviourIndex);
	}

	@Override
	protected void readSettings(class_2540 buffer) {
		value = buffer.method_10816();
		row = buffer.method_10816();
		if (buffer.readBoolean()) {
			interactHand = buffer.readBoolean() ? class_1268.field_5808 : class_1268.field_5810;
			hitResult = buffer.method_17814();
		}
		side = class_2350.values()[buffer.method_10816()];
		ctrlDown = buffer.readBoolean();
		behaviourIndex = buffer.method_10816();
	}

	@Override
	protected void applySettings(class_3222 player, SmartBlockEntity be) {
		for (BlockEntityBehaviour behaviour : be.getAllBehaviours()) {
			if (!(behaviour instanceof ValueSettingsBehaviour valueSettingsBehaviour))
				continue;
			if (!valueSettingsBehaviour.acceptsValueSettings())
				continue;
			if (behaviourIndex != valueSettingsBehaviour.netId())
				continue;
			if (interactHand != null) {
				valueSettingsBehaviour.onShortInteract(player, interactHand, side, hitResult);
				return;
			}
			valueSettingsBehaviour.setValueSettings(player, new ValueSettings(row, value), ctrlDown);
			return;
		}
	}

	@Override
	protected void applySettings(SmartBlockEntity be) {}

}
