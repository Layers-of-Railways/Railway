package com.simibubi.create.foundation.mixin.client;

import java.util.Set;
import java.util.SortedSet;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3191;
import net.minecraft.class_638;
import net.minecraft.class_761;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

import com.google.common.collect.Sets;
import com.simibubi.create.foundation.block.render.BlockDestructionProgressExtension;
import com.simibubi.create.foundation.block.render.MultiPosDestructionHandler;

import it.unimi.dsi.fastutil.longs.Long2ObjectMap;

@Mixin(class_761.class)
public class LevelRendererMixin {
	@Shadow
	private class_638 level;

	@Shadow
	@Final
	private Long2ObjectMap<SortedSet<class_3191>> destructionProgress;

	@Inject(method = "destroyBlockProgress(ILnet/minecraft/core/BlockPos;I)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/server/level/BlockDestructionProgress;updateTick(I)V", shift = Shift.AFTER), locals = LocalCapture.CAPTURE_FAILHARD)
	private void create$onDestroyBlockProgress(int breakerId, class_2338 pos, int progress, CallbackInfo ci, class_3191 progressObj) {
		class_2680 state = level.method_8320(pos);
		if (state.method_26204() instanceof MultiPosDestructionHandler handler) {
			Set<class_2338> extraPositions = handler.getExtraPositions(level, pos, state, progress);
			if (extraPositions != null) {
				extraPositions.remove(pos);
				((BlockDestructionProgressExtension) progressObj).create$setExtraPositions(extraPositions);
				for (class_2338 extraPos : extraPositions) {
					destructionProgress.computeIfAbsent(extraPos.method_10063(), l -> Sets.newTreeSet()).add(progressObj);
				}
			}
		}
	}

	@Inject(method = "removeProgress(Lnet/minecraft/server/level/BlockDestructionProgress;)V", at = @At("RETURN"))
	private void create$onRemoveProgress(class_3191 progress, CallbackInfo ci) {
		Set<class_2338> extraPositions = ((BlockDestructionProgressExtension) progress).create$getExtraPositions();
		if (extraPositions != null) {
			for (class_2338 extraPos : extraPositions) {
				long l = extraPos.method_10063();
				Set<class_3191> set = destructionProgress.get(l);
				if (set != null) {
					set.remove(progress);
					if (set.isEmpty()) {
						destructionProgress.remove(l);
					}
				}
			}
		}
	}
}
