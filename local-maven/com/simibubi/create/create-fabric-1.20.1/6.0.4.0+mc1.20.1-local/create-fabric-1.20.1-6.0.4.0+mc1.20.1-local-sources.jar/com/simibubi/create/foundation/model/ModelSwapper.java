package com.simibubi.create.foundation.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.simibubi.create.foundation.block.render.CustomBlockModels;
import com.simibubi.create.foundation.item.render.CustomItemModels;
import com.simibubi.create.foundation.item.render.CustomRenderedItemModel;
import com.simibubi.create.foundation.item.render.CustomRenderedItems;
import com.tterrag.registrate.util.nullness.NonNullFunction;

import net.createmod.catnip.platform.CatnipServices;
import net.fabricmc.fabric.api.client.model.loading.v1.ModelLoadingPlugin;
import net.fabricmc.fabric.api.client.model.loading.v1.ModelModifier.AfterBake;
import net.minecraft.class_1087;
import net.minecraft.class_1091;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_773;

public class ModelSwapper implements AfterBake {

	protected CustomBlockModels customBlockModels = new CustomBlockModels();
	protected CustomItemModels customItemModels = new CustomItemModels();

	private Map<class_2960, NonNullFunction<class_1087, ? extends class_1087>> swaps = null;

	public CustomBlockModels getCustomBlockModels() {
		return customBlockModels;
	}

	public CustomItemModels getCustomItemModels() {
		return customItemModels;
	}

	public void registerListeners() {
		ModelLoadingPlugin.register(ctx -> ctx.modifyModelAfterBake().register(this));
	}

	@Override
	public class_1087 modifyModelAfterBake(class_1087 model, Context context) {
		if (swaps == null)
			collectSwaps();
		NonNullFunction<class_1087, ? extends class_1087> swap = swaps.get(context.id());
		return swap != null ? swap.apply(model) : model;
	}

	private void collectSwaps() {
		this.swaps = new HashMap<>();

		customBlockModels.forEach((block, swapper) -> getAllBlockStateModelLocations(block).forEach(id -> swaps.put(id, swapper)));
		customItemModels.forEach((item, swapper) -> swaps.put(getItemModelLocation(item), swapper));
		CustomRenderedItems.forEach(item -> swaps.put(getItemModelLocation(item), CustomRenderedItemModel::new));
	}

	public static List<class_1091> getAllBlockStateModelLocations(class_2248 block) {
		List<class_1091> models = new ArrayList<>();
		class_2960 blockRl = CatnipServices.REGISTRIES.getKeyOrThrow(block);
		block.method_9595()
			.method_11662()
			.forEach(state -> {
				models.add(class_773.method_3336(blockRl, state));
			});
		return models;
	}

	public static class_1091 getItemModelLocation(class_1792 item) {
		return new class_1091(CatnipServices.REGISTRIES.getKeyOrThrow(item), "inventory");
	}

}
