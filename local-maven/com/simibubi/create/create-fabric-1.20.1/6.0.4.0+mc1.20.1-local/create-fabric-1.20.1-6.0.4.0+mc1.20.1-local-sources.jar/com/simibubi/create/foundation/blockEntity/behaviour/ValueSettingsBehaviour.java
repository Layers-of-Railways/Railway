package com.simibubi.create.foundation.blockEntity.behaviour;

import com.simibubi.create.content.equipment.clipboard.ClipboardCloneable;
import com.simibubi.create.foundation.utility.CreateLang;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3965;
import net.minecraft.class_5250;

public interface ValueSettingsBehaviour extends ClipboardCloneable {

	public static record ValueSettings(int row, int value) {

		public class_5250 format() {
			return CreateLang.number(value)
				.component();
		}

	};

	public boolean testHit(class_243 hit);

	public boolean isActive();

	default boolean onlyVisibleWithWrench() {
		return false;
	}

	default void newSettingHovered(ValueSettings valueSetting) {}

	public ValueBoxTransform getSlotPositioning();

	public ValueSettingsBoard createBoard(class_1657 player, class_3965 hitResult);

	public void setValueSettings(class_1657 player, ValueSettings valueSetting, boolean ctrlDown);

	public ValueSettings getValueSettings();

	default boolean acceptsValueSettings() {
		return true;
	}

	@Override
	default String getClipboardKey() {
		return "Settings";
	}

	@Override
	default boolean writeToClipboard(class_2487 tag, class_2350 side) {
		if (!acceptsValueSettings())
			return false;
		ValueSettings valueSettings = getValueSettings();
		tag.method_10569("Value", valueSettings.value());
		tag.method_10569("Row", valueSettings.row());
		return true;
	}

	@Override
	default boolean readFromClipboard(class_2487 tag, class_1657 player, class_2350 side, boolean simulate) {
		if (!acceptsValueSettings())
			return false;
		if (!tag.method_10545("Value") || !tag.method_10545("Row"))
			return false;
		if (simulate)
			return true;
		setValueSettings(player, new ValueSettings(tag.method_10550("Row"), tag.method_10550("Value")), false);
		return true;
	}

	default void playFeedbackSound(BlockEntityBehaviour origin) {
		origin.getWorld()
			.method_8396(null, origin.getPos(), class_3417.field_14667, class_3419.field_15245, 0.25f, 2f);
		origin.getWorld()
			.method_8396(null, origin.getPos(), class_3417.field_18308.comp_349(), class_3419.field_15245, 0.03f,
				1.125f);
	}

	default void onShortInteract(class_1657 player, class_1268 hand, class_2350 side, class_3965 hitResult) {}

	default boolean bypassesInput(class_1799 mainhandItem) {
		return false;
	}

	default boolean mayInteract(class_1657 player) {
		return true;
	}

	default int netId() {
		return 0;
	}

}
