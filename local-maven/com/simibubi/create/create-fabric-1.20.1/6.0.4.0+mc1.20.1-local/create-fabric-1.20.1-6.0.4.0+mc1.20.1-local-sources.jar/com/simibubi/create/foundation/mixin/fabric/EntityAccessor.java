package com.simibubi.create.foundation.mixin.fabric;

import net.minecraft.class_1297;
import net.minecraft.class_1937;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_1297.class)
public interface EntityAccessor {
	@Invoker
	void invokeSetLevel(class_1937 level);
}
