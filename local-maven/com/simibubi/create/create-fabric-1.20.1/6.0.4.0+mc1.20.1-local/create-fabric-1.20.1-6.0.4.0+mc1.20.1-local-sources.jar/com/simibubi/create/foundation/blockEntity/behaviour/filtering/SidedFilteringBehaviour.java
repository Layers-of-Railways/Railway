package com.simibubi.create.foundation.blockEntity.behaviour.filtering;

import java.util.HashSet;
import java.util.IdentityHashMap;
import java.util.Map;
import java.util.Set;
import java.util.function.BiFunction;
import java.util.function.Predicate;

import com.simibubi.create.content.schematics.requirement.ItemRequirement;
import com.simibubi.create.foundation.blockEntity.SmartBlockEntity;
import com.simibubi.create.foundation.blockEntity.behaviour.ValueBoxTransform;
import com.simibubi.create.foundation.blockEntity.behaviour.ValueBoxTransform.Sided;

import net.createmod.catnip.data.Iterate;
import net.createmod.catnip.nbt.NBTHelper;
import net.minecraft.class_1799;
import net.minecraft.class_1936;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2520;
import net.minecraft.class_2680;

public class SidedFilteringBehaviour extends FilteringBehaviour {

	Map<class_2350, FilteringBehaviour> sidedFilters;
	private BiFunction<class_2350, FilteringBehaviour, FilteringBehaviour> filterFactory;
	private Predicate<class_2350> validDirections;

	public SidedFilteringBehaviour(SmartBlockEntity be, ValueBoxTransform.Sided sidedSlot,
		BiFunction<class_2350, FilteringBehaviour, FilteringBehaviour> filterFactory,
		Predicate<class_2350> validDirections) {
		super(be, sidedSlot);
		this.filterFactory = filterFactory;
		this.validDirections = validDirections;
		sidedFilters = new IdentityHashMap<>();
		updateFilterPresence();
	}

	@Override
	public void initialize() {
		super.initialize();
	}

	public FilteringBehaviour get(class_2350 side) {
		return sidedFilters.get(side);
	}

	public void updateFilterPresence() {
		Set<class_2350> valid = new HashSet<>();
		for (class_2350 d : Iterate.directions)
			if (validDirections.test(d))
				valid.add(d);
		for (class_2350 d : Iterate.directions)
			if (valid.contains(d)) {
				if (!sidedFilters.containsKey(d))
					sidedFilters.put(d, filterFactory.apply(d, new FilteringBehaviour(blockEntity, slotPositioning)));
			} else if (sidedFilters.containsKey(d))
				removeFilter(d);
	}

	@Override
	public void write(class_2487 nbt, boolean clientPacket) {
		nbt.method_10566("Filters", NBTHelper.writeCompoundList(sidedFilters.entrySet(), entry -> {
			class_2487 compound = new class_2487();
			compound.method_10569("Side", entry.getKey()
				.method_10146());
			entry.getValue()
				.write(compound, clientPacket);
			return compound;
		}));
		super.write(nbt, clientPacket);
	}

	@Override
	public void read(class_2487 nbt, boolean clientPacket) {
		NBTHelper.iterateCompoundList(nbt.method_10554("Filters", class_2520.field_33260), compound -> {
			class_2350 face = class_2350.method_10143(compound.method_10550("Side"));
			if (sidedFilters.containsKey(face))
				sidedFilters.get(face)
					.read(compound, clientPacket);
		});
		super.read(nbt, clientPacket);
	}

	@Override
	public void tick() {
		super.tick();
		sidedFilters.values()
			.forEach(FilteringBehaviour::tick);
	}

	@Override
	public boolean setFilter(class_2350 side, class_1799 stack) {
		if (!sidedFilters.containsKey(side))
			return true;
		sidedFilters.get(side)
			.setFilter(stack);
		return true;
	}

	@Override
	public class_1799 getFilter(class_2350 side) {
		if (!sidedFilters.containsKey(side))
			return class_1799.field_8037;
		return sidedFilters.get(side)
			.getFilter();
	}

	public boolean test(class_2350 side, class_1799 stack) {
		if (!sidedFilters.containsKey(side))
			return true;
		return sidedFilters.get(side)
			.test(stack);
	}

	@Override
	public void destroy() {
		sidedFilters.values()
			.forEach(FilteringBehaviour::destroy);
		super.destroy();
	}

	@Override
	public ItemRequirement getRequiredItems() {
		return sidedFilters.values()
			.stream()
			.reduce(ItemRequirement.NONE, (a, b) -> a.union(b.getRequiredItems()), (a, b) -> a.union(b));
	}

	public void removeFilter(class_2350 side) {
		if (!sidedFilters.containsKey(side))
			return;
		sidedFilters.remove(side)
			.destroy();
	}

	public boolean testHit(class_1936 level, class_2338 pos, class_2350 direction, class_243 hit) {
		ValueBoxTransform.Sided sidedPositioning = (Sided) slotPositioning;
		class_2680 state = blockEntity.method_11010();
		class_243 localHit = hit.method_1020(class_243.method_24954(blockEntity.method_11016()));
		return sidedPositioning.fromSide(direction)
			.testHit(level, pos, state, localHit);
	}

}
