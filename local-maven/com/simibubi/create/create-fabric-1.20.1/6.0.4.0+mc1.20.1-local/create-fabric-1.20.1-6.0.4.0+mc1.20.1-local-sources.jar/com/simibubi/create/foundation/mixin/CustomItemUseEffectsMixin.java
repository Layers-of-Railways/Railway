package com.simibubi.create.foundation.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import com.simibubi.create.foundation.item.CustomUseEffectsItem;

import net.createmod.catnip.data.TriState;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;

@Mixin(class_1309.class)
public abstract class CustomItemUseEffectsMixin extends class_1297 {
	private CustomItemUseEffectsMixin(class_1299<?> entityType, class_1937 level) {
		super(entityType, level);
	}

	@Shadow
	public abstract class_1799 getUseItem();

	@Inject(method = "shouldTriggerItemUseEffects()Z", at = @At("HEAD"), cancellable = true)
	private void create$onShouldTriggerUseEffects(CallbackInfoReturnable<Boolean> cir) {
		class_1799 using = getUseItem();
		class_1792 item = using.method_7909();
		if (item instanceof CustomUseEffectsItem handler) {
			TriState result = handler.shouldTriggerUseEffects(using, (class_1309) (Object) this);
			if (result != TriState.DEFAULT) {
				cir.setReturnValue(result.getValue());
			}
		}
	}

	@Inject(method = "triggerItemUseEffects(Lnet/minecraft/world/item/ItemStack;I)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/item/ItemStack;getUseAnimation()Lnet/minecraft/world/item/UseAnim;", ordinal = 0), cancellable = true)
	private void create$onTriggerUseEffects(class_1799 stack, int count, CallbackInfo ci) {
		class_1792 item = stack.method_7909();
		if (item instanceof CustomUseEffectsItem handler) {
			if (handler.triggerUseEffects(stack, (class_1309) (Object) this, count, field_5974)) {
				ci.cancel();
			}
		}
	}
}
