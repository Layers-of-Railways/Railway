package com.simibubi.create.infrastructure.gametest;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

import org.apache.commons.lang3.tuple.MutablePair;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;

import com.simibubi.create.AllBlockEntityTypes;
import com.simibubi.create.content.contraptions.Contraption;
import com.simibubi.create.content.contraptions.actors.contraptionControls.ContraptionControlsMovement;
import com.simibubi.create.content.contraptions.actors.contraptionControls.ContraptionControlsMovingInteraction;
import com.simibubi.create.content.contraptions.actors.seat.SeatBlock;
import com.simibubi.create.content.contraptions.behaviour.MovementContext;
import com.simibubi.create.content.kinetics.gauge.SpeedGaugeBlockEntity;
import com.simibubi.create.content.kinetics.gauge.StressGaugeBlockEntity;
import com.simibubi.create.content.logistics.tunnel.BrassTunnelBlockEntity.SelectionMode;
import com.simibubi.create.content.redstone.nixieTube.NixieTubeBlockEntity;
import com.simibubi.create.foundation.blockEntity.IMultiBlockEntityContainer;
import com.simibubi.create.foundation.blockEntity.behaviour.BehaviourType;
import com.simibubi.create.foundation.blockEntity.behaviour.BlockEntityBehaviour;
import com.simibubi.create.foundation.blockEntity.behaviour.scrollValue.ScrollOptionBehaviour;
import com.simibubi.create.foundation.blockEntity.behaviour.scrollValue.ScrollValueBehaviour;
import com.simibubi.create.foundation.item.ItemHelper;
import com.simibubi.create.foundation.mixin.accessor.GameTestHelperAccessor;

import it.unimi.dsi.fastutil.objects.Object2LongArrayMap;
import it.unimi.dsi.fastutil.objects.Object2LongMap;
import it.unimi.dsi.fastutil.objects.Object2LongMap.Entry;
import net.createmod.catnip.platform.CatnipServices;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariant;
import net.fabricmc.fabric.api.transfer.v1.item.ItemVariant;
import net.fabricmc.fabric.api.transfer.v1.storage.Storage;
import net.fabricmc.fabric.api.transfer.v1.storage.StorageView;
import net.fabricmc.fabric.api.transfer.v1.transaction.Transaction;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1542;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1935;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2401;
import net.minecraft.class_243;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_3218;
import net.minecraft.class_3341;
import net.minecraft.class_3499.class_3501;
import net.minecraft.class_4516;
import net.minecraft.class_4517;
import net.minecraft.class_7923;
import io.github.fabricators_of_create.porting_lib.fluids.FluidStack;
import io.github.fabricators_of_create.porting_lib.transfer.TransferUtil;
import io.github.fabricators_of_create.porting_lib.transfer.item.ItemHandlerHelper;

/**
 * A helper class expanding the functionality of {@link class_4516}.
 * This class may replace the default helper parameter if a test is registered through {@link CreateTestFunction}.
 */
public class CreateGameTestHelper extends class_4516 {
	public static final int TICKS_PER_SECOND = 20;
	public static final int TEN_SECONDS = 10 * TICKS_PER_SECOND;
	public static final int FIFTEEN_SECONDS = 15 * TICKS_PER_SECOND;
	public static final int TWENTY_SECONDS = 20 * TICKS_PER_SECOND;

	private CreateGameTestHelper(class_4517 testInfo) {
		super(testInfo);
	}

	public static CreateGameTestHelper of(class_4516 original) {
		GameTestHelperAccessor access = (GameTestHelperAccessor) original;
		CreateGameTestHelper helper = new CreateGameTestHelper(access.getTestInfo());
		//noinspection DataFlowIssue // accessor applied at runtime
		GameTestHelperAccessor newAccess = (GameTestHelperAccessor) helper;
		newAccess.setFinalCheckAdded(access.getFinalCheckAdded());
		return helper;
	}

	// blocks

	/**
	 * Flip the direction of any block with the {@link class_2741#field_12525} property.
	 */
	public void flipBlock(class_2338 pos) {
		class_2680 original = method_35980(pos);
		if (!original.method_28498(class_2741.field_12525))
			method_35995("FACING property not in block: " + class_7923.field_41175.method_10206(original.method_26204()));
		class_2350 facing = original.method_11654(class_2741.field_12525);
		class_2680 reversed = original.method_11657(class_2741.field_12525, facing.method_10153());
		method_35986(pos, reversed);
	}

	public void assertNixiePower(class_2338 pos, int strength) {
		NixieTubeBlockEntity nixie = getBlockEntity(AllBlockEntityTypes.NIXIE_TUBE.get(), pos);
		int actualStrength = nixie.getRedstoneStrength();
		if (actualStrength != strength)
			method_35995("Expected nixie tube at %s to have power of %s, got %s".formatted(pos, strength, actualStrength));
	}

	/**
	 * Turn off a lever.
	 */
	public void powerLever(class_2338 pos) {
		method_35972(class_2246.field_10363, pos);
		if (!method_35980(pos).method_11654(class_2401.field_11265)) {
			method_36039(pos);
		}
	}

	/**
	 * Turn on a lever.
	 */
	public void unpowerLever(class_2338 pos) {
		method_35972(class_2246.field_10363, pos);
		if (method_35980(pos).method_11654(class_2401.field_11265)) {
			method_36039(pos);
		}
	}

	/**
	 * Set the {@link SelectionMode} of a belt tunnel at the given position.
	 * @param pos
	 * @param mode
	 */
	public void setTunnelMode(class_2338 pos, SelectionMode mode) {
		ScrollValueBehaviour behavior = getBehavior(pos, ScrollOptionBehaviour.TYPE);
		behavior.setValue(mode.ordinal());
	}

	public void assertSpeedometerSpeed(class_2338 speedometer, float value) {
		SpeedGaugeBlockEntity be = getBlockEntity(AllBlockEntityTypes.SPEEDOMETER.get(), speedometer);
		assertInRange(be.getSpeed(), value - 0.01, value + 0.01);
	}

	public void assertStressometerCapacity(class_2338 stressometer, float value) {
		StressGaugeBlockEntity be = getBlockEntity(AllBlockEntityTypes.STRESSOMETER.get(), stressometer);
		assertInRange(be.getNetworkCapacity(), value - 0.01, value + 0.01);
	}

	public void toggleActorsOfType(Contraption contraption, class_1935 item) {
		AtomicBoolean toggled = new AtomicBoolean(false);
		contraption.getInteractors().forEach((localPos, behavior) -> {
			if (toggled.get() || !(behavior instanceof ContraptionControlsMovingInteraction controls))
				return;
			MutablePair<class_3501, MovementContext> actor = contraption.getActorAt(localPos);
			if (actor == null)
				return;
			class_1799 filter = ContraptionControlsMovement.getFilter(actor.right);
			if (filter != null && filter.method_31574(item.method_8389())) {
				controls.handlePlayerInteraction(
						method_36021(), class_1268.field_5808, localPos, contraption.entity
				);
				toggled.set(true);
			}
		});
	}

	// block entities

	/**
	 * Get the block entity of the expected type. If the type does not match, this fails the test.
	 */
	public <T extends class_2586> T getBlockEntity(class_2591<T> type, class_2338 pos) {
		class_2586 be = method_36014(pos);
		class_2591<?> actualType = be == null ? null : be.method_11017();
		if (actualType != type) {
			String actualId = actualType == null ? "null" : CatnipServices.REGISTRIES.getKeyOrThrow(actualType).toString();
			String error = "Expected block entity at pos [%s] with type [%s], got [%s]".formatted(
					pos, CatnipServices.REGISTRIES.getKeyOrThrow(type), actualId
			);
			method_35995(error);
		}
		return (T) be;
	}

	/**
	 * Given any segment of an {@link IMultiBlockEntityContainer}, get the controller for it.
	 */
	public <T extends class_2586 & IMultiBlockEntityContainer> T getControllerBlockEntity(class_2591<T> type, class_2338 anySegment) {
		T be = getBlockEntity(type, anySegment).getControllerBE();
		if (be == null)
			method_35995("Could not get block entity controller with type [%s] from pos [%s]".formatted(CatnipServices.REGISTRIES.getKeyOrThrow(type), anySegment));
		return be;
	}

	/**
	 * Get the expected {@link BlockEntityBehaviour} from the given position, failing if not present.
	 */
	public <T extends BlockEntityBehaviour> T getBehavior(class_2338 pos, BehaviourType<T> type) {
		T behavior = BlockEntityBehaviour.get(method_35943(), method_36052(pos), type);
		if (behavior == null)
			method_35995("Behavior at " + pos + " missing, expected " + type.getName());
		return behavior;
	}

	// entities

	/**
	 * Spawn an item entity at the given position with no velocity.
	 */
	public class_1542 spawnItem(class_2338 pos, class_1799 stack) {
		class_243 spawn = class_243.method_24953(method_36052(pos));
		class_3218 level = method_35943();
		class_1542 item = new class_1542(level, spawn.field_1352, spawn.field_1351, spawn.field_1350, stack, 0, 0, 0);
		level.method_8649(item);
		return item;
	}

	public <T extends class_1297> T spawnSeated(class_1299<T> type, class_2338 pos) {
		T entity = this.method_35964(type, pos);
		SeatBlock.sitDown(this.method_35943(), this.method_36052(pos), entity);
		return entity;
	}

	/**
	 * Spawn item entities given an item and amount. The amount will be split into multiple entities if
	 * larger than the item's max stack size.
	 */
	public void spawnItems(class_2338 pos, class_1792 item, int amount) {
		while (amount > 0) {
			int toSpawn = Math.min(amount, item.method_7882());
			amount -= toSpawn;
			class_1799 stack = new class_1799(item, toSpawn);
			spawnItem(pos, stack);
		}
	}

	/**
	 * Get the first entity found at the given position.
	 */
	public <T extends class_1297> T getFirstEntity(class_1299<T> type, class_2338 pos) {
		List<T> list = getEntitiesBetween(type, pos.method_10095().method_10078().method_10084(), pos.method_10072().method_10067().method_10074());
		if (list.isEmpty())
			method_35995("No entities at pos: " + pos);
		return list.get(0);
	}

	/**
	 * Get a list of all entities between two positions, inclusive.
	 */
	public <T extends class_1297> List<T> getEntitiesBetween(class_1299<T> type, class_2338 pos1, class_2338 pos2) {
		class_3341 box = class_3341.method_34390(method_36052(pos1), method_36052(pos2));
		List<? extends T> entities = method_35943().method_18198(type, e -> box.method_14662(e.method_24515()));
		return (List<T>) entities;
	}


	// transfer - fluids

	public Storage<FluidVariant> fluidStorageAt(class_2338 pos) {
		Storage<FluidVariant> storage = TransferUtil.getFluidStorage(method_35943(), method_36052(pos));
		if (storage == null)
			method_35995("storage not present");
		return storage;
	}

	/**
	 * Get the content of the tank at the pos.
	 * content is determined by what the tank allows to be extracted.
	 */
	public FluidStack getTankContents(class_2338 tank) {
		Storage<FluidVariant> storage = fluidStorageAt(tank);
		return TransferUtil.firstOrEmpty(storage);
	}

	/**
	 * Get the total capacity of a tank at the given position.
	 */
	public long getTankCapacity(class_2338 pos) {
		Storage<FluidVariant> storage = fluidStorageAt(pos);
		return TransferUtil.totalCapacity(storage);
	}

	/**
	 * Get the total fluid amount across all fluid tanks at the given positions.
	 */
	public long getFluidInTanks(class_2338... tanks) {
		long total = 0;
		for (class_2338 tank : tanks) {
			total += getTankContents(tank).getAmount();
		}
		return total;
	}

	/**
	 * Assert that the given fluid stack is present in the given tank. The tank might also hold more than the fluid.
	 */
	public void assertFluidPresent(FluidStack fluid, class_2338 pos) {
		FluidStack contained = getTankContents(pos);
		if (!fluid.isFluidEqual(contained))
			method_35995("Different fluids");
		if (fluid.getAmount() != contained.getAmount())
			method_35995("Different amounts");
	}

	/**
	 * Assert that the given tank holds no fluid.
	 */
	public void assertTankEmpty(class_2338 pos) {
		assertFluidPresent(FluidStack.EMPTY, pos);
	}

	public void assertTanksEmpty(class_2338... tanks) {
		for (class_2338 tank : tanks) {
			assertTankEmpty(tank);
		}
	}

	// transfer - items

	public Storage<ItemVariant> itemStorageAt(class_2338 pos) {
		Storage<ItemVariant> storage = TransferUtil.getItemStorage(method_35943(), method_36052(pos));
		if (storage == null)
			method_35995("storage not present");
		return storage;
	}

	/**
	 * Get a map of contained items to their amounts. This is not safe for NBT!
	 */
	public Object2LongMap<class_1792> getItemContent(class_2338 pos) {
		Storage<ItemVariant> storage = itemStorageAt(pos);
		Object2LongMap<class_1792> map = new Object2LongArrayMap<>();
		try (Transaction t = TransferUtil.getTransaction()) {
			for (StorageView<ItemVariant> view : storage.nonEmptyViews()) {
				ItemVariant resource = view.getResource();
				class_1792 item = resource.getItem();
				long amount = map.getLong(item);
				amount += view.extract(resource, Long.MAX_VALUE, t);
				map.put(item, amount);
			}
		}
		return map;
	}

	/**
	 * Get the combined total of all ItemStacks inside the inventory.
	 */
	public long getTotalItems(class_2338 pos) {
		Storage<ItemVariant> storage = itemStorageAt(pos);
		try (Transaction t = TransferUtil.getTransaction()) {
			return TransferUtil.extractAllAsStacks(storage).stream().mapToLong(class_1799::method_7947).sum();
		}
	}

	/**
	 * Of the provided items, assert that at least one is present in the given inventory.
	 */
	public void assertAnyContained(class_2338 pos, class_1792... items) {
		Storage<ItemVariant> storage = itemStorageAt(pos);
		boolean noneFound = true;
		try (Transaction t = TransferUtil.getTransaction()) {
			for (class_1792 item : items) {
				if (storage.extract(ItemVariant.of(item), 1, t) > 0) {
					noneFound = false;
					break;
				}
			}
		}
		if (noneFound)
			method_35995("No matching items " + Arrays.toString(items) + " found in handler at pos: " + pos);
	}

	/**
	 * Assert that the inventory contains all the provided content.
	 */
	public void assertContentPresent(Object2LongMap<class_1792> content, class_2338 pos) {
		Storage<ItemVariant> storage = itemStorageAt(pos);
		Object2LongMap<class_1792> missing = new Object2LongArrayMap<>();
		try (Transaction t = TransferUtil.getTransaction()) {
			for (Entry<class_1792> entry : content.object2LongEntrySet()) {
				class_1792 item = entry.getKey();
				long amount = entry.getLongValue();
				long extracted = storage.extract(ItemVariant.of(item), amount, t);
				long remaining = amount - extracted;
				if (remaining > 0) {
					missing.put(item, remaining);
				}
			}
		}
		if (!missing.isEmpty())
			method_35995("Storage missing content: " + missing + ", expected: " + content);
	}

	/**
	 * Assert that all the given inventories hold no items.
	 */
	public void assertContainersEmpty(List<class_2338> positions) {
		for (class_2338 pos : positions) {
			method_36047(pos);
		}
	}

	/**
	 * Assert that the given inventory holds no items.
	 */
	@Override
	public void method_36047(@NotNull class_2338 pos) {
		Storage<ItemVariant> storage = itemStorageAt(pos);
		storage.nonEmptyViews().forEach(view -> method_35995("Storage not empty"));
	}

	/** @see CreateGameTestHelper#assertContainerContains(class_2338, class_1799) */
	public void assertContainerContains(class_2338 pos, class_1935 item) {
		method_35983(pos, item.method_8389());
	}

	/** @see CreateGameTestHelper#assertContainerContains(class_2338, class_1799) */
	@Override
	public void method_35983(@NotNull class_2338 pos, @NotNull class_1792 item) {
		assertContainerContains(pos, new class_1799(item));
	}

	/**
	 * Assert that the inventory holds at least the given ItemStack. It may also hold more than the stack.
	 */
	public void assertContainerContains(class_2338 pos, class_1799 item) {
		Storage<ItemVariant> storage = itemStorageAt(pos);
		class_1799 extracted = ItemHelper.extract(storage, stack -> ItemHandlerHelper.canItemStacksStack(stack, item), item.method_7947(), true);
		if (extracted.method_7960())
			method_35995("item not present: " + item);
	}

	// time

	/**
	 * Fail unless the desired number seconds have passed since test start.
	 */
	public void assertSecondsPassed(int seconds) {
		if (method_36045() < (long) seconds * TICKS_PER_SECOND)
			method_35995("Waiting for %s seconds to pass".formatted(seconds));
	}

	/**
	 * Get the total number of seconds that have passed since test start.
	 */
	public long secondsPassed() {
		return method_36045() % 20;
	}

	/**
	 * Run an action later, once enough time has passed.
	 */
	public void whenSecondsPassed(int seconds, Runnable run) {
		method_36003((long) seconds * TICKS_PER_SECOND, run);
	}

	// numbers

	/**
	 * Assert that a number is less than 1 away from its expected value
	 */
	public void assertCloseEnoughTo(double value, double expected) {
		assertInRange(value, expected - 1, expected + 1);
	}

	public void assertInRange(double value, double min, double max) {
		if (value < min)
			method_35995("Value %s below expected min of %s".formatted(value, min));
		if (value > max)
			method_35995("Value %s greater than expected max of %s".formatted(value, max));
	}

	// misc

	@Contract("_->fail") // make IDEA happier
	@Override
	public void method_35995(@NotNull String exceptionMessage) {
		super.method_35995(exceptionMessage);
	}
}
