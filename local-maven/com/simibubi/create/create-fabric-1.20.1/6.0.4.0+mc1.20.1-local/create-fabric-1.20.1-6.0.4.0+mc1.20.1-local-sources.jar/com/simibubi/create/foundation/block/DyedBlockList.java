package com.simibubi.create.foundation.block;

import java.util.Arrays;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.function.Function;
import net.minecraft.class_1767;
import net.minecraft.class_2248;
import com.tterrag.registrate.util.entry.BlockEntry;

public class DyedBlockList<T extends class_2248> implements Iterable<BlockEntry<T>> {

	private static final int COLOR_AMOUNT = class_1767.values().length;

	private final BlockEntry<?>[] values = new BlockEntry<?>[COLOR_AMOUNT];

	public DyedBlockList(Function<class_1767, BlockEntry<? extends T>> filler) {
		for (class_1767 color : class_1767.values()) {
			values[color.ordinal()] = filler.apply(color);
		}
	}

	@SuppressWarnings("unchecked")
	public BlockEntry<T> get(class_1767 color) {
		return (BlockEntry<T>) values[color.ordinal()];
	}

	public boolean contains(class_2248 block) {
		for (BlockEntry<?> entry : values) {
			if (entry.is(block)) {
				return true;
			}
		}
		return false;
	}

	@SuppressWarnings("unchecked")
	public BlockEntry<T>[] toArray() {
		return (BlockEntry<T>[]) Arrays.copyOf(values, values.length);
	}

	@Override
	public Iterator<BlockEntry<T>> iterator() {
		return new Iterator<>() {
			private int index = 0;

			@Override
			public boolean hasNext() {
				return index < values.length;
			}

			@SuppressWarnings("unchecked")
			@Override
			public BlockEntry<T> next() {
				if (!hasNext())
					throw new NoSuchElementException();
				return (BlockEntry<T>) values[index++];
			}
		};
	}

}
