package com.simibubi.create.api.data.recipe;

import java.util.function.Supplier;
import net.minecraft.class_1792;
import net.minecraft.class_1935;
import net.minecraft.class_2248;
import net.minecraft.class_7784;
import com.simibubi.create.AllRecipeTypes;
import com.tterrag.registrate.util.entry.ItemEntry;

/**
 * The base class for Washing recipe generation.
 * Addons should extend this and use the {@link ProcessingRecipeGen#create} methods
 * or the helper methods contained in this class to make recipes.
 * For an example of how you might do this, see Create's implementation: {@link com.simibubi.create.foundation.data.recipe.CreateWashingRecipeGen}.
 * Needs to be added to a registered recipe provider to do anything, see {@link com.simibubi.create.foundation.data.recipe.CreateRecipeProvider}
 */
public abstract class WashingRecipeGen extends ProcessingRecipeGen {

	public GeneratedRecipe convert(class_2248 block, class_2248 result) {
		return create(() -> block, b -> b.output(result));
	}

	public GeneratedRecipe crushedOre(ItemEntry<class_1792> crushed, Supplier<class_1935> nugget, Supplier<class_1935> secondary,
																 float secondaryChance) {
		return create(crushed::get, b -> b.output(nugget.get(), 9)
			.output(secondaryChance, secondary.get(), 1));
	}

	public WashingRecipeGen(class_7784 output, String defaultNamespace) {
		super(output, defaultNamespace);
	}

	@Override
	protected AllRecipeTypes getRecipeType() {
		return AllRecipeTypes.SPLASHING;
	}

}
