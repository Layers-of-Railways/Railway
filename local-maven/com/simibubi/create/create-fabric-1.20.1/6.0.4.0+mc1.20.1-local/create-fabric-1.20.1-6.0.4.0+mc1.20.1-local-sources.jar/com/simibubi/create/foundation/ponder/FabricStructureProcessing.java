package com.simibubi.create.foundation.ponder;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import org.jetbrains.annotations.ApiStatus.Internal;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import com.mojang.serialization.Codec;
import com.simibubi.create.AllBlocks;
import com.simibubi.create.Create;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidConstants;
import net.minecraft.class_2338;
import net.minecraft.class_2378;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2520;
import net.minecraft.class_2960;
import net.minecraft.class_3491;
import net.minecraft.class_3492;
import net.minecraft.class_3499;
import net.minecraft.class_3499.class_3501;
import net.minecraft.class_3828;
import net.minecraft.class_4538;
import net.minecraft.class_7923;
import io.github.fabricators_of_create.porting_lib.fluids.FluidStack;

/**
 * Processing for structures exported on Forge to allow using the same ones on Forge and Fabric.
 */
public class FabricStructureProcessing {
	public static final Codec<Processor> PROCESSOR_CODEC = class_2960.field_25139
			.fieldOf("structureId")
			.xmap(Processor::new, processor -> processor.structureId)
			.codec();

	public static final class_3828<Processor> PROCESSOR_TYPE = class_2378.method_10230(
			class_7923.field_41161,
			Create.asResource("fabric_structure_processor"),
			() -> PROCESSOR_CODEC
	);

	/**
	 * A predicate that makes all processes apply to all schematics.
	 */
	public static final ProcessingPredicate ALWAYS = (id, process) -> true;

	private static final Map<String, ProcessingPredicate> predicates = new HashMap<>();

	/**
	 * Register a {@link ProcessingPredicate} for a mod.
	 * Only one predicate may be registered for each mod.
	 * The predicate determines which {@link Process}es will be applied to which schematics.
	 */
	public static ProcessingPredicate register(String modId, ProcessingPredicate predicate) {
		ProcessingPredicate existing = predicates.get(modId);
		if (existing != null) {
			throw new IllegalStateException(
					"Tried to register ProcessingPredicate [%s] for mod '%s', while one already exists: [%s]"
							.formatted(predicate, modId, existing)
			);
		}
	    predicates.put(modId, predicate);
		return predicate;
	}

	@Internal
	public static void init() {
		register(Create.ID, ALWAYS);
	}

	public enum Process {
		FLUID_AMOUNTS
	}

	@FunctionalInterface
	public interface ProcessingPredicate {
		boolean shouldApplyProcess(class_2960 schematicId, Process process);
	}

	public static class Processor extends class_3491 {
		public final class_2960 structureId;

		public Processor(class_2960 structureId) {
			this.structureId = structureId;
		}

		@Nullable
		@Override
		public class_3499.class_3501 method_15110(
				@NotNull class_4538 level, @NotNull class_2338 pos, @NotNull class_2338 pivot,
				@NotNull class_3501 blockInfo, @NotNull class_3501 relativeBlockInfo,
				@NotNull class_3492 settings) {
			ProcessingPredicate predicate = predicates.get(structureId.method_12836());
			if (predicate == null) // do nothing
				return relativeBlockInfo;

			class_2487 nbt = relativeBlockInfo.comp_1343();
			if (nbt == null)
				return relativeBlockInfo;

			if (!predicate.shouldApplyProcess(structureId, Process.FLUID_AMOUNTS))
				return relativeBlockInfo;

			if (AllBlocks.FLUID_TANK.has(relativeBlockInfo.comp_1342()) && nbt.method_10573("TankContent", class_2520.field_33260)) {
				class_2487 copy = nbt.method_10553();
				fixTankContent(copy.method_10562("TankContent"));
				return new class_3501(relativeBlockInfo.comp_1341(), relativeBlockInfo.comp_1342(), copy);
			} else if (AllBlocks.BASIN.has(relativeBlockInfo.comp_1342())) {
				class_2487 copy = nbt.method_10553();
				class_2499 inputTanks = copy.method_10554("InputTanks", class_2520.field_33260);
				if (!inputTanks.isEmpty()) {
					for (int i = 0; i < inputTanks.size(); i++) {
						class_2487 compound = inputTanks.method_10602(i);
						class_2487 content = compound.method_10562("TankContent");
						fixTankContent(content);
					}
				}
				class_2499 outputTanks = copy.method_10554("OutputTanks", class_2520.field_33260);
				if (!outputTanks.isEmpty()) {
					for (int i = 0; i < outputTanks.size(); i++) {
						class_2487 compound = outputTanks.method_10602(i);
						class_2487 content = compound.method_10562("TankContent");
						fixTankContent(content);
					}
				}

				return new class_3501(relativeBlockInfo.comp_1341(), relativeBlockInfo.comp_1342(), copy);
			}

			// no processes were applied
			return relativeBlockInfo;
		}

		@Override
		@NotNull
		protected class_3828<?> method_16772() {
			return PROCESSOR_TYPE;
		}
	}

	private static void fixTankContent(class_2487 content) {
		if (content.method_10573("FluidName", class_2520.field_33258) && content.method_10558("FluidName").equals("minecraft:milk")) {
			content.method_10582("FluidName", "milk:still_milk");
		}
		FluidStack stack = FluidStack.loadFluidStackFromNBT(content);
		long amount = stack.getAmount();
		double buckets = amount / 1000d;
		long fixedAmount = Math.round(buckets * FluidConstants.BUCKET);
		stack.setAmount(fixedAmount);
		Set.copyOf(content.method_10541()).forEach(content::method_10551);
		stack.writeToNBT(content);
	}
}
