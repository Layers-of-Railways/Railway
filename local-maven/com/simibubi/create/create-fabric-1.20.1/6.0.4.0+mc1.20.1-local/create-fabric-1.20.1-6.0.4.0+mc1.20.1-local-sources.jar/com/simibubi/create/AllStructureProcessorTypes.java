package com.simibubi.create;

import com.simibubi.create.content.schematics.SchematicProcessor;
import io.github.fabricators_of_create.porting_lib.util.LazyRegistrar;
import io.github.fabricators_of_create.porting_lib.util.RegistryObject;
import net.minecraft.class_3828;
import net.minecraft.class_7924;

public class AllStructureProcessorTypes {
	private static final LazyRegistrar<class_3828<?>> REGISTER = LazyRegistrar.create(class_7924.field_41230, Create.ID);

	public static final RegistryObject<class_3828<SchematicProcessor>> SCHEMATIC = REGISTER.register("schematic", () -> () -> SchematicProcessor.CODEC);

	public static void register() {
		REGISTER.register();
	}
}
