package com.simibubi.create.foundation.utility;

import net.minecraft.class_1657;
import org.jetbrains.annotations.Nullable;
import org.jetbrains.annotations.Nullable;

public class AdventureUtil {
	public static boolean isAdventure(@Nullable class_1657 player) {
		return player != null && !player.method_7294() && !player.method_7325();
	}
}
