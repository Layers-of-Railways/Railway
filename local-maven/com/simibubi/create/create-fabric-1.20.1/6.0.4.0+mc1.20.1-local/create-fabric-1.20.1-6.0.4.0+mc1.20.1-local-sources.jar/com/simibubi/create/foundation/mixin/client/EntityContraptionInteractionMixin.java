package com.simibubi.create.foundation.mixin.client;

import java.lang.ref.Reference;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import net.minecraft.class_1297;
import net.minecraft.class_1313;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2388;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2464;
import net.minecraft.class_2680;
import net.minecraft.class_3499;
import net.minecraft.class_4048;
import net.minecraft.class_5819;
import org.apache.commons.lang3.mutable.MutableBoolean;
import org.apache.logging.log4j.util.TriConsumer;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import com.simibubi.create.content.contraptions.AbstractContraptionEntity;
import com.simibubi.create.content.contraptions.Contraption;
import com.simibubi.create.content.contraptions.ContraptionCollider;
import com.simibubi.create.content.contraptions.ContraptionHandler;
import io.github.fabricators_of_create.porting_lib.block.CustomRunningEffectsBlock;

@Mixin(class_1297.class)
public abstract class EntityContraptionInteractionMixin {
	@Shadow
	private class_1937 level;

	@Shadow
	private class_243 position;

	@Shadow
	private float nextStep;

	@Shadow
	@Final
	protected class_5819 random;

	@Shadow
	private class_4048 dimensions;

	@Shadow
	protected abstract float nextStep();

	@Shadow
	protected abstract void playStepSound(class_2338 pos, class_2680 state);

	@Unique
	private Stream<AbstractContraptionEntity> create$getIntersectionContraptionsStream() {
		return ContraptionHandler.loadedContraptions.get(level)
			.values()
			.stream()
			.map(Reference::get)
			.filter(cEntity -> cEntity != null && cEntity.collidingEntities.containsKey((class_1297) (Object) this));
	}

	@Unique
	private Set<AbstractContraptionEntity> create$getIntersectingContraptions() {
		Set<AbstractContraptionEntity> contraptions = create$getIntersectionContraptionsStream().collect(Collectors.toSet());

		contraptions.addAll(level.method_18467(AbstractContraptionEntity.class, ((class_1297) (Object) this).method_5829()
			.method_1014(1f)));
		return contraptions;
	}

	@Unique
	private void create$forCollision(class_243 worldPos, TriConsumer<Contraption, class_2680, class_2338> action) {
		create$getIntersectingContraptions().forEach(cEntity -> {
			class_243 localPos = ContraptionCollider.worldToLocalPos(worldPos, cEntity);

			class_2338 blockPos = class_2338.method_49638(localPos);
			Contraption contraption = cEntity.getContraption();
			class_3499.class_3501 info = contraption.getBlocks()
				.get(blockPos);

			if (info != null) {
				class_2680 blockstate = info.comp_1342();
				action.accept(contraption, blockstate, blockPos);
			}
		});
	}

	// involves block step sounds on contraptions
	// injecting before `!blockstate1.isAir(this.world, blockpos)`
	// `if (this.moveDist > this.nextStep && !blockstate1.isAir())
	@Inject(method = "move", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/block/state/BlockState;isAir()Z", ordinal = 0))
	private void create$contraptionStepSounds(class_1313 mover, class_243 movement, CallbackInfo ci) {
		class_243 worldPos = position.method_1031(0, -0.2, 0);
		MutableBoolean stepped = new MutableBoolean(false);

		create$forCollision(worldPos, (contraption, state, pos) -> {
			playStepSound(pos, state);
			stepped.setTrue();
		});

		if (stepped.booleanValue())
			nextStep = nextStep();
	}

	// involves client-side view bobbing animation on contraptions
	@Inject(method = "move", at = @At(value = "TAIL"))
	private void create$onMove(class_1313 mover, class_243 movement, CallbackInfo ci) {
		if (!level.field_9236)
			return;
		class_1297 self = (class_1297) (Object) this;
		if (self.method_24828())
			return;
		if (self.method_5765())
			return;

		class_243 worldPos = position.method_1031(0, -0.2, 0);
		boolean onAtLeastOneContraption = create$getIntersectionContraptionsStream().anyMatch(cEntity -> {
			class_243 localPos = ContraptionCollider.worldToLocalPos(worldPos, cEntity);

			class_2338 blockPos = class_2338.method_49638(localPos);
			Contraption contraption = cEntity.getContraption();
			class_3499.class_3501 info = contraption.getBlocks()
				.get(blockPos);

			if (info == null)
				return false;

			cEntity.registerColliding(self);
			return true;
		});

		if (!onAtLeastOneContraption)
			return;

		self.method_24830(true);
		self.getCustomData()
			.method_10556("ContraptionGrounded", true);
	}

	@Inject(method = "spawnSprintParticle", at = @At(value = "TAIL"))
	private void create$onSpawnSprintParticle(CallbackInfo ci) {
		class_1297 self = (class_1297) (Object) this;
		class_243 worldPos = position.method_1031(0, -0.2, 0);
		class_2338 particlePos = class_2338.method_49638(worldPos); // pos where particles are spawned

		create$forCollision(worldPos, (contraption, state, pos) -> {
			boolean particles = state.method_26217() != class_2464.field_11455;
			if (state.method_26204() instanceof CustomRunningEffectsBlock custom &&
					custom.addRunningEffects(state, self.method_37908(), pos, self)) {
				particles = false;
			}
			if (particles) {
				class_243 speed = self.method_18798();
				level.method_8406(
					new class_2388(class_2398.field_11217, state).setSourcePos(particlePos),
					self.method_23317() + ((double) random.method_43057() - 0.5D) * (double) dimensions.field_18067,
					self.method_23318() + 0.1D,
					self.method_23321() + ((double) random.method_43057() - 0.5D) * (double) dimensions.field_18068,
					speed.field_1352 * -4.0D, 1.5D, speed.field_1350 * -4.0D
				);
			}
		});
	}
}
