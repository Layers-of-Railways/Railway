package com.simibubi.create.foundation.data;

import com.tterrag.registrate.providers.DataGenContext;
import com.tterrag.registrate.providers.RegistrateBlockstateProvider;
import io.github.fabricators_of_create.porting_lib.models.generators.ConfiguredModel;
import io.github.fabricators_of_create.porting_lib.models.generators.ModelFile;
import net.minecraft.class_2248;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2769;

public abstract class SpecialBlockStateGen {

	protected class_2769<?>[] getIgnoredProperties() {
		return new class_2769<?>[0];
	}

	public final <T extends class_2248> void generate(DataGenContext<class_2248, T> ctx, RegistrateBlockstateProvider prov) {
		prov.getVariantBuilder(ctx.getEntry())
			.forAllStatesExcept(state -> {
				return ConfiguredModel.builder()
					.modelFile(getModel(ctx, prov, state))
					.rotationX((getXRotation(state) + 360) % 360)
					.rotationY((getYRotation(state) + 360) % 360)
					.build();
			}, getIgnoredProperties());
	}

	protected int horizontalAngle(class_2350 direction) {
		if (direction.method_10166()
			.method_10178())
			return 0;
		return (int) direction.method_10144();
	}

	protected abstract int getXRotation(class_2680 state);

	protected abstract int getYRotation(class_2680 state);

	public abstract <T extends class_2248> ModelFile getModel(DataGenContext<class_2248, T> ctx,
														 RegistrateBlockstateProvider prov, class_2680 state);

}
