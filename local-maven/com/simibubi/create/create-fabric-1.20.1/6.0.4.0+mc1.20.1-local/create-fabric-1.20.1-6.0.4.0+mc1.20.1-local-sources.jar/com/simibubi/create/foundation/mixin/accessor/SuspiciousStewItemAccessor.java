package com.simibubi.create.foundation.mixin.accessor;

import java.util.function.Consumer;
import net.minecraft.class_1293;
import net.minecraft.class_1799;
import net.minecraft.class_1830;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_1830.class)
public interface SuspiciousStewItemAccessor {
	@Invoker("listPotionEffects")
	static void create$listPotionEffects(class_1799 stack, Consumer<class_1293> output) {
		throw new AssertionError();
	}
}
