package com.simibubi.create.foundation.mixin.accessor;

import net.minecraft.class_1540;
import net.minecraft.class_1937;
import net.minecraft.class_2680;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_1540.class)
public interface FallingBlockEntityAccessor {
	@Invoker("<init>")
	static class_1540 create$callInit(class_1937 level, double x, double y, double z, class_2680 state) {
		throw new AssertionError();
	}
}
