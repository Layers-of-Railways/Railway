package com.simibubi.create.foundation.damageTypes;

import net.minecraft.class_1281;
import net.minecraft.class_1282;
import net.minecraft.class_1283;
import net.minecraft.class_1297;
import net.minecraft.class_5321;
import net.minecraft.class_7891;
import net.minecraft.class_8107;
import net.minecraft.class_8108;
import net.minecraft.class_8110;
import net.minecraft.class_8112;

public class DamageTypeBuilder {
	protected final class_5321<class_8110> key;

	protected String msgId;
	protected class_8108 scaling;
	protected float exhaustion = 0.0f;
	protected class_8107 effects;
	protected class_8112 deathMessageType;

	public DamageTypeBuilder(class_5321<class_8110> key) {
		this.key = key;
	}

	/**
	 * Set the message ID. this is used for death message lang keys.
	 *
	 * @see #deathMessageType(class_8112)
	 */
	public DamageTypeBuilder msgId(String msgId) {
		this.msgId = msgId;
		return this;
	}

	public DamageTypeBuilder simpleMsgId() {
		return msgId(key.method_29177().method_12836() + "." + key.method_29177().method_12832());
	}

	/**
	 * Set the scaling of this type. This determines whether damage is increased based on difficulty or not.
	 */
	public DamageTypeBuilder scaling(class_8108 scaling) {
		this.scaling = scaling;
		return this;
	}

	/**
	 * Set the exhaustion of this type. This is the amount of hunger that will be consumed when an entity is damaged.
	 */
	public DamageTypeBuilder exhaustion(float exhaustion) {
		this.exhaustion = exhaustion;
		return this;
	}

	/**
	 * Set the effects of this type. This determines the sound that plays when damaged.
	 */
	public DamageTypeBuilder effects(class_8107 effects) {
		this.effects = effects;
		return this;
	}

	/**
	 * Set the death message type of this damage type. This determines how a death message lang key is assembled.
	 * <ul>
	 *     <li>{@link class_8112#field_42361}: {@link class_1282#method_5506}</li>
	 *     <li>{@link class_8112#field_42362}: {@link class_1283#method_52190(class_1281, class_1297)}</li>
	 *     <li>{@link class_8112#field_42363}: "death.attack." + msgId, wrapped in brackets, linking to MCPE-28723</li>
	 * </ul>
	 */
	public DamageTypeBuilder deathMessageType(class_8112 deathMessageType) {
		this.deathMessageType = deathMessageType;
		return this;
	}

	public class_8110 build() {
		if (msgId == null) {
			simpleMsgId();
		}
		if (scaling == null) {
			scaling(class_8108.field_42286);
		}
		if (effects == null) {
			effects(class_8107.field_42275);
		}
		if (deathMessageType == null) {
			deathMessageType(class_8112.field_42361);
		}
		return new class_8110(msgId, scaling, exhaustion, effects, deathMessageType);
	}

	public class_8110 register(class_7891<class_8110> ctx) {
		class_8110 type = build();
		ctx.method_46838(key, type);
		return type;
	}
}
