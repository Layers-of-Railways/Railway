package com.simibubi.create.foundation.utility;

import java.util.function.Supplier;

import org.jetbrains.annotations.Nullable;
import net.minecraft.class_310;
import net.minecraft.class_5455;
import net.minecraft.class_634;
import net.minecraft.server.MinecraftServer;

import net.fabricmc.api.EnvType;

import io.github.fabricators_of_create.porting_lib.util.EnvExecutor;
import io.github.fabricators_of_create.porting_lib.util.ServerLifecycleHooks;

public final class GlobalRegistryAccess {
	private static Supplier<@Nullable class_5455> supplier;

	static {
		EnvExecutor.runWhenOn(EnvType.CLIENT, () -> () -> supplier = () -> {
			class_634 packetListener = class_310.method_1551().method_1562();
			if (packetListener == null) {
				return null;
			}
			return packetListener.method_29091();
		});

		if (supplier == null) {
			supplier = () -> {
				MinecraftServer server = ServerLifecycleHooks.getCurrentServer();
				if (server == null) {
					return null;
				}
				return server.method_30611();
			};
		}
	}

	@Nullable
	public static class_5455 get() {
		return supplier.get();
	}

	public static class_5455 getOrThrow() {
		class_5455 registryAccess = get();
		if (registryAccess == null) {
			throw new IllegalStateException("Could not get RegistryAccess");
		}
		return registryAccess;
	}
}
