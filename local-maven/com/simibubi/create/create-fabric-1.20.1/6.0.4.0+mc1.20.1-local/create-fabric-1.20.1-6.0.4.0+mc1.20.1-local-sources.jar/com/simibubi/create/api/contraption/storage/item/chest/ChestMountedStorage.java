package com.simibubi.create.api.contraption.storage.item.chest;

import org.jetbrains.annotations.Nullable;

import com.mojang.serialization.Codec;
import com.simibubi.create.AllMountedStorageTypes;
import com.simibubi.create.api.contraption.storage.item.MountedItemStorage;
import com.simibubi.create.api.contraption.storage.item.MountedItemStorageType;
import com.simibubi.create.api.contraption.storage.item.simple.SimpleMountedStorage;
import com.simibubi.create.content.contraptions.Contraption;
import com.simibubi.create.foundation.item.CombinedSlottedStackStorage;
import com.simibubi.create.foundation.item.ItemHelper;
import net.fabricmc.fabric.api.transfer.v1.item.ItemVariant;
import net.fabricmc.fabric.api.transfer.v1.storage.SlottedStorage;
import net.minecraft.class_1263;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2281;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2745;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3499.class_3501;
import io.github.fabricators_of_create.porting_lib.transfer.item.ItemStackHandler;
import io.github.fabricators_of_create.porting_lib.transfer.item.SlottedStackStorage;

/**
 * Mounted storage that handles opening a combined GUI for double chests.
 */
public class ChestMountedStorage extends SimpleMountedStorage {
	public static final Codec<ChestMountedStorage> CODEC = SimpleMountedStorage.codec(ChestMountedStorage::new);

	protected ChestMountedStorage(MountedItemStorageType<?> type, ItemStackHandler handler) {
		super(type, handler);
	}

	public ChestMountedStorage(ItemStackHandler handler) {
		this(AllMountedStorageTypes.CHEST.get(), handler);
	}

	public ChestMountedStorage(SlottedStorage<ItemVariant> storage) {
		this(copyToItemStackHandler(storage));
	}

	@Override
	public void unmount(class_1937 level, class_2680 state, class_2338 pos, @Nullable class_2586 be) {
		// the capability will include both sides of chests, but mounted storage is 1:1
		if (be instanceof class_1263 container && this.getSlotCount() == container.method_5439()) {
			ItemHelper.copyContents(this, container);
		}
	}

	@Override
	protected SlottedStackStorage getHandlerForMenu(class_3501 info, Contraption contraption) {
		class_2680 state = info.comp_1342();
		class_2745 type = state.method_11654(class_2281.field_10770);
		if (type == class_2745.field_12569)
			return this;

		class_2350 facing = state.method_11654(class_2281.field_10768);
		class_2350 connectedDirection = class_2281.method_9758(state);
		class_2338 otherHalfPos = info.comp_1341().method_10093(connectedDirection);

		MountedItemStorage otherHalf = this.getOtherHalf(contraption, otherHalfPos, state.method_26204(), facing, type);
		if (otherHalf == null)
			return this;

		if (type == class_2745.field_12571) {
			return new CombinedSlottedStackStorage<>(this, otherHalf);
		} else {
			return new CombinedSlottedStackStorage<>(otherHalf, this);
		}
	}

	@Nullable
	protected MountedItemStorage getOtherHalf(Contraption contraption, class_2338 localPos, class_2248 block,
											  class_2350 thisFacing, class_2745 thisType) {
		class_3501 info = contraption.getBlocks().get(localPos);
		if (info == null)
			return null;
		class_2680 state = info.comp_1342();
		if (!state.method_27852(block))
			return null;

		class_2350 facing = state.method_11654(class_2281.field_10768);
		class_2745 type = state.method_11654(class_2281.field_10770);

		return facing == thisFacing && type == thisType.method_11824()
			? contraption.getStorage().getMountedItems().storages.get(localPos)
			: null;
	}

	@Override
	protected void playOpeningSound(class_3218 level, class_243 pos) {
		level.method_8396(
			null, class_2338.method_49638(pos),
			class_3417.field_14982, class_3419.field_15245,
			0.75f, 1f
		);
	}

	@Override
	protected void playClosingSound(class_3218 level, class_243 pos) {
		level.method_8396(
			null, class_2338.method_49638(pos),
			class_3417.field_14823, class_3419.field_15245,
			0.75f, 1f
		);
	}
}
