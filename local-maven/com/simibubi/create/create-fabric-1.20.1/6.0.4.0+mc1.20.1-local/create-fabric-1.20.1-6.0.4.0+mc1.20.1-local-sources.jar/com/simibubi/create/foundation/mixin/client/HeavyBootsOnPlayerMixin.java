package com.simibubi.create.foundation.mixin.client;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import com.mojang.authlib.GameProfile;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2487;
import net.minecraft.class_638;
import net.minecraft.class_742;
import net.minecraft.class_746;

@Environment(EnvType.CLIENT)
@Mixin(class_746.class)
public abstract class HeavyBootsOnPlayerMixin extends class_742 {
	private HeavyBootsOnPlayerMixin(class_638 level, GameProfile profile) {
		super(level, profile);
	}

	@Inject(method = "isUnderWater()Z", at = @At("HEAD"), cancellable = true)
	public void create$noSwimmingWithHeavyBootsOn(CallbackInfoReturnable<Boolean> cir) {
		class_2487 persistentData = getCustomData();
		if (persistentData.method_10545("HeavyBoots"))
			cir.setReturnValue(false);
	}
}
