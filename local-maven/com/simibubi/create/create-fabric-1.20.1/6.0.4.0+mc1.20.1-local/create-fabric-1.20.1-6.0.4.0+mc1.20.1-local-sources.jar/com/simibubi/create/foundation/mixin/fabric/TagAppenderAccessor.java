package com.simibubi.create.foundation.mixin.fabric;

import net.minecraft.class_2474.class_5124;
import net.minecraft.class_3495;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_5124.class)
public interface TagAppenderAccessor {
	@Accessor
	class_3495 getBuilder();
}
