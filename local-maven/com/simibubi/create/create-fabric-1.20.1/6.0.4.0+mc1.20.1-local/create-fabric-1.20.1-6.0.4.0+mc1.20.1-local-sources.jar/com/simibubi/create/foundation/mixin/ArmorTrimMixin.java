package com.simibubi.create.foundation.mixin;

import java.util.function.BiFunction;
import net.minecraft.class_156;
import net.minecraft.class_1741;
import net.minecraft.class_2960;
import net.minecraft.class_6880;
import net.minecraft.class_8053;
import net.minecraft.class_8056;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import com.simibubi.create.Create;
import com.simibubi.create.content.equipment.armor.AllArmorMaterials;

@Mixin(class_8053.class)
public abstract class ArmorTrimMixin {
	@Shadow
	@Final
	private class_6880<class_8056> pattern;

	@Shadow
	protected abstract String getColorPaletteSuffix(class_1741 pArmorMaterial);

	@Unique
	private final BiFunction<Boolean, class_1741, class_2960> create$textureCardboard = class_156.method_34865((inner, material) -> {
		String assetPath = pattern.comp_349().comp_1213().method_12832();
		String colorSuffix = getColorPaletteSuffix(material);
		return Create.asResource("trims/models/armor/card_" + assetPath + (inner ? "_leggings_" : "_") + colorSuffix);
	});

	@Inject(method = "innerTexture", at = @At("HEAD"), cancellable = true)
	private void create$swapTexturesForCardboardTrimsInner(class_1741 pArmorMaterial, CallbackInfoReturnable<class_2960> cir) {
		if (pArmorMaterial == AllArmorMaterials.CARDBOARD) {
			cir.setReturnValue(create$textureCardboard.apply(true, pArmorMaterial));
		}
	}

	@Inject(method = "outerTexture", at = @At("HEAD"), cancellable = true)
	private void create$swapTexturesForCardboardTrimsOuter(class_1741 pArmorMaterial, CallbackInfoReturnable<class_2960> cir) {
		if (pArmorMaterial == AllArmorMaterials.CARDBOARD) {
			cir.setReturnValue(create$textureCardboard.apply(false, pArmorMaterial));
		}
	}
}
