package com.simibubi.create.foundation.item;

import java.util.HashMap;
import java.util.Map;
import java.util.function.IntFunction;
import net.minecraft.class_1799;
import net.minecraft.class_5699;
import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.simibubi.create.foundation.utility.CreateCodecs;

import it.unimi.dsi.fastutil.ints.Int2ObjectMap;
import it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap;
import io.github.fabricators_of_create.porting_lib.transfer.item.SlottedStackStorage;

/**
 * Utility class representing non-empty slots in an item inventory.
 */
public class ItemSlots {
	public static final Codec<ItemSlots> CODEC = RecordCodecBuilder.create(instance -> instance.group(
		Codec.unboundedMap(CreateCodecs.boundedIntStr(0), class_1799.field_24671).fieldOf("items").forGetter(ItemSlots::toBoxedMap),
		class_5699.field_33441.fieldOf("size").forGetter(ItemSlots::getSize)
	).apply(instance, ItemSlots::deserialize));

	private final Int2ObjectMap<class_1799> map;
	private int size;

	public ItemSlots() {
		this.map = new Int2ObjectOpenHashMap<>();
		this.size = 0;
	}

	public void set(int slot, class_1799 stack) {
		if (slot < 0) {
			throw new IllegalArgumentException("Slot must be positive");
		} else if (!stack.method_7960()) {
			this.map.put(slot, stack);
			this.size = Math.max(this.size, slot + 1);
		}
	}

	public int getSize() {
		return this.size;
	}

	public void setSize(int size) {
		if (size <= this.getHighestSlot()) {
			throw new IllegalStateException("cannot set size to below the highest slot");
		}
		this.size = size;
	}

	public void forEach(SlotConsumer consumer) {
		for (Int2ObjectMap.Entry<class_1799> entry : this.map.int2ObjectEntrySet()) {
			consumer.accept(entry.getIntKey(), entry.getValue());
		}
	}

	private int getHighestSlot() {
		return this.map.keySet().intStream().max().orElse(-1);
	}

	public <T extends SlottedStackStorage> T toHandler(IntFunction<T> factory) {
		T handler = factory.apply(this.size);
		this.forEach(handler::setStackInSlot);
		return handler;
	}

	public static ItemSlots fromHandler(SlottedStackStorage handler) {
		ItemSlots slots = new ItemSlots();
		slots.setSize(handler.getSlotCount());
		for (int i = 0; i < handler.getSlotCount(); i++) {
			class_1799 stack = handler.getStackInSlot(i);
			if (!stack.method_7960()) {
				slots.set(i, stack.method_7972());
			}
		}
		return slots;
	}

	public Map<Integer, class_1799> toBoxedMap() {
		Map<Integer, class_1799> map = new HashMap<>();
		this.forEach(map::put);
		return map;
	}

	public static ItemSlots fromBoxedMap(Map<Integer, class_1799> map) {
		ItemSlots slots = new ItemSlots();
		map.forEach(slots::set);
		return slots;
	}

	public static Codec<ItemSlots> maxSizeCodec(int maxSize) {
		return class_5699.method_48112(
			CODEC,
			slots -> slots.size <= maxSize
				? DataResult.success(slots)
				: DataResult.error(() -> "Slots above maximum of " + maxSize)
		);
	}

	private static ItemSlots deserialize(Map<Integer, class_1799> map, int size) {
		ItemSlots slots = fromBoxedMap(map);
		slots.setSize(size);
		return slots;
	}

	@FunctionalInterface
	public interface SlotConsumer {
		void accept(int slot, class_1799 stack);
	}
}
