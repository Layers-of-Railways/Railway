package com.simibubi.create.foundation.mixin.fabric.infra;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import com.simibubi.create.infrastructure.fabric.ItemExtras;
import com.simibubi.create.infrastructure.fabric.SecondaryUseBypassingBlock;
import net.fabricmc.fabric.api.util.TriState;
import net.minecraft.class_1268;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import net.minecraft.class_3225;
import net.minecraft.class_3965;

@Mixin(class_3225.class)
public class ServerPlayerGameModeMixin {
	@ModifyExpressionValue(
		method = "useItemOn",
		at = @At(
			value = "INVOKE",
			target = "Lnet/minecraft/server/level/ServerPlayer;isSecondaryUseActive()Z"
		)
	)
	private boolean maybeBypassSecondaryUse(boolean original, class_3222 player, class_1937 level, class_1799 stack, class_1268 hand, class_3965 hit) {
		if (!original)
			return false;

		class_2680 state = player.method_37908().method_8320(hit.method_17777());
		if (state.method_26204() instanceof SecondaryUseBypassingBlock block && block.shouldBypassSecondaryUse(player, hand, state)) {
			return false;
		}

		return true;
	}

	@WrapOperation(
		method = "useItemOn",
		at = {
			@At(
				value = "INVOKE",
				target = "Lnet/minecraft/world/item/ItemStack;isEmpty()Z",
				ordinal = 0
			),
			@At(
				value = "INVOKE",
				target = "Lnet/minecraft/world/item/ItemStack;isEmpty()Z",
				ordinal = 1
			)
		}
	)
	private boolean customHasSecondaryUse(class_1799 stack, Operation<Boolean> original,
										  @Local(argsOnly = true) class_3222 player, @Local class_2338 pos) {
		if (stack.method_7909() instanceof ItemExtras ex) {
			TriState result = ex.hasSecondaryUse(stack, player.method_37908(), pos, player);
			if (result != TriState.DEFAULT) {
				// negate since the result of the target is negated
				return !result.get();
			}
		}

		return original.call(stack);
	}
}
