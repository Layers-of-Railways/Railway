package com.simibubi.create.foundation.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Slice;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import com.simibubi.create.AllItems;
import com.simibubi.create.content.equipment.armor.DivingBootsItem;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_243;

@Mixin(class_1309.class)
public abstract class LavaSwimmingMixin extends class_1297 {
	private LavaSwimmingMixin(class_1299<?> type, class_1937 level) {
		super(type, level);
	}

	@Inject(method = "travel(Lnet/minecraft/world/phys/Vec3;)V", slice = @Slice(from = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/LivingEntity;isInLava()Z")), at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/LivingEntity;move(Lnet/minecraft/world/entity/MoverType;Lnet/minecraft/world/phys/Vec3;)V", shift = Shift.AFTER, ordinal = 0))
	private void create$onLavaTravel(class_243 travelVector, CallbackInfo ci) {
		class_1799 bootsStack = DivingBootsItem.getWornItem(this);
		if (AllItems.NETHERITE_DIVING_BOOTS.isIn(bootsStack))
			method_18799(method_18798().method_18806(DivingBootsItem.getMovementMultiplier((class_1309) (Object) this)));
	}
}
