
package com.simibubi.create.foundation.data;

import java.util.HashMap;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;
import java.util.function.BiFunction;
import java.util.function.Function;

import org.apache.commons.lang3.tuple.Pair;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;
import com.simibubi.create.Create;
import com.simibubi.create.content.contraptions.chassis.LinearChassisBlock;
import com.simibubi.create.content.contraptions.chassis.RadialChassisBlock;
import com.simibubi.create.content.contraptions.mounted.CartAssembleRailType;
import com.simibubi.create.content.contraptions.mounted.CartAssemblerBlock;
import com.simibubi.create.content.decoration.steamWhistle.WhistleBlock.WhistleSize;
import com.simibubi.create.content.decoration.steamWhistle.WhistleExtenderBlock;
import com.simibubi.create.content.decoration.steamWhistle.WhistleExtenderBlock.WhistleExtenderShape;
import com.simibubi.create.content.fluids.pipes.EncasedPipeBlock;
import com.simibubi.create.content.fluids.pipes.FluidPipeBlock;
import com.simibubi.create.content.kinetics.base.DirectionalAxisKineticBlock;
import com.simibubi.create.content.processing.burner.BlazeBurnerBlock;
import com.tterrag.registrate.providers.DataGenContext;
import com.tterrag.registrate.providers.RegistrateBlockstateProvider;
import com.tterrag.registrate.util.nullness.NonNullBiConsumer;
import com.tterrag.registrate.util.nullness.NonnullType;

import net.createmod.catnip.data.Iterate;
import net.createmod.catnip.math.Pointing;
import net.minecraft.class_2248;
import net.minecraft.class_2350;
import net.minecraft.class_2350.class_2351;
import net.minecraft.class_2350.class_2352;
import net.minecraft.class_2533;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_2760;
import net.minecraft.class_2768;
import net.minecraft.class_2960;
import io.github.fabricators_of_create.porting_lib.models.generators.ConfiguredModel;
import io.github.fabricators_of_create.porting_lib.models.generators.ModelFile;
import io.github.fabricators_of_create.porting_lib.models.generators.ModelFile.ExistingModelFile;
import io.github.fabricators_of_create.porting_lib.models.generators.block.BlockModelProvider;
import io.github.fabricators_of_create.porting_lib.models.generators.block.MultiPartBlockStateBuilder;

public class BlockStateGen {

	// Functions

	public static <T extends class_2248> NonNullBiConsumer<DataGenContext<class_2248, T>, RegistrateBlockstateProvider> axisBlockProvider(
		boolean customItem) {
		return (c, p) -> axisBlock(c, p, getBlockModel(customItem, c, p));
	}

	public static <T extends class_2248> NonNullBiConsumer<DataGenContext<class_2248, T>, RegistrateBlockstateProvider> directionalBlockProvider(
		boolean customItem) {
		return (c, p) -> p.directionalBlock(c.get(), getBlockModel(customItem, c, p));
	}

	public static <T extends class_2248> NonNullBiConsumer<DataGenContext<class_2248, T>, RegistrateBlockstateProvider> directionalBlockProviderIgnoresWaterlogged(
		boolean customItem) {
		return (c, p) -> directionalBlockIgnoresWaterlogged(c, p, getBlockModel(customItem, c, p));
	}

	public static <T extends class_2248> NonNullBiConsumer<DataGenContext<class_2248, T>, RegistrateBlockstateProvider> horizontalBlockProvider(
		boolean customItem) {
		return (c, p) -> p.horizontalBlock(c.get(), getBlockModel(customItem, c, p));
	}

	public static <T extends class_2248> NonNullBiConsumer<DataGenContext<class_2248, T>, RegistrateBlockstateProvider> horizontalAxisBlockProvider(
		boolean customItem) {
		return (c, p) -> horizontalAxisBlock(c, p, getBlockModel(customItem, c, p));
	}

	public static <T extends class_2248> NonNullBiConsumer<DataGenContext<class_2248, T>, RegistrateBlockstateProvider> simpleCubeAll(
		String path) {
		return (c, p) -> p.simpleBlock(c.get(), p.models()
			.cubeAll(c.getName(), p.modLoc("block/" + path)));
	}

	public static <T extends DirectionalAxisKineticBlock> NonNullBiConsumer<DataGenContext<class_2248, T>, RegistrateBlockstateProvider> directionalAxisBlockProvider() {
		return (c, p) -> directionalAxisBlock(c, p, ($, vertical) -> p.models()
			.getExistingFile(p.modLoc("block/" + c.getName() + "/" + (vertical ? "vertical" : "horizontal"))));
	}

	public static <T extends class_2248> NonNullBiConsumer<DataGenContext<class_2248, T>, RegistrateBlockstateProvider> horizontalWheelProvider(
		boolean customItem) {
		return (c, p) -> horizontalWheel(c, p, getBlockModel(customItem, c, p));
	}

	// Utility

	private static <T extends class_2248> Function<class_2680, ModelFile> getBlockModel(boolean customItem,
																				   DataGenContext<class_2248, T> c, RegistrateBlockstateProvider p) {
		return $ -> customItem ? AssetLookup.partialBaseModel(c, p) : AssetLookup.standardModel(c, p);
	}

	// Generators

	public static <T extends class_2248> void directionalBlockIgnoresWaterlogged(DataGenContext<class_2248, T> ctx,
		RegistrateBlockstateProvider prov, Function<class_2680, ModelFile> modelFunc) {
		prov.getVariantBuilder(ctx.getEntry())
			.forAllStatesExcept(state -> {
				class_2350 dir = state.method_11654(class_2741.field_12525);
				return ConfiguredModel.builder()
					.modelFile(modelFunc.apply(state))
					.rotationX(dir == class_2350.field_11033 ? 180
						: dir.method_10166()
							.method_10179() ? 90 : 0)
					.rotationY(dir.method_10166()
						.method_10178() ? 0 : (((int) dir.method_10144()) + 180) % 360)
					.build();
			}, class_2741.field_12508);
	}

	public static <T extends class_2248> void axisBlock(DataGenContext<class_2248, T> ctx, RegistrateBlockstateProvider prov,
		Function<class_2680, ModelFile> modelFunc) {
		axisBlock(ctx, prov, modelFunc, false);
	}

	public static <T extends class_2248> void axisBlock(DataGenContext<class_2248, T> ctx, RegistrateBlockstateProvider prov,
		Function<class_2680, ModelFile> modelFunc, boolean uvLock) {
		prov.getVariantBuilder(ctx.getEntry())
			.forAllStatesExcept(state -> {
				class_2351 axis = state.method_11654(class_2741.field_12496);
				return ConfiguredModel.builder()
					.modelFile(modelFunc.apply(state))
					.uvLock(uvLock)
					.rotationX(axis == class_2351.field_11052 ? 0 : 90)
					.rotationY(axis == class_2351.field_11048 ? 90 : axis == class_2351.field_11051 ? 180 : 0)
					.build();
			}, class_2741.field_12508);
	}

	public static <T extends class_2248> void simpleBlock(DataGenContext<class_2248, T> ctx, RegistrateBlockstateProvider prov,
		Function<class_2680, ModelFile> modelFunc) {
		prov.getVariantBuilder(ctx.getEntry())
			.forAllStatesExcept(state -> {
				return ConfiguredModel.builder()
					.modelFile(modelFunc.apply(state))
					.build();
			}, class_2741.field_12508);
	}

	public static <T extends class_2248> void horizontalAxisBlock(DataGenContext<class_2248, T> ctx,
		RegistrateBlockstateProvider prov, Function<class_2680, ModelFile> modelFunc) {
		prov.getVariantBuilder(ctx.getEntry())
			.forAllStates(state -> {
				class_2351 axis = state.method_11654(class_2741.field_12529);
				return ConfiguredModel.builder()
					.modelFile(modelFunc.apply(state))
					.rotationY(axis == class_2351.field_11048 ? 90 : 0)
					.build();
			});
	}

	public static <T extends DirectionalAxisKineticBlock> void directionalAxisBlock(DataGenContext<class_2248, T> ctx,
		RegistrateBlockstateProvider prov, BiFunction<class_2680, Boolean, ModelFile> modelFunc) {
		prov.getVariantBuilder(ctx.getEntry())
			.forAllStates(state -> {

				boolean alongFirst = state.method_11654(DirectionalAxisKineticBlock.AXIS_ALONG_FIRST_COORDINATE);
				class_2350 direction = state.method_11654(DirectionalAxisKineticBlock.FACING);
				boolean vertical = direction.method_10166()
					.method_10179() && (direction.method_10166() == class_2351.field_11048) == alongFirst;
				int xRot = direction == class_2350.field_11033 ? 270 : direction == class_2350.field_11036 ? 90 : 0;
				int yRot = direction.method_10166()
					.method_10178() ? alongFirst ? 0 : 90 : (int) direction.method_10144();

				return ConfiguredModel.builder()
					.modelFile(modelFunc.apply(state, vertical))
					.rotationX(xRot)
					.rotationY(yRot)
					.build();
			});
	}

	public static <T extends class_2248> void horizontalWheel(DataGenContext<class_2248, T> ctx,
		RegistrateBlockstateProvider prov, Function<class_2680, ModelFile> modelFunc) {
		prov.getVariantBuilder(ctx.get())
			.forAllStates(state -> ConfiguredModel.builder()
				.modelFile(modelFunc.apply(state))
				.rotationX(90)
				.rotationY(((int) state.method_11654(class_2741.field_12481)
					.method_10144() + 180) % 360)
				.build());
	}

	public static <T extends class_2248> void cubeAll(DataGenContext<class_2248, T> ctx, RegistrateBlockstateProvider prov,
		String textureSubDir) {
		cubeAll(ctx, prov, textureSubDir, ctx.getName());
	}

	public static <T extends class_2248> void cubeAll(DataGenContext<class_2248, T> ctx, RegistrateBlockstateProvider prov,
		String textureSubDir, String name) {
		String texturePath = "block/" + textureSubDir + name;
		prov.simpleBlock(ctx.get(), prov.models()
			.cubeAll(ctx.getName(), prov.modLoc(texturePath)));
	}

	public static NonNullBiConsumer<DataGenContext<class_2248, CartAssemblerBlock>, RegistrateBlockstateProvider> cartAssembler() {
		return (c, p) -> p.getVariantBuilder(c.get())
			.forAllStates(state -> {
				CartAssembleRailType type = state.method_11654(CartAssemblerBlock.RAIL_TYPE);
				Boolean powered = state.method_11654(CartAssemblerBlock.POWERED);
				Boolean backwards = state.method_11654(CartAssemblerBlock.BACKWARDS);
				class_2768 shape = state.method_11654(CartAssemblerBlock.RAIL_SHAPE);

				int yRotation = shape == class_2768.field_12674 ? 270 : 0;
				if (backwards)
					yRotation += 180;

				return ConfiguredModel.builder()
					.modelFile(p.models()
						.getExistingFile(p.modLoc("block/" + c.getName() + "/block_" + type.method_15434()
							+ (powered ? "_powered" : ""))))
					.rotationY(yRotation % 360)
					.build();
			});
	}

	public static NonNullBiConsumer<DataGenContext<class_2248, BlazeBurnerBlock>, RegistrateBlockstateProvider> blazeHeater() {
		return (c, p) -> ConfiguredModel.builder()
			.modelFile(p.models()
				.getExistingFile(p.modLoc("block/" + c.getName() + "/block")))
			.build();
	}

	public static <B extends LinearChassisBlock> NonNullBiConsumer<DataGenContext<class_2248, B>, RegistrateBlockstateProvider> linearChassis() {
		return (c, p) -> {
			class_2960 side = p.modLoc("block/" + c.getName() + "_side");
			class_2960 top = p.modLoc("block/linear_chassis_end");
			class_2960 top_sticky = p.modLoc("block/linear_chassis_end_sticky");

			Vector<ModelFile> models = new Vector<>(4);
			for (boolean isTopSticky : Iterate.trueAndFalse)
				for (boolean isBottomSticky : Iterate.trueAndFalse)
					models.add(p.models()
						.withExistingParent(
							c.getName() + (isTopSticky ? "_top" : "") + (isBottomSticky ? "_bottom" : ""),
							"block/cube_bottom_top")
						.texture("side", side)
						.texture("bottom", isBottomSticky ? top_sticky : top)
						.texture("top", isTopSticky ? top_sticky : top));
			BiFunction<Boolean, Boolean, ModelFile> modelFunc = (t, b) -> models.get((t ? 0 : 2) + (b ? 0 : 1));

			axisBlock(c, p, state -> modelFunc.apply(state.method_11654(LinearChassisBlock.STICKY_TOP),
				state.method_11654(LinearChassisBlock.STICKY_BOTTOM)));
		};
	}

	public static <B extends RadialChassisBlock> NonNullBiConsumer<DataGenContext<class_2248, B>, RegistrateBlockstateProvider> radialChassis() {
		return (c, p) -> {
			String path = "block/" + c.getName();
			class_2960 side = p.modLoc(path + "_side");
			class_2960 side_sticky = p.modLoc(path + "_side_sticky");

			String templateModelPath = "block/radial_chassis";
			ModelFile base = p.models()
				.getExistingFile(p.modLoc(templateModelPath + "/base"));
			Vector<ModelFile> faces = new Vector<>(3);
			Vector<ModelFile> stickyFaces = new Vector<>(3);

			for (class_2351 axis : Iterate.axes) {
				String suffix = "side_" + axis.method_15434();
				faces.add(p.models()
					.withExistingParent("block/" + c.getName() + "_" + suffix,
						p.modLoc(templateModelPath + "/" + suffix))
					.texture("side", side));
			}
			for (class_2351 axis : Iterate.axes) {
				String suffix = "side_" + axis.method_15434();
				stickyFaces.add(p.models()
					.withExistingParent("block/" + c.getName() + "_" + suffix + "_sticky",
						p.modLoc(templateModelPath + "/" + suffix))
					.texture("side", side_sticky));
			}

			MultiPartBlockStateBuilder builder = p.getMultipartBuilder(c.get());
			class_2680 propertyGetter = c.get()
				.method_9564()
				.method_11657(RadialChassisBlock.field_11459, class_2351.field_11052);

			for (class_2351 axis : Iterate.axes)
				builder.part()
					.modelFile(base)
					.rotationX(axis != class_2351.field_11052 ? 90 : 0)
					.rotationY(axis != class_2351.field_11048 ? 0 : 90)
					.addModel()
					.condition(RadialChassisBlock.field_11459, axis)
					.end();

			for (class_2350 face : Iterate.horizontalDirections) {
				for (boolean sticky : Iterate.trueAndFalse) {
					for (class_2351 axis : Iterate.axes) {
						int horizontalAngle = (int) (face.method_10144());
						int index = axis.ordinal();
						int xRot = 0;
						int yRot = 0;

						if (axis == class_2351.field_11048)
							xRot = -horizontalAngle + 180;
						if (axis == class_2351.field_11052)
							yRot = horizontalAngle;
						if (axis == class_2351.field_11051) {
							yRot = -horizontalAngle + 270;

							// blockstates can't have zRot, so here we are
							if (face.method_10166() == class_2351.field_11051) {
								index = 0;
								xRot = horizontalAngle + 180;
								yRot = 90;
							}
						}

						builder.part()
							.modelFile((sticky ? stickyFaces : faces).get(index))
							.rotationX((xRot + 360) % 360)
							.rotationY((yRot + 360) % 360)
							.addModel()
							.condition(RadialChassisBlock.field_11459, axis)
							.condition(c.get()
								.getGlueableSide(propertyGetter, face), sticky)
							.end();
					}
				}
			}
		};
	}

	public static <P extends class_2248> NonNullBiConsumer<DataGenContext<class_2248, P>, RegistrateBlockstateProvider> naturalStoneTypeBlock(
		String type) {
		return (c, p) -> {
			ConfiguredModel[] variants = new ConfiguredModel[4];
			for (int i = 0; i < variants.length; i++)
				variants[i] = ConfiguredModel.builder()
					.modelFile(p.models()
						.cubeAll(type + "_natural_" + i, p.modLoc("block/palettes/stone_types/natural/" + type + "_" + i)))
					.buildLast();
			p.getVariantBuilder(c.get())
				.partialState()
				.setModels(variants);
		};
	}

	public static <P extends EncasedPipeBlock> NonNullBiConsumer<DataGenContext<class_2248, P>, RegistrateBlockstateProvider> encasedPipe() {
		return (c, p) -> {
			ModelFile open = AssetLookup.partialBaseModel(c, p, "open");
			ModelFile flat = AssetLookup.partialBaseModel(c, p, "flat");
			MultiPartBlockStateBuilder builder = p.getMultipartBuilder(c.get());
			for (boolean flatPass : Iterate.trueAndFalse)
				for (class_2350 d : Iterate.directions) {
					int verticalAngle = d == class_2350.field_11036 ? 90 : d == class_2350.field_11033 ? -90 : 0;
					builder.part()
						.modelFile(flatPass ? flat : open)
						.rotationX(verticalAngle)
						.rotationY((int) (d.method_10144() + (d.method_10166()
							.method_10178() ? 90 : 0)) % 360)
						.addModel()
						.condition(EncasedPipeBlock.FACING_TO_PROPERTY_MAP.get(d), !flatPass)
						.end();
				}
		};
	}

	public static <P extends class_2533> NonNullBiConsumer<DataGenContext<class_2248, P>, RegistrateBlockstateProvider> uvLockedTrapdoorBlock(
		P block, ModelFile bottom, ModelFile top, ModelFile open) {
		return (c, p) -> {
			p.getVariantBuilder(block)
				.forAllStatesExcept(state -> {
					int xRot = 0;
					int yRot = ((int) state.method_11654(class_2533.field_11177)
						.method_10144()) + 180;
					boolean isOpen = state.method_11654(class_2533.field_11631);
					if (!isOpen)
						yRot = 0;
					yRot %= 360;
					return ConfiguredModel.builder()
						.modelFile(isOpen ? open : state.method_11654(class_2533.field_11625) == class_2760.field_12619 ? top : bottom)
						.rotationX(xRot)
						.rotationY(yRot)
						.uvLock(!isOpen)
						.build();
				}, class_2533.field_11629, class_2533.field_11626);
		};
	}

	public static <P extends WhistleExtenderBlock> NonNullBiConsumer<DataGenContext<class_2248, P>, RegistrateBlockstateProvider> whistleExtender() {
		return (c, p) -> {
			BlockModelProvider models = p.models();
			String basePath = "block/steam_whistle/extension/";
			MultiPartBlockStateBuilder builder = p.getMultipartBuilder(c.get());

			for (WhistleSize size : WhistleSize.values()) {
				String basePathSize = basePath + size.method_15434() + "_";
				ExistingModelFile topRim = models.getExistingFile(Create.asResource(basePathSize + "top_rim"));
				ExistingModelFile single = models.getExistingFile(Create.asResource(basePathSize + "single"));
				ExistingModelFile double_ = models.getExistingFile(Create.asResource(basePathSize + "double"));

				builder.part()
					.modelFile(topRim)
					.addModel()
					.condition(WhistleExtenderBlock.SIZE, size)
					.condition(WhistleExtenderBlock.SHAPE, WhistleExtenderShape.DOUBLE)
					.end()
					.part()
					.modelFile(single)
					.addModel()
					.condition(WhistleExtenderBlock.SIZE, size)
					.condition(WhistleExtenderBlock.SHAPE, WhistleExtenderShape.SINGLE)
					.end()
					.part()
					.modelFile(double_)
					.addModel()
					.condition(WhistleExtenderBlock.SIZE, size)
					.condition(WhistleExtenderBlock.SHAPE, WhistleExtenderShape.DOUBLE,
						WhistleExtenderShape.DOUBLE_CONNECTED)
					.end();
			}
		};
	}

	public static <P extends FluidPipeBlock> NonNullBiConsumer<DataGenContext<class_2248, P>, RegistrateBlockstateProvider> pipe() {
		return (c, p) -> {
			String path = "block/" + c.getName();

			String LU = "lu";
			String RU = "ru";
			String LD = "ld";
			String RD = "rd";
			String LR = "lr";
			String UD = "ud";
			String U = "u";
			String D = "d";
			String L = "l";
			String R = "r";

			List<String> orientations = ImmutableList.of(LU, RU, LD, RD, LR, UD, U, D, L, R);
			Map<String, Pair<Integer, Integer>> uvs = ImmutableMap.<String, Pair<Integer, Integer>>builder()
				.put(LU, Pair.of(12, 4))
				.put(RU, Pair.of(8, 4))
				.put(LD, Pair.of(12, 0))
				.put(RD, Pair.of(8, 0))
				.put(LR, Pair.of(4, 8))
				.put(UD, Pair.of(0, 8))
				.put(U, Pair.of(4, 4))
				.put(D, Pair.of(0, 0))
				.put(L, Pair.of(4, 0))
				.put(R, Pair.of(0, 4))
				.build();

			Map<class_2351, class_2960> coreTemplates = new IdentityHashMap<>();
			Map<Pair<String, class_2351>, ModelFile> coreModels = new HashMap<>();

			for (class_2351 axis : Iterate.axes)
				coreTemplates.put(axis, p.modLoc(path + "/core_" + axis.method_15434()));

			for (class_2351 axis : Iterate.axes) {
				class_2960 parent = coreTemplates.get(axis);
				for (String s : orientations) {
					Pair<String, class_2351> key = Pair.of(s, axis);
					String modelName = path + "/" + s + "_" + axis.method_15434();
					coreModels.put(key, p.models()
						.withExistingParent(modelName, parent)
						.element()
						.from(4, 4, 4)
						.to(12, 12, 12)
						.face(class_2350.method_10156(class_2352.field_11056, axis))
						.end()
						.face(class_2350.method_10156(class_2352.field_11060, axis))
						.end()
						.faces((d, builder) -> {
							Pair<Integer, Integer> pair = uvs.get(s);
							float u = pair.getKey();
							float v = pair.getValue();
							if (d == class_2350.field_11036)
								builder.uvs(u + 4, v + 4, u, v);
							if (d == class_2350.field_11033)
								builder.uvs(u + 4, v, u, v + 4);
							if (d == class_2350.field_11043)
								builder.uvs(u, v, u + 4, v + 4);
							if (d == class_2350.field_11035)
								builder.uvs(u + 4, v, u, v + 4);
							if (d == class_2350.field_11034)
								builder.uvs(u, v, u + 4, v + 4);
							if (d == class_2350.field_11039)
								builder.uvs(u + 4, v, u, v + 4);
							builder.texture("#0");
						})
						.end());
				}
			}

			MultiPartBlockStateBuilder builder = p.getMultipartBuilder(c.get());
			for (class_2351 axis : Iterate.axes) {
				putPart(coreModels, builder, axis, LU, true, false, true, false);
				putPart(coreModels, builder, axis, RU, true, false, false, true);
				putPart(coreModels, builder, axis, LD, false, true, true, false);
				putPart(coreModels, builder, axis, RD, false, true, false, true);
				putPart(coreModels, builder, axis, UD, true, true, false, false);
				putPart(coreModels, builder, axis, U, true, false, false, false);
				putPart(coreModels, builder, axis, D, false, true, false, false);
				putPart(coreModels, builder, axis, LR, false, false, true, true);
				putPart(coreModels, builder, axis, L, false, false, true, false);
				putPart(coreModels, builder, axis, R, false, false, false, true);
			}
		};
	}

	private static void putPart(Map<Pair<String, class_2351>, ModelFile> coreModels, MultiPartBlockStateBuilder builder,
		class_2351 axis, String s, boolean up, boolean down, boolean left, boolean right) {
		class_2350 positiveAxis = class_2350.method_10156(class_2352.field_11056, axis);
		Map<class_2350, class_2746> propertyMap = FluidPipeBlock.field_11329;

		class_2350 upD = Pointing.UP.getCombinedDirection(positiveAxis);
		class_2350 leftD = Pointing.LEFT.getCombinedDirection(positiveAxis);
		class_2350 rightD = Pointing.RIGHT.getCombinedDirection(positiveAxis);
		class_2350 downD = Pointing.DOWN.getCombinedDirection(positiveAxis);

		if (axis == class_2351.field_11052 || axis == class_2351.field_11048) {
			leftD = leftD.method_10153();
			rightD = rightD.method_10153();
		}

		builder.part()
			.modelFile(coreModels.get(Pair.of(s, axis)))
			.addModel()
			.condition(propertyMap.get(upD), up)
			.condition(propertyMap.get(leftD), left)
			.condition(propertyMap.get(rightD), right)
			.condition(propertyMap.get(downD), down)
			.end();
	}

	public static Function<class_2680, ConfiguredModel[]> mapToAir(@NonnullType RegistrateBlockstateProvider p) {
		return state -> ConfiguredModel.builder()
			.modelFile(p.models()
				.getExistingFile(p.mcLoc("block/air")))
			.build();
	}

}
