package com.simibubi.create.foundation.data;

import static net.minecraft.class_2741.field_12487;
import static net.minecraft.class_2741.field_12489;
import static net.minecraft.class_2741.field_12540;
import static net.minecraft.class_2741.field_12527;

import java.util.function.Supplier;
import net.minecraft.class_1921;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2389;
import net.minecraft.class_2498;
import net.minecraft.class_2960;
import net.minecraft.class_3620;
import net.minecraft.class_7800;
import com.simibubi.create.AllTags.AllBlockTags;
import com.simibubi.create.Create;
import com.tterrag.registrate.providers.DataGenContext;
import com.tterrag.registrate.providers.RegistrateBlockstateProvider;
import com.tterrag.registrate.util.DataIngredient;
import com.tterrag.registrate.util.entry.BlockEntry;
import com.tterrag.registrate.util.nullness.NonNullBiConsumer;
import io.github.fabricators_of_create.porting_lib.models.generators.ModelFile;

public class MetalBarsGen {

	public static <P extends class_2389> NonNullBiConsumer<DataGenContext<class_2248, P>, RegistrateBlockstateProvider> barsBlockState(
		String name, boolean specialEdge) {
		return (c, p) -> {

			ModelFile post_ends = barsSubModel(p, name, "post_ends", specialEdge);
			ModelFile post = barsSubModel(p, name, "post", specialEdge);
			ModelFile cap = barsSubModel(p, name, "cap", specialEdge);
			ModelFile cap_alt = barsSubModel(p, name, "cap_alt", specialEdge);
			ModelFile side = barsSubModel(p, name, "side", specialEdge);
			ModelFile side_alt = barsSubModel(p, name, "side_alt", specialEdge);

			p.getMultipartBuilder(c.get())
				.part()
				.modelFile(post_ends)
				.addModel()
				.end()
				.part()
				.modelFile(post)
				.addModel()
				.condition(field_12489, false)
				.condition(field_12487, false)
				.condition(field_12540, false)
				.condition(field_12527, false)
				.end()
				.part()
				.modelFile(cap)
				.addModel()
				.condition(field_12489, true)
				.condition(field_12487, false)
				.condition(field_12540, false)
				.condition(field_12527, false)
				.end()
				.part()
				.modelFile(cap)
				.rotationY(90)
				.addModel()
				.condition(field_12489, false)
				.condition(field_12487, true)
				.condition(field_12540, false)
				.condition(field_12527, false)
				.end()
				.part()
				.modelFile(cap_alt)
				.addModel()
				.condition(field_12489, false)
				.condition(field_12487, false)
				.condition(field_12540, true)
				.condition(field_12527, false)
				.end()
				.part()
				.modelFile(cap_alt)
				.rotationY(90)
				.addModel()
				.condition(field_12489, false)
				.condition(field_12487, false)
				.condition(field_12540, false)
				.condition(field_12527, true)
				.end()
				.part()
				.modelFile(side)
				.addModel()
				.condition(field_12489, true)
				.end()
				.part()
				.modelFile(side)
				.rotationY(90)
				.addModel()
				.condition(field_12487, true)
				.end()
				.part()
				.modelFile(side_alt)
				.addModel()
				.condition(field_12540, true)
				.end()
				.part()
				.modelFile(side_alt)
				.rotationY(90)
				.addModel()
				.condition(field_12527, true)
				.end();
		};
	}

	private static ModelFile barsSubModel(RegistrateBlockstateProvider p, String name, String suffix,
										  boolean specialEdge) {
		class_2960 barsTexture = p.modLoc("block/bars/" + name + "_bars");
		class_2960 edgeTexture = specialEdge ? p.modLoc("block/bars/" + name + "_bars_edge") : barsTexture;
		return p.models()
			.withExistingParent(name + "_" + suffix, p.modLoc("block/bars/" + suffix))
			.texture("bars", barsTexture)
			.texture("particle", barsTexture)
			.texture("edge", edgeTexture);
	}

	public static BlockEntry<class_2389> createBars(String name, boolean specialEdge,
													   Supplier<DataIngredient> ingredient, class_3620 color) {
		return Create.registrate().block(name + "_bars", class_2389::new)
			.addLayer(() -> class_1921::method_23579)
			.initialProperties(() -> class_2246.field_10576)
			.properties(p -> p.method_9626(class_2498.field_27204)
				.method_31710(color))
			.tag(AllBlockTags.WRENCH_PICKUP.tag)
			.tag(AllBlockTags.FAN_TRANSPARENT.tag)
			.transform(TagGen.pickaxeOnly())
			.blockstate(barsBlockState(name, specialEdge))
			.item()
			.model((c, p) -> {
				class_2960 barsTexture = p.modLoc("block/bars/" + name + "_bars");
				p.generated(c, barsTexture);
			})
			.recipe((c, p) -> p.stonecutting(ingredient.get(), class_7800.field_40635, c::get, 4))
			.build()
			.register();
	}

}
