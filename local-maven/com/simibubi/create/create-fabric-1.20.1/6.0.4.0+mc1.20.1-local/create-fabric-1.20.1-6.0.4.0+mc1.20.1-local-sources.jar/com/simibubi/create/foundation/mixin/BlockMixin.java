package com.simibubi.create.foundation.mixin;

import java.util.List;
import net.minecraft.class_1297;
import net.minecraft.class_1542;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import com.llamalad7.mixinextras.injector.v2.WrapWithCondition;
import com.simibubi.create.content.kinetics.deployer.DeployerHandler;

@Mixin(class_2248.class)
public class BlockMixin {
	@WrapWithCondition(method = "popResource(Lnet/minecraft/world/level/Level;Ljava/util/function/Supplier;Lnet/minecraft/world/item/ItemStack;)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/Level;addFreshEntity(Lnet/minecraft/world/entity/Entity;)Z"))
	private static boolean create$handlePopResource(class_1937 instance, class_1297 entity) {
		List<class_1542> list = DeployerHandler.CAPTURED_BLOCK_DROPS_VIEW.get(entity.method_24515());
		if (list != null) {
			list.add((class_1542) entity);
			return false;
		}
		return true;
	}
}
