package com.simibubi.create.foundation.item;

import net.fabricmc.fabric.api.registry.FuelRegistry;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_3956;

public class CombustibleItem extends class_1792 {
	private int burnTime = -1;

	public CombustibleItem(class_1793 properties) {
		super(properties);
	}

	public void setBurnTime(int burnTime) {
		FuelRegistry.INSTANCE.add(this, burnTime);
		this.burnTime = burnTime;
	}

//	@Override
	public int getBurnTime(class_1799 itemStack, class_3956<?> recipeType) {
		return this.burnTime;
	}

}
