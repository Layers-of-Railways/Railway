package com.simibubi.create.foundation.networking;

import com.simibubi.create.foundation.blockEntity.SyncedBlockEntity;

import com.simibubi.create.foundation.utility.AdventureUtil;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2540;
import net.minecraft.class_2586;
import net.minecraft.class_3222;

public abstract class BlockEntityConfigurationPacket<BE extends SyncedBlockEntity> extends SimplePacketBase {

	protected class_2338 pos;

	public BlockEntityConfigurationPacket(class_2540 buffer) {
		pos = buffer.method_10811();
		readSettings(buffer);
	}

	public BlockEntityConfigurationPacket(class_2338 pos) {
		this.pos = pos;
	}

	@Override
	public void write(class_2540 buffer) {
		buffer.method_10807(pos);
		writeSettings(buffer);
	}

	@SuppressWarnings("unchecked")
	@Override
	public boolean handle(Context context) {
		context.enqueueWork(() -> {
			class_3222 player = context.getSender();
			if (player == null || player.method_7325() || AdventureUtil.isAdventure(player))
				return;
			class_1937 world = player.method_37908();
			if (world == null || !world.method_8477(pos))
				return;
			if (!pos.method_19771(player.method_24515(), maxRange()))
				return;
			class_2586 blockEntity = world.method_8321(pos);
			if (blockEntity instanceof SyncedBlockEntity) {
				applySettings(player, (BE) blockEntity);
				if (!causeUpdate())
					return;
				((SyncedBlockEntity) blockEntity).sendData();
				blockEntity.method_5431();
			}
		});
		return true;
	}

	protected int maxRange() {
		return 20;
	}

	protected abstract void writeSettings(class_2540 buffer);

	protected abstract void readSettings(class_2540 buffer);

	protected void applySettings(class_3222 player, BE be) {
		applySettings(be);
	}

	protected boolean causeUpdate() {
		return true;
	}

	protected abstract void applySettings(BE be);

}
