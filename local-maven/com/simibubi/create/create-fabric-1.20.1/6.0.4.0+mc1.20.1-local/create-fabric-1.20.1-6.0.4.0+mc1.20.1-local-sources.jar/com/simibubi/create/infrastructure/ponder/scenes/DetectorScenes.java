package com.simibubi.create.infrastructure.ponder.scenes;

import com.simibubi.create.content.redstone.smartObserver.SmartObserverBlockEntity;
import com.simibubi.create.content.redstone.thresholdSwitch.ThresholdSwitchBlock;
import com.simibubi.create.foundation.ponder.CreateSceneBuilder;

import net.createmod.catnip.math.Pointing;
import net.createmod.ponder.api.PonderPalette;
import net.createmod.ponder.api.element.ElementLink;
import net.createmod.ponder.api.element.WorldSectionElement;
import net.createmod.ponder.api.scene.SceneBuilder;
import net.createmod.ponder.api.scene.SceneBuildingUtil;
import net.createmod.ponder.api.scene.Selection;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;

public class DetectorScenes {

	public static void smartObserver(SceneBuilder builder, SceneBuildingUtil util) {
		CreateSceneBuilder scene = new CreateSceneBuilder(builder);
		scene.title("smart_observer", "Advanced detection with Smart Observers");
		scene.configureBasePlate(0, 0, 5);
		scene.showBasePlate();
		scene.idle(5);

		Selection chuteObserver = util.select().fromTo(0, 1, 4, 0, 2, 4);
		Selection chute = util.select().fromTo(1, 1, 4, 1, 3, 4);
		Selection pipe = util.select().fromTo(3, 1, 4, 3, 3, 4);
		Selection pipeObserver = util.select().fromTo(4, 1, 4, 4, 2, 4);
		Selection redstoneDust = util.select().fromTo(1, 1, 2, 0, 1, 2);
		Selection belt = util.select().fromTo(1, 1, 1, 3, 1, 1);
		Selection chest = util.select().position(2, 1, 0);
		Selection amethyst = util.select().position(3, 1, 0);
		Selection largeCog = util.select().position(5, 0, 2);
		Selection smallCogs = util.select().fromTo(3, 1, 2, 4, 1, 2);
		class_2338 observerPos = util.grid().at(2, 1, 2);
		class_2338 funnelPos = util.grid().at(3, 2, 1);
		Selection funnelChest = util.select().fromTo(4, 1, 1, 4, 2, 1);

		scene.world().showSection(util.select().position(observerPos), class_2350.field_11033);
		scene.idle(10);

		scene.overlay().showText(60)
			.text("Smart Observers can be used to detect a variety of events")
			.pointAt(util.vector().blockSurface(observerPos, class_2350.field_11039))
			.placeNearTarget();
		scene.idle(50);

		scene.world().showSection(redstoneDust, class_2350.field_11034);
		scene.idle(5);
		ElementLink<WorldSectionElement> chestLink = scene.world().showIndependentSection(chest, class_2350.field_11035);
		scene.world().moveSection(chestLink, util.vector().of(0, 0, 1), 0);
		scene.idle(15);

		class_1799 copperIngot = new class_1799(class_1802.field_27022);
		class_1799 amethystItem = new class_1799(class_2246.field_27159);

		scene.overlay().showControls(util.vector().blockSurface(observerPos.method_10095(), class_2350.field_11043), Pointing.RIGHT, 40)
				.withItem(copperIngot);
		scene.idle(7);
		scene.world().toggleRedstonePower(util.select().position(observerPos));
		scene.world().toggleRedstonePower(redstoneDust);
		scene.effects().indicateRedstone(observerPos);
		scene.idle(15);

		scene.overlay().showText(60)
			.text("It can detect items or fluids inside of generic containers")
			.attachKeyFrame()
			.pointAt(util.vector().blockSurface(observerPos, class_2350.field_11039))
			.placeNearTarget();
		scene.idle(65);

		scene.overlay().showCenteredScrollInput(observerPos, class_2350.field_11036, 10);
		scene.idle(5);
		scene.overlay().showControls(util.vector().blockSurface(observerPos, class_2350.field_11036), Pointing.DOWN, 60).rightClick()
				.withItem(amethystItem);
		scene.idle(7);
		scene.world().setFilterData(util.select().position(observerPos), SmartObserverBlockEntity.class, amethystItem);
		scene.world().toggleRedstonePower(util.select().position(observerPos));
		scene.world().toggleRedstonePower(redstoneDust);
		scene.idle(25);

		scene.overlay().showText(60)
			.text("The filter slot can be used to look for specific contents only")
			.attachKeyFrame()
			.pointAt(util.vector().blockSurface(observerPos, class_2350.field_11036))
			.placeNearTarget();
		scene.idle(50);

		scene.world().hideIndependentSection(chestLink, class_2350.field_11034);
		scene.idle(10);
		ElementLink<WorldSectionElement> amethystLink = scene.world().showIndependentSection(amethyst, class_2350.field_11034);
		scene.world().moveSection(amethystLink, util.vector().of(-1, 0, 1), 0);
		scene.idle(15);
		scene.world().toggleRedstonePower(util.select().position(observerPos));
		scene.world().toggleRedstonePower(redstoneDust);
		scene.effects().indicateRedstone(observerPos);
		scene.idle(15);

		scene.overlay().showText(50)
			.text("It also activates when the block itself matches the filter")
			.attachKeyFrame()
			.pointAt(util.vector().blockSurface(observerPos.method_10095(), class_2350.field_11039))
			.placeNearTarget();

		scene.idle(45);
		scene.world().hideIndependentSection(amethystLink, class_2350.field_11034);
		scene.world().toggleRedstonePower(util.select().position(observerPos));
		scene.world().toggleRedstonePower(redstoneDust);
		scene.idle(15);
		scene.world().showSection(largeCog, class_2350.field_11036);
		scene.idle(5);
		scene.world().showSection(smallCogs, class_2350.field_11033);
		scene.world().showSection(belt, class_2350.field_11035);
		scene.idle(15);
		scene.world().setFilterData(util.select().position(0, 2, 4), SmartObserverBlockEntity.class, copperIngot);
		scene.world().showSection(chuteObserver, class_2350.field_11033);
		scene.idle(2);
		scene.world().setFilterData(util.select().position(4, 2, 4), SmartObserverBlockEntity.class,
									new class_1799(class_1802.field_8187));
		scene.world().showSection(pipeObserver, class_2350.field_11033);
		scene.idle(5);
		scene.world().showSection(chute, class_2350.field_11039);
		scene.idle(2);
		scene.world().showSection(pipe, class_2350.field_11034);
		scene.idle(10);

		scene.overlay().showText(60)
			.text("Additionally, smart observers can monitor belts, chutes and pipes")
			.attachKeyFrame()
			.pointAt(util.vector().blockSurface(observerPos, class_2350.field_11036))
			.placeNearTarget();
		scene.idle(60);

		scene.world().createItemOnBelt(util.grid().at(3, 1, 1), class_2350.field_11034, amethystItem);
		scene.idle(15);

		scene.world().toggleRedstonePower(util.select().position(observerPos));
		scene.world().toggleRedstonePower(redstoneDust);
		scene.effects().indicateRedstone(observerPos);
		scene.idle(13);

		scene.world().toggleRedstonePower(util.select().position(observerPos));
		scene.world().toggleRedstonePower(redstoneDust);
		scene.idle(25);

		scene.world().showSection(funnelChest, class_2350.field_11039);
		scene.idle(5);
		scene.world().showSection(util.select().position(funnelPos), class_2350.field_11033);
		scene.idle(5);
		ElementLink<WorldSectionElement> observerLink =
			scene.world().makeSectionIndependent(util.select().position(observerPos));
		scene.world().moveSection(observerLink, util.vector().of(1, 1, 0), 10);
		scene.world().hideSection(redstoneDust, class_2350.field_11034);
		scene.idle(20);

		scene.overlay().showText(60)
			.text("...and will emit a pulse, if an item enters or exits a funnel")
			.attachKeyFrame()
			.pointAt(util.vector().blockSurface(observerPos.method_10084()
				.method_10078(), class_2350.field_11039))
			.placeNearTarget();
		scene.idle(60);

		for (int i = 0; i < 3; i++) {
			scene.world().createItemOnBelt(util.grid().at(3, 1, 1), class_2350.field_11034, amethystItem);

			scene.world().toggleRedstonePower(util.select().position(observerPos));
			scene.effects().indicateRedstone(observerPos.method_10084()
				.method_10078());
			scene.idle(5);

			scene.world().toggleRedstonePower(util.select().position(observerPos));
			scene.idle(25);
		}

	}

	public static void thresholdSwitch(SceneBuilder builder, SceneBuildingUtil util) {
		CreateSceneBuilder scene = new CreateSceneBuilder(builder);
		scene.title("threshold_switch", "Monitoring with the Threshold Switch");
		scene.configureBasePlate(0, 1, 5);

		Selection fluidTank = util.select().fromTo(1, 1, 5, 1, 3, 5);
		Selection pulley = util.select().fromTo(3, 2, 3, 2, 2, 3);
		class_2338 pulleyPos = util.grid().at(2, 2, 3);
		class_2338 switchPos = util.grid().at(1, 1, 3);
		Selection redstone = util.select().fromTo(1, 1, 2, 1, 1, 1);
		Selection chest = util.select().fromTo(3, 1, 3, 2, 1, 3);
		Selection belt = util.select().fromTo(3, 0, 0, 3, 0, 6);
		Selection cogs = util.select().fromTo(4, 0, 6, 5, 0, 6)
			.add(util.select().position(5, 0, 5));
		Selection inFunnel = util.select().position(3, 1, 2);
		Selection outFunnel = util.select().position(3, 1, 4);
		Selection baseStrip = util.select().fromTo(1, 0, 1, 1, 0, 5);
		Selection basePlate = util.select().fromTo(0, 0, 1, 2, 0, 5)
			.add(util.select().fromTo(4, 0, 5, 4, 0, 1));

		scene.world().showSection(basePlate, class_2350.field_11036);
		ElementLink<WorldSectionElement> stripLink = scene.world().showIndependentSection(baseStrip, class_2350.field_11036);
		scene.world().moveSection(stripLink, util.vector().of(2, 0, 0), 0);
		scene.idle(5);

		scene.world().showSection(util.select().position(switchPos), class_2350.field_11033);
		scene.idle(10);
		scene.world().showSection(chest, class_2350.field_11039);
		scene.idle(10);
		scene.world().cycleBlockProperty(switchPos, ThresholdSwitchBlock.LEVEL);
		scene.idle(5);

		scene.overlay().showText(60)
			.text("Threshold Switches monitor the fill level of containers")
			.pointAt(util.vector().blockSurface(switchPos, class_2350.field_11043))
			.placeNearTarget();
		scene.idle(60);

		scene.world().hideIndependentSection(stripLink, class_2350.field_11033);
		scene.idle(15);
		scene.world().showSection(cogs, class_2350.field_11039);
		scene.world().showSection(belt, class_2350.field_11043);
		scene.idle(5);
		scene.world().showSection(inFunnel, class_2350.field_11033);
		scene.idle(10);
		scene.world().showSection(redstone, class_2350.field_11035);
		class_1799 ironIngot = new class_1799(class_1802.field_8620, 32);

		for (int i = 0; i < 5; i++) {
			scene.world().createItemOnBelt(util.grid().at(3, 0, 0), class_2350.field_11043, ironIngot);
			scene.idle(10);
			scene.world().removeItemsFromBelt(util.grid().at(3, 0, 2));
			scene.world().flapFunnel(util.grid().at(3, 1, 2), false);

			if (i % 2 == 1)
				scene.world().cycleBlockProperty(switchPos, ThresholdSwitchBlock.LEVEL);
		}

		scene.addLazyKeyframe();
		scene.world().createItemOnBelt(util.grid().at(3, 0, 0), class_2350.field_11043, ironIngot);
		scene.world().removeItemsFromBelt(util.grid().at(3, 0, 2));
		scene.world().multiplyKineticSpeed(util.select().everywhere(), 1 / 8f);
		scene.idle(10);

		class_243 upper = util.vector().blockSurface(switchPos, class_2350.field_11043)
			.method_1031(0, 3 / 16f, 0);
		scene.overlay().showLine(PonderPalette.RED, upper.method_1031(2 / 16f, 0, 0), upper.method_1023(2 / 16f, 0, 0), 60);
		scene.overlay().showText(70)
			.text("When the inventory content exceeds the upper threshold...")
			.colored(PonderPalette.RED)
			.pointAt(upper.method_1023(2 / 16f, 0, 0))
			.placeNearTarget();

		scene.idle(60);
		scene.world().removeItemsFromBelt(util.grid().at(3, 0, 2));
		scene.world().flapFunnel(util.grid().at(3, 1, 2), false);
		scene.world().cycleBlockProperty(switchPos, ThresholdSwitchBlock.LEVEL);
		scene.effects().indicateRedstone(switchPos);
		scene.world().toggleRedstonePower(redstone);
		scene.idle(20);

		scene.overlay().showText(50)
			.text("...the switch will change its redstone output")
			.pointAt(util.vector().blockSurface(switchPos.method_10095(), class_2350.field_11033))
			.placeNearTarget();
		scene.idle(50);

		scene.world().showSection(outFunnel, class_2350.field_11033);
		scene.world().toggleRedstonePower(outFunnel);
		scene.idle(15);

		scene.world().multiplyKineticSpeed(util.select().everywhere(), 8f);
		for (int i = 0; i < 5; i++) {
			scene.idle(10);
			scene.world().createItemOnBelt(util.grid().at(3, 0, 4), class_2350.field_11043, ironIngot);
			if (i % 3 == 1)
				scene.world().modifyBlock(switchPos,
					s -> s.method_11657(ThresholdSwitchBlock.LEVEL, s.method_11654(ThresholdSwitchBlock.LEVEL) - 1), false);
		}
		scene.world().multiplyKineticSpeed(util.select().everywhere(), 1 / 8f);

		class_243 lower = util.vector().blockSurface(switchPos, class_2350.field_11043)
			.method_1031(0, -3 / 16f, 0);
		scene.overlay().showLine(PonderPalette.GREEN, lower.method_1031(2 / 16f, 0, 0), lower.method_1023(2 / 16f, 0, 0), 60);
		scene.overlay().showText(70)
			.text("The signal stays until the lower threshold is reached")
			.attachKeyFrame()
			.colored(PonderPalette.GREEN)
			.pointAt(lower.method_1023(2 / 16f, 0, 0))
			.placeNearTarget();
		scene.idle(30);

		for (int i = 0; i < 3; i++) {
			scene.idle(10);
			scene.world().createItemOnBelt(util.grid().at(3, 0, 4), class_2350.field_11043, ironIngot);
			if (i % 3 == 2)
				scene.world().modifyBlock(switchPos,
					s -> s.method_11657(ThresholdSwitchBlock.LEVEL, s.method_11654(ThresholdSwitchBlock.LEVEL) - 1), false);
		}

		scene.world().toggleRedstonePower(redstone);
		scene.idle(40);

		scene.overlay().showText(90)
			.text("The redstone output can now be used to control item supply, keeping the buffer filled")
			.pointAt(util.vector().blockSurface(switchPos.method_10095(), class_2350.field_11033))
			.attachKeyFrame()
			.placeNearTarget();
		scene.idle(100);

		scene.addKeyframe();
		scene.overlay().showLine(PonderPalette.GREEN, lower.method_1031(2 / 16f, 0, 0), lower.method_1023(2 / 16f, 0, 0), 105);
		scene.idle(5);
		scene.overlay().showLine(PonderPalette.RED, upper.method_1031(2 / 16f, 0, 0), upper.method_1023(2 / 16f, 0, 0), 100);
		scene.idle(15);
		scene.overlay().showControls(util.vector().blockSurface(switchPos, class_2350.field_11036), Pointing.DOWN, 60).rightClick();
		scene.idle(7);
		scene.overlay().showText(70)
			.text("The specific thresholds can be changed in the UI")
			.pointAt(upper.method_1023(2 / 16f, 0, 0))
			.placeNearTarget();
		scene.idle(80);

		scene.overlay().showCenteredScrollInput(switchPos, class_2350.field_11036, 70);
		scene.overlay().showText(70)
			.text("A filter can help to only count specific contents toward the total")
			.pointAt(util.vector().blockSurface(switchPos, class_2350.field_11036))
			.attachKeyFrame()
			.placeNearTarget();

		scene.idle(80);
		scene.world().hideSection(belt, class_2350.field_11035);
		scene.world().hideSection(cogs, class_2350.field_11034);
		scene.idle(2);
		scene.world().hideSection(inFunnel, class_2350.field_11034);
		scene.idle(2);
		scene.world().hideSection(chest, class_2350.field_11034);
		scene.idle(2);
		scene.world().hideSection(outFunnel, class_2350.field_11034);
		scene.idle(9);
		stripLink = scene.world().showIndependentSection(baseStrip, class_2350.field_11036);
		scene.world().moveSection(stripLink, util.vector().of(2, 0, 0), 0);
		scene.idle(5);
		ElementLink<WorldSectionElement> tankLink = scene.world().showIndependentSection(fluidTank, class_2350.field_11033);
		scene.world().moveSection(tankLink, util.vector().of(1, 0, -2), 0);
		scene.idle(10);

		scene.world().cycleBlockProperty(switchPos, ThresholdSwitchBlock.LEVEL);
		scene.world().cycleBlockProperty(switchPos, ThresholdSwitchBlock.LEVEL);
		scene.idle(15);

		scene.overlay().showText(70)
			.text("Fluid buffers can be monitored in a similar fashion")
			.pointAt(util.vector().blockSurface(switchPos, class_2350.field_11043))
			.attachKeyFrame()
			.placeNearTarget();
		scene.idle(80);

		scene.world().hideIndependentSection(tankLink, class_2350.field_11035);
		scene.world().hideSection(redstone, class_2350.field_11043);
		ElementLink<WorldSectionElement> switchLink =
			scene.world().makeSectionIndependent(util.select().position(switchPos));
		scene.idle(10);
		scene.world().moveSection(switchLink, util.vector().of(0, 1, 0), 15);
		scene.world().modifyBlock(switchPos, s -> s.method_11657(ThresholdSwitchBlock.LEVEL, 0), false);
		scene.idle(5);
		scene.world().showSection(pulley, class_2350.field_11033);
		scene.idle(15);
		ElementLink<WorldSectionElement> hole = scene.world().makeSectionIndependent(util.select().position(2, 0, 3));
		scene.world().hideIndependentSection(hole, class_2350.field_11033);

		scene.overlay().showText(70)
			.text("...as well as, curiously, the length of an extended rope pulley")
			.pointAt(util.vector().blockSurface(switchPos.method_10084(), class_2350.field_11043))
			.attachKeyFrame()
			.placeNearTarget();
		scene.idle(10);

		scene.world().setKineticSpeed(pulley, 32);
		scene.world().movePulley(pulleyPos, 15, 205);

		for (int i = 0; i < 4; i++) {
			scene.idle(5);
			scene.world().cycleBlockProperty(switchPos, ThresholdSwitchBlock.LEVEL);
			scene.idle(45);
			if (i == 1)
				scene.markAsFinished();
		}

		scene.idle(5);
		scene.world().cycleBlockProperty(switchPos, ThresholdSwitchBlock.LEVEL);
		scene.world().setKineticSpeed(pulley, 0);

	}

}
