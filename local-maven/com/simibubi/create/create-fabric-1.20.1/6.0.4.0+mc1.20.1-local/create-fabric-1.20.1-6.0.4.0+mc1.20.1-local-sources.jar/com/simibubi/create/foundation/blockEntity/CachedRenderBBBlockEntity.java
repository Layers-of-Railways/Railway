package com.simibubi.create.foundation.blockEntity;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import io.github.fabricators_of_create.porting_lib.block.CustomRenderBoundingBoxBlockEntity;

public abstract class CachedRenderBBBlockEntity extends SyncedBlockEntity implements CustomRenderBoundingBoxBlockEntity {

	private class_238 renderBoundingBox;

	public CachedRenderBBBlockEntity(class_2591<?> type, class_2338 pos, class_2680 state) {
		super(type, pos, state);
	}

	@Override
	@Environment(EnvType.CLIENT)
	public class_238 getRenderBoundingBox() {
		if (renderBoundingBox == null) {
			renderBoundingBox = createRenderBoundingBox();
		}
		return renderBoundingBox;
	}

	protected void invalidateRenderBoundingBox() {
		renderBoundingBox = null;
	}

	protected class_238 createRenderBoundingBox() {
		return CustomRenderBoundingBoxBlockEntity.super.getRenderBoundingBox();
	}

}
