package com.simibubi.create.foundation.blockEntity.behaviour.scrollValue;

import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;

import com.google.common.collect.ImmutableList;
import com.simibubi.create.foundation.blockEntity.SmartBlockEntity;
import com.simibubi.create.foundation.blockEntity.behaviour.BehaviourType;
import com.simibubi.create.foundation.blockEntity.behaviour.BlockEntityBehaviour;
import com.simibubi.create.foundation.blockEntity.behaviour.ValueBoxTransform;
import com.simibubi.create.foundation.blockEntity.behaviour.ValueSettingsBehaviour;
import com.simibubi.create.foundation.blockEntity.behaviour.ValueSettingsBoard;
import com.simibubi.create.foundation.blockEntity.behaviour.ValueSettingsFormatter;
import net.fabricmc.fabric.api.entity.FakePlayer;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3532;
import net.minecraft.class_3965;

public class ScrollValueBehaviour extends BlockEntityBehaviour implements ValueSettingsBehaviour {

	public static final BehaviourType<ScrollValueBehaviour> TYPE = new BehaviourType<>();

	ValueBoxTransform slotPositioning;
	class_243 textShift;

	int min = 0;
	protected int max = 1;
	public int value;
	public class_2561 label;
	Consumer<Integer> callback;
	Consumer<Integer> clientCallback;
	Function<Integer, String> formatter;
	private Supplier<Boolean> isActive;
	boolean needsWrench;

	public ScrollValueBehaviour(class_2561 label, SmartBlockEntity be, ValueBoxTransform slot) {
		super(be);
		this.setLabel(label);
		slotPositioning = slot;
		callback = i -> {
		};
		clientCallback = i -> {
		};
		formatter = i -> Integer.toString(i);
		value = 0;
		isActive = () -> true;
	}

	@Override
	public boolean isSafeNBT() {
		return true;
	}

	@Override
	public void write(class_2487 nbt, boolean clientPacket) {
		nbt.method_10569("ScrollValue", value);
		super.write(nbt, clientPacket);
	}

	@Override
	public void read(class_2487 nbt, boolean clientPacket) {
		value = nbt.method_10550("ScrollValue");
		super.read(nbt, clientPacket);
	}

	public ScrollValueBehaviour withClientCallback(Consumer<Integer> valueCallback) {
		clientCallback = valueCallback;
		return this;
	}

	public ScrollValueBehaviour withCallback(Consumer<Integer> valueCallback) {
		callback = valueCallback;
		return this;
	}

	public ScrollValueBehaviour between(int min, int max) {
		this.min = min;
		this.max = max;
		return this;
	}

	public ScrollValueBehaviour requiresWrench() {
		this.needsWrench = true;
		return this;
	}

	public ScrollValueBehaviour withFormatter(Function<Integer, String> formatter) {
		this.formatter = formatter;
		return this;
	}

	public ScrollValueBehaviour onlyActiveWhen(Supplier<Boolean> condition) {
		isActive = condition;
		return this;
	}

	public void setValue(int value) {
		value = class_3532.method_15340(value, min, max);
		if (value == this.value)
			return;
		this.value = value;
		callback.accept(value);
		blockEntity.method_5431();
		blockEntity.sendData();
	}

	public int getValue() {
		return value;
	}

	public String formatValue() {
		return formatter.apply(value);
	}

	@Override
	public BehaviourType<?> getType() {
		return TYPE;
	}

	@Override
	public boolean isActive() {
		return isActive.get();
	}

	@Override
	public boolean testHit(class_243 hit) {
		class_2680 state = blockEntity.method_11010();
		class_243 localHit = hit.method_1020(class_243.method_24954(blockEntity.method_11016()));
		return slotPositioning.testHit(getWorld(), getPos(), state, localHit);
	}

	public void setLabel(class_2561 label) {
		this.label = label;
	}

	public static class StepContext {
		public int currentValue;
		public boolean forward;
		public boolean shift;
		public boolean control;
	}

	@Override
	public ValueBoxTransform getSlotPositioning() {
		return slotPositioning;
	}

	@Override
	public ValueSettingsBoard createBoard(class_1657 player, class_3965 hitResult) {
		return new ValueSettingsBoard(label, max, 10, ImmutableList.of(class_2561.method_43470("Value")),
			new ValueSettingsFormatter(ValueSettings::format));
	}

	@Override
	public void setValueSettings(class_1657 player, ValueSettings valueSetting, boolean ctrlDown) {
		if (valueSetting.equals(getValueSettings()))
			return;
		setValue(valueSetting.value());
		playFeedbackSound(this);
	}

	@Override
	public ValueSettings getValueSettings() {
		return new ValueSettings(0, value);
	}

	@Override
	public boolean onlyVisibleWithWrench() {
		return needsWrench;
	}

	@Override
	public void onShortInteract(class_1657 player, class_1268 hand, class_2350 side, class_3965 hitResult) {
		if (player instanceof FakePlayer)
			blockEntity.method_11010()
				.method_26174(getWorld(), player, hand, hitResult);
	}

}
