package com.simibubi.create.foundation.mixin.accessor;

import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3609;
import net.minecraft.class_3610;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_3609.class)
public interface FlowingFluidAccessor {
	@Invoker("getNewLiquid")
	class_3610 create$getNewLiquid(class_1937 pLevel, class_2338 pPos, class_2680 pBlockState);
}
