package com.simibubi.create.foundation.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.minecraft.class_1263;
import net.minecraft.class_2480;
import net.minecraft.class_2586;

@Mixin(class_2480.class)
public class ShulkerBoxBlockMixin {
	@ModifyExpressionValue(method = "getAnalogOutputSignal", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/Level;getBlockEntity(Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/level/block/entity/BlockEntity;"))
	private class_2586 create$backportCCESuppressionFix(class_2586 original) {
		return original instanceof class_1263 ? original : null;
	}
}
