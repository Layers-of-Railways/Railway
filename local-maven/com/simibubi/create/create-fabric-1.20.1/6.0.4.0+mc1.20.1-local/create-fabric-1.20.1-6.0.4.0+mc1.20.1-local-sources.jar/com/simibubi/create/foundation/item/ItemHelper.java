package com.simibubi.create.foundation.item;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;

import javax.annotation.Nullable;

import org.apache.commons.lang3.mutable.MutableInt;

import com.simibubi.create.content.logistics.box.PackageEntity;
import com.simibubi.create.foundation.block.IBE;

import net.createmod.catnip.data.Pair;
import net.fabricmc.fabric.api.transfer.v1.item.ItemStorage;
import net.fabricmc.fabric.api.transfer.v1.item.ItemVariant;
import net.fabricmc.fabric.api.transfer.v1.storage.Storage;
import net.fabricmc.fabric.api.transfer.v1.storage.StorageView;
import net.fabricmc.fabric.api.transfer.v1.transaction.Transaction;
import net.minecraft.class_1263;
import net.minecraft.class_1264;
import net.minecraft.class_1297;
import net.minecraft.class_1542;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2371;
import net.minecraft.class_2586;
import net.minecraft.class_3532;
import io.github.fabricators_of_create.porting_lib.transfer.TransferUtil;
import io.github.fabricators_of_create.porting_lib.transfer.item.ItemHandlerHelper;
import io.github.fabricators_of_create.porting_lib.transfer.item.ItemStackHandler;
import io.github.fabricators_of_create.porting_lib.transfer.item.SlottedStackStorage;

public class ItemHelper {

	public static boolean sameItem(class_1799 stack, class_1799 otherStack) {
		return !otherStack.method_7960() && stack.method_31574(otherStack.method_7909());
	}

	public static Predicate<class_1799> sameItemPredicate(class_1799 stack) {
		return s -> sameItem(stack, s);
	}

	public static void dropContents(class_1937 world, class_2338 pos, Storage<ItemVariant> inv) {
		try (Transaction t = TransferUtil.getTransaction()) {
			for (StorageView<ItemVariant> view : inv.nonEmptyViews()) {
				class_1799 stack = view.getResource().toStack((int) view.getAmount());
				class_1264.method_5449(world, pos.method_10263(), pos.method_10264(), pos.method_10260(), stack);
			}
		}
	}

	public static List<class_1799> multipliedOutput(class_1799 in, class_1799 out) {
		List<class_1799> stacks = new ArrayList<>();
		class_1799 result = out.method_7972();
		result.method_7939(in.method_7947() * out.method_7947());

		while (result.method_7947() > result.method_7914()) {
			stacks.add(result.method_7971(result.method_7914()));
		}

		stacks.add(result);
		return stacks;
	}

	public static void addToList(class_1799 stack, List<class_1799> stacks) {
		for (class_1799 s : stacks) {
			if (!ItemHandlerHelper.canItemStacksStack(stack, s))
				continue;
			int transferred = Math.min(s.method_7914() - s.method_7947(), stack.method_7947());
			s.method_7933(transferred);
			stack.method_7934(transferred);
		}
		if (stack.method_7947() > 0)
			stacks.add(stack);
	}

//	public static boolean isSameInventory(Storage<ItemVariant> h1, Storage<ItemVariant> h2) {
//		if (h1 == null || h2 == null)
//			return false;
//		if (h1.getSlotCount() != h2.getSlotCount())
//			return false;
//		for (int slot = 0; slot < h1.getSlotCount(); slot++) {
//			if (h1.getStackInSlot(slot) != h2.getStackInSlot(slot))
//				return false;
//		}
//		return true;
//	}

	public static <T extends IBE<? extends class_2586>> int calcRedstoneFromBlockEntity(T ibe, class_1937 level, class_2338 pos) {
		return calcRedstoneFromInventory(ItemStorage.SIDED.find(level, pos, null));
	}

	public static int calcRedstoneFromInventory(@Nullable Storage<ItemVariant> inv) {
		if (inv == null)
			return 0;
		int i = 0;
		float f = 0.0F;
		int totalSlots = 0;

		try (Transaction t = TransferUtil.getTransaction()) {
			for (StorageView<ItemVariant> view : inv) {
				long slotLimit = view.getCapacity();
				if (slotLimit == 0) {
					continue;
				}
				totalSlots++;
				if (!view.isResourceBlank()) {
					f += (float) view.getAmount() / (float) Math.min(slotLimit, view.getResource().getItem().method_7882());
					++i;
				}
			}
		}

		if (totalSlots == 0)
			return 0;

		f = f / totalSlots;
		return class_3532.method_15375(f * 14.0F) + (i > 0 ? 1 : 0);
	}

	public static List<Pair<class_1856, MutableInt>> condenseIngredients(class_2371<class_1856> recipeIngredients) {
		List<Pair<class_1856, MutableInt>> actualIngredients = new ArrayList<>();
		Ingredients:
		for (class_1856 igd : recipeIngredients) {
			for (Pair<class_1856, MutableInt> pair : actualIngredients) {
				class_1799[] stacks1 = pair.getFirst()
					.method_8105();
				class_1799[] stacks2 = igd.method_8105();
				if (stacks1.length != stacks2.length)
					continue;
				for (int i = 0; i <= stacks1.length; i++) {
					if (i == stacks1.length) {
						pair.getSecond()
							.increment();
						continue Ingredients;
					}
					if (!class_1799.method_7973(stacks1[i], stacks2[i]))
						break;
				}
			}
			actualIngredients.add(Pair.of(igd, new MutableInt(1)));
		}
		return actualIngredients;
	}

	public static boolean matchIngredients(class_1856 i1, class_1856 i2) {
		if (i1 == i2)
			return true;
		class_1799[] stacks1 = i1.method_8105();
		class_1799[] stacks2 = i2.method_8105();
		if (stacks1 == stacks2)
			return true;
		if (stacks1.length == stacks2.length) {
			for (int i = 0; i < stacks1.length; i++)
				if (!class_1799.method_7984(stacks1[i], stacks2[i]))
					return false;
			return true;
		}
		return false;
	}

	public static boolean matchAllIngredients(class_2371<class_1856> ingredients) {
		if (ingredients.size() <= 1)
			return true;
		class_1856 firstIngredient = ingredients.get(0);
		for (int i = 1; i < ingredients.size(); i++)
			if (!matchIngredients(firstIngredient, ingredients.get(i)))
				return false;
		return true;
	}

	public static enum ExtractionCountMode {
		EXACTLY, UPTO
	}

	public static class_1799 extract(Storage<ItemVariant> inv, Predicate<class_1799> test, boolean simulate) {
		return extract(inv, test, ExtractionCountMode.UPTO, 64, simulate);
	}

	public static class_1799 extract(Storage<ItemVariant> inv, Predicate<class_1799> test, int exactAmount, boolean simulate) {
		return extract(inv, test, ExtractionCountMode.EXACTLY, exactAmount, simulate);
	}

	public static class_1799 extract(Storage<ItemVariant> inv, Predicate<class_1799> test, ExtractionCountMode mode, int amount,
									boolean simulate) {
		int extracted = 0;
		ItemVariant extracting = null;
		List<ItemVariant> otherTargets = null;

		if (inv.supportsExtraction()) {
			try (Transaction t = TransferUtil.getTransaction()) {
				for (StorageView<ItemVariant> view : inv.nonEmptyViews()) {
					ItemVariant contained = view.getResource();
					int maxStackSize = contained.getItem().method_7882();
					// amount stored, amount needed, or max size, whichever is lowest.
					int amountToExtractFromThisSlot = Math.min(truncateLong(view.getAmount()), Math.min(amount - extracted, maxStackSize));
					if (!test.test(contained.toStack(amountToExtractFromThisSlot)))
						continue;
					if (extracting == null) {
						extracting = contained; // we found a target
					}
					boolean sameType = extracting.equals(contained);
					if (sameType && maxStackSize == extracted) {
						// stack is maxed out, skip
						continue;
					}
					if (!sameType) {
						// multiple types passed the test
						if (otherTargets == null) {
							otherTargets = new ArrayList<>();
						}
						otherTargets.add(contained);
						continue;
					}
					ItemVariant toExtract = extracting;
					long actualExtracted = view.extract(toExtract, amountToExtractFromThisSlot, t);
					if (actualExtracted == 0) continue;
					extracted += actualExtracted;
					if (extracted == amount) {
						if (!simulate)
							t.commit();
						return toExtract.toStack(extracted);
					}
				}

				// if the code reaches this point, we've extracted as much as possible, and it isn't enough.
				if (mode == ExtractionCountMode.UPTO) { // we don't need to get exactly the amount requested
					if (extracting != null && extracted != 0) {
						if (!simulate) t.commit();
						return extracting.toStack(extracted);
					}
				} else {
					// let's try a different target
					if (otherTargets != null) {
						t.abort();
						try (Transaction nested = TransferUtil.getTransaction()) {
							for (ItemVariant target : otherTargets) {
								// try again, but now only match the existing matches we've found
								class_1799 successfulExtraction = extract(inv, target::matches, mode, amount, simulate);
								if (!successfulExtraction.method_7960()) {
									if (!simulate) nested.commit();
									return successfulExtraction;
								}
							}
						}
					}
				}
			}
		}
		return class_1799.field_8037;
	}

	public static class_1799 extract(Storage<ItemVariant> inv, Predicate<class_1799> test,
									Function<class_1799, Integer> amountFunction, boolean simulate) {
		class_1799 extracting = class_1799.field_8037;
		int maxExtractionCount = 64;

		try (Transaction t = TransferUtil.getTransaction()) {
			for (StorageView<ItemVariant> view : inv.nonEmptyViews()) {
				ItemVariant var = view.getResource();
				class_1799 stackInSlot = var.toStack();
				if (!test.test(stackInSlot))
					continue;
				if (extracting.method_7960()) {
					int maxExtractionCountForItem = amountFunction.apply(stackInSlot);
					if (maxExtractionCountForItem == 0)
						continue;
					maxExtractionCount = Math.min(maxExtractionCount, maxExtractionCountForItem);
				}

				try (Transaction nested = t.openNested()) {
					long extracted = view.extract(var, maxExtractionCount - extracting.method_7947(), nested);
					class_1799 stack = var.toStack((int) extracted);

					if (!test.test(stack))
						continue;
					if (!extracting.method_7960() && !canItemStackAmountsStack(stack, extracting))
						continue;
					nested.commit();
					if (extracting.method_7960())
						extracting = stack.method_7972();
					else
						extracting.method_7933(stack.method_7947());

					if (extracting.method_7947() >= maxExtractionCount)
						break;
				}
			}
			if (!simulate) t.commit();
		}

		return extracting;
	}

	public static boolean canItemStackAmountsStack(class_1799 a, class_1799 b) {
		return ItemHandlerHelper.canItemStacksStack(a, b) && a.method_7947() + b.method_7947() <= a.method_7914();
	}

	public static int truncateLong(long l) {
		if (l > Integer.MAX_VALUE) {
			return Integer.MAX_VALUE;
		} else if (l < Integer.MIN_VALUE) {
			return Integer.MIN_VALUE;
		} else {
			return (int) l;
		}
	}

	public static class_1799 fromItemEntity(class_1297 entityIn) {
		if (!entityIn.method_5805())
			return class_1799.field_8037;
		if (entityIn instanceof PackageEntity packageEntity) {
			return packageEntity.getBox();
		}
		return entityIn instanceof class_1542 itemEntity ? itemEntity.method_6983() : class_1799.field_8037;
	}

	public static class_1799 limitCountToMaxStackSize(class_1799 stack, boolean simulate) {
		int count = stack.method_7947();
		int max = stack.method_7914();
		if (count <= max)
			return class_1799.field_8037;
		class_1799 remainder = ItemHandlerHelper.copyStackWithSize(stack, count - max);
		if (!simulate)
			stack.method_7939(max);
		return remainder;
	}

	public static void copyContents(SlottedStackStorage from, SlottedStackStorage to) {
		if (from.getSlotCount() != to.getSlotCount()) {
			throw new IllegalArgumentException("Slot count mismatch");
		}

		for (int i = 0; i < from.getSlotCount(); i++) {
			to.setStackInSlot(i, from.getStackInSlot(i).method_7972());
		}
	}

	public static void copyContents(SlottedStackStorage from, class_1263 to) {
		if (from.getSlotCount() != to.method_5439()) {
			throw new IllegalArgumentException("Slot count mismatch");
		}

		for (int i = 0; i < from.getSlotCount(); i++) {
			to.method_5447(i, from.getStackInSlot(i).method_7972());
		}
	}

	public static List<class_1799> getNonEmptyStacks(ItemStackHandler handler) {
		List<class_1799> stacks = new ArrayList<>();
		for (int i = 0; i < handler.getSlotCount(); i++) {
			class_1799 stack = handler.getStackInSlot(i);
			if (!stack.method_7960()) {
				stacks.add(stack);
			}
		}
		return stacks;
	}
}
