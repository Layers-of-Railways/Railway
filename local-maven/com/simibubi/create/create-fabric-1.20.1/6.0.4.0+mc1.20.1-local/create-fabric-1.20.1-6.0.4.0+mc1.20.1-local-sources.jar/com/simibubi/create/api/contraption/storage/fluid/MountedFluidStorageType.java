package com.simibubi.create.api.contraption.storage.fluid;

import org.jetbrains.annotations.Nullable;

import com.mojang.serialization.Codec;
import com.simibubi.create.api.registry.CreateBuiltInRegistries;
import com.simibubi.create.api.registry.CreateRegistries;
import com.simibubi.create.api.registry.SimpleRegistry;
import com.tterrag.registrate.builders.BlockBuilder;
import com.tterrag.registrate.util.entry.RegistryEntry;
import com.tterrag.registrate.util.nullness.NonNullUnaryOperator;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2680;

public abstract class MountedFluidStorageType<T extends MountedFluidStorage> {
	public static final Codec<MountedFluidStorageType<?>> CODEC = CreateBuiltInRegistries.MOUNTED_FLUID_STORAGE_TYPE.method_39673();
	public static final SimpleRegistry<class_2248, MountedFluidStorageType<?>> REGISTRY = SimpleRegistry.create();

	public final Codec<? extends T> codec;

	protected MountedFluidStorageType(Codec<? extends T> codec) {
		this.codec = codec;
	}

	@Nullable
	public abstract T mount(class_1937 level, class_2680 state, class_2338 pos, @Nullable class_2586 be);

	/**
	 * Utility for use with Registrate builders. Creates a builder transformer
	 * that will register the given MountedFluidStorageType to a block when ready.
	 */
	public static <B extends class_2248, P> NonNullUnaryOperator<BlockBuilder<B, P>> mountedFluidStorage(RegistryEntry<? extends MountedFluidStorageType<?>> type) {
		return builder -> builder.onRegisterAfter(CreateRegistries.MOUNTED_FLUID_STORAGE_TYPE, block -> REGISTRY.register(block, type.get()));
	}
}
