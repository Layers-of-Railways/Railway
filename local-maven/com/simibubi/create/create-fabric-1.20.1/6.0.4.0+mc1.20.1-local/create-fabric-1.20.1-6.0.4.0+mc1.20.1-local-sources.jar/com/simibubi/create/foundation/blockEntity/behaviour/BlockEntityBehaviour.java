package com.simibubi.create.foundation.blockEntity.behaviour;

import java.util.ConcurrentModificationException;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import com.simibubi.create.content.schematics.requirement.ItemRequirement;
import com.simibubi.create.foundation.blockEntity.SmartBlockEntity;

public abstract class BlockEntityBehaviour {

	public SmartBlockEntity blockEntity;
	private int lazyTickRate;
	private int lazyTickCounter;

	public BlockEntityBehaviour(SmartBlockEntity be) {
		blockEntity = be;
		setLazyTickRate(10);
	}

	public abstract BehaviourType<?> getType();

	public void initialize() {

	}

	public void tick() {
		if (lazyTickCounter-- <= 0) {
			lazyTickCounter = lazyTickRate;
			lazyTick();
		}

	}

	public void read(class_2487 nbt, boolean clientPacket) {

	}

	public void write(class_2487 nbt, boolean clientPacket) {

	}

	/**
	 * Called when isSafeNBT == true. Defaults to write()
	 */
	public void writeSafe(class_2487 nbt) {
		write(nbt, false);
	}

	public boolean isSafeNBT() {
		return false;
	}

	public ItemRequirement getRequiredItems() {
		return ItemRequirement.NONE;
	}

	public void onBlockChanged(class_2680 oldState) {

	}

	public void onNeighborChanged(class_2338 neighborPos) {

	}

	/**
	 * Block destroyed or Chunk unloaded. Usually invalidates capabilities
	 */
	public void unload() {
	}

	/**
	 * Block destroyed or removed. Requires block to call ITE::onRemove
	 */
	public void destroy() {
	}

	public void setLazyTickRate(int slowTickRate) {
		this.lazyTickRate = slowTickRate;
		this.lazyTickCounter = slowTickRate;
	}

	public void lazyTick() {

	}

	public class_2338 getPos() {
		return blockEntity.method_11016();
	}

	public class_1937 getWorld() {
		return blockEntity.method_10997();
	}

	public static <T extends BlockEntityBehaviour> T get(class_1922 reader, class_2338 pos, BehaviourType<T> type) {
		class_2586 be;
		try {
			be = reader.method_8321(pos);
		} catch (ConcurrentModificationException e) {
			be = null;
		}
		return get(be, type);
	}

	public static <T extends BlockEntityBehaviour> T get(class_2586 be, BehaviourType<T> type) {
		if (be == null)
			return null;
		if (!(be instanceof SmartBlockEntity ste))
			return null;
		return ste.getBehaviour(type);
	}
}
