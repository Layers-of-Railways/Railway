package com.simibubi.create.foundation.blockEntity.behaviour.edgeInteraction;

import java.util.function.Predicate;
import net.minecraft.class_1792;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import com.simibubi.create.AllTags;
import com.simibubi.create.foundation.blockEntity.SmartBlockEntity;
import com.simibubi.create.foundation.blockEntity.behaviour.BehaviourType;
import com.simibubi.create.foundation.blockEntity.behaviour.BlockEntityBehaviour;

public class EdgeInteractionBehaviour extends BlockEntityBehaviour {

	public static final BehaviourType<EdgeInteractionBehaviour> TYPE = new BehaviourType<>();

	ConnectionCallback connectionCallback;
	ConnectivityPredicate connectivityPredicate;
	Predicate<class_1792> requiredPredicate;

	public EdgeInteractionBehaviour(SmartBlockEntity be, ConnectionCallback callback) {
		super(be);
		this.connectionCallback = callback;
		requiredPredicate = item -> false;
		connectivityPredicate = (world, pos, face, face2) -> true;
	}

	public EdgeInteractionBehaviour connectivity(ConnectivityPredicate pred) {
		this.connectivityPredicate = pred;
		return this;
	}

	public EdgeInteractionBehaviour require(class_1792 item) {
		this.requiredPredicate = item1 -> item1 == item;
		return this;
	}

	public EdgeInteractionBehaviour require(AllTags.AllItemTags tag) {
		this.requiredPredicate = tag::matches;
		return this;
	}

	@Override
	public BehaviourType<?> getType() {
		return TYPE;
	}

	@FunctionalInterface
	public interface ConnectionCallback {
		public void apply(class_1937 world, class_2338 clicked, class_2338 neighbour);
	}

	@FunctionalInterface
	public interface ConnectivityPredicate {
		public boolean test(class_1937 world, class_2338 pos, class_2350 selectedFace, class_2350 connectedFace);
	}

}
