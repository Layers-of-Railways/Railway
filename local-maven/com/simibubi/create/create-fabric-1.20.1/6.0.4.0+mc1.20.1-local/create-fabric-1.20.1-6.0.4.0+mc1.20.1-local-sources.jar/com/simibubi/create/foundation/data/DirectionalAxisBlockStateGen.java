package com.simibubi.create.foundation.data;

import com.simibubi.create.content.kinetics.gauge.GaugeBlock;
import com.tterrag.registrate.providers.DataGenContext;
import com.tterrag.registrate.providers.RegistrateBlockstateProvider;
import io.github.fabricators_of_create.porting_lib.models.generators.ModelFile;
import net.minecraft.class_2248;
import net.minecraft.class_2350;
import net.minecraft.class_2350.class_2351;
import net.minecraft.class_2680;

public abstract class DirectionalAxisBlockStateGen extends SpecialBlockStateGen {

	@Override
	protected int getXRotation(class_2680 state) {
		class_2350 direction = state.method_11654(GaugeBlock.FACING);
		boolean alongFirst = state.method_11654(GaugeBlock.AXIS_ALONG_FIRST_COORDINATE);

		if (direction == class_2350.field_11033)
			return 180;
		if (direction == class_2350.field_11036)
			return 0;
		if ((direction.method_10166() == class_2351.field_11048) == alongFirst)
			return 90;

		return 0;
	}

	@Override
	protected int getYRotation(class_2680 state) {
		class_2350 direction = state.method_11654(GaugeBlock.FACING);
		boolean alongFirst = state.method_11654(GaugeBlock.AXIS_ALONG_FIRST_COORDINATE);

		if (direction.method_10166()
			.method_10178())
			return alongFirst ? 90 : 0;

		return horizontalAngle(direction) + 90;
	}

	public abstract <T extends class_2248> String getModelPrefix(DataGenContext<class_2248, T> ctx,
		RegistrateBlockstateProvider prov, class_2680 state);

	@Override
	public <T extends class_2248> ModelFile getModel(DataGenContext<class_2248, T> ctx, RegistrateBlockstateProvider prov,
												class_2680 state) {
		boolean vertical = state.method_11654(GaugeBlock.FACING)
			.method_10166()
			.method_10178();
		String partial = vertical ? "" : "_wall";
		return prov.models()
			.getExistingFile(prov.modLoc(getModelPrefix(ctx, prov, state) + partial));
	}

}
