package com.simibubi.create.foundation.blockEntity.behaviour.scrollValue;

import com.google.common.collect.ImmutableList;
import com.simibubi.create.foundation.blockEntity.SmartBlockEntity;
import com.simibubi.create.foundation.blockEntity.behaviour.ValueBoxTransform;
import com.simibubi.create.foundation.blockEntity.behaviour.ValueSettingsBoard;
import com.simibubi.create.foundation.blockEntity.behaviour.ValueSettingsFormatter.ScrollOptionSettingsFormatter;
import net.minecraft.class_1657;
import net.minecraft.class_2561;
import net.minecraft.class_3965;

public class ScrollOptionBehaviour<E extends Enum<E> & INamedIconOptions> extends ScrollValueBehaviour {

	private E[] options;

	public ScrollOptionBehaviour(Class<E> enum_, class_2561 label, SmartBlockEntity be, ValueBoxTransform slot) {
		super(label, be, slot);
		options = enum_.getEnumConstants();
		between(0, options.length - 1);
	}

	INamedIconOptions getIconForSelected() {
		return get();
	}

	public E get() {
		return options[value];
	}

	@Override
	public ValueSettingsBoard createBoard(class_1657 player, class_3965 hitResult) {
		return new ValueSettingsBoard(label, max, 1, ImmutableList.of(class_2561.method_43470("Select")),
			new ScrollOptionSettingsFormatter(options));
	}

	@Override
	public String getClipboardKey() {
		return options[0].getClass().getSimpleName();
	}

}
