package com.simibubi.create.foundation.blockEntity.behaviour.edgeInteraction;

import java.util.ArrayList;
import java.util.List;

import com.simibubi.create.foundation.blockEntity.behaviour.BlockEntityBehaviour;
import com.simibubi.create.foundation.utility.AdventureUtil;
import com.simibubi.create.foundation.utility.BlockHelper;
import com.simibubi.create.foundation.utility.RaycastHelper;

import net.createmod.catnip.data.Iterate;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_2382;
import net.minecraft.class_243;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3965;

public class EdgeInteractionHandler {

	public static class_1269 onBlockActivated(class_1657 player, class_1937 world, class_1268 hand, class_3965 hitResult) {
//		Level world = event.getWorld();
		class_2338 pos = hitResult.method_17777();//event.getPos();
//		Player player = event.getPlayer();
//		InteractionHand hand = event.getHand();
		class_1799 heldItem = player.method_5998(hand);

		if (player.method_5715() || player.method_7325() || AdventureUtil.isAdventure(player))
			return class_1269.field_5811;
		EdgeInteractionBehaviour behaviour = BlockEntityBehaviour.get(world, pos, EdgeInteractionBehaviour.TYPE);
		if (behaviour == null)
			return class_1269.field_5811;
		if (!behaviour.requiredPredicate.test(heldItem.method_7909()))
			return class_1269.field_5811;
		class_3965 ray = RaycastHelper.rayTraceRange(world, player, 10);
		if (ray == null)
			return class_1269.field_5811;

		class_2350 activatedDirection = getActivatedDirection(world, pos, ray.method_17780(), ray.method_17784(), behaviour);
		if (activatedDirection == null)
			return class_1269.field_5811;

		if (!world.method_8608())
			behaviour.connectionCallback.apply(world, pos, pos.method_10093(activatedDirection));
//		event.setCanceled(true);
//		event.setCancellationResult(InteractionResult.SUCCESS);
		world.method_8396(null, pos, class_3417.field_14667, class_3419.field_15245, .25f, .1f);
		return class_1269.field_5812;
	}

	public static List<class_2350> getConnectiveSides(class_1937 world, class_2338 pos, class_2350 face,
		EdgeInteractionBehaviour behaviour) {
		List<class_2350> sides = new ArrayList<>(6);
		if (BlockHelper.hasBlockSolidSide(world.method_8320(pos.method_10093(face)), world, pos.method_10093(face), face.method_10153()))
			return sides;

		for (class_2350 direction : Iterate.directions) {
			if (direction.method_10166() == face.method_10166())
				continue;
			class_2338 neighbourPos = pos.method_10093(direction);
			if (BlockHelper.hasBlockSolidSide(world.method_8320(neighbourPos.method_10093(face)), world, neighbourPos.method_10093(face),
				face.method_10153()))
				continue;
			if (!behaviour.connectivityPredicate.test(world, pos, face, direction))
				continue;
			sides.add(direction);
		}

		return sides;
	}

	public static class_2350 getActivatedDirection(class_1937 world, class_2338 pos, class_2350 face, class_243 hit,
		EdgeInteractionBehaviour behaviour) {
		for (class_2350 facing : getConnectiveSides(world, pos, face, behaviour)) {
			class_238 bb = getBB(pos, facing);
			if (bb.method_1006(hit))
				return facing;
		}
		return null;
	}

	static class_238 getBB(class_2338 pos, class_2350 direction) {
		class_238 bb = new class_238(pos);
		class_2382 vec = direction.method_10163();
		int x = vec.method_10263();
		int y = vec.method_10264();
		int z = vec.method_10260();
		double margin = 10 / 16f;
		double absX = Math.abs(x) * margin;
		double absY = Math.abs(y) * margin;
		double absZ = Math.abs(z) * margin;

		bb = bb.method_1002(absX, absY, absZ);
		bb = bb.method_989(absX / 2d, absY / 2d, absZ / 2d);
		bb = bb.method_989(x / 2d, y / 2d, z / 2d);
		bb = bb.method_1014(1 / 256f);
		return bb;
	}

}
