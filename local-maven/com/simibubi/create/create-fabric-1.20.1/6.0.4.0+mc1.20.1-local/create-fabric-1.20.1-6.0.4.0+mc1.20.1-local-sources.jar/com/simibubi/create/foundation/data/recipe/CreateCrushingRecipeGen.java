package com.simibubi.create.foundation.data.recipe;

import static com.simibubi.create.foundation.data.recipe.CompatMetals.ALUMINUM;
import static com.simibubi.create.foundation.data.recipe.CompatMetals.LEAD;
import static com.simibubi.create.foundation.data.recipe.CompatMetals.NICKEL;
import static com.simibubi.create.foundation.data.recipe.CompatMetals.OSMIUM;
import static com.simibubi.create.foundation.data.recipe.CompatMetals.PLATINUM;
import static com.simibubi.create.foundation.data.recipe.CompatMetals.QUICKSILVER;
import static com.simibubi.create.foundation.data.recipe.CompatMetals.SILVER;
import static com.simibubi.create.foundation.data.recipe.CompatMetals.TIN;
import static com.simibubi.create.foundation.data.recipe.CompatMetals.URANIUM;

import java.util.function.UnaryOperator;

import com.simibubi.create.AllBlocks;
import com.simibubi.create.AllItems;
import com.simibubi.create.AllTags;
import com.simibubi.create.Create;
import com.simibubi.create.api.data.recipe.CrushingRecipeGen;
import com.simibubi.create.content.decoration.palettes.AllPaletteStoneTypes;
import com.simibubi.create.content.processing.recipe.ProcessingRecipe;
import com.simibubi.create.content.processing.recipe.ProcessingRecipeBuilder;

import net.createmod.catnip.lang.Lang;
import net.minecraft.class_1802;
import net.minecraft.class_1935;
import net.minecraft.class_2246;
import net.minecraft.class_2960;
import net.minecraft.class_3489;
import net.minecraft.class_7784;
import net.minecraft.class_7923;
import io.github.fabricators_of_create.porting_lib.tags.Tags;

/**
 * Create's own Data Generation for Crushing recipes
 * @see CrushingRecipeGen
 */
@SuppressWarnings("unused")
public final class CreateCrushingRecipeGen extends CrushingRecipeGen {

	GeneratedRecipe

	BLAZE_ROD = create(() -> class_1802.field_8894, b -> b.duration(100)
		.output(class_1802.field_8183, 3)
		.output(.25f, class_1802.field_8183, 3)),

	PRISMARINE_CRYSTALS = create(() -> class_1802.field_8434, b -> b.duration(150)
		.output(1f, class_1802.field_8155, 1)
		.output(.5f, class_1802.field_8155, 2)
		.output(.1f, class_1802.field_8601, 2)),

	LEATHER_HORSE_ARMOR = create(() -> class_1802.field_18138, b -> b.duration(200)
		.output(class_1802.field_8745, 2)
		.output(.5f, class_1802.field_8745, 2)),

	IRON_HORSE_ARMOR = create(() -> class_1802.field_8578, b -> b.duration(200)
		.output(class_1802.field_8620, 2)
		.output(.5f, class_1802.field_8745, 1)
		.output(.5f, class_1802.field_8620, 1)
		.output(.25f, class_1802.field_8276, 2)
		.output(.25f, class_1802.field_8675, 4)),

	GOLDEN_HORSE_ARMOR = create(() -> class_1802.field_8560, b -> b.duration(200)
		.output(class_1802.field_8695, 2)
		.output(.5f, class_1802.field_8745, 2)
		.output(.5f, class_1802.field_8695, 2)
		.output(.25f, class_1802.field_8276, 2)
		.output(.25f, class_1802.field_8397, 8)),

	DIAMOND_HORSE_ARMOR = create(() -> class_1802.field_8807, b -> b.duration(200)
		.output(class_1802.field_8477, 1)
		.output(.5f, class_1802.field_8745, 2)
		.output(.1f, class_1802.field_8477, 3)
		.output(.25f, class_1802.field_8276, 2)),

	WOOL = create("wool", b -> b.duration(100)
		.require(class_3489.field_15544)
		.output(class_1802.field_8276, 2)
		.output(.5f, class_1802.field_8276)),

	NETHER_WART = create("nether_wart_block", b -> b.duration(150)
		.require(class_2246.field_10541)
		.output(.25f, class_1802.field_8790, 1)),

	AMETHYST_CLUSTER = create(() -> class_2246.field_27161, b -> b.duration(150)
		.output(class_1802.field_27063, 7)
		.output(.5f, class_1802.field_27063)),

	GLOWSTONE = create(() -> class_2246.field_10171, b -> b.duration(150)
		.output(class_1802.field_8601, 3)
		.output(.5f, class_1802.field_8601)),

	AMETHYST_BLOCK = create(() -> class_2246.field_27159, b -> b.duration(150)
		.output(class_1802.field_27063, 3)
		.output(.5f, class_1802.field_27063)),

	GRAVEL = create(() -> class_2246.field_10255, b -> b.duration(250)
		.output(class_2246.field_10102)
		.output(.1f, class_1802.field_8145)
		.output(.05f, class_1802.field_8696)),

	NETHERRACK = create(() -> class_2246.field_10515, b -> b.duration(250)
		.output(AllItems.CINDER_FLOUR.get())
		.output(.5f, AllItems.CINDER_FLOUR.get())
		.whenModMissing(Mods.ENS.getId())),

	OBSIDIAN = create(() -> class_2246.field_10540, b -> b.duration(500)
		.output(AllItems.POWDERED_OBSIDIAN.get())
		.output(.75f, class_2246.field_10540)),

	DIORITE = ensMineralRecycling(AllPaletteStoneTypes.DIORITE, b -> b.duration(350)
		.output(.25f, class_1802.field_8155, 1)),

	CRIMSITE =
		mineralRecycling(AllPaletteStoneTypes.CRIMSITE, AllItems.CRUSHED_IRON::get, () -> class_1802.field_8675, .4f),

	VERIDIUM = mineralRecycling(AllPaletteStoneTypes.VERIDIUM, AllItems.CRUSHED_COPPER::get,
		() -> AllItems.COPPER_NUGGET::get, .8f),

	ASURINE = mineralRecycling(AllPaletteStoneTypes.ASURINE, AllItems.CRUSHED_ZINC::get,
		() -> AllItems.ZINC_NUGGET::get, .3f),

	OCHRUM =
		mineralRecycling(AllPaletteStoneTypes.OCHRUM, AllItems.CRUSHED_GOLD::get, () -> class_1802.field_8397, .2f),

	TUFF = mineralRecycling(AllPaletteStoneTypes.TUFF, b -> b.duration(350)
		.output(.25f, class_1802.field_8145, 1)
		.output(.1f, class_1802.field_8397, 1)
		.output(.1f, AllItems.COPPER_NUGGET.get(), 1)
		.output(.1f, AllItems.ZINC_NUGGET.get(), 1)
		.output(.1f, class_1802.field_8675, 1)),

	COAL_ORE = stoneOre(() -> class_1802.field_8476, () -> class_1802.field_8713, 1.75f, 150),
		IRON_ORE = stoneOre(() -> class_1802.field_8599, AllItems.CRUSHED_IRON::get, 1.75f, 250),
		COPPER_ORE = stoneOre(() -> class_1802.field_27018, AllItems.CRUSHED_COPPER::get, 5.25f, 250),
		GOLD_ORE = stoneOre(() -> class_1802.field_8775, AllItems.CRUSHED_GOLD::get, 1.75f, 250),
		REDSTONE_ORE = stoneOre(() -> class_1802.field_8604, () -> class_1802.field_8725, 6.5f, 250),
		EMERALD_ORE = stoneOre(() -> class_1802.field_8837, () -> class_1802.field_8687, 1.75f, 350),
		LAPIS_ORE = stoneOre(() -> class_1802.field_8809, () -> class_1802.field_8759, 10.5f, 250),
		DIAMOND_ORE = stoneOre(() -> class_1802.field_8787, () -> class_1802.field_8477, 1.75f, 350),
		ZINC_ORE = stoneOre(AllBlocks.ZINC_ORE::get, AllItems.CRUSHED_ZINC::get, 1.75f, 250),

	DEEP_COAL_ORE = deepslateOre(() -> class_1802.field_29212, () -> class_1802.field_8713, 2.25f, 300),
		DEEP_IRON_ORE = deepslateOre(() -> class_1802.field_29020, AllItems.CRUSHED_IRON::get, 2.25f, 350),
		DEEP_COPPER_ORE = deepslateOre(() -> class_1802.field_29211, AllItems.CRUSHED_COPPER::get, 7.25f, 350),
		DEEP_GOLD_ORE = deepslateOre(() -> class_1802.field_29019, AllItems.CRUSHED_GOLD::get, 2.25f, 350),
		DEEP_REDSTONE_ORE = deepslateOre(() -> class_1802.field_29023, () -> class_1802.field_8725, 7.5f, 350),
		DEEP_EMERALD_ORE = deepslateOre(() -> class_1802.field_29216, () -> class_1802.field_8687, 2.25f, 450),
		DEEP_LAPIS_ORE = deepslateOre(() -> class_1802.field_29021, () -> class_1802.field_8759, 12.5f, 350),
		DEEP_DIAMOND_ORE = deepslateOre(() -> class_1802.field_29022, () -> class_1802.field_8477, 2.25f, 450),
		DEEP_ZINC_ORE = deepslateOre(AllBlocks.DEEPSLATE_ZINC_ORE::get, AllItems.CRUSHED_ZINC::get, 2.25f, 350),

	NETHER_GOLD_ORE = netherOre(() -> class_1802.field_23140, () -> class_1802.field_8397, 18, 350),
		NETHER_QUARTZ_ORE = netherOre(() -> class_1802.field_8702, () -> class_1802.field_8155, 2.25f, 350),

	GILDED_BLACKSTONE = ore(class_1802.field_23843, () -> class_1802.field_23847, () -> class_1802.field_8397, 18, 400),

	OSMIUM_ORE = moddedOre(OSMIUM, AllItems.CRUSHED_OSMIUM::get),
		PLATINUM_ORE = moddedOre(PLATINUM, AllItems.CRUSHED_PLATINUM::get),
		SILVER_ORE = moddedOre(SILVER, AllItems.CRUSHED_SILVER::get),
		TIN_ORE = moddedOre(TIN, AllItems.CRUSHED_TIN::get),
		QUICKSILVER_ORE = moddedOre(QUICKSILVER, AllItems.CRUSHED_QUICKSILVER::get),
		LEAD_ORE = moddedOre(LEAD, AllItems.CRUSHED_LEAD::get),
		ALUMINUM_ORE = moddedOre(ALUMINUM, AllItems.CRUSHED_BAUXITE::get),
		URANIUM_ORE = moddedOre(URANIUM, AllItems.CRUSHED_URANIUM::get),
		NICKEL_ORE = moddedOre(NICKEL, AllItems.CRUSHED_NICKEL::get),

	RAW_IRON_ORE = rawOre("iron", () -> Tags.Items.RAW_MATERIALS_IRON, AllItems.CRUSHED_IRON::get, 1),
		RAW_COPPER_ORE = rawOre("copper", () -> Tags.Items.RAW_MATERIALS_COPPER, AllItems.CRUSHED_COPPER::get, 1),
		RAW_GOLD_ORE = rawOre("gold", () -> Tags.Items.RAW_MATERIALS_GOLD, AllItems.CRUSHED_GOLD::get, 2),
		RAW_ZINC_ORE = rawOre("zinc", () -> AllTags.forgeItemTag("raw_materials/zinc"), AllItems.CRUSHED_ZINC::get, 1),

	OSMIUM_RAW_ORE = moddedRawOre(OSMIUM, AllItems.CRUSHED_OSMIUM::get),
		PLATINUM_RAW_ORE = moddedRawOre(PLATINUM, AllItems.CRUSHED_PLATINUM::get),
		SILVER_RAW_ORE = moddedRawOre(SILVER, AllItems.CRUSHED_SILVER::get),
		TIN_RAW_ORE = moddedRawOre(TIN, AllItems.CRUSHED_TIN::get),
		QUICKSILVER_RAW_ORE = moddedRawOre(QUICKSILVER, AllItems.CRUSHED_QUICKSILVER::get),
		LEAD_RAW_ORE = moddedRawOre(LEAD, AllItems.CRUSHED_LEAD::get),
		ALUMINUM_RAW_ORE = moddedRawOre(ALUMINUM, AllItems.CRUSHED_BAUXITE::get),
		URANIUM_RAW_ORE = moddedRawOre(URANIUM, AllItems.CRUSHED_URANIUM::get),
		NICKEL_RAW_ORE = moddedRawOre(NICKEL, AllItems.CRUSHED_NICKEL::get),

	RAW_IRON_BLOCK = rawOreBlock("iron", () -> Tags.Items.STORAGE_BLOCKS_RAW_IRON, AllItems.CRUSHED_IRON::get, 1),
		RAW_COPPER_BLOCK = rawOreBlock("copper", () -> Tags.Items.STORAGE_BLOCKS_RAW_COPPER, AllItems.CRUSHED_COPPER::get, 1),
		RAW_GOLD_BLOCK = rawOreBlock("gold", () -> Tags.Items.STORAGE_BLOCKS_RAW_GOLD, AllItems.CRUSHED_GOLD::get, 2),
		RAW_ZINC_BLOCK = rawOreBlock("zinc", () -> AllTags.forgeItemTag("storage_blocks/raw_zinc"), AllItems.CRUSHED_ZINC::get, 1),

	OSMIUM_RAW_BLOCK = moddedRawOreBlock(OSMIUM, AllItems.CRUSHED_OSMIUM::get),
		PLATINUM_RAW_BLOCK = moddedRawOreBlock(PLATINUM, AllItems.CRUSHED_PLATINUM::get),
		SILVER_RAW_BLOCK = moddedRawOreBlock(SILVER, AllItems.CRUSHED_SILVER::get),
		TIN_RAW_BLOCK = moddedRawOreBlock(TIN, AllItems.CRUSHED_TIN::get),
		QUICKSILVER_RAW_BLOCK = moddedRawOreBlock(QUICKSILVER, AllItems.CRUSHED_QUICKSILVER::get),
		LEAD_RAW_BLOCK = moddedRawOreBlock(LEAD, AllItems.CRUSHED_LEAD::get),
		ALUMINUM_RAW_BLOCK = moddedRawOreBlock(ALUMINUM, AllItems.CRUSHED_BAUXITE::get),
		URANIUM_RAW_BLOCK = moddedRawOreBlock(URANIUM, AllItems.CRUSHED_URANIUM::get),
		NICKEL_RAW_BLOCK = moddedRawOreBlock(NICKEL, AllItems.CRUSHED_NICKEL::get),

	// Oh The Biomes You'll Go
	BYG_AMETRINE_ORE = create(Mods.BYG.recipeId("ametrine_ore"), b -> b.duration(500)
		.require(AllTags.optionalTag(class_7923.field_41178,
			new class_2960("forge", "ores/ametrine")))
		.output(1f, Mods.BYG, "ametrine_gems", 2)
		.output(.25f, Mods.BYG, "ametrine_gems", 1)
		.output(.75f, AllItems.EXP_NUGGET.get(), 1)
		.output(.125f, Mods.BYG, "cobbled_ether_stone", 1)
		.whenModLoaded(Mods.BYG.getId())),

	BYG_ANTHRACITE_ORE = create(Mods.BYG.recipeId("anthracite_ore"), b -> b.duration(150)
		.require(AllTags.optionalTag(class_7923.field_41178,
			new class_2960("forge", "ores/anthracite")))
		.output(1f, Mods.BYG, "anthracite", 2)
		.output(.5f, Mods.BYG, "anthracite", 1)
		.output(.75f, AllItems.EXP_NUGGET.get(), 1)
		.output(.125f, Mods.BYG, "brimstone", 1)
		.whenModLoaded(Mods.BYG.getId())),

	BYG_BLUE_GOLD_ORE = create(Mods.BYG.recipeId("blue_nether_gold_ore"), b -> b.duration(350)
		.require(Mods.BYG, "blue_nether_gold_ore")
		.output(1f, class_1802.field_8397, 18)
		.output(.75f, AllItems.EXP_NUGGET.get(), 1)
		.output(.125f, Mods.BYG, "blue_netherrack", 1)
		.whenModLoaded(Mods.BYG.getId())),

	BYG_BLUE_QUARTZ_ORE = create(Mods.BYG.recipeId("blue_nether_quartz_ore"), b -> b.duration(350)
		.require(Mods.BYG, "blue_nether_quartz_ore")
		.output(1f, class_1802.field_8155, 2)
		.output(.25f, class_1802.field_8155, 1)
		.output(.75f, AllItems.EXP_NUGGET.get(), 1)
		.output(.125f, Mods.BYG, "blue_netherrack", 1)
		.whenModLoaded(Mods.BYG.getId())),

	BYG_BRIMSTONE_GOLD_ORE = create(Mods.BYG.recipeId("brimstone_nether_gold_ore"), b -> b.duration(350)
		.require(Mods.BYG, "brimstone_nether_gold_ore")
		.output(1f, class_1802.field_8397, 18)
		.output(.75f, AllItems.EXP_NUGGET.get(), 1)
		.output(.125f, Mods.BYG, "brimstone", 1)
		.whenModLoaded(Mods.BYG.getId())),

	BYG_BRIMSTONE_QUARTZ_ORE = create(Mods.BYG.recipeId("brimstone_nether_quartz_ore"), b -> b.duration(350)
		.require(Mods.BYG, "brimstone_nether_quartz_ore")
		.output(1f, class_1802.field_8155, 2)
		.output(.25f, class_1802.field_8155, 1)
		.output(.75f, AllItems.EXP_NUGGET.get(), 1)
		.output(.125f, Mods.BYG, "brimstone", 1)
		.whenModLoaded(Mods.BYG.getId())),

	BYG_REDSTONE_ORE = create(Mods.BYG.recipeId("cryptic_redstone_ore"), b -> b.duration(250)
		.require(Mods.BYG, "cryptic_redstone_ore")
		.output(1f, class_1802.field_8725, 6)
		.output(.5f, class_1802.field_8725, 1)
		.output(.75f, AllItems.EXP_NUGGET.get(), 1)
		.output(.125f, Mods.BYG, "cryptic_stone", 1)
		.whenModLoaded(Mods.BYG.getId())),

	BYG_EMERALDITE_ORE = create(Mods.BYG.recipeId("emeraldite_ore"), b -> b.duration(500)
		.require(AllTags.forgeItemTag("ores/emeraldite"))
		.output(1f,Mods.BYG, "emeraldite_shards", 2)
		.output(.25f, Mods.BYG, "emeraldite_shards", 1)
		.output(.75f, AllItems.EXP_NUGGET.get(), 1)
		.output(.125f, Mods.BYG, "scoria_cobblestone", 1)
		.whenModLoaded(Mods.BYG.getId())),

	BYG_LIGNITE_ORE = create(Mods.BYG.recipeId("lignite_ore"), b -> b.duration(300)
		.require(AllTags.forgeItemTag("ores/lignite"))
		.output(1f,Mods.BYG, "lignite", 2)
		.output(.5f, Mods.BYG, "lignite", 2)
		.output(.75f, AllItems.EXP_NUGGET.get(), 1)
		.output(.125f, Mods.BYG, "cobbled_ether_stone", 1)
		.whenModLoaded(Mods.BYG.getId())),

	BYG_NETHERRACK_ORE = create(Mods.BYG.recipeId("pervaded_netherrack"), b -> b.duration(150)
		.require(AllTags.forgeItemTag("ores/emeraldite"))
		.output(1f, class_1802.field_8801, 2)
		.output(.5f, class_1802.field_8801, 1)
		.output(.75f, AllItems.EXP_NUGGET.get(), 1)
		.output(.125f, class_1802.field_8328, 1)
		.whenModLoaded(Mods.BYG.getId())),

	BYG_RED_ROCK_ORE = create(Mods.BYG.recipeId("red_rock"), b -> b.duration(150)
		.require(Mods.BYG, "red_rock")
		.output(1f, class_1802.field_8200, 1)
		.whenModLoaded(Mods.BYG.getId())),

	// Druidcraft

	DC_AMBER_ORE = create(Mods.DRUIDCRAFT.recipeId("amber_ore"), b -> b.duration(300)
		.require(Mods.DRUIDCRAFT, "amber_ore")
		.output(1f, Mods.DRUIDCRAFT, "amber", 2)
		.output(.5f, Mods.DRUIDCRAFT, "amber", 1)
		.output(.125f, class_1802.field_20412, 1)
		.whenModLoaded(Mods.DRUIDCRAFT.getId())),

	DC_FIERY_GLASS_ORE = create(Mods.DRUIDCRAFT.recipeId("fiery_glass_ore"), b -> b.duration(300)
		.require(Mods.DRUIDCRAFT, "fiery_glass_ore")
		.output(1f, Mods.DRUIDCRAFT, "fiery_glass", 8)
		.output(.25f, Mods.DRUIDCRAFT, "fiery_glass", 6)
		.output(.125f, class_1802.field_20412, 1)
		.whenModLoaded(Mods.DRUIDCRAFT.getId())),

	DC_MOONSTONE_ORE = create(Mods.DRUIDCRAFT.recipeId("moonstone_ore"), b -> b.duration(300)
		.require(Mods.DRUIDCRAFT, "moonstone_ore")
		.output(1f, Mods.DRUIDCRAFT, "moonstone", 2)
		.output(.5f, Mods.DRUIDCRAFT, "moonstone", 1)
		.output(.125f, class_1802.field_20412, 1)
		.whenModLoaded(Mods.DRUIDCRAFT.getId())),

	// Neapolitan

	NEA_ICE = create(Mods.NEA.recipeId("ice"), b -> b.duration(100)
		.require(class_1802.field_8426)
		.output(1f, Mods.NEA, "ice_cubes", 3)
		.output(.25f, Mods.NEA, "ice_cubes", 3)
		.whenModLoaded(Mods.NEA.getId())),

	// Quark

	Q_MOSS = create(Mods.Q.recipeId("moss_block"), b -> b.duration(50)
		.require(class_1802.field_28654)
		.output(1f, Mods.Q, "moss_paste", 2)
		.output(.1f, Mods.Q, "moss_paste", 1)
		.whenModLoaded(Mods.Q.getId())),

	// Silent Gems

	SG_STONE = sgStoneOres("peridot", "ruby", "sapphire", "topaz"),

	SG_NETHER = sgNetherOres("alexandrite", "black_diamond", "carnelian", "citrine", "iolite", "moldavite", "turquoise"),

	SG_END = sgEndOres("ammolite", "kyanite", "rose_quartz"),

	// Simple Farming

	SF = sfPlants("barley", "oat", "rice", "rye"),

	// Thermal Expansion

	TH = thOres("apatite", "cinnabar", "niter", "sulfur"),

	//Galosphere

	GS_ALLURITE = create(Mods.GS.recipeId("allurite"), b -> b.duration(300)
		.require(AllTags.AllItemTags.ALLURITE.tag)
		.output(.8f, Mods.GS, "allurite_shard", 4)
		.whenModLoaded(Mods.GS.getId())),

	GS_LUMIERE = create(Mods.GS.recipeId("lumiere"), b -> b.duration(300)
		.require(AllTags.AllItemTags.LUMIERE.tag)
		.output(.8f, Mods.GS, "lumiere_shard", 4)
		.whenModLoaded(Mods.GS.getId())),

	GS_AMETHYST = create(Mods.GS.recipeId("amethyst"), b -> b.duration(300)
		.require(AllTags.AllItemTags.AMETHYST.tag)
		.output(.8f, class_1802.field_27063, 4)
		.whenModLoaded(Mods.GS.getId())),

	//Elementary Ores
	EO_COAL_NETHER = eoNetherOre("coal", class_1802.field_8713, 1),
		EO_COPPER_NETHER = eoNetherOre("copper", AllItems.CRUSHED_COPPER.get(), 5),
		EO_IRON_NETHER = eoNetherOre("iron", AllItems.CRUSHED_IRON.get(), 1),
		EO_EMERALD_NETHER = eoNetherOre("emerald", class_1802.field_8687, 1),
		EO_LAPIS_NETHER = eoNetherOre("lapis", class_1802.field_8759, 10),
		EO_DIAMOND_NETHER = eoNetherOre("diamond", class_1802.field_8477, 1),
		EO_GHAST_NETHER = eoNetherOre("ghast", class_1802.field_8070, 1),
		EO_COAL_END = eoEndOre("coal", class_1802.field_8713, 1),
		EO_COPPER_END = eoEndOre("copper", AllItems.CRUSHED_COPPER.get(), 5),
		EO_EMERALD_END = eoEndOre("emerald", class_1802.field_8687, 1),
		EO_LAPIS_END = eoEndOre("lapis", class_1802.field_8759, 10),
		EO_DIAMOND_END = eoEndOre("diamond", class_1802.field_8477, 1),
		EO_REDSTONE_END = eoEndOre("redstone", class_1802.field_8725, 6),
		EO_ENDER_END = eoEndOre("ender", class_1802.field_8634, 1),

	// Ex Nihilo: Sequentia

	ENS_STONES = ensStones("andesite", "diorite", "end_stone", "granite", "netherrack"),

	ENS_DUST = create(Mods.ENS.recipeId("dust"), b -> b.duration(200)
		.require(class_2246.field_10102).output(Mods.ENS, "dust")
		.whenModLoaded(Mods.ENS.getId())),

	ENS_NETHERRACK = create(Mods.ENS.recipeId("crushed_netherrack"), b -> b.duration(100)
		.require(Mods.ENS, "crushed_netherrack")
		.output(AllItems.CINDER_FLOUR.get())
		.output(.5f, AllItems.CINDER_FLOUR.get())
		.whenModLoaded(Mods.ENS.getId())),

	ENS_DIORITE = create(Mods.ENS.recipeId("crushed_diorite"), b -> b.duration(100)
		.require(Mods.ENS, "crushed_diorite")
		.output(.25f, class_1802.field_8155, 1)
		.whenModLoaded(Mods.ENS.getId())),

	// Aether

	AET_ZANITE = create(Mods.AET.recipeId("zanite_ore"), b -> b.duration(350)
		.require(Mods.AET, "zanite_ore")
		.output(Mods.AET, "zanite_gemstone")
		.output(0.75f, Mods.AET, "zanite_gemstone", 1)
		.output(0.125f, Mods.AET, "holystone", 1)
		.output(0.75f, AllItems.EXP_NUGGET.get())
		.whenModLoaded(Mods.AET.getId())),

	AET_AMBROSIUM = create(Mods.AET.recipeId("ambrosium_ore"), b -> b.duration(150)
		.require(Mods.AET, "ambrosium_ore")
		.output(Mods.AET, "ambrosium_shard")
		.output(0.75f, Mods.AET, "ambrosium_shard", 1)
		.output(0.125f, Mods.AET, "holystone", 1)
		.output(0.75f, AllItems.EXP_NUGGET.get())
		.whenModLoaded(Mods.AET.getId())),

	// IE

	IE_COKE_DUST = create(Mods.IE.recipeId("coal_coke"), b -> b.duration(200)
		.require(Mods.IE, "coal_coke").output(Mods.IE, "dust_coke")
		.whenModLoaded(Mods.IE.getId())),

	IE_COKE_BLOCK = create(Mods.IE.recipeId("coke_block"), b -> b.duration(200)
		.require(Mods.IE, "coke").output(1, Mods.IE.asResource("dust_coke"), 9)
		.whenModLoaded(Mods.IE.getId())),

	IE_SLAG_GRAVEL = create(Mods.IE.recipeId("slag"), b -> b.duration(200)
		.require(Mods.IE, "slag").output(Mods.IE, "slag_gravel")
		.whenModLoaded(Mods.IE.getId()));

	GeneratedRecipe sgStoneOres(String... types) {
		for (String type : types) {
			create(Mods.SILENT_GEMS.recipeId(type + "_ore"), b -> b.duration(350)
					.require(Mods.SILENT_GEMS, type + "_ore")
					.output(1f, Mods.SILENT_GEMS, type, 2)
					.output(.25f, Mods.SILENT_GEMS, type, 1)
					.output(.75f, AllItems.EXP_NUGGET.get())
					.output(.12f, class_1802.field_20412)
					.whenModLoaded(Mods.SILENT_GEMS.getId()));
		}
		return null;
	}

	GeneratedRecipe sgNetherOres(String... types) {
		for (String type : types) {
			create(Mods.SILENT_GEMS.recipeId(type + "_ore"), b -> b.duration(350)
					.require(Mods.SILENT_GEMS, type + "_ore")
					.output(1f, Mods.SILENT_GEMS, type, 2)
					.output(.25f, Mods.SILENT_GEMS, type, 1)
					.output(.75f, AllItems.EXP_NUGGET.get())
					.output(.12f, class_1802.field_8328)
					.whenModLoaded(Mods.SILENT_GEMS.getId()));
		}
		return null;
	}

	GeneratedRecipe sgEndOres(String... types) {
		for (String type : types) {
			create(Mods.SILENT_GEMS.recipeId(type + "_ore"), b -> b.duration(350)
					.require(Mods.SILENT_GEMS, type + "_ore")
					.output(1f, Mods.SILENT_GEMS, type, 2)
					.output(.25f, Mods.SILENT_GEMS, type, 1)
					.output(.75f, AllItems.EXP_NUGGET.get())
					.output(.12f, class_1802.field_20399)
					.whenModLoaded(Mods.SILENT_GEMS.getId()));
		}
		return null;
	}

	GeneratedRecipe sfPlants(String... types) {
		for (String type : types) {
			create(Mods.SF.recipeId(type), b -> b.duration(150)
					.require(Mods.SF, type)
					.output(1f, AllItems.WHEAT_FLOUR.get(), 1)
					.output(.25f, AllItems.WHEAT_FLOUR.get(), 2)
					.output(.25f, Mods.SF, type + "_seeds", 1)
					.whenModLoaded(Mods.SF.getId()));
		}
		return null;
	}

	GeneratedRecipe thOres(String... types) {
		for (String type : types) {
			create(Mods.TH.recipeId(type + "_ore"), b -> b.duration(350)
					.require(Mods.TH, type + "_ore")
					.output(1f, Mods.TH, type, 2)
					.output(.25f, Mods.TH, type, 1)
					.output(.12f, class_1802.field_20412)
					.output(.75f, AllItems.EXP_NUGGET.get())
					.whenModLoaded(Mods.TH.getId()));
		}
		return null;
	}

	GeneratedRecipe eoNetherOre(String material, class_1935 result, int count){
		String oreName = "ore_" + material + "_nether";
		return create(Mods.EO.recipeId(oreName), b -> b.duration(350)
				.require(Mods.EO, oreName)
				.output(1f, result, count)
				.output(.25f, result)
				.output(.75f, AllItems.EXP_NUGGET.get())
				.output(.12f, class_1802.field_8328)
				.whenModLoaded(Mods.EO.getId()));
	}

	GeneratedRecipe eoEndOre(String material, class_1935 result, int count){
		String oreName = "ore_" + material + "_end";
		return create(Mods.EO.recipeId(oreName), b -> b.duration(350)
				.require(Mods.EO, oreName)
				.output(1f, result, count)
				.output(.25f, result)
				.output(.75f, AllItems.EXP_NUGGET.get())
				.output(.12f, class_1802.field_20399)
				.whenModLoaded(Mods.EO.getId()));
	}

	GeneratedRecipe ensStones(String... stones) {
		for (String stone : stones) {
			String crushed = "crushed_" + stone;
			create(Mods.ENS.recipeId(stone), b -> b.duration(350)
					.require(Mods.MC, stone)
					.output(Mods.ENS, crushed)
					.whenModLoaded(Mods.ENS.getId()));
		}
		return null;
	}

	public CreateCrushingRecipeGen(class_7784 output) {
		super(output, Create.ID);
	}

	GeneratedRecipe ensMineralRecycling(AllPaletteStoneTypes type,
																			 UnaryOperator<ProcessingRecipeBuilder<ProcessingRecipe<?>>> transform) {
		create(Lang.asId(type.name()) + "_recycling", b -> transform.apply(b.require(type.materialTag)));
		return create(type.getBaseBlock()::get, b -> transform.apply(b.whenModMissing(Mods.ENS.getId())));
	}
}
