package com.simibubi.create.foundation.mixin.accessor;

import java.util.function.Function;
import net.minecraft.class_2960;
import net.minecraft.class_327;
import net.minecraft.class_377;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_327.class)
public interface FontAccessor {
	@Accessor("fonts")
	Function<class_2960, class_377> create$getFonts();
}
