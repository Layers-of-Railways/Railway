package com.simibubi.create.foundation.gui;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Nonnull;
import net.minecraft.class_1799;
import net.minecraft.class_2477;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_289;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5348;
import net.minecraft.class_5481;
import net.minecraft.class_5684;
import org.joml.Matrix4f;

import com.mojang.blaze3d.systems.RenderSystem;
import io.github.fabricators_of_create.porting_lib.util.client.ScreenUtils;

public class RemovedGuiUtils {
	@Nonnull
	private static class_1799 cachedTooltipStack = class_1799.field_8037;

	public static void preItemToolTip(@Nonnull class_1799 stack) {
		cachedTooltipStack = stack;
	}

	public static void postItemToolTip() {
		cachedTooltipStack = class_1799.field_8037;
	}

	public static void drawHoveringText(class_332 graphics, List<? extends class_5348> textLines, int mouseX,
										int mouseY, int screenWidth, int screenHeight, int maxTextWidth, class_327 font) {
		drawHoveringText(graphics, textLines, mouseX, mouseY, screenWidth, screenHeight, maxTextWidth,
				ScreenUtils.DEFAULT_BACKGROUND_COLOR, ScreenUtils.DEFAULT_BORDER_COLOR_START, ScreenUtils.DEFAULT_BORDER_COLOR_END,
				font);
	}

	public static void drawHoveringText(class_332 graphics, List<? extends class_5348> textLines, int mouseX,
										int mouseY, int screenWidth, int screenHeight, int maxTextWidth, int backgroundColor, int borderColorStart,
										int borderColorEnd, class_327 font) {
		drawHoveringText(cachedTooltipStack, graphics, textLines, mouseX, mouseY, screenWidth, screenHeight, maxTextWidth,
				backgroundColor, borderColorStart, borderColorEnd, font);
	}

	public static void drawHoveringText(@Nonnull final class_1799 stack, class_332 graphics,
										List<? extends class_5348> textLines, int mouseX, int mouseY, int screenWidth, int screenHeight,
										int maxTextWidth, class_327 font) {
		drawHoveringText(stack, graphics, textLines, mouseX, mouseY, screenWidth, screenHeight, maxTextWidth,
				ScreenUtils.DEFAULT_BACKGROUND_COLOR, ScreenUtils.DEFAULT_BORDER_COLOR_START, ScreenUtils.DEFAULT_BORDER_COLOR_END,
				font);
	}

	public static void drawHoveringText(@Nonnull final class_1799 stack, class_332 graphics,
										List<? extends class_5348> textLines, int mouseX, int mouseY, int screenWidth, int screenHeight,
										int maxTextWidth, int backgroundColor, int borderColorStart, int borderColorEnd, class_327 font) {
		if (textLines.isEmpty())
			return;

		List<class_5684> list = new ArrayList<>();
		for (class_5348 textLine : textLines) {
			class_5481 charSequence = textLine instanceof class_2561 component
					? component.method_30937()
					: class_2477.method_10517().method_30934(textLine);
			list.add(class_5684.method_32662(charSequence));
		}

		class_4587 pStack = graphics.method_51448();

		// RenderSystem.disableRescaleNormal();
		RenderSystem.disableDepthTest();
		int tooltipTextWidth = 0;

		for (class_5348 textLine : textLines) {
			int textLineWidth = font.method_27525(textLine);
			if (textLineWidth > tooltipTextWidth)
				tooltipTextWidth = textLineWidth;
		}

		boolean needsWrap = false;

		int titleLinesCount = 1;
		int tooltipX = mouseX + 12;
		if (tooltipX + tooltipTextWidth + 4 > screenWidth) {
			tooltipX = mouseX - 16 - tooltipTextWidth;
			if (tooltipX < 4) // if the tooltip doesn't fit on the screen
			{
				if (mouseX > screenWidth / 2)
					tooltipTextWidth = mouseX - 12 - 8;
				else
					tooltipTextWidth = screenWidth - 16 - mouseX;
				needsWrap = true;
			}
		}

		if (maxTextWidth > 0 && tooltipTextWidth > maxTextWidth) {
			tooltipTextWidth = maxTextWidth;
			needsWrap = true;
		}

		if (needsWrap) {
			int wrappedTooltipWidth = 0;
			List<class_5348> wrappedTextLines = new ArrayList<>();
			for (int i = 0; i < textLines.size(); i++) {
				class_5348 textLine = textLines.get(i);
				List<class_5348> wrappedLine = font.method_27527()
						.method_27495(textLine, tooltipTextWidth, class_2583.field_24360);
				if (i == 0)
					titleLinesCount = wrappedLine.size();

				for (class_5348 line : wrappedLine) {
					int lineWidth = font.method_27525(line);
					if (lineWidth > wrappedTooltipWidth)
						wrappedTooltipWidth = lineWidth;
					wrappedTextLines.add(line);
				}
			}
			tooltipTextWidth = wrappedTooltipWidth;
			textLines = wrappedTextLines;

			if (mouseX > screenWidth / 2)
				tooltipX = mouseX - 16 - tooltipTextWidth;
			else
				tooltipX = mouseX + 12;
		}

		int tooltipY = mouseY - 12;
		int tooltipHeight = 8;

		if (textLines.size() > 1) {
			tooltipHeight += (textLines.size() - 1) * 10;
			if (textLines.size() > titleLinesCount)
				tooltipHeight += 2; // gap between title lines and next lines
		}

		if (tooltipY < 4)
			tooltipY = 4;
		else if (tooltipY + tooltipHeight + 4 > screenHeight)
			tooltipY = screenHeight - tooltipHeight - 4;

		final int zLevel = 400;

		pStack.method_22903();
		Matrix4f mat = pStack.method_23760()
				.method_23761();
		graphics.method_33284(tooltipX - 3, tooltipY - 4, tooltipX + tooltipTextWidth + 3,
				tooltipY - 3, zLevel, backgroundColor, backgroundColor);
		graphics.method_33284(tooltipX - 3, tooltipY + tooltipHeight + 3,
				tooltipX + tooltipTextWidth + 3, tooltipY + tooltipHeight + 4, zLevel, backgroundColor, backgroundColor);
		graphics.method_33284(tooltipX - 3, tooltipY - 3, tooltipX + tooltipTextWidth + 3,
				tooltipY + tooltipHeight + 3, zLevel, backgroundColor, backgroundColor);
		graphics.method_33284(tooltipX - 4, tooltipY - 3, tooltipX - 3, tooltipY + tooltipHeight + 3,
				zLevel, backgroundColor, backgroundColor);
		graphics.method_33284(tooltipX + tooltipTextWidth + 3, tooltipY - 3,
				tooltipX + tooltipTextWidth + 4, tooltipY + tooltipHeight + 3, zLevel, backgroundColor, backgroundColor);
		graphics.method_33284(tooltipX - 3, tooltipY - 3 + 1, tooltipX - 3 + 1,
				tooltipY + tooltipHeight + 3 - 1, zLevel, borderColorStart, borderColorEnd);
		graphics.method_33284(tooltipX + tooltipTextWidth + 2, tooltipY - 3 + 1,
				tooltipX + tooltipTextWidth + 3, tooltipY + tooltipHeight + 3 - 1, zLevel, borderColorStart, borderColorEnd);
		graphics.method_33284(tooltipX - 3, tooltipY - 3, tooltipX + tooltipTextWidth + 3,
				tooltipY - 3 + 1, zLevel, borderColorStart, borderColorStart);
		graphics.method_33284(tooltipX - 3, tooltipY + tooltipHeight + 2,
				tooltipX + tooltipTextWidth + 3, tooltipY + tooltipHeight + 3, zLevel, borderColorEnd, borderColorEnd);

		class_4597.class_4598 renderType = class_4597.method_22991(class_289.method_1348()
				.method_1349());
		pStack.method_22904(0.0D, 0.0D, zLevel);

		for (int lineNumber = 0; lineNumber < list.size(); ++lineNumber) {
			class_5684 line = list.get(lineNumber);

			if (line != null)
				line.method_32665(font, tooltipX, tooltipY, mat, renderType);

			if (lineNumber + 1 == titleLinesCount)
				tooltipY += 2;

			tooltipY += 10;
		}

		renderType.method_22993();
		pStack.method_22909();

		RenderSystem.enableDepthTest();
	}
}
