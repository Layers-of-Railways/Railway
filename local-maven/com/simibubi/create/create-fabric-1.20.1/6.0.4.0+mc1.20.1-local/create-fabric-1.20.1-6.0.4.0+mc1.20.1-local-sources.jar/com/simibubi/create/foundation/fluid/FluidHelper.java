package com.simibubi.create.foundation.fluid;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.simibubi.create.Create;
import com.simibubi.create.content.fluids.tank.CreativeFluidTankBlockEntity;
import com.simibubi.create.content.fluids.transfer.GenericItemEmptying;
import com.simibubi.create.content.fluids.transfer.GenericItemFilling;
import com.simibubi.create.foundation.blockEntity.SmartBlockEntity;

import net.createmod.catnip.data.Pair;
import net.createmod.catnip.platform.CatnipServices;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidStorage;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariant;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariantAttributes;
import net.fabricmc.fabric.api.transfer.v1.storage.Storage;
import net.fabricmc.fabric.api.transfer.v1.transaction.Transaction;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2350;
import net.minecraft.class_2487;
import net.minecraft.class_2522;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.minecraft.class_3518;
import net.minecraft.class_3609;
import net.minecraft.class_3610;
import net.minecraft.class_3611;
import net.minecraft.class_3612;
import net.minecraft.class_6862;
import net.minecraft.class_7923;
import io.github.fabricators_of_create.porting_lib.fluids.FluidStack;
import io.github.fabricators_of_create.porting_lib.transfer.TransferUtil;

public class FluidHelper {

	public static enum FluidExchange {
		ITEM_TO_TANK, TANK_TO_ITEM;
	}

	public static boolean isWater(class_3611 fluid) {
		return convertToStill(fluid) == class_3612.field_15910;
	}

	public static boolean isLava(class_3611 fluid) {
		return convertToStill(fluid) == class_3612.field_15908;
	}

	public static boolean isSame(FluidStack fluidStack, FluidStack fluidStack2) {
		return fluidStack.getFluid() == fluidStack2.getFluid();
	}

	public static boolean isSame(FluidStack fluidStack, class_3611 fluid) {
		return fluidStack.getFluid() == fluid;
	}

	@SuppressWarnings("deprecation")
	public static boolean isTag(class_3611 fluid, class_6862<class_3611> tag) {
		return fluid.method_15791(tag);
	}

	public static boolean isTag(class_3610 fluid, class_6862<class_3611> tag) {
		return fluid.method_15767(tag);
	}

	public static boolean isTag(FluidStack fluid, class_6862<class_3611> tag) {
		return isTag(fluid.getFluid(), tag);
	}

	public static class_3414 getFillSound(FluidStack fluid) {
		return FluidVariantAttributes.getFillSound(fluid.getType());
	}

	public static class_3414 getEmptySound(FluidStack fluid) {
		return FluidVariantAttributes.getEmptySound(fluid.getType());
	}

	public static boolean hasBlockState(class_3611 fluid) {
		return !fluid.method_15785().method_15759().method_26215();
	}

	public static FluidStack copyStackWithAmount(FluidStack fs, long amount) {
		if (amount <= 0)
			return FluidStack.EMPTY;
		if (fs.isEmpty())
			return FluidStack.EMPTY;
		FluidStack copy = fs.copy();
		copy.setAmount(amount);
		return copy;
	}

	public static class_3611 convertToFlowing(class_3611 fluid) {
		if (fluid == class_3612.field_15910)
			return class_3612.field_15909;
		if (fluid == class_3612.field_15908)
			return class_3612.field_15907;
		if (fluid instanceof class_3609)
			return ((class_3609) fluid).method_15750();
		return fluid;
	}

	public static class_3611 convertToStill(class_3611 fluid) {
		if (fluid == class_3612.field_15909)
			return class_3612.field_15910;
		if (fluid == class_3612.field_15907)
			return class_3612.field_15908;
		if (fluid instanceof class_3609)
			return ((class_3609) fluid).method_15751();
		return fluid;
	}

	public static JsonElement serializeFluidStack(FluidStack stack) {
		JsonObject json = new JsonObject();
		json.addProperty("fluid", CatnipServices.REGISTRIES.getKeyOrThrow(stack.getFluid())
			.toString());
		json.addProperty("amount", stack.getAmount());
		if (stack.hasTag())
			json.addProperty("nbt", stack.getTag()
				.toString());
		return json;
	}

	public static FluidStack deserializeFluidStack(JsonObject json) {
		class_2960 id = new class_2960(class_3518.method_15265(json, "fluid"));
		class_3611 fluid = class_7923.field_41173.method_10223(id);
		if (fluid == null)
			throw new JsonSyntaxException("Unknown fluid '" + id + "'");
		if (fluid == class_3612.field_15906)
			throw new JsonSyntaxException("Invalid empty fluid '" + id + "'");
		int amount = class_3518.method_15260(json, "amount");
		if (!json.has("nbt"))
			return new FluidStack(fluid, amount);

		try {
			JsonElement element = json.get("nbt");
			class_2487 nbt = class_2522.method_10718(
					element.isJsonObject() ? Create.GSON.toJson(element) : class_3518.method_15287(element, "nbt"));
			return new FluidStack(FluidVariant.of(fluid, nbt), amount, nbt);
		} catch (CommandSyntaxException e) {
			throw new JsonSyntaxException("Failed to read NBT", e);
		}
	}

	public static boolean tryEmptyItemIntoBE(class_1937 worldIn, class_1657 player, class_1268 handIn, class_1799 heldItem,
		SmartBlockEntity be, class_2350 side) {
		if (!GenericItemEmptying.canItemBeEmptied(worldIn, heldItem))
			return false;

		Pair<FluidStack, class_1799> emptyingResult = GenericItemEmptying.emptyItem(worldIn, heldItem, true);

		Storage<FluidVariant> tank = FluidStorage.SIDED.find(worldIn, be.method_11016(), null, be, side);
		FluidStack fluidStack = emptyingResult.getFirst();

		if (tank == null)
			return false;
		if (worldIn.field_9236)
			return true;

		try (Transaction t = TransferUtil.getTransaction()) {
			long inserted = tank.insert(fluidStack.getType(), fluidStack.getAmount(), t);
			if (inserted != fluidStack.getAmount())
				return false;

			class_1799 copyOfHeld = heldItem.method_7972();
			emptyingResult = GenericItemEmptying.emptyItem(worldIn, copyOfHeld, false);
			t.commit();

			if (!player.method_7337() && !(be instanceof CreativeFluidTankBlockEntity)) {
				if (copyOfHeld.method_7960())
					player.method_6122(handIn, emptyingResult.getSecond());
				else {
					player.method_6122(handIn, copyOfHeld);
					player.method_31548().method_7398(emptyingResult.getSecond());
				}
			}
			return true;
		}
	}

	public static boolean tryFillItemFromBE(class_1937 world, class_1657 player, class_1268 handIn, class_1799 heldItem,
		SmartBlockEntity be, class_2350 side) {
		if (!GenericItemFilling.canItemBeFilled(world, heldItem))
			return false;

		Storage<FluidVariant> tank = FluidStorage.SIDED.find(world, be.method_11016(), null, be, side);

		if (tank == null)
			return false;

		try (Transaction t = TransferUtil.getTransaction()) {
			for (FluidStack fluid : TransferUtil.getAllFluids(tank)) {
				if (fluid.isEmpty())
					continue;
				long requiredAmountForItem = GenericItemFilling.getRequiredAmountForItem(world, heldItem, fluid.copy());
				if (requiredAmountForItem == -1)
					continue;
				if (requiredAmountForItem > fluid.getAmount())
					continue;

				if (world.field_9236)
					return true;

				if (player.method_7337() || be instanceof CreativeFluidTankBlockEntity)
					heldItem = heldItem.method_7972();
				class_1799 out = GenericItemFilling.fillItem(world, requiredAmountForItem, heldItem, fluid.copy());

				FluidStack copy = fluid.copy();
				copy.setAmount(requiredAmountForItem);
				tank.extract(copy.getType(), copy.getAmount(), t);
				t.commit();

				if (!player.method_7337())
					player.method_31548().method_7398(out);
				be.notifyUpdate();
				return true;
			}
		}

		return false;
	}

//	@Nullable
//	public static FluidExchange exchange(IFluidHandler fluidTank, IFluidHandlerItem fluidItem, FluidExchange preferred,
//										 int maxAmount) {
//		return exchange(fluidTank, fluidItem, preferred, true, maxAmount);
//	}
//
//	@Nullable
//	public static FluidExchange exchangeAll(IFluidHandler fluidTank, IFluidHandlerItem fluidItem,
//		FluidExchange preferred) {
//		return exchange(fluidTank, fluidItem, preferred, false, Integer.MAX_VALUE);
//	}
//
//	@Nullable
//	private static FluidExchange exchange(IFluidHandler fluidTank, IFluidHandlerItem fluidItem, FluidExchange preferred,
//		boolean singleOp, int maxTransferAmountPerTank) {
//
//		// Locks in the transfer direction of this operation
//		FluidExchange lockedExchange = null;
//
//		for (int tankSlot = 0; tankSlot < fluidTank.getTanks(); tankSlot++) {
//			for (int slot = 0; slot < fluidItem.getTanks(); slot++) {
//
//				FluidStack fluidInTank = fluidTank.getFluidInTank(tankSlot);
//				long tankCapacity = fluidTank.getTankCapacity(tankSlot) - fluidInTank.getAmount();
//				boolean tankEmpty = fluidInTank.isEmpty();
//
//				FluidStack fluidInItem = fluidItem.getFluidInTank(tankSlot);
//				long itemCapacity = fluidItem.getTankCapacity(tankSlot) - fluidInItem.getAmount();
//				boolean itemEmpty = fluidInItem.isEmpty();
//
//				boolean undecided = lockedExchange == null;
//				boolean canMoveToTank = (undecided || lockedExchange == FluidExchange.ITEM_TO_TANK) && tankCapacity > 0;
//				boolean canMoveToItem = (undecided || lockedExchange == FluidExchange.TANK_TO_ITEM) && itemCapacity > 0;
//
//				// Incompatible Liquids
//				if (!tankEmpty && !itemEmpty && !fluidInItem.isFluidEqual(fluidInTank))
//					continue;
//
//				// Transfer liquid to tank
//				if (((tankEmpty || itemCapacity <= 0) && canMoveToTank)
//					|| undecided && preferred == FluidExchange.ITEM_TO_TANK) {
//
//					long amount = fluidTank.fill(
//						fluidItem.drain(Math.min(maxTransferAmountPerTank, tankCapacity), false),
//						false);
//					if (amount > 0) {
//						lockedExchange = FluidExchange.ITEM_TO_TANK;
//						if (singleOp)
//							return lockedExchange;
//						continue;
//					}
//				}
//
//				// Transfer liquid from tank
//				if (((itemEmpty || tankCapacity <= 0) && canMoveToItem)
//					|| undecided && preferred == FluidExchange.TANK_TO_ITEM) {
//
//					long amount = fluidItem.fill(
//						fluidTank.drain(Math.min(maxTransferAmountPerTank, itemCapacity), false),
//						false);
//					if (amount > 0) {
//						lockedExchange = FluidExchange.TANK_TO_ITEM;
//						if (singleOp)
//							return lockedExchange;
//						continue;
//					}
//
//				}
//
//			}
//		}
//
//		return null;
//	}

}
