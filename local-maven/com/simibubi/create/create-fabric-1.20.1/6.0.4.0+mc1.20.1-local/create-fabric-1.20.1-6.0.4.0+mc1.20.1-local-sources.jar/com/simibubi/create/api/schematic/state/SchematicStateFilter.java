package com.simibubi.create.api.schematic.state;

import net.minecraft.class_2586;
import net.minecraft.class_2680;
import org.jetbrains.annotations.Nullable;

public interface SchematicStateFilter {
	/**
	 * This will always be called from the logical server
	 */
	class_2680 filterStates(@Nullable class_2586 be, class_2680 state);
}
