package com.simibubi.create.foundation.item;

import net.minecraft.class_1747;
import net.minecraft.class_2248;

public class UncontainableBlockItem extends class_1747 {
	public UncontainableBlockItem(class_2248 block, class_1793 properties) {
		super(block, properties);
	}

	@Override
	public boolean method_31568() {
		return false;
	}
}
