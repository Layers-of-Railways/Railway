package com.simibubi.create.foundation.mixin.accessor;

import net.minecraft.class_2505;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_2505.class)
public interface NbtAccounterAccessor {
	@Accessor("usage")
	long create$getUsage();
}
