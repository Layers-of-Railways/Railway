package com.simibubi.create.infrastructure.ponder.scenes;

import com.simibubi.create.AllBlocks;
import com.simibubi.create.content.contraptions.actors.contraptionControls.ContraptionControlsBlockEntity;
import com.simibubi.create.content.contraptions.actors.harvester.HarvesterBlockEntity;
import com.simibubi.create.content.contraptions.actors.psi.PortableItemInterfaceBlockEntity;
import com.simibubi.create.content.contraptions.actors.psi.PortableStorageInterfaceBlockEntity;
import com.simibubi.create.content.contraptions.chassis.LinearChassisBlock;
import com.simibubi.create.foundation.ponder.CreateSceneBuilder;

import net.createmod.catnip.math.Pointing;
import net.createmod.ponder.api.PonderPalette;
import net.createmod.ponder.api.element.ElementLink;
import net.createmod.ponder.api.element.EntityElement;
import net.createmod.ponder.api.element.ParrotElement;
import net.createmod.ponder.api.element.ParrotPose;
import net.createmod.ponder.api.element.WorldSectionElement;
import net.createmod.ponder.api.scene.SceneBuilder;
import net.createmod.ponder.api.scene.SceneBuildingUtil;
import net.createmod.ponder.api.scene.Selection;
import net.minecraft.class_1297;
import net.minecraft.class_1542;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2302;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2680;

public class MovementActorScenes {

	public static void psiTransfer(SceneBuilder builder, SceneBuildingUtil util) {
		CreateSceneBuilder scene = new CreateSceneBuilder(builder);
		scene.title("portable_storage_interface", "Contraption Storage Exchange");
		scene.configureBasePlate(0, 0, 6);
		scene.scaleSceneView(0.95f);
		scene.setSceneOffsetY(-1);
		scene.world().showSection(util.select().layer(0), class_2350.field_11036);
		scene.idle(5);

		class_2338 bearing = util.grid().at(5, 1, 2);
		scene.world().showSection(util.select().position(bearing), class_2350.field_11033);
		scene.idle(5);
		ElementLink<WorldSectionElement> contraption =
			scene.world().showIndependentSection(util.select().fromTo(5, 2, 2, 6, 3, 2), class_2350.field_11033);
		scene.world().configureCenterOfRotation(contraption, util.vector().centerOf(bearing));
		scene.idle(10);
		scene.world().rotateBearing(bearing, 360, 70);
		scene.world().rotateSection(contraption, 0, 360, 0, 70);
		scene.overlay().showText(60)
			.pointAt(util.vector().topOf(bearing.method_10086(2)))
			.colored(PonderPalette.RED)
			.placeNearTarget()
			.attachKeyFrame()
			.text("Moving inventories can be tricky to access with automation.");

		scene.idle(70);
		class_2338 psi = util.grid().at(4, 2, 2);
		scene.world().showSectionAndMerge(util.select().position(psi), class_2350.field_11034, contraption);
		scene.idle(13);
		scene.effects().superGlue(psi, class_2350.field_11034, true);

		scene.overlay().showText(80)
			.pointAt(util.vector().topOf(psi))
			.colored(PonderPalette.GREEN)
			.placeNearTarget()
			.attachKeyFrame()
			.text("This component can interact with storage without the need to stop the contraption.");
		scene.idle(90);

		class_2338 psi2 = psi.method_10088(2);
		scene.world().showSection(util.select().position(psi2), class_2350.field_11033);
		scene.overlay().showOutlineWithText(util.select().position(psi.method_10067()), 50)
			.colored(PonderPalette.RED)
			.placeNearTarget()
			.attachKeyFrame()
			.text("Place a second one with a gap of 1 or 2 blocks inbetween");
		scene.idle(55);

		scene.world().rotateBearing(bearing, 360, 60);
		scene.world().rotateSection(contraption, 0, 360, 0, 60);
		scene.idle(20);

		scene.overlay().showText(40)
			.placeNearTarget()
			.pointAt(util.vector().of(3, 3, 2.5))
			.text("Whenever they pass by each other, they will engage in a connection");
		scene.idle(38);

		Selection both = util.select().fromTo(2, 2, 2, 4, 2, 2);
		Class<PortableItemInterfaceBlockEntity> psiClass = PortableItemInterfaceBlockEntity.class;

		scene.world().modifyBlockEntityNBT(both, psiClass, nbt -> {
			nbt.method_10548("Distance", 1);
			nbt.method_10548("Timer", 12);
		});

		scene.idle(17);
		scene.overlay().showOutline(PonderPalette.GREEN, psi, util.select().fromTo(5, 3, 2, 6, 3, 2), 80);
		scene.idle(10);

		scene.overlay().showOutlineWithText(util.select().position(psi2), 70)
			.placeNearTarget()
			.colored(PonderPalette.GREEN)
			.attachKeyFrame()
			.text("While engaged, the stationary interface will represent ALL inventories on the contraption");

		scene.idle(80);

		class_2338 hopper = util.grid().at(2, 3, 2);
		scene.world().showSection(util.select().position(hopper), class_2350.field_11033);
		scene.overlay().showText(70)
			.placeNearTarget()
			.pointAt(util.vector().topOf(hopper))
			.attachKeyFrame()
			.text("Items can now be inserted...");

		class_1799 itemStack = new class_1799(class_1802.field_27022);
		class_243 entitySpawn = util.vector().topOf(hopper.method_10086(3));

		ElementLink<EntityElement> entity1 =
			scene.world().createItemEntity(entitySpawn, util.vector().of(0, 0.2, 0), itemStack);
		scene.idle(10);
		ElementLink<EntityElement> entity2 =
			scene.world().createItemEntity(entitySpawn, util.vector().of(0, 0.2, 0), itemStack);
		scene.idle(10);
		scene.world().modifyEntity(entity1, class_1297::method_31472);
		scene.idle(10);
		scene.world().modifyEntity(entity2, class_1297::method_31472);

		scene.overlay().showControls(util.vector().topOf(5, 3, 2), Pointing.DOWN, 40).withItem(itemStack);

		scene.idle(30);
		scene.world().hideSection(util.select().position(hopper), class_2350.field_11036);
		scene.idle(15);

		class_2338 beltPos = util.grid().at(1, 1, 2);
		scene.world().showSection(util.select().fromTo(0, 1, 0, 1, 2, 6), class_2350.field_11033);
		scene.idle(10);
		scene.world().createItemOnBelt(beltPos, class_2350.field_11034, itemStack.method_7972());
		scene.overlay().showText(40)
			.placeNearTarget()
			.pointAt(util.vector().topOf(beltPos.method_10084()))
			.text("...or extracted from the contraption");
		scene.idle(15);
		scene.world().createItemOnBelt(beltPos, class_2350.field_11034, itemStack);

		scene.idle(20);
		scene.world().modifyEntities(class_1542.class, class_1297::method_31472);
		scene.idle(15);
		scene.world().modifyEntities(class_1542.class, class_1297::method_31472);

		scene.overlay().showText(120)
			.placeNearTarget()
			.pointAt(util.vector().topOf(psi2))
			.text("After no items have been exchanged for a while, the contraption will continue on its way");
		scene.world().modifyBlockEntityNBT(both, psiClass, nbt -> nbt.method_10548("Timer", 2));

		scene.idle(15);
		scene.markAsFinished();
		scene.world().rotateBearing(bearing, 270, 120);
		scene.world().rotateSection(contraption, 0, 270, 0, 120);
	}

	public static void psiRedstone(SceneBuilder builder, SceneBuildingUtil util) {
		CreateSceneBuilder scene = new CreateSceneBuilder(builder);
		scene.title("portable_storage_interface_redstone", "Redstone Control");
		scene.configureBasePlate(0, 0, 5);
		scene.setSceneOffsetY(-1);

		Class<PortableStorageInterfaceBlockEntity> psiClass = PortableStorageInterfaceBlockEntity.class;
		Selection psis = util.select().fromTo(1, 1, 3, 1, 3, 3);
		scene.world().modifyBlockEntityNBT(psis, psiClass, nbt -> {
			nbt.method_10548("Distance", 1);
			nbt.method_10548("Timer", 12);
		});

		scene.world().showSection(util.select().layer(0), class_2350.field_11036);
		scene.idle(5);
		scene.world().showSection(util.select().layer(1), class_2350.field_11033);
		scene.idle(5);

		ElementLink<WorldSectionElement> contraption =
			scene.world().showIndependentSection(util.select().layersFrom(2), class_2350.field_11033);
		class_2338 bearing = util.grid().at(3, 1, 3);
		scene.world().configureCenterOfRotation(contraption, util.vector().topOf(bearing));
		scene.idle(20);
		scene.world().modifyBlockEntityNBT(psis, psiClass, nbt -> nbt.method_10548("Timer", 2));
		scene.world().rotateBearing(bearing, 360 * 3 + 270, 240 + 60);
		scene.world().rotateSection(contraption, 0, 360 * 3 + 270, 0, 240 + 60);
		scene.idle(20);

		scene.world().toggleRedstonePower(util.select().fromTo(1, 1, 1, 1, 1, 2));
		scene.effects().indicateRedstone(util.grid().at(1, 1, 1));

		scene.idle(10);

		scene.overlay().showOutlineWithText(util.select().position(1, 1, 3), 120)
			.colored(PonderPalette.RED)
			.text("Redstone power will prevent the stationary interface from engaging");

		scene.idle(20);
		scene.markAsFinished();
	}

	public static void harvester(SceneBuilder builder, SceneBuildingUtil util) {
		CreateSceneBuilder scene = new CreateSceneBuilder(builder);
		scene.title("mechanical_harvester", "Using Mechanical Harvesters on Contraptions");
		scene.configureBasePlate(0, 0, 6);
		scene.scaleSceneView(0.9f);

		Selection crops = util.select().fromTo(4, 1, 2, 3, 1, 2)
			.add(util.select().fromTo(3, 1, 1, 2, 1, 1)
				.add(util.select().position(2, 1, 3))
				.add(util.select().position(1, 1, 2)));

		scene.world().setBlocks(crops, class_2246.field_10293.method_9564()
			.method_11657(class_2302.field_10835, 7), false);
		scene.world().showSection(util.select().layer(0), class_2350.field_11036);

		class_2338 bearingPos = util.grid().at(4, 1, 4);

		scene.idle(5);
		scene.world().showSection(crops, class_2350.field_11036);
		scene.world().showSection(util.select().position(bearingPos), class_2350.field_11033);
		scene.idle(5);
		ElementLink<WorldSectionElement> contraption =
			scene.world().showIndependentSection(util.select().fromTo(4, 2, 4, 2, 2, 5)
				.add(util.select().fromTo(2, 1, 5, 0, 1, 5)), class_2350.field_11033);
		scene.world().configureCenterOfRotation(contraption, util.vector().centerOf(bearingPos));
		scene.idle(10);

		for (int i = 0; i < 3; i++) {
			scene.world().showSectionAndMerge(util.select().position(i, 1, 4), class_2350.field_11035, contraption);
			scene.idle(5);
		}

		scene.overlay().showText(60)
			.attachKeyFrame()
			.placeNearTarget()
			.pointAt(util.vector().blockSurface(util.grid().at(1, 1, 4), class_2350.field_11035))
			.text("Whenever Harvesters are moved as part of an animated Contraption...");
		scene.idle(70);

		for (int i = 0; i < 3; i++)
			scene.world().modifyBlockEntity(util.grid().at(i, 1, 4), HarvesterBlockEntity.class,
				hte -> hte.setAnimatedSpeed(-150));
		scene.world().rotateBearing(bearingPos, -360, 140);
		scene.world().rotateSection(contraption, 0, -360, 0, 140);

		class_2680 harvested = class_2246.field_10293.method_9564();
		class_1799 wheatItem = new class_1799(class_1802.field_8861);

		scene.idle(5);
		class_2338 current = util.grid().at(2, 1, 3);
		scene.world().setBlock(current, harvested, true);
		scene.world().createItemEntity(util.vector().centerOf(current), util.vector().of(0, 0.3, -.2), wheatItem);
		scene.idle(5);
		current = util.grid().at(1, 1, 2);
		scene.world().setBlock(current, harvested, true);
		scene.world().createItemEntity(util.vector().centerOf(current), util.vector().of(0, 0.3, -.2), wheatItem);
		scene.idle(5);
		current = util.grid().at(3, 1, 2);
		scene.world().setBlock(current, harvested, true);
		scene.world().createItemEntity(util.vector().centerOf(current), util.vector().of(.1, 0.3, -.1), wheatItem);
		current = util.grid().at(2, 1, 1);
		scene.world().setBlock(current, harvested, true);
		scene.world().createItemEntity(util.vector().centerOf(current), util.vector().of(.1, 0.3, -.1), wheatItem);
		scene.idle(5);
		current = util.grid().at(3, 1, 1);
		scene.world().setBlock(current, harvested, true);
		scene.world().createItemEntity(util.vector().centerOf(current), util.vector().of(.1, 0.3, -.1), wheatItem);
		scene.idle(5);
		current = util.grid().at(4, 1, 2);
		scene.world().setBlock(current, harvested, true);
		scene.world().createItemEntity(util.vector().centerOf(current), util.vector().of(.2, 0.3, 0), wheatItem);

		scene.overlay().showText(80)
			.pointAt(util.vector().topOf(1, 0, 2))
			.text("They will harvest and reset any mature crops on their way")
			.placeNearTarget();

		scene.idle(101);
		scene.world().hideSection(crops, class_2350.field_11033);
		scene.idle(15);
		scene.world().modifyEntities(class_1542.class, class_1297::method_31472);
		scene.world().setBlocks(crops, class_2246.field_10293.method_9564()
			.method_11657(class_2302.field_10835, 7), false);
		scene.world().showSection(crops, class_2350.field_11036);

		for (int i = 0; i < 3; i++)
			scene.world().modifyBlockEntity(util.grid().at(i, 1, 4), HarvesterBlockEntity.class,
				hte -> hte.setAnimatedSpeed(0));
		scene.idle(10);

		scene.world().cycleBlockProperty(util.grid().at(1, 1, 5), LinearChassisBlock.STICKY_TOP);
		scene.world().glueBlockOnto(util.grid().at(1, 2, 5), class_2350.field_11033, contraption);

		scene.overlay().showText(60)
			.attachKeyFrame()
			.placeNearTarget()
			.pointAt(util.vector().blockSurface(util.grid().at(1, 2, 5), class_2350.field_11039))
			.sharedText("storage_on_contraption");
		scene.idle(70);

		for (int i = 0; i < 3; i++)
			scene.world().modifyBlockEntity(util.grid().at(i, 1, 4), HarvesterBlockEntity.class,
				hte -> hte.setAnimatedSpeed(-150));
		scene.world().rotateBearing(bearingPos, -360, 140);
		scene.world().rotateSection(contraption, 0, -360, 0, 140);

		scene.idle(5);
		current = util.grid().at(2, 1, 3);
		scene.world().setBlock(current, harvested, true);
		scene.idle(5);
		current = util.grid().at(1, 1, 2);
		scene.world().setBlock(current, harvested, true);
		scene.idle(5);
		current = util.grid().at(3, 1, 2);
		scene.world().setBlock(current, harvested, true);
		current = util.grid().at(2, 1, 1);
		scene.world().setBlock(current, harvested, true);
		scene.idle(5);
		current = util.grid().at(3, 1, 1);
		scene.world().setBlock(current, harvested, true);
		scene.idle(5);
		current = util.grid().at(4, 1, 2);
		scene.world().setBlock(current, harvested, true);

		scene.idle(116);
		scene.overlay().showControls(util.vector().topOf(1, 2, 5), Pointing.DOWN, 50).withItem(wheatItem);
		for (int i = 0; i < 3; i++)
			scene.world().modifyBlockEntity(util.grid().at(i, 1, 4), HarvesterBlockEntity.class,
				hte -> hte.setAnimatedSpeed(0));
	}

	public static void plough(SceneBuilder builder, SceneBuildingUtil util) {
		CreateSceneBuilder scene = new CreateSceneBuilder(builder);
		scene.title("mechanical_plough", "Using Mechanical Ploughs on Contraptions");
		scene.configureBasePlate(0, 0, 6);
		scene.scaleSceneView(0.9f);

		Selection garbage = util.select().fromTo(2, 1, 3, 1, 1, 2);
		Selection kinetics = util.select().fromTo(5, 1, 6, 5, 1, 2);
		Selection dynamic = util.select().fromTo(4, 0, 6, 5, 1, 6);

		scene.showBasePlate();
		ElementLink<WorldSectionElement> cogs =
			scene.world().showIndependentSection(util.select().fromTo(4, 0, 6, 5, 1, 6), class_2350.field_11036);
		scene.idle(5);
		scene.world().showSection(kinetics.substract(dynamic), class_2350.field_11033);
		ElementLink<WorldSectionElement> pistonHead =
			scene.world().showIndependentSection(util.select().fromTo(5, 1, 1, 7, 1, 1), class_2350.field_11033);
		scene.world().moveSection(pistonHead, util.vector().of(0, 0, 1), 0);
		scene.idle(5);
		ElementLink<WorldSectionElement> contraption =
			scene.world().showIndependentSection(util.select().fromTo(4, 1, 3, 4, 1, 2), class_2350.field_11033);
		scene.idle(10);
		scene.world().showSectionAndMerge(util.select().position(3, 1, 3), class_2350.field_11034, contraption);
		scene.idle(5);
		scene.world().showSectionAndMerge(util.select().position(3, 1, 2), class_2350.field_11034, contraption);
		scene.idle(20);

		scene.overlay().showText(60)
			.attachKeyFrame()
			.placeNearTarget()
			.pointAt(util.vector().blockSurface(util.grid().at(3, 1, 3), class_2350.field_11034))
			.text("Whenever Ploughs are moved as part of an animated Contraption...");
		scene.idle(50);
		scene.world().showSection(garbage, class_2350.field_11034);
		scene.idle(20);

		scene.world().setKineticSpeed(util.select().position(4, 0, 6), -8);
		scene.world().setKineticSpeed(kinetics, 16);
		scene.world().moveSection(pistonHead, util.vector().of(-2, 0, 0), 60);
		scene.world().moveSection(contraption, util.vector().of(-2, 0, 0), 60);
		scene.idle(15);

		class_243 m = util.vector().of(-0.1, .2, 0);
		scene.world().destroyBlock(util.grid().at(2, 1, 3));
		scene.world().createItemEntity(util.vector().centerOf(2, 1, 3), m, new class_1799(class_1802.field_8865));
		scene.world().destroyBlock(util.grid().at(2, 1, 2));
		scene.world().createItemEntity(util.vector().centerOf(2, 1, 2), m, new class_1799(class_1802.field_8810));

		scene.idle(30);

		scene.world().destroyBlock(util.grid().at(1, 1, 3));
		scene.world().createItemEntity(util.vector().centerOf(1, 1, 3), m, new class_1799(class_1802.field_8129));
		scene.world().destroyBlock(util.grid().at(1, 1, 2));
		scene.world().createItemEntity(util.vector().centerOf(1, 1, 2), m, new class_1799(class_1802.field_8725));

		scene.overlay().showText(60)
			.placeNearTarget()
			.pointAt(util.vector().blockSurface(util.grid().at(1, 1, 3), class_2350.field_11034))
			.text("...they will break blocks without a solid collision hitbox");
		scene.idle(50);

		scene.world().modifyKineticSpeed(util.select().everywhere(), f -> -f);
		scene.world().moveSection(pistonHead, util.vector().of(2, 0, 0), 40);
		scene.world().moveSection(contraption, util.vector().of(2, 0, 0), 40);
		scene.world().hideSection(garbage, class_2350.field_11036);
		scene.idle(40);
		scene.world().setBlocks(garbage, class_2246.field_10477.method_9564(), false);
		scene.world().modifyEntities(class_1542.class, class_1297::method_31472);
		ElementLink<WorldSectionElement> chest =
			scene.world().showIndependentSection(util.select().position(4, 2, 2), class_2350.field_11033);

		scene.overlay().showText(60)
			.attachKeyFrame()
			.placeNearTarget()
			.pointAt(util.vector().blockSurface(util.grid().at(4, 2, 2), class_2350.field_11039))
			.sharedText("storage_on_contraption");
		scene.idle(15);
		scene.effects().superGlue(util.grid().at(4, 2, 2), class_2350.field_11033, true);
		scene.idle(45);
		scene.world().showSection(garbage, class_2350.field_11034);
		scene.idle(20);

		scene.world().modifyKineticSpeed(util.select().everywhere(), f -> -f);
		scene.world().moveSection(pistonHead, util.vector().of(-2, 0, 0), 60);
		scene.world().moveSection(contraption, util.vector().of(-2, 0, 0), 60);
		scene.world().moveSection(chest, util.vector().of(-2, 0, 0), 60);
		scene.idle(15);
		scene.world().destroyBlock(util.grid().at(2, 1, 3));
		scene.world().destroyBlock(util.grid().at(2, 1, 2));
		scene.idle(30);
		scene.world().destroyBlock(util.grid().at(1, 1, 3));
		scene.world().destroyBlock(util.grid().at(1, 1, 2));
		scene.idle(15);

		scene.overlay().showControls(util.vector().topOf(2, 2, 2), Pointing.DOWN, 40).withItem(new class_1799(class_1802.field_8543));
		scene.idle(40);
		scene.world().hideIndependentSection(chest, class_2350.field_11036);
		scene.world().modifyKineticSpeed(util.select().everywhere(), f -> -f);
		scene.world().moveSection(pistonHead, util.vector().of(2, 0, 0), 40);
		scene.world().moveSection(contraption, util.vector().of(2, 0, 0), 40);
		scene.idle(40);

		Selection dirt = util.select().fromTo(2, 0, 3, 1, 0, 2);
		scene.world().hideSection(dirt, class_2350.field_11033);
		scene.idle(15);
		scene.world().setBlocks(dirt, class_2246.field_10219.method_9564(), false);
		scene.world().showSection(dirt, class_2350.field_11036);
		scene.overlay().showText(60)
			.placeNearTarget()
			.attachKeyFrame()
			.pointAt(util.vector().blockSurface(util.grid().at(3, 1, 3), class_2350.field_11034))
			.text("Additionally, ploughs can create farmland");
		scene.idle(30);

		scene.world().modifyKineticSpeed(util.select().everywhere(), f -> -f);
		scene.world().moveSection(pistonHead, util.vector().of(-2, 0, 0), 60);
		scene.world().moveSection(contraption, util.vector().of(-2, 0, 0), 60);
		scene.world().moveSection(chest, util.vector().of(-2, 0, 0), 60);
		scene.idle(15);
		scene.world().setBlocks(util.select().fromTo(2, 0, 2, 2, 0, 3), class_2246.field_10362.method_9564(), true);
		scene.idle(30);
		scene.world().setBlocks(util.select().fromTo(1, 0, 2, 1, 0, 3), class_2246.field_10362.method_9564(), true);
		scene.idle(20);

		scene.world().modifyKineticSpeed(util.select().everywhere(), f -> -f);
		scene.world().moveSection(pistonHead, util.vector().of(2, 0, 0), 40);
		scene.world().moveSection(contraption, util.vector().of(2, 0, 0), 40);

		scene.idle(50);
		scene.world().setKineticSpeed(util.select().everywhere(), 0);
		scene.world().hideSection(kinetics.substract(dynamic), class_2350.field_11034);
		scene.world().hideSection(dirt, class_2350.field_11033);
		scene.world().hideIndependentSection(pistonHead, class_2350.field_11034);
		scene.world().moveSection(cogs, util.vector().of(-1, 0, 0), 15);
		scene.idle(15);
		scene.world().restoreBlocks(dirt);
		scene.world().showSection(dirt, class_2350.field_11036);
		scene.world().showSection(util.select().fromTo(4, 1, 6, 4, 3, 4), class_2350.field_11043);
		scene.idle(15);
		scene.world().showSectionAndMerge(util.select().fromTo(4, 3, 3, 4, 2, 3), class_2350.field_11033, contraption);
		scene.idle(15);

		class_2338 bearingPos = util.grid().at(4, 3, 4);
		scene.addKeyframe();

		scene.world().setKineticSpeed(util.select().position(4, 0, 6), 8);
		scene.world().setKineticSpeed(util.select().position(5, 1, 6), -16);
		scene.world().setKineticSpeed(util.select().position(4, 3, 5), -16);
		scene.world().setKineticSpeed(util.select().position(4, 1, 5), -16);
		scene.world().setKineticSpeed(util.select().position(4, 2, 5), 16);
		scene.world().modifyKineticSpeed(util.select().everywhere(), f -> -2 * f);
		scene.world().configureCenterOfRotation(contraption, util.vector().centerOf(bearingPos));
		scene.world().rotateSection(contraption, 0, 0, 90, 20);
		scene.world().rotateBearing(bearingPos, 90, 20);

		scene.idle(10);
		ElementLink<ParrotElement> birb = scene.special().createBirb(util.vector().topOf(3, 0, 2)
			.method_1031(0, 0, 0.5), ParrotPose.FlappyPose::new);
		scene.idle(11);

		scene.world().modifyKineticSpeed(util.select().everywhere(), f -> -2 * f);
		scene.world().rotateSection(contraption, 0, 0, -135, 10);
		scene.world().rotateBearing(bearingPos, -135, 10);
		scene.idle(7);
		scene.special().moveParrot(birb, util.vector().of(-20, 15, 0), 20);
		scene.special().rotateParrot(birb, 0, 360, 0, 20);
		scene.idle(3);
		scene.world().setKineticSpeed(util.select().everywhere(), 0);
		scene.idle(20);

		scene.overlay().showText(60)
			.placeNearTarget()
			.pointAt(util.vector().centerOf(util.grid().at(1, 3, 2)))
			.text("...they can also launch entities without hurting them");
		scene.idle(30);
	}

	public static void contraptionControls(SceneBuilder builder, SceneBuildingUtil util) {
		CreateSceneBuilder scene = new CreateSceneBuilder(builder);
		scene.title("contraption_controls", "Using Contraption Controls");
		scene.configureBasePlate(1, 0, 6);
		scene.scaleSceneView(0.9f);
		scene.showBasePlate();

		class_2338 cobblePos = util.grid().at(3, 1, 2);
		class_2338 wheatPos = util.grid().at(2, 1, 1);
		class_2338 bearingPos = util.grid().at(5, 1, 4);
		Selection contraption = util.select().fromTo(5, 2, 4, 3, 2, 5)
			.add(util.select().fromTo(3, 1, 5, 1, 1, 4));
		class_2338 controlsPos1 = util.grid().at(1, 2, 5);
		class_2338 controlsPos2 = util.grid().at(2, 2, 5);
		class_2338 drillPos = util.grid().at(2, 1, 4);
		class_2338 harvesterPos = util.grid().at(1, 1, 4);
		Selection leverCol = util.select().fromTo(0, 0, 5, 0, 2, 5);
		class_2338 leverPos = util.grid().at(0, 2, 5);
		scene.idle(5);

		scene.world().showSection(util.select().position(wheatPos), class_2350.field_11036);
		scene.world().showSection(util.select().position(cobblePos), class_2350.field_11036);
		scene.idle(10);

		scene.world().showSection(util.select().position(bearingPos), class_2350.field_11033);
		scene.idle(5);

		ElementLink<WorldSectionElement> contraptionLink =
			scene.world().showIndependentSection(contraption, class_2350.field_11033);
		scene.world().configureCenterOfRotation(contraptionLink, util.vector().centerOf(bearingPos));
		scene.idle(10);

		scene.world().modifyBlockEntity(harvesterPos, HarvesterBlockEntity.class, hte -> hte.setAnimatedSpeed(-280));
		scene.world().setKineticSpeed(util.select().position(drillPos), 64);
		scene.world().rotateBearing(bearingPos, -30, 20);
		scene.world().rotateSection(contraptionLink, 0, -30, 0, 20);

		class_2680 harvested = class_2246.field_10293.method_9564();

		scene.idle(20);
		scene.overlay().showText(60)
			.placeNearTarget()
			.pointAt(util.vector().topOf(cobblePos))
			.text("Actors on moving contraptions are always active by default");

		for (int i = 0; i < 10; i++) {
			scene.idle(3);
			scene.world().incrementBlockBreakingProgress(cobblePos);
		}

		class_243 m = util.vector().of(.1, 0, -.1);
		class_1799 cobbleItem = new class_1799(class_1802.field_20412);
		class_1799 wheatItem = new class_1799(class_1802.field_8861);
		ElementLink<EntityElement> item1 = scene.world().createItemEntity(util.vector().centerOf(cobblePos), m, cobbleItem);

		scene.idle(5);

		scene.world().rotateBearing(bearingPos, -60, 40);
		scene.world().rotateSection(contraptionLink, 0, -60, 0, 40);
		scene.idle(5);

		scene.world().setBlock(wheatPos, harvested, true);
		ElementLink<EntityElement> item2 = scene.world().createItemEntity(util.vector().centerOf(wheatPos), m, wheatItem);
		scene.idle(35);

		scene.world().modifyBlockEntity(harvesterPos, HarvesterBlockEntity.class, hte -> hte.setAnimatedSpeed(0));
		scene.world().setKineticSpeed(util.select().position(drillPos), 0);
		scene.idle(5);

		scene.world().modifyEntity(item1, class_1297::method_31472);
		scene.world().modifyEntity(item2, class_1297::method_31472);
		scene.world().hideIndependentSection(contraptionLink, class_2350.field_11036);
		scene.idle(15);
		contraptionLink = scene.world().showIndependentSection(contraption, class_2350.field_11033);
		scene.world().configureCenterOfRotation(contraptionLink, util.vector().centerOf(bearingPos));
		scene.world().moveSection(contraptionLink, util.vector().of(0, 1 / 512f, 0), 0);

		scene.world().restoreBlocks(util.select().position(wheatPos));
		scene.world().restoreBlocks(util.select().position(cobblePos));
		scene.idle(10);

		scene.world().showSectionAndMerge(util.select().position(controlsPos1), class_2350.field_11033, contraptionLink);
		scene.idle(15);
		scene.effects().superGlue(controlsPos1, class_2350.field_11033, true);

		scene.overlay().showText(60)
			.placeNearTarget()
			.pointAt(util.vector().topOf(controlsPos1)
				.method_1031(0, -4 / 16f, 0))
			.attachKeyFrame()
			.text("Contraption Controls can be used to toggle them on the fly");
		scene.idle(55);

		scene.world().rotateBearing(bearingPos, -15, 10);
		scene.world().rotateSection(contraptionLink, 0, -15, 0, 10);
		scene.world().modifyBlockEntity(harvesterPos, HarvesterBlockEntity.class, hte -> hte.setAnimatedSpeed(-280));
		scene.world().setKineticSpeed(util.select().position(drillPos), 64);
		scene.idle(10);
		scene.world().modifyBlockEntity(harvesterPos, HarvesterBlockEntity.class, hte -> hte.setAnimatedSpeed(0));
		scene.world().setKineticSpeed(util.select().position(drillPos), 0);
		scene.overlay().showControls(util.vector().of(1.5, 2.75, 4.5), Pointing.DOWN, 15).rightClick();
		scene.idle(7);
		scene.world().modifyBlockEntity(controlsPos1, ContraptionControlsBlockEntity.class, ccte -> ccte.disabled = true);
		scene.effects().indicateRedstone(util.grid().at(1, 2, 4));
		scene.idle(10);
		scene.world().rotateBearing(bearingPos, -60, 40);
		scene.world().rotateSection(contraptionLink, 0, -60, 0, 40);
		scene.idle(40);

		scene.overlay().showControls(util.vector().of(3.5, 2.75, 1), Pointing.DOWN, 15).rightClick();
		scene.idle(7);
		scene.world().modifyBlockEntity(controlsPos1, ContraptionControlsBlockEntity.class,
			ccte -> ccte.disabled = false);
		scene.effects().indicateRedstone(util.grid().at(3, 2, 0));
		scene.idle(10);
		scene.world().modifyBlockEntity(harvesterPos, HarvesterBlockEntity.class, hte -> hte.setAnimatedSpeed(-280));
		scene.world().setKineticSpeed(util.select().position(drillPos), 64);
		scene.world().rotateBearing(bearingPos, -15, 10);
		scene.world().rotateSection(contraptionLink, 0, -15, 0, 10);
		scene.idle(10);
		scene.world().modifyBlockEntity(harvesterPos, HarvesterBlockEntity.class, hte -> hte.setAnimatedSpeed(0));
		scene.world().setKineticSpeed(util.select().position(drillPos), 0);
		scene.idle(5);

		scene.world().hideIndependentSection(contraptionLink, class_2350.field_11036);
		scene.idle(15);
		contraptionLink = scene.world().showIndependentSection(contraption, class_2350.field_11033);
		scene.world().showSectionAndMerge(util.select().position(controlsPos1), class_2350.field_11033, contraptionLink);
		scene.world().configureCenterOfRotation(contraptionLink, util.vector().centerOf(bearingPos));
		scene.world().moveSection(contraptionLink, util.vector().of(0, 1 / 512f, 0), 0);

		scene.idle(15);
		scene.world().showSectionAndMerge(util.select().position(controlsPos2), class_2350.field_11033, contraptionLink);
		scene.idle(15);
		scene.effects().superGlue(controlsPos2, class_2350.field_11033, true);

		scene.overlay().showText(60)
			.placeNearTarget()
			.pointAt(util.vector().topOf(controlsPos2)
				.method_1031(0, -4 / 16f, 0))
			.attachKeyFrame()
			.text("They can be attached anywhere on the contraption");
		scene.idle(75);

		scene.overlay().showControls(util.vector().topOf(controlsPos2), Pointing.DOWN, 30).rightClick()
			.withItem(AllBlocks.MECHANICAL_DRILL.asStack());
		scene.idle(5);
		scene.overlay().showControls(util.vector().centerOf(controlsPos1), Pointing.UP, 25).rightClick()
			.withItem(AllBlocks.MECHANICAL_HARVESTER.asStack());
		scene.idle(2);
		scene.world().setFilterData(util.select().position(controlsPos2), ContraptionControlsBlockEntity.class,
									AllBlocks.MECHANICAL_DRILL.asStack());
		scene.idle(5);
		scene.world().setFilterData(util.select().position(controlsPos1), ContraptionControlsBlockEntity.class,
									AllBlocks.MECHANICAL_HARVESTER.asStack());
		scene.idle(30);

		scene.overlay().showText(90)
			.placeNearTarget()
			.independent(80)
			.attachKeyFrame()
			.text("While disassembled, the filter can be changed to target specific types of actors");
		scene.idle(90);

		scene.overlay().showControls(util.vector().topOf(controlsPos2), Pointing.RIGHT, 15).rightClick();
		scene.idle(7);
		scene.world().modifyBlockEntity(controlsPos2, ContraptionControlsBlockEntity.class, ccte -> ccte.disabled = true);
		scene.effects().indicateRedstone(controlsPos2);
		scene.idle(10);

		scene.world().modifyBlockEntity(harvesterPos, HarvesterBlockEntity.class, hte -> hte.setAnimatedSpeed(-280));
		scene.world().rotateBearing(bearingPos, -90, 60);
		scene.world().rotateSection(contraptionLink, 0, -90, 0, 60);
		scene.idle(25);
		scene.world().setBlock(wheatPos, harvested, true);
		ElementLink<EntityElement> item3 = scene.world().createItemEntity(util.vector().centerOf(wheatPos), m, wheatItem);
		scene.idle(35);
		scene.world().modifyBlockEntity(harvesterPos, HarvesterBlockEntity.class, hte -> hte.setAnimatedSpeed(0));
		scene.idle(5);

		scene.world().modifyEntity(item3, class_1297::method_31472);
		scene.world().hideIndependentSection(contraptionLink, class_2350.field_11036);
		scene.idle(15);
		scene.world().modifyBlockEntity(controlsPos2, ContraptionControlsBlockEntity.class,
			ccte -> ccte.disabled = false);
		contraptionLink = scene.world().showIndependentSection(contraption, class_2350.field_11033);
		scene.world().showSectionAndMerge(util.select().position(controlsPos1), class_2350.field_11033, contraptionLink);
		scene.world().showSectionAndMerge(util.select().position(controlsPos2), class_2350.field_11033, contraptionLink);
		scene.world().configureCenterOfRotation(contraptionLink, util.vector().centerOf(bearingPos));
		scene.world().moveSection(contraptionLink, util.vector().of(0, 1 / 512f, 0), 0);

		scene.world().restoreBlocks(util.select().position(wheatPos));
		scene.idle(30);

		scene.world().showSection(leverCol, class_2350.field_11034);

		scene.overlay().showText(50)
			.placeNearTarget()
			.independent(100)
			.attachKeyFrame()
			.text("If it is redstone-activated during assembly...");
		scene.idle(30);

		scene.world().toggleRedstonePower(leverCol);
		scene.effects().indicateRedstone(leverPos);
		scene.world().modifyBlockEntity(controlsPos1, ContraptionControlsBlockEntity.class, ccte -> ccte.disabled = true);
		scene.idle(35);

		scene.world().setKineticSpeed(util.select().position(drillPos), 64);
		scene.world().rotateBearing(bearingPos, -30, 20);
		scene.world().rotateSection(contraptionLink, 0, -30, 0, 20);

		scene.idle(20);
		scene.overlay().showText(60)
			.placeNearTarget()
			.pointAt(util.vector().centerOf(wheatPos))
			.text("...targeted actors will be turned off from the start");

		for (int i = 0; i < 10; i++) {
			scene.idle(3);
			scene.world().incrementBlockBreakingProgress(cobblePos);
		}

		ElementLink<EntityElement> item4 = scene.world().createItemEntity(util.vector().centerOf(cobblePos), m, cobbleItem);

		scene.idle(5);
		scene.world().rotateBearing(bearingPos, -60, 40);
		scene.world().rotateSection(contraptionLink, 0, -60, 0, 40);
		scene.idle(40);
		scene.world().setKineticSpeed(util.select().position(drillPos), 0);
		scene.idle(5);
		scene.world().modifyEntity(item4, class_1297::method_31472);
	}

}
