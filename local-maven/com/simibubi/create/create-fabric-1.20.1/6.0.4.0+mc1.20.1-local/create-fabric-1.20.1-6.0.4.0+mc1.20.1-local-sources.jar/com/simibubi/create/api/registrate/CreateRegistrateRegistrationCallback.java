package com.simibubi.create.api.registrate;

import java.util.function.Consumer;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import com.simibubi.create.foundation.data.CreateRegistrate;
import com.simibubi.create.impl.registrate.CreateRegistrateRegistrationCallbackImpl;

/**
 * Register a callback for when an entry is added to any {@link CreateRegistrate} instance
 */
public class CreateRegistrateRegistrationCallback {
	public static <T> void register(class_5321<? extends class_2378<T>> registry, class_2960 id, Consumer<T> callback) {
		CreateRegistrateRegistrationCallbackImpl.register(registry, id, callback);
	}
}
