package com.simibubi.create.api.behaviour.spouting;

import java.util.function.Predicate;
import java.util.function.UnaryOperator;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2758;
import net.minecraft.class_3611;
import com.simibubi.create.content.fluids.spout.SpoutBlockEntity;
import io.github.fabricators_of_create.porting_lib.fluids.FluidStack;

/**
 * An implementation of {@link BlockSpoutingBehaviour} that allows for easily modifying a BlockState through spouting.
 * @param amount the amount of fluid consumed when filling
 * @param fluidTest a predicate for fluids that can be used to fill the target block
 * @param canFill a predicate that must match the target BlockState to fill it
 * @param fillFunction a function that converts the current state into the filled one
 */
public record StateChangingBehavior(int amount, Predicate<class_3611> fluidTest, Predicate<class_2680> canFill,
									UnaryOperator<class_2680> fillFunction) implements BlockSpoutingBehaviour {
	@Override
	public long fillBlock(class_1937 level, class_2338 pos, SpoutBlockEntity spout, FluidStack availableFluid, boolean simulate) {
		if (availableFluid.getAmount() < this.amount || !this.fluidTest.test(availableFluid.getFluid()))
			return 0;

		class_2680 state = level.method_8320(pos);
		if (!this.canFill.test(state))
			return 0;

		if (!simulate) {
			class_2680 newState = this.fillFunction.apply(state);
			level.method_8501(pos, newState);
		}

		return this.amount;
	}

	/**
	 * Shortcut for {@link #setTo(int, Predicate, class_2680)} that uses the Block's default state.
	 */
	public static BlockSpoutingBehaviour setTo(int amount, Predicate<class_3611> fluidTest, class_2248 block) {
		return setTo(amount, fluidTest, block.method_9564());
	}

	/**
	 * Create a {@link BlockSpoutingBehaviour} that will simply convert the target block to the given state.
	 * @param newState the state that will be set after filling
	 */
	public static BlockSpoutingBehaviour setTo(int amount, Predicate<class_3611> fluidTest, class_2680 newState) {
		return new StateChangingBehavior(amount, fluidTest, state -> true, state -> newState);
	}

	/**
	 * Create a {@link BlockSpoutingBehaviour} that will increment the given {@link class_2758} until it reaches
	 * its maximum value, consuming {@code amount} each time fluid is filled.
	 * @param property the property that will be incremented by one on each fill
	 */
	public static BlockSpoutingBehaviour incrementingState(int amount, Predicate<class_3611> fluidTest, class_2758 property) {
		int max = property.method_11898().stream().max(Integer::compareTo).orElseThrow();

		Predicate<class_2680> canFill = state -> state.method_11654(property) < max;
		UnaryOperator<class_2680> fillFunction = state -> state.method_11657(property, state.method_11654(property) + 1);

		return new StateChangingBehavior(amount, fluidTest, canFill, fillFunction);
	}
}
