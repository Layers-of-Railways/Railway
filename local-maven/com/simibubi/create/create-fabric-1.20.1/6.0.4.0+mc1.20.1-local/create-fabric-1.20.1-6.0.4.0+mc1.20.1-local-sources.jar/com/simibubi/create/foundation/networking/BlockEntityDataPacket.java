package com.simibubi.create.foundation.networking;

import com.simibubi.create.foundation.blockEntity.SyncedBlockEntity;
import net.minecraft.class_2338;
import net.minecraft.class_2540;
import net.minecraft.class_2586;
import net.minecraft.class_310;
import net.minecraft.class_638;

/**
 * A server to client version of {@link BlockEntityConfigurationPacket}
 *
 * @param <BE>
 */
public abstract class BlockEntityDataPacket<BE extends SyncedBlockEntity> extends SimplePacketBase {

	protected class_2338 pos;

	public BlockEntityDataPacket(class_2540 buffer) {
		pos = buffer.method_10811();
	}

	public BlockEntityDataPacket(class_2338 pos) {
		this.pos = pos;
	}

	@Override
	public void write(class_2540 buffer) {
		buffer.method_10807(pos);
		writeData(buffer);
	}

	@Override
	public boolean handle(Context context) {
		context.enqueueWork(() -> {
			class_638 world = class_310.method_1551().field_1687;

			if (world == null)
				return;

			class_2586 blockEntity = world.method_8321(pos);

			if (blockEntity instanceof SyncedBlockEntity) {
				handlePacket((BE) blockEntity);
			}
		});
		return true;
	}

	protected abstract void writeData(class_2540 buffer);

	protected abstract void handlePacket(BE blockEntity);
}
