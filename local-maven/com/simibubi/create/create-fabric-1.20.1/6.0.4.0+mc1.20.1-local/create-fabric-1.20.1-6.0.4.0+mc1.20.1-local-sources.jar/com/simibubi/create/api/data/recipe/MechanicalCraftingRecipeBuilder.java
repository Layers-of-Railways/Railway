package com.simibubi.create.api.data.recipe;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.function.Consumer;

import javax.annotation.Nullable;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.simibubi.create.AllRecipeTypes;

import net.createmod.catnip.platform.CatnipServices;
import net.fabricmc.fabric.api.resource.conditions.v1.ConditionJsonProvider;
import net.fabricmc.fabric.api.resource.conditions.v1.DefaultResourceConditions;
import net.minecraft.class_1792;
import net.minecraft.class_1856;
import net.minecraft.class_1865;
import net.minecraft.class_1935;
import net.minecraft.class_2444;
import net.minecraft.class_2960;
import net.minecraft.class_6862;

/**
 * The builder for building Mechanical Crafting recipes.
 * @see MechanicalCraftingRecipeGen
 */
public class MechanicalCraftingRecipeBuilder {

	private final class_1792 result;
	private final int count;
	private final List<String> pattern = Lists.newArrayList();
	private final Map<Character, class_1856> key = Maps.newLinkedHashMap();
	private boolean acceptMirrored;
	private List<ConditionJsonProvider> recipeConditions;

	public MechanicalCraftingRecipeBuilder(class_1935 result, int resultCount) {
		this.result = result.method_8389();
		count = resultCount;
		acceptMirrored = true;
		recipeConditions = new ArrayList<>();
	}

	/**
	 * Creates a new builder for a shaped recipe with the specified result with a count of 1
	 */
	public static MechanicalCraftingRecipeBuilder shapedRecipe(class_1935 result) {
		return shapedRecipe(result, 1);
	}

	/**
	 * Creates a new builder for a shaped recipe with the specified result and count.
	 */
	public static MechanicalCraftingRecipeBuilder shapedRecipe(class_1935 result, int resultCount) {
		return new MechanicalCraftingRecipeBuilder(result, resultCount);
	}

	/**
	 * Adds a new unique key to the recipe key for use in the pattern
	 */
	public MechanicalCraftingRecipeBuilder key(Character c, class_6862<class_1792> tag) {
		return this.key(c, class_1856.method_8106(tag));
	}

	/**
	 * Adds a new unique key to the recipe key for use in the pattern
	 */
	public MechanicalCraftingRecipeBuilder key(Character c, class_1935 item) {
		return this.key(c, class_1856.method_8091(item));
	}

	/**
	 * Adds a new unique key to the recipe key for use in the pattern
	 */
	public MechanicalCraftingRecipeBuilder key(Character c, class_1856 ingredient) {
		if (this.key.containsKey(c)) {
			throw new IllegalArgumentException("Symbol '" + c + "' is already defined!");
		} else if (c == ' ') {
			throw new IllegalArgumentException("Symbol ' ' (whitespace) is reserved and cannot be defined");
		} else {
			this.key.put(c, ingredient);
			return this;
		}
	}

	/**
	 * Adds a new line to the pattern for this recipe. All lines
	 * for a pattern must be the same length, pad with spaces (empty slots)
	 * if necessary.
	 */
	public MechanicalCraftingRecipeBuilder patternLine(String line) {
		if (!this.pattern.isEmpty() && line.length() != this.pattern.get(0)
			.length()) {
			throw new IllegalArgumentException("Pattern must be the same width on every line!");
		} else {
			this.pattern.add(line);
			return this;
		}
	}

	/**
	 * Prevents the crafters from matching a vertically flipped version of the recipe
	 */
	public MechanicalCraftingRecipeBuilder disallowMirrored() {
		acceptMirrored = false;
		return this;
	}

	/**
	 * Builds this recipe into a {@link class_2444}.
	 */
	public void build(Consumer<class_2444> out) {
		this.build(out, CatnipServices.REGISTRIES.getKeyOrThrow(this.result));
	}

	/**
	 * Builds this recipe into a {@link class_2444}. Use
	 * {@link #build(Consumer)} if the recipe id is the same as the result item id
	 */
	public void build(Consumer<class_2444> out, String id) {
		class_2960 resourcelocation = CatnipServices.REGISTRIES.getKeyOrThrow(this.result);
		if ((new class_2960(id)).equals(resourcelocation)) {
			throw new IllegalStateException("Shaped Recipe " + id + " should remove its 'id' argument");
		} else {
			this.build(out, new class_2960(id));
		}
	}

	/**
	 * Builds this recipe into a {@link class_2444}.
	 */
	public void build(Consumer<class_2444> out, class_2960 id) {
		validate(id);
		out
			.accept(new MechanicalCraftingRecipeBuilder.Result(id, result, count, pattern, key, acceptMirrored, recipeConditions));
	}

	/**
	 * Makes sure that this recipe is valid.
	 * @param recipeId The id of this recipe, only used for error messages.
	 */
	private void validate(class_2960 recipeId) {
		if (pattern.isEmpty()) {
			throw new IllegalStateException("No pattern is defined for shaped recipe " + recipeId + "!");
		} else {
			Set<Character> set = Sets.newHashSet(key.keySet());
			set.remove(' ');

			for (String s : pattern) {
				for (int i = 0; i < s.length(); ++i) {
					char c0 = s.charAt(i);
					if (!key.containsKey(c0) && c0 != ' ')
						throw new IllegalStateException(
							"Pattern in recipe " + recipeId + " uses undefined symbol '" + c0 + "'");
					set.remove(c0);
				}
			}

			if (!set.isEmpty())
				throw new IllegalStateException(
					"Ingredients are defined but not used in pattern for recipe " + recipeId);
		}
	}

	/**
	 * Add a new condition so this recipe is only enabled when the specified mod is loaded.
	 */
	public MechanicalCraftingRecipeBuilder whenModLoaded(String modid) {
		return withCondition(DefaultResourceConditions.allModsLoaded(modid));
	}

	/**
	 * Add a new condition so this recipe is only enabled when the specified mod is not loaded.
	 */
	public MechanicalCraftingRecipeBuilder whenModMissing(String modid) {
		return withCondition(DefaultResourceConditions.not(DefaultResourceConditions.allModsLoaded(modid)));
	}

	/**
	 * Add a new condition so this recipe is only enabled when the condition is true.
	 */
	public MechanicalCraftingRecipeBuilder withCondition(ConditionJsonProvider condition) {
		recipeConditions.add(condition);
		return this;
	}

	public class Result implements class_2444 {
		private final class_2960 id;
		private final class_1792 result;
		private final int count;
		private final List<String> pattern;
		private final Map<Character, class_1856> key;
		private final boolean acceptMirrored;
		private List<ConditionJsonProvider> recipeConditions;

		public Result(class_2960 recipeId, class_1792 result, int count, List<String> pattern,
			Map<Character, class_1856> key, boolean asymmetrical, List<ConditionJsonProvider> recipeConditions) {
			this.id = recipeId;
			this.result = result;
			this.count = count;
			this.pattern = pattern;
			this.key = key;
			this.acceptMirrored = asymmetrical;
			this.recipeConditions = recipeConditions;
		}

		public void method_10416(JsonObject o) {
			JsonArray jsonarray = new JsonArray();
			for (String s : this.pattern)
				jsonarray.add(s);

			o.add("pattern", jsonarray);
			JsonObject jsonobject = new JsonObject();
			for (Entry<Character, class_1856> entry : this.key.entrySet())
				jsonobject.add(String.valueOf(entry.getKey()), entry.getValue()
					.method_8089());

			o.add("key", jsonobject);
			JsonObject jsonobject1 = new JsonObject();
			jsonobject1.addProperty("item", CatnipServices.REGISTRIES.getKeyOrThrow(this.result)
				.toString());
			if (this.count > 1)
				jsonobject1.addProperty("count", this.count);

			o.add("result", jsonobject1);
			o.addProperty("acceptMirrored", acceptMirrored);

			if (recipeConditions.isEmpty())
				return;

			JsonArray conds = new JsonArray();
			recipeConditions.forEach(c -> conds.add(c.toJson()));
			o.add("conditions", conds);
		}

		public class_1865<?> method_17800() {
			return AllRecipeTypes.MECHANICAL_CRAFTING.getSerializer();
		}

		public class_2960 method_10417() {
			return this.id;
		}

		@Nullable
		public JsonObject method_10415() {
			return null;
		}

		@Nullable
		public class_2960 method_10418() {
			return null;
		}
	}

}
