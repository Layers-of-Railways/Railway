package com.simibubi.create.infrastructure.gametest.tests;

import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import net.minecraft.class_1299;
import net.minecraft.class_1667;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2302;
import net.minecraft.class_2338;
import net.minecraft.class_2401;
import net.minecraft.class_2453;
import net.minecraft.class_6302;
import com.simibubi.create.AllBlockEntityTypes;
import com.simibubi.create.AllBlocks;
import com.simibubi.create.AllEntityTypes;
import com.simibubi.create.content.contraptions.Contraption;
import com.simibubi.create.content.contraptions.bearing.MechanicalBearingBlockEntity;
import com.simibubi.create.content.contraptions.elevator.ElevatorPulleyBlockEntity;
import com.simibubi.create.content.kinetics.transmission.sequencer.SequencedGearshiftBlock;
import com.simibubi.create.infrastructure.gametest.CreateGameTestHelper;
import com.simibubi.create.infrastructure.gametest.GameTestGroup;

import it.unimi.dsi.fastutil.objects.Object2LongMap;
import io.github.fabricators_of_create.porting_lib.fluids.FluidStack;

@GameTestGroup(path = "contraptions")
public class TestContraptions {
	@class_6302(method_35936 = "arrow_dispenser", method_35932 = CreateGameTestHelper.TEN_SECONDS)
	public static void arrowDispenser(CreateGameTestHelper helper) {
		class_2338 lever = new class_2338(2, 3, 1);
		helper.method_36039(lever);
		class_2338 pos1 = new class_2338(0, 5, 0);
		class_2338 pos2 = new class_2338(4, 5, 4);
		helper.method_36018(() -> {
			helper.assertSecondsPassed(7);
			List<class_1667> arrows = helper.getEntitiesBetween(class_1299.field_6122, pos1, pos2);
			if (arrows.size() != 4)
				helper.method_35995("Expected 4 arrows");
			helper.powerLever(lever); // disassemble contraption
			class_2338 dispenser = new class_2338(2, 5, 2);
			// there should be 1 left over
			helper.method_35983(dispenser, class_1802.field_8107);
		});
	}

	@class_6302(method_35936 = "crop_farming", method_35932 = CreateGameTestHelper.TEN_SECONDS)
	public static void cropFarming(CreateGameTestHelper helper) {
		class_2338 lever = new class_2338(4, 3, 1);
		helper.method_36039(lever);
		class_2338 output = new class_2338(1, 3, 12);
		helper.method_36018(() -> helper.assertAnyContained(output, class_1802.field_8861, class_1802.field_8567, class_1802.field_8179));
	}

	@class_6302(method_35936 = "mounted_item_extract", method_35932 = CreateGameTestHelper.TWENTY_SECONDS)
	public static void mountedItemExtract(CreateGameTestHelper helper) {
		class_2338 barrel = new class_2338(1, 3, 2);
		Object2LongMap<class_1792> content = helper.getItemContent(barrel);
		class_2338 lever = new class_2338(1, 5, 1);
		helper.method_36039(lever);
		class_2338 outputPos = new class_2338(4, 2, 1);
		helper.method_36018(() -> {
			helper.assertContentPresent(content, outputPos); // verify all extracted
			helper.powerLever(lever);
			helper.method_36047(barrel); // verify nothing left
		});
	}

	@class_6302(method_35936 = "mounted_fluid_drain", method_35932 = CreateGameTestHelper.TEN_SECONDS)
	public static void mountedFluidDrain(CreateGameTestHelper helper) {
		class_2338 tank = new class_2338(1, 3, 2);
		FluidStack fluid = helper.getTankContents(tank);
		if (fluid.isEmpty())
			helper.method_35995("Tank empty");
		class_2338 lever = new class_2338(1, 5, 1);
		helper.method_36039(lever);
		class_2338 output = new class_2338(4, 2, 1);
		helper.method_36018(() -> {
			helper.assertFluidPresent(fluid, output); // verify all extracted
			helper.powerLever(lever); // disassemble contraption
			helper.assertTankEmpty(tank); // verify nothing left
		});
	}

	@class_6302(method_35936 = "ploughing")
	public static void ploughing(CreateGameTestHelper helper) {
		class_2338 dirt = new class_2338(4, 2, 1);
		class_2338 lever = new class_2338(3, 3, 2);
		helper.method_36039(lever);
		helper.method_36018(() -> helper.method_35972(class_2246.field_10362, dirt));
	}

	@class_6302(method_35936 = "redstone_contacts")
	public static void redstoneContacts(CreateGameTestHelper helper) {
		class_2338 end = new class_2338(5, 10, 1);
		class_2338 lever = new class_2338(1, 3, 2);
		helper.method_36039(lever);
		helper.method_36018(() -> helper.method_35972(class_2246.field_10201, end));
	}

	@class_6302(method_35936 = "controls", method_35932 = CreateGameTestHelper.TEN_SECONDS)
	public static void controls(CreateGameTestHelper helper) {
		class_2338 button = new class_2338(5, 5, 4);
		class_2338 gearshift = new class_2338(4, 5, 4);
		class_2338 bearingPos = new class_2338(4, 4, 4);
		AtomicInteger step = new AtomicInteger(1);

		List<class_2338> dirt = List.of(new class_2338(4, 2, 6), new class_2338(2, 2, 4), new class_2338(4, 2, 2));
		List<class_2338> wheat = List.of(new class_2338(4, 3, 7), new class_2338(1, 3, 4), new class_2338(4, 3, 1));

		helper.method_36026(button);
		helper.method_36018(() -> {
			// wait for gearshift to reset
			helper.method_35987(gearshift, SequencedGearshiftBlock.STATE, 0);
			if (step.get() == 4)
				return; // step 4: all done!
			MechanicalBearingBlockEntity bearing = helper.getBlockEntity(AllBlockEntityTypes.MECHANICAL_BEARING.get(), bearingPos);
			if (bearing.getMovedContraption() == null)
				helper.method_35995("Contraption not assembled");
			Contraption contraption = bearing.getMovedContraption().getContraption();
			switch (step.get()) {
				case 1 -> { // step 1: both should be active
					helper.method_35972(class_2246.field_10362, dirt.get(0));
					helper.method_35987(wheat.get(0), class_2302.field_10835, 0);
					// now disable harvester
					helper.toggleActorsOfType(contraption, AllBlocks.MECHANICAL_HARVESTER.get());
					helper.method_36026(button);
					step.incrementAndGet();
					helper.method_35995("Entering step 2");
				}
				case 2 -> { // step 2: harvester disabled
					helper.method_35972(class_2246.field_10362, dirt.get(1));
					helper.method_35987(wheat.get(1), class_2302.field_10835, 7);
					// now disable plough
					helper.toggleActorsOfType(contraption, AllBlocks.MECHANICAL_PLOUGH.get());
					helper.method_36026(button);
					step.incrementAndGet();
					helper.method_35995("Entering step 3");
				}
				case 3 -> { // step 3: both disabled
					helper.method_35972(class_2246.field_10566, dirt.get(2));
					helper.method_35987(wheat.get(2), class_2302.field_10835, 7);
					// successful!
					helper.method_36026(button);
					step.incrementAndGet();
					helper.method_35995("Entering step 4");
				}
			}
		});
	}

	@class_6302(method_35936 = "elevator")
	public static void elevator(CreateGameTestHelper helper) {
		class_2338 pulley = new class_2338(5, 12, 3);
		class_2338 secondaryPulley = new class_2338(5, 12, 1);
		class_2338 bottomLamp = new class_2338(2, 3, 2);
		class_2338 topLamp = new class_2338(2, 12, 2);
		class_2338 lever = new class_2338(1, 11, 2);
		class_2338 elevatorStart = new class_2338(4, 2, 2);
		class_2338 cowSpawn = new class_2338(4, 4, 2);
		class_2338 cowEnd = new class_2338(4, 13, 2);

		helper.method_35951(1, () -> helper.method_35964(class_1299.field_6085, cowSpawn));
		helper.method_35951(
				15, () -> helper.getBlockEntity(AllBlockEntityTypes.ELEVATOR_PULLEY.get(), pulley).clicked()
		);
		helper.method_36018(() -> {
			helper.assertSecondsPassed(1);
			if (!helper.method_35980(lever).method_11654(class_2401.field_11265)) { // step 1: check entity, lamps, and secondary, then move up
				helper.getFirstEntity(AllEntityTypes.CONTROLLED_CONTRAPTION.get(), elevatorStart); // make sure entity exists

				helper.method_35987(topLamp, class_2453.field_11413, false);
				helper.method_35987(bottomLamp, class_2453.field_11413, true);

				ElevatorPulleyBlockEntity secondary = helper.getBlockEntity(AllBlockEntityTypes.ELEVATOR_PULLEY.get(), secondaryPulley);
				if (secondary.getMirrorParent() == null)
					helper.method_35995("Secondary pulley has no parent");

				helper.method_36039(lever);
				helper.method_35995("Entering step 2");
			} else { // step 2: wait for top lamp and cow passenger
				helper.method_35987(topLamp, class_2453.field_11413, true);
				helper.method_35987(bottomLamp, class_2453.field_11413, false);
				helper.method_36023(class_1299.field_6085, cowEnd);
				// all done, disassemble
				helper.getBlockEntity(AllBlockEntityTypes.ELEVATOR_PULLEY.get(), pulley).clicked();
			}
		});
	}

	@class_6302(method_35936 = "roller_filling")
	public static void rollerFilling(CreateGameTestHelper helper) {
		class_2338 lever = new class_2338(7, 6, 1);
		class_2338 barrelEnd = new class_2338(2, 5, 2);
		List<class_2338> existing = class_2338.method_20437(new class_2338(1, 3, 2), new class_2338(4, 2, 2)).toList();
		List<class_2338> filled = class_2338.method_20437(new class_2338(1, 2, 1), new class_2338(4, 3, 3))
				.filter(pos -> !existing.contains(pos)).toList();
		List<class_2338> tracks = class_2338.method_20437(new class_2338(1, 4, 2), new class_2338(4, 4, 2)).toList();
		helper.method_36039(lever);
		helper.method_36018(() -> {
			helper.assertSecondsPassed(4);
			existing.forEach(pos -> helper.method_35972(AllBlocks.RAILWAY_CASING.get(), pos));
			filled.forEach(pos -> helper.method_35972(AllBlocks.ANDESITE_CASING.get(), pos));
			tracks.forEach(pos -> helper.method_35972(AllBlocks.TRACK.get(), pos));
			helper.method_36047(barrelEnd);
		});
	}

	@class_6302(method_35936 = "roller_paving_and_clearing", method_35932 = CreateGameTestHelper.TEN_SECONDS)
	public static void rollerPavingAndClearing(CreateGameTestHelper helper) {
		class_2338 lever = new class_2338(8, 5, 1);
		List<class_2338> paved = class_2338.method_20437(new class_2338(1, 2, 1), new class_2338(4, 2, 1)).toList();
		// block above will be cleared too, but will later be replaced by the contraption's barrel
		class_2338 cleared = new class_2338(2, 3, 1);
		helper.method_36039(lever);
		helper.method_36018(() -> {
			helper.assertSecondsPassed(9);
			paved.forEach(pos -> helper.method_35972(AllBlocks.ANDESITE_CASING.get(), pos));
			helper.method_35972(class_2246.field_10124, cleared);
		});
	}

	// FIXME: trains do not enjoy being loaded in structures
	// https://gist.github.com/TropheusJ/f2d0a7df48360d2e078d0987c115c6ef
//	@GameTest(template = "train_observer")
//	public static void trainObserver(CreateGameTestHelper helper) {
//		helper.fail("NYI");
//	}

	@class_6302(method_35936 = "dispensers_dont_fight")
	public static void dispensersDontFight(CreateGameTestHelper helper) {
		helper.method_36002(2, 3, 1);
		class_2338 bottom = new class_2338(6, 4, 1);
		class_2338 top = new class_2338(6, 6, 1);
		class_2338 dispenser = new class_2338(3, 4, 1);

		helper.method_36018(() -> {
			helper.method_44606(class_1299.field_6122, bottom, 3, 0);
			helper.method_36032(class_1299.field_6122, top);
			helper.method_35972(class_2246.field_10200, dispenser);
			helper.assertContainerContains(dispenser, new class_1799(class_1802.field_8107, 2));
		});
	}

	@class_6302(method_35936 = "dispensers_refill")
	public static void dispensersRefill(CreateGameTestHelper helper) {
		class_2338 lever = new class_2338(2, 3, 1);
		helper.method_36039(lever);
		class_2338 barrel = lever.method_10084();
		class_2338 dispenser = barrel.method_10078();

		helper.method_36018(() -> {
			helper.method_35972(class_2246.field_10200, dispenser);
			helper.assertContainerContains(dispenser, new class_1799(class_1802.field_8236, 2));
			helper.method_36047(barrel);
		});
	}

	@class_6302(method_35936 = "vaults_protect_fuel")
	public static void vaultsProtectFuel(CreateGameTestHelper helper) {
		class_2338 lever = new class_2338(2, 2, 1);
		helper.method_36039(lever);
		class_2338 barrelLamp = new class_2338(1, 3, 3);
		class_2338 vaultLamp = barrelLamp.method_10089(2);

		helper.method_35951(10, () -> helper.method_36039(lever));

		helper.method_36018(() -> {
			helper.method_35987(barrelLamp, class_2453.field_11413, false);
			helper.method_35987(vaultLamp, class_2453.field_11413, true);
		});
	}
}
