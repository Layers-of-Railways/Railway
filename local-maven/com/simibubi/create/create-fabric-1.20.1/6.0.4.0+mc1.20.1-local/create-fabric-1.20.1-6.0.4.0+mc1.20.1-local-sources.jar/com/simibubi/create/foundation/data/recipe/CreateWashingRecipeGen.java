package com.simibubi.create.foundation.data.recipe;

import static com.simibubi.create.foundation.data.recipe.CompatMetals.ALUMINUM;
import static com.simibubi.create.foundation.data.recipe.CompatMetals.LEAD;
import static com.simibubi.create.foundation.data.recipe.CompatMetals.NICKEL;
import static com.simibubi.create.foundation.data.recipe.CompatMetals.OSMIUM;
import static com.simibubi.create.foundation.data.recipe.CompatMetals.PLATINUM;
import static com.simibubi.create.foundation.data.recipe.CompatMetals.QUICKSILVER;
import static com.simibubi.create.foundation.data.recipe.CompatMetals.SILVER;
import static com.simibubi.create.foundation.data.recipe.CompatMetals.TIN;
import static com.simibubi.create.foundation.data.recipe.CompatMetals.URANIUM;

import com.simibubi.create.AllBlocks;
import com.simibubi.create.AllItems;
import com.simibubi.create.AllRecipeTypes;
import com.simibubi.create.Create;
import com.simibubi.create.api.data.recipe.WashingRecipeGen;
import com.simibubi.create.content.decoration.palettes.AllPaletteBlocks;
import com.simibubi.create.foundation.data.recipe.CreateRecipeProvider.I;
import com.tterrag.registrate.util.entry.ItemEntry;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_1856;
import net.minecraft.class_2246;
import net.minecraft.class_2960;
import net.minecraft.class_3489;
import io.github.fabricators_of_create.porting_lib.tags.Tags;

/**
 * Create's own Data Generation for Washing recipes
 *
 * @see WashingRecipeGen
 */
@SuppressWarnings("unused")
public final class CreateWashingRecipeGen extends WashingRecipeGen {

	GeneratedRecipe

		WOOL = create("wool", b -> b.require(class_3489.field_15544)
		.output(class_1802.field_19044)),

	STAINED_GLASS = create("stained_glass", b -> b.require(Tags.Items.STAINED_GLASS)
		.output(class_1802.field_8280)),
		STAINED_GLASS_PANE = create("stained_glass_pane", b -> b.require(Tags.Items.STAINED_GLASS_PANES)
			.output(class_1802.field_8141)),

	GRAVEL = create(() -> class_2246.field_10255, b -> b.output(.25f, class_1802.field_8145)
		.output(.125f, class_1802.field_8675)),
		SOUL_SAND = create(() -> class_2246.field_10114, b -> b.output(.125f, class_1802.field_8155, 4)
			.output(.02f, class_1802.field_8397)),
		RED_SAND = create(() -> class_2246.field_10534, b -> b.output(.125f, class_1802.field_8397, 3)
			.output(.05f, class_1802.field_8689)),
		SAND = create(() -> class_2246.field_10102, b -> b.output(.25f, class_1802.field_8696)),

	WEATHERED_IRON_BLOCK =
		create(AllBlocks.INDUSTRIAL_IRON_BLOCK::get, b -> b.output(AllBlocks.WEATHERED_IRON_BLOCK)),
		WEATHERED_IRON_WINDOW =
			create(AllPaletteBlocks.INDUSTRIAL_IRON_WINDOW::get, b -> b.output(AllPaletteBlocks.WEATHERED_IRON_WINDOW)),
		WEATHERED_IRON_WINDOW_PANE = create(AllPaletteBlocks.INDUSTRIAL_IRON_WINDOW_PANE::get,
			b -> b.output(AllPaletteBlocks.WEATHERED_IRON_WINDOW_PANE)),

	CRUSHED_COPPER = crushedOre(AllItems.CRUSHED_COPPER, AllItems.COPPER_NUGGET::get, () -> class_1802.field_8696, .5f),
		CRUSHED_ZINC = crushedOre(AllItems.CRUSHED_ZINC, AllItems.ZINC_NUGGET::get, () -> class_1802.field_8054, .25f),
		CRUSHED_GOLD = crushedOre(AllItems.CRUSHED_GOLD, () -> class_1802.field_8397, () -> class_1802.field_8155, .5f),
		CRUSHED_IRON = crushedOre(AllItems.CRUSHED_IRON, () -> class_1802.field_8675, () -> class_1802.field_8725, .75f),

	CRUSHED_OSMIUM = moddedCrushedOre(AllItems.CRUSHED_OSMIUM, OSMIUM),
		CRUSHED_PLATINUM = moddedCrushedOre(AllItems.CRUSHED_PLATINUM, PLATINUM),
		CRUSHED_SILVER = moddedCrushedOre(AllItems.CRUSHED_SILVER, SILVER),
		CRUSHED_TIN = moddedCrushedOre(AllItems.CRUSHED_TIN, TIN),
		CRUSHED_LEAD = moddedCrushedOre(AllItems.CRUSHED_LEAD, LEAD),
		CRUSHED_QUICKSILVER = moddedCrushedOre(AllItems.CRUSHED_QUICKSILVER, QUICKSILVER),
		CRUSHED_BAUXITE = moddedCrushedOre(AllItems.CRUSHED_BAUXITE, ALUMINUM),
		CRUSHED_URANIUM = moddedCrushedOre(AllItems.CRUSHED_URANIUM, URANIUM),
		CRUSHED_NICKEL = moddedCrushedOre(AllItems.CRUSHED_NICKEL, NICKEL),

	ICE = convert(class_2246.field_10295, class_2246.field_10225), MAGMA_BLOCK = convert(class_2246.field_10092, class_2246.field_10540),



		FLOUR = create("wheat_flour", b -> b.require(I.wheatFlour())
			.output(AllItems.DOUGH.get())),

	// Atmospheric
	ATMO_SAND = create("atmospheric/arid_sand", b -> b.require(Mods.ATM, "arid_sand")
		.output(.25f, class_1802.field_8696, 1)
		.output(0.05f, Mods.ATM, "aloe_kernels", 1)
		.whenModLoaded(Mods.ATM.getId())),

	ATMO_RED_SAND = create("atmospheric/red_arid_sand", b -> b.require(Mods.ATM, "red_arid_sand")
		.output(.125f, class_1802.field_8696, 4)
		.output(0.05f, Mods.ATM, "aloe_kernels", 1)
		.whenModLoaded(Mods.ATM.getId())),

	// Oh The Biomes You'll Go

	BYG = create("byg/cryptic_magma_block", b -> b.require(Mods.BYG, "cryptic_magma_block")
		.output(class_2246.field_10540).whenModLoaded(Mods.BYG.getId())),

	// Endergetic

	ENDER_END = simpleModded(Mods.ENDER, "end_corrock", "petrified_end_corrock"),
		ENDER_END_BLOCK = simpleModded(Mods.ENDER, "end_corrock_block", "petrified_end_corrock_block"),
		ENDER_END_CROWN = simpleModded(Mods.ENDER, "end_corrock_crown", "petrified_end_corrock_crown"),
		ENDER_NETHER = simpleModded(Mods.ENDER, "nether_corrock", "petrified_nether_corrock"),
		ENDER_NETHER_BLOCK = simpleModded(Mods.ENDER, "nether_corrock_block", "petrified_nether_corrock_block"),
		ENDER_NETHER_CROWN = simpleModded(Mods.ENDER, "nether_corrock_crown", "petrified_nether_corrock_crown"),
		ENDER_OVERWORLD = simpleModded(Mods.ENDER, "overworld_corrock", "petrified_overworld_corrock"),
		ENDER_OVERWORLD_BLOCK = simpleModded(Mods.ENDER, "overworld_corrock_block", "petrified_overworld_corrock_block"),
		ENDER_OVERWORLD_CROWN = simpleModded(Mods.ENDER, "overworld_corrock_crown", "petrified_overworld_corrock_crown"),

	// Quark
	Q = simpleModded(Mods.Q, "iron_plate", "rusty_iron_plate"),

	// Supplementaries
	SUP = simpleModded(Mods.SUP, "blackboard", "blackboard"),

	//Vault Hunters
	VH = simpleModded(Mods.VH, "ornate_chain", "ornate_chain_rusty");


	public CreateWashingRecipeGen(FabricDataOutput output) {
		super(output, Create.ID);
	}

	public GeneratedRecipe moddedCrushedOre(ItemEntry<? extends class_1792> crushed, CompatMetals metal) {
		for (Mods mod : metal.getMods()) {
			String metalName = metal.getName(mod);
			class_2960 nugget = mod.nuggetOf(metalName);
			create(mod.getId() + "/" + crushed.getId()
					.method_12832(),
				b -> b.withItemIngredients(class_1856.method_8091(crushed::get))
					.output(1, nugget, 9)
					.whenModLoaded(mod.getId()));
		}
		return null;
	}

	public GeneratedRecipe simpleModded(Mods mod, String input, String output) {
		return create(mod.getId() + "/" + output, b -> b.require(mod, input)
			.output(mod, output).whenModLoaded(mod.getId()));
	}

	@Override
	protected AllRecipeTypes getRecipeType() {
		return AllRecipeTypes.SPLASHING;
	}

}
