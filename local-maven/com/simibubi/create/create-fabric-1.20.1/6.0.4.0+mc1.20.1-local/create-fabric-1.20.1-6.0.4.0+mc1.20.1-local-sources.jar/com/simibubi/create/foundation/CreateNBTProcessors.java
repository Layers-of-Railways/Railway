package com.simibubi.create.foundation;

import java.util.List;

import com.simibubi.create.AllBlockEntityTypes;

import net.createmod.catnip.nbt.NBTHelper;
import net.createmod.catnip.nbt.NBTProcessors;
import net.minecraft.class_1802;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2520;
import net.minecraft.class_2591;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class CreateNBTProcessors {
	public static void register() {

		NBTProcessors.addProcessor(class_2591.field_11911, data -> {
			for (int i = 0; i < 4; ++i) {
				if (NBTProcessors.textComponentHasClickEvent(data.method_10558("Text" + (i + 1))))
					return null;
			}
			return data;
		});

		NBTProcessors.addProcessor(class_2591.field_16412, data -> {
			if (!data.method_10573("Book", class_2520.field_33260))
				return data;
			class_2487 book = data.method_10562("Book");

			// Writable books can't have click events, so they're safe to keep
			class_2960 writableBookResource = class_7923.field_41178.method_10221(class_1802.field_8674);
			if (book.method_10558("id").equals(writableBookResource.toString()))
				return data;

			if (!book.method_10573("tag", class_2520.field_33260))
				return data;
			class_2487 tag = book.method_10562("tag");

			if (!tag.method_10573("pages", class_2520.field_33259))
				return data;
			class_2499 pages = tag.method_10554("pages", class_2520.field_33258);

			for (class_2520 inbt : pages) {
				if (NBTProcessors.textComponentHasClickEvent(inbt.method_10714()))
					return null;
			}
			return data;
		});

		NBTProcessors.addProcessor(AllBlockEntityTypes.CLIPBOARD.get(), CreateNBTProcessors::clipboardProcessor);

		NBTProcessors.addProcessor(AllBlockEntityTypes.CREATIVE_CRATE.get(), NBTProcessors.itemProcessor("Filter"));
		NBTProcessors.addProcessor(AllBlockEntityTypes.PLACARD.get(), NBTProcessors.itemProcessor("Item"));
	}

	public static class_2487 clipboardProcessor(class_2487 data) {
		if (!data.method_10573("Item", class_2520.field_33260))
			return data;
		class_2487 book = data.method_10562("Item");

		if (!book.method_10573("tag", class_2520.field_33260))
			return data;
		class_2487 itemData = book.method_10562("tag");

		for (List<String> entries : NBTHelper.readCompoundList(itemData.method_10554("Pages", class_2520.field_33260),
			pageTag -> NBTHelper.readCompoundList(pageTag.method_10554("Entries", class_2520.field_33260),
				tag -> tag.method_10558("Text")))) {
			for (String entry : entries)
				if (NBTProcessors.textComponentHasClickEvent(entry))
					return null;
		}
		return data;
	}
}
