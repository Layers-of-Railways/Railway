package com.simibubi.create.foundation.item;

import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.stream.Stream;

import com.simibubi.create.foundation.blockEntity.behaviour.filtering.FilteringBehaviour;

import net.createmod.catnip.data.LongAttached;
import net.fabricmc.fabric.api.transfer.v1.item.ItemVariant;
import net.fabricmc.fabric.api.transfer.v1.storage.Storage;
import net.fabricmc.fabric.api.transfer.v1.storage.StorageView;
import net.fabricmc.fabric.api.transfer.v1.transaction.Transaction;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_5250;
import io.github.fabricators_of_create.porting_lib.transfer.TransferUtil;
import io.github.fabricators_of_create.porting_lib.transfer.item.ItemHandlerHelper;

public class CountedItemStackList {

	Map<class_1792, Set<ItemStackEntry>> items = new HashMap<>();

	public CountedItemStackList(Storage<ItemVariant> inventory, FilteringBehaviour filteringBehaviour) {
		try (Transaction t = TransferUtil.getTransaction()) {
			for (StorageView<ItemVariant> view : inventory.nonEmptyViews()) {
				ItemVariant resource = view.getResource();
				class_1799 stack = resource.toStack();
				if (!filteringBehaviour.test(stack))
					continue;

				long amount = view.getAmount();
				add(stack, amount);
				// fabric: extract to avoid counting multiple times
				view.extract(resource, amount, t);
			}
		}
	}

	public Stream<LongAttached<class_5250>> getTopNames(int limit) {
		return items.values()
			.stream()
			.flatMap(Collection::stream)
			.sorted(LongAttached.comparator())
			.limit(limit)
			.map(entry -> LongAttached.with(entry.count(), entry.stack()
				.method_7964()
				.method_27661()));
	}

	// fabric: use add(stack, long) when longs are involved
	public void add(class_1799 stack) {
		add(stack, stack.method_7947());
	}

	public void add(class_1799 stack, long amount) {
		if (stack.method_7960())
			return;

		Set<ItemStackEntry> stackSet = getOrCreateItemSet(stack);
		for (ItemStackEntry entry : stackSet) {
			if (!entry.matches(stack))
				continue;
			entry.grow(amount);
			return;
		}
		stackSet.add(new ItemStackEntry(stack, amount));
	}

	private Set<ItemStackEntry> getOrCreateItemSet(class_1799 stack) {
		if (!items.containsKey(stack.method_7909()))
			items.put(stack.method_7909(), new HashSet<>());
		return getItemSet(stack);
	}

	private Set<ItemStackEntry> getItemSet(class_1799 stack) {
		return items.get(stack.method_7909());
	}

	public static class ItemStackEntry extends LongAttached<class_1799> {

		public ItemStackEntry(class_1799 stack) {
			this(stack, stack.method_7947());
		}

		public ItemStackEntry(class_1799 stack, long amount) {
			super(amount, stack);
		}

		public boolean matches(class_1799 other) {
			return ItemHandlerHelper.canItemStacksStack(other, stack());
		}

		public class_1799 stack() {
			return getSecond();
		}

		public void grow(long amount) {
			setFirst(getFirst() + amount);
		}

		public long count() {
			return getFirst();
		}

	}

}
