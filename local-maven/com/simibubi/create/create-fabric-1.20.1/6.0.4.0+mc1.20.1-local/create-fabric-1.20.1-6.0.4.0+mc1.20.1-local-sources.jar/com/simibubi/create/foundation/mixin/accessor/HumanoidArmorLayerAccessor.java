package com.simibubi.create.foundation.mixin.accessor;

import java.util.Map;
import net.minecraft.class_1304;
import net.minecraft.class_2960;
import net.minecraft.class_572;
import net.minecraft.class_970;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_970.class)
public interface HumanoidArmorLayerAccessor {
	@Accessor("ARMOR_LOCATION_CACHE")
	static Map<String, class_2960> create$getArmorLocationCache() {
		throw new RuntimeException();
	}

	@Accessor("innerModel")
	class_572<?> create$getInnerModel();

	@Accessor("outerModel")
	class_572<?> create$getOuterModel();

	@Invoker("setPartVisibility")
	void create$callSetPartVisibility(class_572<?> model, class_1304 slot);
}
