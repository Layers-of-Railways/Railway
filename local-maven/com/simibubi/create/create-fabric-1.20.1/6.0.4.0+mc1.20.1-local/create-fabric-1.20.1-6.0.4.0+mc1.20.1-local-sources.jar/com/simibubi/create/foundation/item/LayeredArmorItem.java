package com.simibubi.create.foundation.item;

import java.util.Map;
import com.simibubi.create.foundation.mixin.accessor.HumanoidArmorLayerAccessor;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1738;
import net.minecraft.class_1799;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_3879;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_572;
import net.minecraft.class_970;

public interface LayeredArmorItem extends CustomRenderedArmorItem {
	@Environment(EnvType.CLIENT)
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	default void renderArmorPiece(class_970<?, ?, ?> layer, class_4587 poseStack,
			class_4597 bufferSource, class_1309 entity, class_1304 slot, int light,
			class_572<?> originalModel, class_1799 stack) {
		if (!(stack.method_7909() instanceof class_1738 item)) {
			return;
		}
		if (class_1309.method_32326(stack) != slot) {
			return;
		}

		HumanoidArmorLayerAccessor accessor = (HumanoidArmorLayerAccessor) layer;
		Map<String, class_2960> locationCache = HumanoidArmorLayerAccessor.create$getArmorLocationCache();
		boolean glint = stack.method_7958();

		class_572<?> innerModel = accessor.create$getInnerModel();
		layer.method_17165().method_2818((class_572) innerModel);
		accessor.create$callSetPartVisibility(innerModel, slot);
		String locationStr2 = getArmorTextureLocation(entity, slot, stack, 2);
		class_2960 location2 = locationCache.computeIfAbsent(locationStr2, class_2960::new);
		renderModel(poseStack, bufferSource, light, item, innerModel, glint, 1.0F, 1.0F, 1.0F, location2);

		class_572<?> outerModel = accessor.create$getOuterModel();
		layer.method_17165().method_2818((class_572) outerModel);
		accessor.create$callSetPartVisibility(outerModel, slot);
		String locationStr1 = getArmorTextureLocation(entity, slot, stack, 1);
		class_2960 location1 = locationCache.computeIfAbsent(locationStr1, class_2960::new);
		renderModel(poseStack, bufferSource, light, item, outerModel, glint, 1.0F, 1.0F, 1.0F, location1);
	}

	// from HumanoidArmorLayer.renderModel
	private void renderModel(class_4587 poseStack, class_4597 bufferSource, int light, class_1738 item,
		class_3879 model, boolean glint, float red, float green, float blue, class_2960 armorResource) {
		class_4588 vertexconsumer = bufferSource.getBuffer(class_1921.method_25448(armorResource));
		model.method_2828(poseStack, vertexconsumer, light, class_4608.field_21444, red, green, blue, 1.0F);
	}

	String getArmorTextureLocation(class_1309 entity, class_1304 slot, class_1799 stack, int layer);
}
