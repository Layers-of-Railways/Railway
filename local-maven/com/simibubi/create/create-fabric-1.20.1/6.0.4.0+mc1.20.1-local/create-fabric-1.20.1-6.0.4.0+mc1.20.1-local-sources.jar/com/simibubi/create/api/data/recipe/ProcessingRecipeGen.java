package com.simibubi.create.api.data.recipe;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;
import java.util.function.UnaryOperator;

import org.jetbrains.annotations.NotNull;

import com.simibubi.create.content.processing.recipe.ProcessingRecipe;
import com.simibubi.create.content.processing.recipe.ProcessingRecipeBuilder;
import com.simibubi.create.content.processing.recipe.ProcessingRecipeSerializer;
import com.simibubi.create.foundation.recipe.IRecipeTypeInfo;

import net.createmod.catnip.platform.CatnipServices;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidConstants;
import net.minecraft.class_1856;
import net.minecraft.class_1935;
import net.minecraft.class_2960;
import net.minecraft.class_7784;

/**
 * A base class for all processing recipes, containing helper methods
 * for datagenning processing recipes. Addons should extend this for
 * custom processing recipe types, and return that recipe type in {@link #getRecipeType()}.
 */
public abstract class ProcessingRecipeGen extends BaseRecipeProvider {
	protected static final List<ProcessingRecipeGen> GENERATORS = new ArrayList<>();
	protected static final long BUCKET = FluidConstants.BUCKET;
	protected static final long BOTTLE = FluidConstants.BOTTLE;

	public ProcessingRecipeGen(class_7784 generator, String defaultNamespace) {
		super(generator, defaultNamespace);
	}

	/**
	 * Create a processing recipe with a single itemstack ingredient, using its id
	 * as the name of the recipe
	 */
	protected <T extends ProcessingRecipe<?>> GeneratedRecipe create(String namespace,
																								Supplier<class_1935> singleIngredient, UnaryOperator<ProcessingRecipeBuilder<T>> transform) {
		ProcessingRecipeSerializer<T> serializer = getSerializer();
		GeneratedRecipe generatedRecipe = c -> {
			class_1935 itemLike = singleIngredient.get();
			transform
				.apply(new ProcessingRecipeBuilder<>(serializer.getFactory(),
					new class_2960(namespace, CatnipServices.REGISTRIES.getKeyOrThrow(itemLike.method_8389())
						.method_12832())).withItemIngredients(class_1856.method_8091(itemLike)))
				.build(c);
		};
		all.add(generatedRecipe);
		return generatedRecipe;
	}

	/**
	 * Create a new processing recipe, with supplied name and recipe definitions
	 * provided by the function
	 */
	protected <T extends ProcessingRecipe<?>> GeneratedRecipe createWithDeferredId(Supplier<class_2960> name,
																											  UnaryOperator<ProcessingRecipeBuilder<T>> transform) {
		ProcessingRecipeSerializer<T> serializer = getSerializer();
		GeneratedRecipe generatedRecipe =
			c -> transform.apply(new ProcessingRecipeBuilder<>(serializer.getFactory(), name.get()))
				.build(c);
		all.add(generatedRecipe);
		return generatedRecipe;
	}

	/**
	 * Create a new processing recipe, with recipe definitions provided by the
	 * function
	 */
	protected <T extends ProcessingRecipe<?>> GeneratedRecipe create(class_2960 name,
																								UnaryOperator<ProcessingRecipeBuilder<T>> transform) {
		return createWithDeferredId(() -> name, transform);
	}

	/**
	 * Gets this recipe generators generated recipe type.
	 * Subclasses should override this to return an instance of IRecipeTypeInfo
	 * Create uses an enum, however this is not in any way required for addons.
	 */
	protected abstract IRecipeTypeInfo getRecipeType();

	protected <T extends ProcessingRecipe<?>> ProcessingRecipeSerializer<T> getSerializer() {
		return getRecipeType().getSerializer();
	}

	protected Supplier<class_2960> idWithSuffix(Supplier<class_1935> item, String suffix) {
		return () -> {
			class_2960 registryName = CatnipServices.REGISTRIES.getKeyOrThrow(item.get()
					.method_8389());
			return asResource(registryName.method_12832() + suffix);
		};
	}

	/**
	 * Create a new processing recipe, with recipe definitions provided by the
	 * function, under the default namespace
	 */
	protected <T extends ProcessingRecipe<?>> GeneratedRecipe create(String name, UnaryOperator<ProcessingRecipeBuilder<T>> transform) {
		return create(asResource(name), transform);
	}

	/**
	 * Create a processing recipe with a single itemstack ingredient, using its id
	 * as the name of the recipe, under the default namespace
	 */
	protected <T extends ProcessingRecipe<?>> GeneratedRecipe create(Supplier<class_1935> singleIngredient, UnaryOperator<ProcessingRecipeBuilder<T>> transform) {
		return create(modid, singleIngredient, transform);
	}


	/**
	 * Gets a display name for this recipe generator.
	 * It is recommended to override this for a prettier name, however that is not
	 * required.
	 */
	@NotNull
	@Override
	public String method_10321() {
		return modid + "'s processing recipes: " + getRecipeType().getId()
			.method_12832();
	}

}
