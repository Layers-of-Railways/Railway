package com.simibubi.create.foundation.block;

import com.simibubi.create.foundation.utility.RaycastHelper;
import com.simibubi.create.foundation.utility.fabric.ReachUtil;

import net.createmod.catnip.animation.AnimationTickHolder;
import net.createmod.catnip.math.VecHelper;
import net.minecraft.class_1657;
import net.minecraft.class_2338;
import net.minecraft.class_2338.class_2339;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3965;
import net.minecraft.class_746;


/**
 * For mods wanting to use this take a look at {@link IHaveBigOutline}
 */
public class BigOutlines {
	static class_3965 result = null;

	public static void pick() {
		class_310 mc = class_310.method_1551();
		if (!(mc.field_1719 instanceof class_746 player))
			return;
		if (mc.field_1687 == null)
			return;

		result = null;

		class_243 origin = player.method_5836(AnimationTickHolder.getPartialTicks(mc.field_1687));

		double maxRange = mc.field_1765 == null ? Double.MAX_VALUE
			: mc.field_1765.method_17784()
				.method_1025(origin) + 0.5;

		double range = ReachUtil.reach(player);
		class_243 target = RaycastHelper.getTraceTarget(player, Math.min(maxRange, range) + 1, origin);

		RaycastHelper.rayTraceUntil(origin, target, pos -> {
			class_2339 p = class_2338.field_10980.method_25503();

			for (int x = -1; x <= 1; x++) {
				for (int y = -1; y <= 1; y++) {
					for (int z = -1; z <= 1; z++) {
						p.method_10103(pos.method_10263() + x, pos.method_10264() + y, pos.method_10260() + z);
						class_2680 blockState = mc.field_1687.method_8320(p);

						if (!(blockState.method_26204() instanceof IHaveBigOutline))
							continue;

						class_3965 hit = blockState.method_26224(mc.field_1687, p)
								.method_1092(origin, target, p.method_10062());
						if (hit == null)
							continue;

						if (result != null && class_243.method_24953(p)
								.method_1025(origin) >= class_243.method_24953(result.method_17777())
								.method_1025(origin))
							continue;

						class_243 vec = hit.method_17784();
						double interactionDist = vec.method_1025(origin);
						if (interactionDist >= maxRange)
							continue;

						class_2338 hitPos = hit.method_17777();

						// pacifies ServerGamePacketListenerImpl.handleUseItemOn
						vec = vec.method_1020(class_243.method_24953(hitPos));
						vec = VecHelper.clampComponentWise(vec, 1);
						vec = vec.method_1019(class_243.method_24953(hitPos));

						result = new class_3965(vec, hit.method_17780(), hitPos, hit.method_17781());
					}
				}
			}

			return result != null;
		});

		if (result != null)
			mc.field_1765 = result;
	}

	static boolean isValidPos(class_1657 player, class_2338 pos) {
		// verify that the server will accept the fake result
		double x = player.method_23317() - (pos.method_10263() + .5);
		double y = player.method_23318() - (pos.method_10264() + .5) + 1.5;
		double z = player.method_23321() - (pos.method_10260() + .5);
		double distSqr = x * x + y * y + z * z;
		double maxDist = ReachUtil.reach(player) + 1;
		maxDist *= maxDist;
		return distSqr <= maxDist;
	}

}
