package com.simibubi.create.foundation.events;

import com.simibubi.create.AllBlocks;
import com.simibubi.create.AllTags.AllItemTags;
import com.simibubi.create.CreateClient;
import com.simibubi.create.content.contraptions.elevator.ElevatorControlsHandler;
import com.simibubi.create.content.contraptions.wrench.RadialWrenchHandler;
import com.simibubi.create.content.equipment.toolbox.ToolboxHandlerClient;
import com.simibubi.create.content.kinetics.chainConveyor.ChainConveyorConnectionHandler;
import com.simibubi.create.content.kinetics.chainConveyor.ChainConveyorInteractionHandler;
import com.simibubi.create.content.kinetics.chainConveyor.ChainPackageInteractionHandler;
import com.simibubi.create.content.logistics.factoryBoard.FactoryPanelConnectionHandler;
import com.simibubi.create.content.logistics.packagePort.PackagePortTargetSelectionHandler;
import com.simibubi.create.content.redstone.link.controller.LinkedControllerClientHandler;
import com.simibubi.create.content.trains.TrainHUD;
import com.simibubi.create.content.trains.entity.TrainRelocator;
import com.simibubi.create.content.trains.track.CurvedTrackInteraction;
import io.github.fabricators_of_create.porting_lib.event.client.InteractEvents;
import io.github.fabricators_of_create.porting_lib.event.client.KeyInputCallback;
import io.github.fabricators_of_create.porting_lib.event.client.MouseInputEvents;
import io.github.fabricators_of_create.porting_lib.event.client.MouseInputEvents.Action;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_239;
import net.minecraft.class_310;

public class InputEvents {

	public static void onKeyInput(int key, int scancode, int action, int mods) {
		if (class_310.method_1551().field_1755 != null)
			return;

		boolean pressed = !(action == 0);

		CreateClient.SCHEMATIC_HANDLER.onKeyInput(key, pressed);
		ToolboxHandlerClient.onKeyInput(key, pressed);
		RadialWrenchHandler.onKeyInput(key, pressed);
	}

	public static boolean onMouseScrolled(double deltaX, double delta /* Y */) {
		if (class_310.method_1551().field_1755 != null)
			return false;

//		CollisionDebugger.onScroll(delta);
		boolean cancelled = CreateClient.SCHEMATIC_HANDLER.mouseScrolled(delta)
			|| CreateClient.SCHEMATIC_AND_QUILL_HANDLER.mouseScrolled(delta) || TrainHUD.onScroll(delta)
			|| ElevatorControlsHandler.onScroll(delta);
		return cancelled;
	}

	public static boolean onMouseInput(int button, int modifiers, Action action) {
		if (class_310.method_1551().field_1755 != null)
			return false;

		boolean pressed = action == Action.PRESS;

		RadialWrenchHandler.onKeyInput(button, pressed);
		if (CreateClient.SCHEMATIC_HANDLER.onMouseInput(button, pressed))
			return true;
		else if (CreateClient.SCHEMATIC_AND_QUILL_HANDLER.onMouseInput(button, pressed))
			return true;
		return false;
	}

	// fabric: onClickInput split up
	public static class_1269 onUse(class_310 mc, class_239 hit, class_1268 hand) {
		if (mc.field_1755 != null)
			return class_1269.field_5811;

		if (CurvedTrackInteraction.onClickInput(true, false)) {
			return class_1269.field_5812;
		}

		if (CreateClient.GLUE_HANDLER.onMouseInput(false))
			return class_1269.field_5812;

		if (FactoryPanelConnectionHandler.onRightClick() || ChainConveyorConnectionHandler.onRightClick()) {
			return class_1269.field_5812;
		}

		LinkedControllerClientHandler.deactivateInLectern();
		boolean cancel = TrainRelocator.onClicked();

		if (ChainConveyorInteractionHandler.onUse() || PackagePortTargetSelectionHandler.onUse()) {
			return class_1269.field_5812;
		}

		if (mc.field_1724 != null) {
			class_1799 itemInHand = mc.field_1724.method_5998(hand);
			if (!AllItemTags.WRENCH.matches(itemInHand)
				&& !itemInHand.method_31574(class_1802.field_23983)
				&& !AllBlocks.PACKAGE_FROGPORT.isIn(itemInHand)
				&& ChainPackageInteractionHandler.onUse()) {
				return class_1269.field_5812;
			}
		}

		return cancel ? class_1269.field_5812 : class_1269.field_5811;
	}

	public static class_1269 onAttack(class_310 mc, class_239 hit) {
		if (mc.field_1755 != null)
			return class_1269.field_5811;

		if (CurvedTrackInteraction.onClickInput(false, true)) {
			return class_1269.field_5812;
		}

		return CreateClient.GLUE_HANDLER.onMouseInput(true)
				? class_1269.field_5812
				: class_1269.field_5811;
	}

	public static boolean onPick(class_310 mc, class_239 hit) {
		if (mc.field_1755 != null)
			return false;

		return ToolboxHandlerClient.onPickItem();
	}

	public static void register() {
		KeyInputCallback.EVENT.register(InputEvents::onKeyInput);
		MouseInputEvents.BEFORE_SCROLL.register(InputEvents::onMouseScrolled);
		MouseInputEvents.BEFORE_BUTTON.register(InputEvents::onMouseInput);
		InteractEvents.USE.register(InputEvents::onUse);
		InteractEvents.ATTACK.register(InputEvents::onAttack);
		InteractEvents.PICK.register(InputEvents::onPick);
	}

}
