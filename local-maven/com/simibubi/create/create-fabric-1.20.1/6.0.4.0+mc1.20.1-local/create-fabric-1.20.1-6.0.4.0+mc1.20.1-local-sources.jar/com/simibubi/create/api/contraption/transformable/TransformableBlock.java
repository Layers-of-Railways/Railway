package com.simibubi.create.api.contraption.transformable;

import com.simibubi.create.content.contraptions.StructureTransform;
import net.minecraft.class_2680;

@FunctionalInterface
public interface TransformableBlock {
	class_2680 transform(class_2680 state, StructureTransform transform);
}
