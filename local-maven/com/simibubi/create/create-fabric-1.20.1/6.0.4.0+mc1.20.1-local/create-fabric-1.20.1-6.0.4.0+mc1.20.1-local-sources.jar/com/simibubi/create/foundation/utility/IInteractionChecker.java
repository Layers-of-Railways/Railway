package com.simibubi.create.foundation.utility;

import net.minecraft.class_1657;

public interface IInteractionChecker {
	boolean canPlayerUse(class_1657 player);
}
