package com.simibubi.create.foundation.mixin.fabric;

import java.util.List;

import javax.annotation.Nullable;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import com.google.common.collect.ImmutableList;
import com.simibubi.create.content.contraptions.minecart.capability.CapabilityMinecartController;

import net.createmod.ponder.api.level.PonderLevel;
import net.minecraft.class_1297;
import net.minecraft.class_1297.class_5529;
import net.minecraft.class_1688;
import net.minecraft.class_1937;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_265;
import net.minecraft.class_2784;
import io.github.fabricators_of_create.porting_lib.mixin.accessors.common.accessor.EntityAccessor;

@Mixin(class_1297.class)
public abstract class EntityMixin {
	@Shadow
	public abstract class_1937 level();

	// AbstractMinecart does not override remove, so we have to inject here.
	@Inject(method = "remove", at = @At("HEAD"))
	private void removeMinecartController(class_5529 reason, CallbackInfo ci) {
		//noinspection ConstantValue
		if ((Object) this instanceof class_1688 cart) {
			CapabilityMinecartController.onCartRemoved(level(), cart);
		}
	}

	/**
	 * @author AeiouEnigma
	 * @reason We stan Lithium's collision optimizations but need to ensure they aren't applied in Create's PonderWorld.
	 */
	@Inject(method = "collideBoundingBox", at = @At("HEAD"), cancellable = true)
	private static void create$stopLithiumCollisionChangesInPonderWorld(@Nullable class_1297 entity, class_243 movement, class_238 entityBoundingBox, class_1937 world, List<class_265> shapes, CallbackInfoReturnable<class_243> ci) {
		if (world instanceof PonderLevel) {
			// Vanilla copy
			ImmutableList.Builder<class_265> builder = ImmutableList.builderWithExpectedSize(shapes.size() + 1);
			if (!shapes.isEmpty()) {
				builder.addAll(shapes);
			}

			class_2784 worldBorder = world.method_8621();
			boolean bl = entity != null && worldBorder.method_39459(entity, entityBoundingBox.method_18804(movement));
			if (bl) {
				builder.add(worldBorder.method_17903());
			}

			builder.addAll(world.method_20812(entity, entityBoundingBox.method_18804(movement)));
			// Prevent Lithium's changes from executing for PonderWorlds
			ci.setReturnValue(EntityAccessor.port_lib$collideWithShapes(movement, entityBoundingBox, builder.build()));

		}
	}
}
