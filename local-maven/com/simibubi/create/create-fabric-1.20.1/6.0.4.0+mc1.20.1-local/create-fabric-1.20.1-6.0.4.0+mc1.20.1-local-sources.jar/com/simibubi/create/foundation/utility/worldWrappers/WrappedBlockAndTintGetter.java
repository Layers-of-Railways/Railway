package com.simibubi.create.foundation.utility.worldWrappers;

import net.minecraft.class_1920;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_3568;
import net.minecraft.class_3610;
import net.minecraft.class_6539;

public class WrappedBlockAndTintGetter implements class_1920 {
	protected final class_1920 wrapped;

	public WrappedBlockAndTintGetter(class_1920 wrapped) {
		this.wrapped = wrapped;
	}

	@Override
	public class_2586 method_8321(class_2338 pos) {
		return wrapped.method_8321(pos);
	}

	@Override
	public class_2680 method_8320(class_2338 pos) {
		return wrapped.method_8320(pos);
	}

	@Override
	public class_3610 method_8316(class_2338 pos) {
		return wrapped.method_8316(pos);
	}

	@Override
	public int method_31605() {
		return wrapped.method_31605();
	}

	@Override
	public int method_31607() {
		return wrapped.method_31607();
	}

	@Override
	public float method_24852(class_2350 pDirection, boolean pShade) {
		return wrapped.method_24852(pDirection, pShade);
	}

	@Override
	public class_3568 method_22336() {
		return wrapped.method_22336();
	}

	@Override
	public int method_23752(class_2338 pBlockPos, class_6539 pColorResolver) {
		return wrapped.method_23752(pBlockPos, pColorResolver);
	}
}
