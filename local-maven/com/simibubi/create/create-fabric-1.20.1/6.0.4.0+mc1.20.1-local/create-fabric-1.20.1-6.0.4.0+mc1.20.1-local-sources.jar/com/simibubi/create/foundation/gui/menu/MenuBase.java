package com.simibubi.create.foundation.gui.menu;

import com.simibubi.create.foundation.utility.IInteractionChecker;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_2540;
import net.minecraft.class_3917;

public abstract class MenuBase<T> extends class_1703 {

	public class_1657 player;
	public class_1661 playerInventory;
	public T contentHolder;

	protected MenuBase(class_3917<?> type, int id, class_1661 inv, class_2540 extraData) {
		super(type, id);
		init(inv, createOnClient(extraData));
	}

	protected MenuBase(class_3917<?> type, int id, class_1661 inv, T contentHolder) {
		super(type, id);
		init(inv, contentHolder);
	}

	protected void init(class_1661 inv, T contentHolderIn) {
		player = inv.field_7546;
		playerInventory = inv;
		contentHolder = contentHolderIn;
		initAndReadInventory(contentHolder);
		addSlots();
		method_7623();
	}

	@Environment(EnvType.CLIENT)
	protected abstract T createOnClient(class_2540 extraData);

	protected abstract void initAndReadInventory(T contentHolder);

	protected abstract void addSlots();

	protected abstract void saveData(T contentHolder);

	protected void addPlayerSlots(int x, int y) {
		for (int hotbarSlot = 0; hotbarSlot < 9; ++hotbarSlot)
			this.method_7621(new class_1735(playerInventory, hotbarSlot, x + hotbarSlot * 18, y + 58));
		for (int row = 0; row < 3; ++row)
			for (int col = 0; col < 9; ++col)
				this.method_7621(new class_1735(playerInventory, col + row * 9 + 9, x + col * 18, y + row * 18));
	}

	@Override
	public void method_7595(class_1657 playerIn) {
		super.method_7595(playerIn);
		saveData(contentHolder);
	}

	@Override
	public boolean method_7597(class_1657 player) {
		if (contentHolder == null)
			return false;
		if (contentHolder instanceof IInteractionChecker)
			return ((IInteractionChecker) contentHolder).canPlayerUse(player);
		return true;
	}

}
