package com.simibubi.create.api.data.recipe;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;
import net.minecraft.class_1802;
import net.minecraft.class_1935;
import net.minecraft.class_3489;
import net.minecraft.class_5955.class_5811;
import net.minecraft.class_7784;
import com.simibubi.create.AllRecipeTypes;
import com.simibubi.create.api.data.recipe.BaseRecipeProvider.GeneratedRecipe;
import com.simibubi.create.foundation.block.CopperBlockSet;
import com.simibubi.create.foundation.block.CopperBlockSet.Variant;

/**
 * The base class for Deploying recipe generation.
 * Addons should extend this and use the {@link ProcessingRecipeGen#create} methods
 * or the helper methods contained in this class to make recipes.
 * For an example of how you might do this, see Create's implementation: {@link com.simibubi.create.foundation.data.recipe.CreateDeployingRecipeGen}.
 * Needs to be added to a registered recipe provider to do anything, see {@link com.simibubi.create.foundation.data.recipe.CreateRecipeProvider}
 */
public abstract class DeployingRecipeGen extends ProcessingRecipeGen {

	public GeneratedRecipe copperChain(CopperBlockSet set) {
		for (Variant<?> variant : set.getVariants()) {
			List<Supplier<class_1935>> chain = new ArrayList<>(4);

			for (class_5811 state : class_5811.values()) {
				addWax(set.get(variant, state, true)::get, set.get(variant, state, false)::get);
				chain.add(set.get(variant, state, false)::get);
			}

			oxidizationChain(chain);
		}
		return null;
	}

	public GeneratedRecipe addWax(Supplier<class_1935> waxed, Supplier<class_1935> nonWaxed) {
		createWithDeferredId(idWithSuffix(nonWaxed, "_from_removing_wax"), b -> b.require(waxed.get())
			.require(class_3489.field_42612)
			.toolNotConsumed()
			.output(nonWaxed.get()));

		return createWithDeferredId(idWithSuffix(waxed, "_from_adding_wax"), b -> b.require(nonWaxed.get())
			.require(class_1802.field_21087)
			.toolNotConsumed()
			.output(waxed.get()));
	}

	public GeneratedRecipe oxidizationChain(List<Supplier<class_1935>> chain) {
		for (int i = 0; i < chain.size() - 1; i++) {
			Supplier<class_1935> to = chain.get(i);
			Supplier<class_1935> from = chain.get(i + 1);
			createWithDeferredId(idWithSuffix(to, "_from_deoxidising"), b -> b.require(from.get())
				.require(class_3489.field_42612)
				.toolNotConsumed()
				.output(to.get()));
		}
		return null;
	}

	public DeployingRecipeGen(class_7784 output, String defaultNamespace) {
		super(output, defaultNamespace);
	}

	@Override
	protected AllRecipeTypes getRecipeType() {
		return AllRecipeTypes.DEPLOYING;
	}

}
