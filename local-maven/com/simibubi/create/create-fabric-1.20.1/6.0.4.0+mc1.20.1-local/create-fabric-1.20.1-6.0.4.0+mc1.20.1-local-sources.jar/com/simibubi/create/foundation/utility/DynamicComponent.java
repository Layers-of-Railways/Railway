package com.simibubi.create.foundation.utility;

import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;
import com.google.gson.JsonParser;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.simibubi.create.Create;
import net.minecraft.class_1937;
import net.minecraft.class_2165;
import net.minecraft.class_2168;
import net.minecraft.class_2338;
import net.minecraft.class_241;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2564;
import net.minecraft.class_3218;
import net.minecraft.class_5250;

public class DynamicComponent {

	private JsonElement rawCustomText;
	private class_2561 parsedCustomText;

	public DynamicComponent() {}

	public void displayCustomText(class_1937 level, class_2338 pos, String tagElement) {
		if (tagElement == null)
			return;

		rawCustomText = getJsonFromString(tagElement);
		parsedCustomText = parseCustomText(level, pos, rawCustomText);
	}

	public boolean sameAs(String tagElement) {
		return isValid() && rawCustomText.equals(getJsonFromString(tagElement));
	}

	public boolean isValid() {
		return parsedCustomText != null && rawCustomText != null;
	}

	public String resolve() {
		return parsedCustomText.getString();
	}

	public class_5250 get() {
		return parsedCustomText == null ? class_2561.method_43473() : parsedCustomText.method_27661();
	}

	public void read(class_1937 level, class_2338 pos, class_2487 nbt) {
		rawCustomText = getJsonFromString(nbt.method_10558("RawCustomText"));
		try {
			parsedCustomText = class_2561.class_2562.method_10877(nbt.method_10558("CustomText"));
		} catch (JsonParseException e) {
			parsedCustomText = null;
		}
	}

	public void write(class_2487 nbt) {
		if (!isValid())
			return;

		nbt.method_10582("RawCustomText", rawCustomText.toString());
		nbt.method_10582("CustomText", class_2561.class_2562.method_10867(parsedCustomText));
	}

	public static JsonElement getJsonFromString(String string) {
		try {
			return JsonParser.parseString(string);
		} catch (JsonParseException e) {
			return null;
		}
	}

	public static class_2561 parseCustomText(class_1937 level, class_2338 pos, JsonElement customText) {
		if (!(level instanceof class_3218 serverLevel))
			return null;
		try {
			return class_2564.method_10881(getCommandSource(serverLevel, pos),
				class_2561.class_2562.method_10872(customText), null, 0);
		} catch (JsonParseException e) {
			return null;
		} catch (CommandSyntaxException e) {
			return null;
		}
	}

	public static class_2168 getCommandSource(class_3218 level, class_2338 pos) {
		return new class_2168(class_2165.field_17395, class_243.method_24953(pos), class_241.field_1340, level, 2, Create.ID,
			class_2561.method_43470(Create.ID), level.method_8503(), null);
	}

}
