package com.simibubi.create.foundation.mixin.client;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import com.llamalad7.mixinextras.sugar.Local;
import com.simibubi.create.foundation.item.CustomRenderedArmorItem;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_572;
import net.minecraft.class_970;

@Mixin(class_970.class)
public class HumanoidArmorLayerMixin {
	@Inject(
		method = "renderArmorPiece(Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;Lnet/minecraft/world/entity/LivingEntity;Lnet/minecraft/world/entity/EquipmentSlot;ILnet/minecraft/client/model/HumanoidModel;)V",
		at = @At(
			value = "INVOKE",
			target = "Lnet/minecraft/world/item/ItemStack;getItem()Lnet/minecraft/world/item/Item;"
		),
		cancellable = true
	)
	private void create$onRenderArmorPiece(class_4587 poseStack, class_4597 bufferSource, class_1309 entity, class_1304 slot, int light, class_572<?> model, CallbackInfo ci, @Local class_1799 stack) {
		if (stack.method_7909() instanceof CustomRenderedArmorItem renderer) {
			renderer.renderArmorPiece((class_970<?, ?, ?>) (Object) this, poseStack, bufferSource, entity, slot, light, model, stack);
			ci.cancel();
		}
	}
}
