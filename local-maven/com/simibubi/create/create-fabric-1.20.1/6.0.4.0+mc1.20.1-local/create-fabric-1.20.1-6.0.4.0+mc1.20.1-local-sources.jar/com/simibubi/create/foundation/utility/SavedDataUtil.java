package com.simibubi.create.foundation.utility;

import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;
import net.minecraft.class_156;
import net.minecraft.class_18;
import net.minecraft.class_2487;
import net.minecraft.class_2507;
import net.minecraft.class_2512;
import com.simibubi.create.Create;

public class SavedDataUtil {
	public static <T extends class_18> void saveWithDatOld(T savedData, File file) {
		if (savedData.method_79()) {
			class_2487 compoundtag = new class_2487();
			compoundtag.method_10566("data", savedData.method_75(new class_2487()));
			class_2512.method_48310(compoundtag);

			String savedDataName = file.getName().split("\\.")[0];

			try {
				File temp = File.createTempFile(savedDataName, ".dat", file.getParentFile());
				class_2507.method_30614(compoundtag, temp);
				File oldFile = Paths.get(file.getParent(), savedDataName + ".dat_old").toFile();
				class_156.method_27760(file, temp, oldFile);
			} catch (IOException ioexception) {
				Create.LOGGER.error("Could not save data {}", savedData, ioexception);
			}

			savedData.method_78(false);
		}
	}
}
