package com.simibubi.create.foundation.utility;

import com.simibubi.create.Create;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_5250;

/** Deprecated so simi doensn't forget to remove debug calls **/
@Environment(value = EnvType.CLIENT)
public class Debug {

	@Deprecated
	public static void debugChat(String message) {
		if (class_310.method_1551().field_1724 != null) {
            class_310.method_1551().field_1724.method_7353(class_2561.method_43470(message), false);
        }
	}

	@Deprecated
	public static void debugChatAndShowStack(String message, int depth) {
		if (class_310.method_1551().field_1724 != null) {
            class_310.method_1551().field_1724.method_7353(class_2561.method_43470(message).method_27693("@")
                .method_10852(debugStack(depth)), false);
        }
	}

	@Deprecated
	public static void debugMessage(String message) {
		if (class_310.method_1551().field_1724 != null) {
            class_310.method_1551().field_1724.method_7353(class_2561.method_43470(message), true);
        }
	}

	@Deprecated
	public static void log(String message) {
		Create.LOGGER.info(message);
	}

	@Deprecated
	public static String getLogicalSide() {
		return class_310.method_1551().field_1687 // only called on client, this is safe (but completely redundant)
			.method_8608() ? "CL" : "SV";
	}

	@Deprecated
	public static class_2561 debugStack(int depth) {
		StackTraceElement[] stackTraceElements = Thread.currentThread()
			.getStackTrace();
		class_5250 text = class_2561.method_43470("[")
			.method_10852(class_2561.method_43470(getLogicalSide()).method_27692(class_124.field_1065))
			.method_27693("] ");
		for (int i = 1; i < depth + 2 && i < stackTraceElements.length; i++) {
			StackTraceElement e = stackTraceElements[i];
			if (e.getClassName()
				.equals(Debug.class.getName()))
				continue;
			text.method_10852(class_2561.method_43470(e.getMethodName()).method_27692(class_124.field_1054))
				.method_27693(", ");
		}
		return text.method_10852(class_2561.method_43470(" ...").method_27692(class_124.field_1080));
	}

	@Deprecated
	public static void markTemporary() {}

}
