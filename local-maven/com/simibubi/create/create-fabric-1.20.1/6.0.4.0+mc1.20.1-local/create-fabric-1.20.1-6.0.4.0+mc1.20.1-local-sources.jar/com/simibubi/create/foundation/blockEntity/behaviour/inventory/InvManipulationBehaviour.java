package com.simibubi.create.foundation.blockEntity.behaviour.inventory;

import java.util.function.Predicate;

import org.jetbrains.annotations.Nullable;

import com.google.common.base.Predicates;
import com.simibubi.create.api.packager.InventoryIdentifier;
import com.simibubi.create.content.logistics.packager.IdentifiedInventory;
import com.simibubi.create.foundation.blockEntity.SmartBlockEntity;
import com.simibubi.create.foundation.blockEntity.behaviour.BehaviourType;
import com.simibubi.create.foundation.blockEntity.behaviour.filtering.FilteringBehaviour;
import com.simibubi.create.foundation.item.ItemHelper;
import com.simibubi.create.foundation.item.ItemHelper.ExtractionCountMode;
import net.fabricmc.fabric.api.transfer.v1.item.ItemStorage;
import net.fabricmc.fabric.api.transfer.v1.item.ItemVariant;
import net.fabricmc.fabric.api.transfer.v1.storage.Storage;
import net.fabricmc.fabric.api.transfer.v1.transaction.Transaction;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import io.github.fabricators_of_create.porting_lib.transfer.TransferUtil;
import io.github.fabricators_of_create.porting_lib.util.StorageProvider;

public class InvManipulationBehaviour extends CapManipulationBehaviourBase<ItemVariant, InvManipulationBehaviour> {

	// Extra types available for multibehaviour
	public static final BehaviourType<InvManipulationBehaviour>

	TYPE = new BehaviourType<>(), EXTRACT = new BehaviourType<>(), INSERT = new BehaviourType<>();

	private BehaviourType<InvManipulationBehaviour> behaviourType;

	public static InvManipulationBehaviour forExtraction(SmartBlockEntity be, InterfaceProvider target) {
		return new InvManipulationBehaviour(EXTRACT, be, target);
	}

	public static InvManipulationBehaviour forInsertion(SmartBlockEntity be, InterfaceProvider target) {
		return new InvManipulationBehaviour(INSERT, be, target);
	}

	public InvManipulationBehaviour(SmartBlockEntity be, InterfaceProvider target) {
		this(TYPE, be, target);
	}

	private InvManipulationBehaviour(BehaviourType<InvManipulationBehaviour> type, SmartBlockEntity be,
		InterfaceProvider target) {
		super(be, target);
		behaviourType = type;
	}

	@Nullable
	public IdentifiedInventory getIdentifiedInventory() {
		Storage<ItemVariant> inventory = this.getInventory();
		if (inventory == null)
			return null;

		InventoryIdentifier identifier = InventoryIdentifier.get(this.getWorld(), this.getTarget().getOpposite());
		return new IdentifiedInventory(identifier, inventory);
	}

	@Override
	protected StorageProvider<ItemVariant> getProvider(class_2338 pos, boolean bypassSided) {
		return bypassSided
				? new UnsidedItemStorageProvider(getWorld(), pos)
				: StorageProvider.createForItems(getWorld(), pos);
	}

	public class_1799 extract() {
		return extract(getModeFromFilter(), getAmountFromFilter());
	}

	public class_1799 extract(ExtractionCountMode mode, int amount) {
		return extract(mode, amount, Predicates.alwaysTrue());
	}

	public class_1799 extract(ExtractionCountMode mode, int amount, Predicate<class_1799> filter) {
		boolean shouldSimulate = simulateNext;
		simulateNext = false;

		if (getWorld().field_9236 || !hasInventory())
			return class_1799.field_8037;
		Storage<ItemVariant> inventory = getInventory();
		if (inventory == null)
			return class_1799.field_8037;

		Predicate<class_1799> test = getFilterTest(filter);
		class_1799 simulatedItems = ItemHelper.extract(inventory, test, mode, amount, true);
		if (shouldSimulate || simulatedItems.method_7960())
			return simulatedItems;
		return ItemHelper.extract(inventory, test, mode, amount, false);
	}

	public class_1799 insert(class_1799 stack) {
		boolean shouldSimulate = simulateNext;
		simulateNext = false;
		Storage<ItemVariant> inventory = hasInventory() ? getInventory() : null;
		if (inventory == null)
			return stack;
		try (Transaction t = TransferUtil.getTransaction()) {
			long inserted = inventory.insert(ItemVariant.of(stack), stack.method_7947(), t);
			if (!shouldSimulate) t.commit();
			long remainder = stack.method_7947() - inserted;
			if (remainder == 0)
				return class_1799.field_8037;
			stack = stack.method_7972();
			stack.method_7939((int) remainder);
			return stack;
		}
	}

	protected Predicate<class_1799> getFilterTest(Predicate<class_1799> customFilter) {
		Predicate<class_1799> test = customFilter;
		FilteringBehaviour filter = blockEntity.getBehaviour(FilteringBehaviour.TYPE);
		if (filter != null)
			test = customFilter.and(filter::test);
		return test;
	}

	@Override
	public BehaviourType<?> getType() {
		return behaviourType;
	}

	public static class UnsidedItemStorageProvider extends UnsidedStorageProvider<ItemVariant> {
		protected UnsidedItemStorageProvider(class_1937 level, class_2338 pos) {
			super(ItemStorage.SIDED, level, pos);
		}

		@Nullable
		@Override
		public Storage<ItemVariant> get() {
			return TransferUtil.getItemStorage(level, pos);
		}
	}
}
