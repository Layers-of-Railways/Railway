package com.simibubi.create.foundation.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.simibubi.create.content.contraptions.AbstractContraptionEntity;
import net.minecraft.class_1297;
import net.minecraft.class_1675;

@Mixin(class_1675.class)
public class ProjectileUtilMixin {
	@ModifyExpressionValue(
		method = "getEntityHitResult(Lnet/minecraft/world/entity/Entity;Lnet/minecraft/world/phys/Vec3;Lnet/minecraft/world/phys/Vec3;Lnet/minecraft/world/phys/AABB;Ljava/util/function/Predicate;D)Lnet/minecraft/world/phys/EntityHitResult;",
		at = @At(
			value = "INVOKE",
			target = "Lnet/minecraft/world/entity/Entity;getRootVehicle()Lnet/minecraft/world/entity/Entity;",
			ordinal = 1
		)
	)
	private static class_1297 create$interactWithEntitiesOnContraptions(class_1297 root) {
		// return null when root is a contraption, so the interaction isn't blocked
		return root instanceof AbstractContraptionEntity ? null : root;
	}
}
