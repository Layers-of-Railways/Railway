package com.simibubi.create.foundation.mixin.accessor;

import net.minecraft.class_1799;
import net.minecraft.class_2315;
import net.minecraft.class_2357;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_2315.class)
public interface DispenserBlockAccessor {
	@Invoker("getDispenseMethod")
	class_2357 create$callGetDispenseMethod(class_1799 stack);
}
