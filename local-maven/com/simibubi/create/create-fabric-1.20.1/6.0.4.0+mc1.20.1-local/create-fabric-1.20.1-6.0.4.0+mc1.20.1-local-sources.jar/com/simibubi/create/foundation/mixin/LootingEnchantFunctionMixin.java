package com.simibubi.create.foundation.mixin;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import com.simibubi.create.AllDamageTypes;
import net.minecraft.class_125;
import net.minecraft.class_1282;
import net.minecraft.class_1799;
import net.minecraft.class_181;
import net.minecraft.class_47;
import net.minecraft.class_5658;

@Mixin(class_125.class)
public abstract class LootingEnchantFunctionMixin {
	@Shadow
	@Final
	class_5658 value;

	@Shadow
	@Final
	int limit;

	@Shadow
	abstract boolean hasLimit();

	@Inject(method = "run", at = @At("TAIL"))
	private void create$crushingWheelsHaveLooting(class_1799 stack, class_47 context, CallbackInfoReturnable<class_1799> cir) {
		class_1282 damageSource = context.method_296(class_181.field_1231);
		if (damageSource != null && damageSource.method_49708(AllDamageTypes.CRUSH)) {
			int lootingLevel = 2;

			float f = (float) lootingLevel * this.value.method_32454(context);
			stack.method_7933(Math.round(f));
			if (this.hasLimit() && stack.method_7947() > this.limit)
				stack.method_7939(this.limit);
		}
	}
}
