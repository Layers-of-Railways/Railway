package com.simibubi.create.foundation.block;

import java.util.HashSet;
import java.util.Set;

import com.simibubi.create.AllItems;

import net.createmod.catnip.math.VecHelper;
import net.createmod.catnip.platform.CatnipServices;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3965;

public class ItemUseOverrides {

	private static final Set<class_2960> OVERRIDES = new HashSet<>();

	public static void addBlock(class_2248 block) {
		OVERRIDES.add(CatnipServices.REGISTRIES.getKeyOrThrow(block));
	}

	public static class_1269 onBlockActivated(class_1657 player, class_1937 world, class_1268 hand, class_3965 traceResult) {
		if (AllItems.WRENCH.isIn(player.method_5998(hand)))
			return class_1269.field_5811;

		if (player.method_7325())
			return class_1269.field_5811;

		class_2338 pos = traceResult.method_17777();

		class_2680 state = world
				.method_8320(pos);
		class_2960 id = CatnipServices.REGISTRIES.getKeyOrThrow(state.method_26204());

		if (!OVERRIDES.contains(id))
			return class_1269.field_5811;

		class_3965 blockTrace =
				new class_3965(VecHelper.getCenterOf(pos), traceResult.method_17780(), pos, true);
		class_1269 result = state.method_26174(world, player, hand, blockTrace);

		if (!result.method_23665())
			return class_1269.field_5811;

		return result;
	}

}
