package com.simibubi.create.foundation.blockEntity;

import com.simibubi.create.foundation.networking.BlockEntityDataPacket;
import net.minecraft.class_2338;
import net.minecraft.class_2540;

public class RemoveBlockEntityPacket extends BlockEntityDataPacket<SyncedBlockEntity> {

	public RemoveBlockEntityPacket(class_2338 pos) {
		super(pos);
	}

	public RemoveBlockEntityPacket(class_2540 buffer) {
		super(buffer);
	}

	@Override
	protected void writeData(class_2540 buffer) {}

	@Override
	protected void handlePacket(SyncedBlockEntity be) {
		if (!be.method_11002()) {
			be.method_11012();
			return;
		}

		be.method_10997()
			.method_8544(pos);
	}

}
