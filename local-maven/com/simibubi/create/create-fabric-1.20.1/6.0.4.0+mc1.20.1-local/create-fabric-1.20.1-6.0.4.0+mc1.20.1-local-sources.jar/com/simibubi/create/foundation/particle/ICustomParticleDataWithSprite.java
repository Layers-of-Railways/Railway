package com.simibubi.create.foundation.particle;

import com.mojang.serialization.Codec;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.particle.v1.ParticleFactoryRegistry;
import net.minecraft.class_2394;
import net.minecraft.class_2394.class_2395;
import net.minecraft.class_2396;
import net.minecraft.class_702;
import net.minecraft.class_702.class_4091;
import net.minecraft.class_707;

public interface ICustomParticleDataWithSprite<T extends class_2394> extends ICustomParticleData<T> {

	class_2395<T> getDeserializer();

	public default class_2396<T> createType() {
		return new class_2396<>(false, getDeserializer()) {

			@Override
			public Codec<T> method_29138() {
				return ICustomParticleDataWithSprite.this.getCodec(this);
			}
		};
	}

	@Override
	@Environment(EnvType.CLIENT)
	default class_707<T> getFactory() {
		throw new IllegalAccessError("This particle type uses a metaFactory!");
	}

	@Environment(EnvType.CLIENT)
	public class_4091<T> getMetaFactory();

	@Override
	@Environment(EnvType.CLIENT)
	public default void register(class_2396<T> type, class_702 particles) {
		ParticleFactoryRegistry.getInstance().register(type, getMetaFactory()::create);
	}

}
