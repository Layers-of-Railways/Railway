package com.simibubi.create.foundation.data;

import java.util.function.Function;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2758;
import net.minecraft.class_2960;
import com.tterrag.registrate.providers.DataGenContext;
import com.tterrag.registrate.providers.RegistrateBlockstateProvider;
import com.tterrag.registrate.providers.RegistrateItemModelProvider;
import com.tterrag.registrate.util.nullness.NonNullBiConsumer;
import io.github.fabricators_of_create.porting_lib.models.generators.ModelFile;
import io.github.fabricators_of_create.porting_lib.models.generators.item.ItemModelBuilder;

public class AssetLookup {

	/**
	 * Custom block models packaged with other partials. Example:
	 * models/block/schematicannon/block.json <br>
	 * <br>
	 * Adding "powered", "vertical" will look for /block_powered_vertical.json
	 */
	public static ModelFile partialBaseModel(DataGenContext<?, ?> ctx, RegistrateBlockstateProvider prov,
											 String... suffix) {
		String string = "/block";
		for (String suf : suffix)
			if (!suf.isEmpty())
				string += "_" + suf;
		final String location = "block/" + ctx.getName() + string;
		return prov.models()
			.getExistingFile(prov.modLoc(location));
	}

	/**
	 * Custom block model from models/block/x.json
	 */
	public static ModelFile standardModel(DataGenContext<?, ?> ctx, RegistrateBlockstateProvider prov) {
		return prov.models()
			.getExistingFile(prov.modLoc("block/" + ctx.getName()));
	}

	/**
	 * Generate item model inheriting from a seperate model in
	 * models/block/x/item.json
	 */
	public static <I extends class_1747> ItemModelBuilder customItemModel(DataGenContext<class_1792, I> ctx,
																		 RegistrateItemModelProvider prov) {
		return prov.blockItem(() -> ctx.getEntry()
			.method_7711(), "/item");
	}

	/**
	 * Generate item model inheriting from a seperate model in
	 * models/block/folders[0]/folders[1]/.../item.json "_" will be replaced by the
	 * item name
	 */
	public static <I extends class_1747> NonNullBiConsumer<DataGenContext<class_1792, I>, RegistrateItemModelProvider> customBlockItemModel(
		String... folders) {
		return (c, p) -> {
			String path = "block";
			for (String string : folders)
				path += "/" + ("_".equals(string) ? c.getName() : string);
			p.withExistingParent(c.getName(), p.modLoc(path));
		};
	}

	public static <I extends class_1792> NonNullBiConsumer<DataGenContext<class_1792, I>, RegistrateItemModelProvider> customGenericItemModel(
		String... folders) {
		return (c, p) -> {
			String path = "block";
			for (String string : folders)
				path += "/" + ("_".equals(string) ? c.getName() : string);
			p.withExistingParent(c.getName(), p.modLoc(path));
		};
	}

	public static Function<class_2680, ModelFile> forPowered(DataGenContext<?, ?> ctx,
		RegistrateBlockstateProvider prov) {
		return state -> state.method_11654(class_2741.field_12484) ? partialBaseModel(ctx, prov, "powered")
			: partialBaseModel(ctx, prov);
	}

	public static Function<class_2680, ModelFile> forPowered(DataGenContext<?, ?> ctx,
		RegistrateBlockstateProvider prov, String path) {
		return state -> prov.models()
			.getExistingFile(
				prov.modLoc("block/" + path + (state.method_11654(class_2741.field_12484) ? "_powered" : "")));
	}

	public static Function<class_2680, ModelFile> withIndicator(DataGenContext<?, ?> ctx,
		RegistrateBlockstateProvider prov, Function<class_2680, ModelFile> baseModelFunc, class_2758 property) {
		return state -> {
			class_2960 baseModel = baseModelFunc.apply(state)
				.getLocation();
			Integer integer = state.method_11654(property);
			return prov.models()
				.withExistingParent(ctx.getName() + "_" + integer, baseModel)
				.texture("indicator", "block/indicator/" + integer);
		};
	}

	public static <T extends class_1792> NonNullBiConsumer<DataGenContext<class_1792, T>, RegistrateItemModelProvider> existingItemModel() {
		return (c, p) -> p.getExistingFile(p.modLoc("item/" + c.getName()));
	}

	public static <T extends class_1792> NonNullBiConsumer<DataGenContext<class_1792, T>, RegistrateItemModelProvider> itemModel(String name) {
		return (c, p) -> p.getExistingFile(p.modLoc("item/" + name));
	}

	public static <T extends class_1792> NonNullBiConsumer<DataGenContext<class_1792, T>, RegistrateItemModelProvider> itemModelWithPartials() {
		return (c, p) -> p.withExistingParent("item/" + c.getName(), p.modLoc("item/" + c.getName() + "/item"));
	}

}
