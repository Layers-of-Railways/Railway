package com.simibubi.create.foundation.advancement;

import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.UnaryOperator;
import net.minecraft.class_161;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_184;
import net.minecraft.class_189;
import net.minecraft.class_1935;
import net.minecraft.class_2035;
import net.minecraft.class_2066;
import net.minecraft.class_2073;
import net.minecraft.class_2096;
import net.minecraft.class_2105;
import net.minecraft.class_2248;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_4711;
import net.minecraft.class_6862;
import com.simibubi.create.Create;
import com.tterrag.registrate.util.entry.ItemProviderEntry;

public class CreateAdvancement {

	static final class_2960 BACKGROUND = Create.asResource("textures/gui/advancements.png");
	static final String LANG = "advancement." + Create.ID + ".";
	static final String SECRET_SUFFIX = "\n\u00A77(Hidden Advancement)";

	private class_161.class_162 builder;
	private SimpleCreateTrigger builtinTrigger;
	private CreateAdvancement parent;

	class_161 datagenResult;

	private String id;
	private String title;
	private String description;

	public CreateAdvancement(String id, UnaryOperator<Builder> b) {
		this.builder = class_161.class_162.method_707();
		this.id = id;

		Builder t = new Builder();
		b.apply(t);

		if (!t.externalTrigger) {
			builtinTrigger = AllTriggers.addSimple(id + "_builtin");
			builder.method_709("0", builtinTrigger.instance());
		}

        builder.method_20416(t.icon, class_2561.method_43471(titleKey()),
			class_2561.method_43471(descriptionKey()).method_27694(s -> s.method_36139(0xDBA213)),
			id.equals("root") ? BACKGROUND : null, t.type.frame, t.type.toast, t.type.announce, t.type.hide);

		if (t.type == TaskType.SECRET)
			description += SECRET_SUFFIX;

		AllAdvancements.ENTRIES.add(this);
	}

	private String titleKey() {
		return LANG + id;
	}

	private String descriptionKey() {
		return titleKey() + ".desc";
	}

	public boolean isAlreadyAwardedTo(class_1657 player) {
		if (!(player instanceof class_3222 sp))
			return true;
		class_161 advancement = sp.method_5682()
			.method_3851()
			.method_12896(Create.asResource(id));
		if (advancement == null)
			return true;
		return sp.method_14236()
			.method_12882(advancement)
			.method_740();
	}

	public void awardTo(class_1657 player) {
		if (!(player instanceof class_3222 sp))
			return;
		if (builtinTrigger == null)
			throw new UnsupportedOperationException(
				"Advancement " + id + " uses external Triggers, it cannot be awarded directly");
		builtinTrigger.trigger(sp);
	}

	void save(Consumer<class_161> t) {
		if (parent != null)
			builder.method_701(parent.datagenResult);
		datagenResult = builder.method_694(t, Create.asResource(id)
			.toString());
	}

	void provideLang(BiConsumer<String, String> consumer) {
		consumer.accept(titleKey(), title);
		consumer.accept(descriptionKey(), description);
	}

	static enum TaskType {

		SILENT(class_189.field_1254, false, false, false),
		NORMAL(class_189.field_1254, true, false, false),
		NOISY(class_189.field_1254, true, true, false),
		EXPERT(class_189.field_1249, true, true, false),
		SECRET(class_189.field_1249, true, true, true),

		;

		private class_189 frame;
		private boolean toast;
		private boolean announce;
		private boolean hide;

		private TaskType(class_189 frame, boolean toast, boolean announce, boolean hide) {
			this.frame = frame;
			this.toast = toast;
			this.announce = announce;
			this.hide = hide;
		}
	}

	class Builder {

		private TaskType type = TaskType.NORMAL;
		private boolean externalTrigger;
		private int keyIndex;
		private class_1799 icon;

		Builder special(TaskType type) {
			this.type = type;
			return this;
		}

		Builder after(CreateAdvancement other) {
			CreateAdvancement.this.parent = other;
			return this;
		}

		Builder icon(ItemProviderEntry<?> item) {
			return icon(item.asStack());
		}

		Builder icon(class_1935 item) {
			return icon(new class_1799(item));
		}

		Builder icon(class_1799 stack) {
			icon = stack;
			return this;
		}

		Builder title(String title) {
			CreateAdvancement.this.title = title;
			return this;
		}

		Builder description(String description) {
			CreateAdvancement.this.description = description;
			return this;
		}

		Builder whenBlockPlaced(class_2248 block) {
			return externalTrigger(class_4711.class_4712.method_51710(block));
		}

		Builder whenIconCollected() {
			return externalTrigger(class_2066.class_2068.method_8959(icon.method_7909()));
		}

		Builder whenItemCollected(ItemProviderEntry<?> item) {
			return whenItemCollected(item.asStack()
				.method_7909());
		}

		Builder whenItemCollected(class_1935 itemProvider) {
			return externalTrigger(class_2066.class_2068.method_8959(itemProvider));
		}

		Builder whenItemCollected(class_6862<class_1792> tag) {
			return externalTrigger(class_2066.class_2068
				.method_8957(new class_2073(tag, null, class_2096.class_2100.field_9708, class_2096.class_2100.field_9708,
					class_2035.field_20687, class_2035.field_20687, null, class_2105.field_9716)));
		}

		Builder awardedForFree() {
			return externalTrigger(class_2066.class_2068.method_8959(new class_1935[] {}));
		}

		Builder externalTrigger(class_184 trigger) {
			builder.method_709(String.valueOf(keyIndex), trigger);
			externalTrigger = true;
			keyIndex++;
			return this;
		}

	}

}
