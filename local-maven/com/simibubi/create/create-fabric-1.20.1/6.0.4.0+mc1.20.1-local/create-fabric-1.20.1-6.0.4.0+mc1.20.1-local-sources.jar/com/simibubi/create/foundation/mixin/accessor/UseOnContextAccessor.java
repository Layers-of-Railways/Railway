package com.simibubi.create.foundation.mixin.accessor;

import net.minecraft.class_1838;
import net.minecraft.class_3965;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_1838.class)
public interface UseOnContextAccessor {
	@Invoker("getHitResult")
	class_3965 create$getHitResult();
}
