package com.simibubi.create.foundation.data.recipe;

import java.util.List;
import net.minecraft.class_2246;
import net.minecraft.class_7784;
import com.simibubi.create.AllBlocks;
import com.simibubi.create.Create;
import com.simibubi.create.api.data.recipe.DeployingRecipeGen;
import com.simibubi.create.foundation.data.recipe.CreateRecipeProvider.I;

/**
 * Create's own Data Generation for Deploying recipes
 * @see DeployingRecipeGen
 */
@SuppressWarnings("unused")
public final class CreateDeployingRecipeGen extends DeployingRecipeGen {

	GeneratedRecipe COPPER_TILES = copperChain(AllBlocks.COPPER_TILES);
	GeneratedRecipe COPPER_SHINGLES = copperChain(AllBlocks.COPPER_SHINGLES);

	GeneratedRecipe

	COGWHEEL = create("cogwheel", b -> b.require(I.shaft())
		.require(I.planks())
		.output(I.cog())),

	LARGE_COGWHEEL = create("large_cogwheel", b -> b.require(I.cog())
		.require(I.planks())
		.output(I.largeCog()));

	GeneratedRecipe

	CB1 = addWax(() -> class_2246.field_27133, () -> class_2246.field_27119),
	CB2 = addWax(() -> class_2246.field_27135, () -> class_2246.field_27118),
	CB3 = addWax(() -> class_2246.field_27134, () -> class_2246.field_27117),
	CB4 = addWax(() -> class_2246.field_33407, () -> class_2246.field_27116),

	CCB1 = addWax(() -> class_2246.field_27138, () -> class_2246.field_27124),
	CCB2 = addWax(() -> class_2246.field_27137, () -> class_2246.field_27123),
	CCB3 = addWax(() -> class_2246.field_27136, () -> class_2246.field_27122),
	CCB4 = addWax(() -> class_2246.field_33408, () -> class_2246.field_27121),

	CCST1 = addWax(() -> class_2246.field_27167, () -> class_2246.field_27128),
	CCST2 = addWax(() -> class_2246.field_27166, () -> class_2246.field_27127),
	CCST3 = addWax(() -> class_2246.field_27139, () -> class_2246.field_27126),
	CCST4 = addWax(() -> class_2246.field_33409, () -> class_2246.field_27125),

	CCS1 = addWax(() -> class_2246.field_27170, () -> class_2246.field_27132),
	CCS2 = addWax(() -> class_2246.field_27169, () -> class_2246.field_27131),
	CCS3 = addWax(() -> class_2246.field_27168, () -> class_2246.field_27130),
	CCS4 = addWax(() -> class_2246.field_33410, () -> class_2246.field_27129);

	GeneratedRecipe

	CB_OX = oxidizationChain(List.of(() -> class_2246.field_27119, () -> class_2246.field_27118, () -> class_2246.field_27117, () -> class_2246.field_27116)),
	CCB_OX = oxidizationChain(List.of(() -> class_2246.field_27124, () -> class_2246.field_27123, () -> class_2246.field_27122, () -> class_2246.field_27121)),
	CCST_OX = oxidizationChain(List.of(() -> class_2246.field_27128, () -> class_2246.field_27127, () -> class_2246.field_27126, () -> class_2246.field_27125)),
	CCS_OX = oxidizationChain(List.of(() -> class_2246.field_27132, () -> class_2246.field_27131, () -> class_2246.field_27130, () -> class_2246.field_27129));

	public CreateDeployingRecipeGen(class_7784 output) {
		super(output, Create.ID);
	}
}
