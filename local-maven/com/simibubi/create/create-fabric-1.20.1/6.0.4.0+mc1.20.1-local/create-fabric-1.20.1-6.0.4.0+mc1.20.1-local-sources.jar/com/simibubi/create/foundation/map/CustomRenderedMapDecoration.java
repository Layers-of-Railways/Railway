package com.simibubi.create.foundation.map;

import net.minecraft.class_22;
import net.minecraft.class_4587;
import net.minecraft.class_4597;

public interface CustomRenderedMapDecoration {
	void render(class_4587 poseStack, class_4597 bufferSource, boolean active, int packedLight, class_22 mapData, int index);
}
