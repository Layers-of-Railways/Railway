package com.simibubi.create.foundation.damageTypes;

import javax.annotation.Nullable;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1937;
import net.minecraft.class_2378;
import net.minecraft.class_4538;
import net.minecraft.class_5321;
import net.minecraft.class_7924;
import net.minecraft.class_8110;
import com.simibubi.create.AllDamageTypes;

public class CreateDamageSources {
	public static class_1282 crush(class_1937 level) {
		return source(AllDamageTypes.CRUSH, level);
	}

	public static class_1282 cuckooSurprise(class_1937 level) {
		return source(AllDamageTypes.CUCKOO_SURPRISE, level);
	}

	public static class_1282 fanFire(class_1937 level) {
		return source(AllDamageTypes.FAN_FIRE, level);
	}

	public static class_1282 fanLava(class_1937 level) {
		return source(AllDamageTypes.FAN_LAVA, level);
	}

	public static class_1282 drill(class_1937 level) {
		return source(AllDamageTypes.DRILL, level);
	}

	public static class_1282 roller(class_1937 level) {
		return source(AllDamageTypes.ROLLER, level);
	}

	public static class_1282 saw(class_1937 level) {
		return source(AllDamageTypes.SAW, level);
	}

	public static class_1282 potatoCannon(class_1937 level, class_1297 causingEntity, class_1297 directEntity) {
		return source(AllDamageTypes.POTATO_CANNON, level, causingEntity, directEntity);
	}

	public static class_1282 runOver(class_1937 level, class_1297 entity) {
		return source(AllDamageTypes.RUN_OVER, level, entity);
	}

	private static class_1282 source(class_5321<class_8110> key, class_4538 level) {
		class_2378<class_8110> registry = level.method_30349().method_30530(class_7924.field_42534);
		return new class_1282(registry.method_40290(key));
	}

	private static class_1282 source(class_5321<class_8110> key, class_4538 level, @Nullable class_1297 entity) {
		class_2378<class_8110> registry = level.method_30349().method_30530(class_7924.field_42534);
		return new class_1282(registry.method_40290(key), entity);
	}

	private static class_1282 source(class_5321<class_8110> key, class_4538 level, @Nullable class_1297 causingEntity, @Nullable class_1297 directEntity) {
		class_2378<class_8110> registry = level.method_30349().method_30530(class_7924.field_42534);
		return new class_1282(registry.method_40290(key), causingEntity, directEntity);
	}
}
