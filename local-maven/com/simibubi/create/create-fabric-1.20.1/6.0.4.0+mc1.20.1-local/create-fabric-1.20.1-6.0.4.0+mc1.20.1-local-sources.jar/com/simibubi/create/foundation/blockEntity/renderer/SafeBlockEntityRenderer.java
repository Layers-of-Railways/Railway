package com.simibubi.create.foundation.blockEntity.renderer;

import com.simibubi.create.foundation.mixin.accessor.LevelRendererAccessor;

import net.createmod.ponder.api.level.PonderLevel;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2586;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4604;
import net.minecraft.class_827;

public abstract class SafeBlockEntityRenderer<T extends class_2586> implements class_827<T> {
	@Override
	public final void method_3569(T be, float partialTicks, class_4587 ms, class_4597 bufferSource, int light,
		int overlay) {
		if (isInvalid(be))
			return;
		renderSafe(be, partialTicks, ms, bufferSource, light, overlay);
	}

	protected abstract void renderSafe(T be, float partialTicks, class_4587 ms, class_4597 bufferSource, int light,
		int overlay);

	public boolean isInvalid(T be) {
		return !be.method_11002() || be.method_11010()
			.method_26204() == class_2246.field_10124;
	}

	public boolean shouldCullItem(class_243 itemPos, class_1937 level) {
		if (level instanceof PonderLevel)
			return false;

		LevelRendererAccessor accessor = (LevelRendererAccessor) class_310.method_1551().field_1769;
		class_4604 frustum = accessor.create$getCapturedFrustum() != null ?
			accessor.create$getCapturedFrustum() :
			accessor.create$getCullingFrustum();

		class_238 itemBB = new class_238(
				itemPos.field_1352 - 0.25,
				itemPos.field_1351 - 0.25,
				itemPos.field_1350 - 0.25,
				itemPos.field_1352 + 0.25,
				itemPos.field_1351 + 0.25,
				itemPos.field_1350 + 0.25
		);

		return !frustum.method_23093(itemBB);
	}
}
