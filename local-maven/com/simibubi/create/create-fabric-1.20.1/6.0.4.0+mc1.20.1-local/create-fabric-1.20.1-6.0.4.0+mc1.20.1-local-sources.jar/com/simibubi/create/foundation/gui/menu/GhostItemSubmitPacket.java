package com.simibubi.create.foundation.gui.menu;

import com.simibubi.create.content.logistics.filter.FilterItem;
import com.simibubi.create.content.logistics.stockTicker.StockKeeperCategoryMenu;
import com.simibubi.create.foundation.networking.SimplePacketBase;
import net.minecraft.class_1799;
import net.minecraft.class_2540;
import net.minecraft.class_3222;

public class GhostItemSubmitPacket extends SimplePacketBase {

	private final class_1799 item;
	private final int slot;

	public GhostItemSubmitPacket(class_1799 item, int slot) {
		this.item = item;
		this.slot = slot;
	}

	public GhostItemSubmitPacket(class_2540 buffer) {
		item = buffer.method_10819();
		slot = buffer.readInt();
	}

	@Override
	public void write(class_2540 buffer) {
		buffer.method_10793(item);
		buffer.writeInt(slot);
	}

	@Override
	public boolean handle(Context context) {
		context.enqueueWork(() -> {
			class_3222 player = context.getSender();
			if (player == null)
				return;

			if (player.field_7512 instanceof GhostItemMenu<?> menu) {
				menu.ghostInventory.setStackInSlot(slot, item);
				menu.method_7611(36 + slot)
					.method_7668();
			}
			if (player.field_7512 instanceof StockKeeperCategoryMenu menu
				&& (item.method_7960() || item.method_7909() instanceof FilterItem)) {
				menu.proxyInventory.setStackInSlot(slot, item);
				menu.method_7611(36 + slot)
					.method_7668();
			}
		});
		return true;
	}

}
