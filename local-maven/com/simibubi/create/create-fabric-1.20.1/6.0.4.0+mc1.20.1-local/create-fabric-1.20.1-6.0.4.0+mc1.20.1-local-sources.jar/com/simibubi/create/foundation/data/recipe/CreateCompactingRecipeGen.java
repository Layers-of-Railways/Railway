package com.simibubi.create.foundation.data.recipe;

import com.simibubi.create.AllFluids;
import com.simibubi.create.AllItems;
import com.simibubi.create.AllTags.AllFluidTags;
import com.simibubi.create.Create;
import com.simibubi.create.api.data.recipe.BaseRecipeProvider.GeneratedRecipe;
import com.simibubi.create.api.data.recipe.CompactingRecipeGen;
import io.github.fabricators_of_create.porting_lib.tags.Tags;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_3612;
import net.minecraft.class_7784;

/**
 * Create's own Data Generation for Compacting recipes
 * @see CompactingRecipeGen
 */
@SuppressWarnings("unused")
public final class CreateCompactingRecipeGen extends CompactingRecipeGen {
	public CreateCompactingRecipeGen(class_7784 output) {
		super(output, Create.ID);
	}

	GeneratedRecipe

	GRANITE = create("granite_from_flint", b -> b.require(class_1802.field_8145)
		.require(class_1802.field_8145)
		.require(class_3612.field_15908, 100)
		.require(class_1802.field_8200)
		.output(class_2246.field_10474, 1)),

	DIORITE = create("diorite_from_flint", b -> b.require(class_1802.field_8145)
		.require(class_1802.field_8145)
		.require(class_3612.field_15908, 100)
		.require(class_1802.field_27020)
		.output(class_2246.field_10508, 1)),

	ANDESITE = create("andesite_from_flint", b -> b.require(class_1802.field_8145)
		.require(class_1802.field_8145)
		.require(class_3612.field_15908, 100)
		.require(class_1802.field_8110)
		.output(class_2246.field_10115, 1)),

	CHOCOLATE = create("chocolate", b -> b.require(AllFluids.CHOCOLATE.get(), 250)
		.output(AllItems.BAR_OF_CHOCOLATE.get(), 1)),

	BLAZE_CAKE = create("blaze_cake", b -> b.require(Tags.Items.EGGS)
		.require(class_1802.field_8479)
		.require(AllItems.CINDER_FLOUR.get())
		.output(AllItems.BLAZE_CAKE_BASE.get(), 1)),

	HONEY = create("honey", b -> b.require(AllFluidTags.HONEY.tag, 1000)
		.output(class_1802.field_21086, 1)),

	ICE = create("ice", b -> b
		.require(class_2246.field_10491).require(class_2246.field_10491).require(class_2246.field_10491)
		.require(class_2246.field_10491).require(class_2246.field_10491).require(class_2246.field_10491)
		.require(class_2246.field_10491).require(class_2246.field_10491).require(class_2246.field_10491)
		.output(class_2246.field_10295))

		;
}
