package com.simibubi.create.foundation.gui.menu;

import com.simibubi.create.foundation.networking.SimplePacketBase;
import net.minecraft.class_2540;
import net.minecraft.class_3222;

public class ClearMenuPacket extends SimplePacketBase {

	public ClearMenuPacket() {}

	public ClearMenuPacket(class_2540 buffer) {}

	@Override
	public void write(class_2540 buffer) {}

	@Override
	public boolean handle(Context context) {
		context.enqueueWork(() -> {
			class_3222 player = context.getSender();
			if (player == null)
				return;
			if (!(player.field_7512 instanceof IClearableMenu))
				return;
			((IClearableMenu) player.field_7512).clearContents();
		});
		return true;
	}

}
