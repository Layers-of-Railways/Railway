package com.simibubi.create.foundation.mixin.accessor;

import net.minecraft.class_4592;
import net.minecraft.class_630;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_4592.class)
public interface AgeableListModelAccessor {
	@Invoker("headParts")
	Iterable<class_630> create$callHeadParts();

	@Invoker("bodyParts")
	Iterable<class_630> create$callBodyParts();

	// fabric: additional fields needed

	@Accessor
	boolean getScaleHead();

	@Accessor
	float getBabyHeadScale();

	@Accessor
	float getBabyYHeadOffset();

	@Accessor
	float getBabyZHeadOffset();
}
