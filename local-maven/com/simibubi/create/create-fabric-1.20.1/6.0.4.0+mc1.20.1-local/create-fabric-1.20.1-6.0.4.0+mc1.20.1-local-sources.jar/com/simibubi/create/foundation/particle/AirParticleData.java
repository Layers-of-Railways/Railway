package com.simibubi.create.foundation.particle;

import java.util.Locale;

import com.mojang.brigadier.StringReader;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.simibubi.create.AllParticleTypes;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2394;
import net.minecraft.class_2396;
import net.minecraft.class_2540;
import net.minecraft.class_702.class_4091;

public class AirParticleData implements class_2394, ICustomParticleDataWithSprite<AirParticleData> {

	public static final Codec<AirParticleData> CODEC = RecordCodecBuilder.create(i ->
		i.group(
				Codec.FLOAT.fieldOf("drag").forGetter(p -> p.drag),
				Codec.FLOAT.fieldOf("speed").forGetter(p -> p.speed))
			.apply(i, AirParticleData::new));
	public static final class_2394.class_2395<AirParticleData> DESERIALIZER =
		new class_2394.class_2395<>() {
			public AirParticleData method_10296(class_2396<AirParticleData> particleTypeIn, StringReader reader)
				throws CommandSyntaxException {
				reader.expect(' ');
				float drag = reader.readFloat();
				reader.expect(' ');
				float speed = reader.readFloat();
				return new AirParticleData(drag, speed);
			}

			public AirParticleData method_10297(class_2396<AirParticleData> particleTypeIn, class_2540 buffer) {
				return new AirParticleData(buffer.readFloat(), buffer.readFloat());
			}
		};

	float drag;
	float speed;

	public AirParticleData(float drag, float speed) {
		this.drag = drag;
		this.speed = speed;
	}

	public AirParticleData() {
		this(0, 0);
	}

	@Override
	public class_2396<?> method_10295() {
		return AllParticleTypes.AIR.get();
	}

	@Override
	public void method_10294(class_2540 buffer) {
		buffer.writeFloat(drag);
		buffer.writeFloat(speed);
	}

	@Override
	public String method_10293() {
		return String.format(Locale.ROOT, "%s %f %f", AllParticleTypes.AIR.parameter(), drag, speed);
	}

	@Override
	public class_2395<AirParticleData> getDeserializer() {
		return DESERIALIZER;
	}

	@Override
	public Codec<AirParticleData> getCodec(class_2396<AirParticleData> type) {
		return CODEC;
	}

	@Override
	@Environment(EnvType.CLIENT)
	public class_4091<AirParticleData> getMetaFactory() {
		return AirParticle.Factory::new;
	}

}
