package com.simibubi.create.foundation.data;

import com.tterrag.registrate.AbstractRegistrate;
import com.tterrag.registrate.builders.BuilderCallback;
import com.tterrag.registrate.builders.FluidBuilder;
import com.tterrag.registrate.fabric.SimpleFlowableFluid;
import com.tterrag.registrate.fabric.SimpleFlowableFluid.Properties;
import com.tterrag.registrate.util.nullness.NonNullFunction;
import com.tterrag.registrate.util.nullness.NonNullSupplier;
import net.minecraft.class_2960;

/**
 * For registering fluids with no buckets/blocks
 */
public class VirtualFluidBuilder<T extends SimpleFlowableFluid, P> extends FluidBuilder<T, P> {

	public VirtualFluidBuilder(AbstractRegistrate<?> owner, P parent, String name, BuilderCallback callback,
		class_2960 stillTexture, class_2960 flowingTexture,
		NonNullFunction<Properties, T> sourceFactory,
	    NonNullFunction<Properties, T> flowingFactory
   ) {
		super(owner, parent, name, callback, stillTexture, flowingTexture, flowingFactory);
		source(sourceFactory);
	}

	@Override
	public NonNullSupplier<T> asSupplier() {
		return this::getEntry;
	}

}
