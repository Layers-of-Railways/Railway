package com.simibubi.create.foundation.mixin;

import java.util.function.Consumer;
import net.minecraft.class_2378;
import net.minecraft.class_7923;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.simibubi.create.Create;
import com.simibubi.create.api.registry.CreateBuiltInRegistries;

@Mixin(class_7923.class)
public class BuiltInRegistriesMixin {
	static {
		CreateBuiltInRegistries.init();
	}

	@WrapOperation(method = "validate", at = @At(value = "INVOKE", target = "Lnet/minecraft/core/Registry;forEach(Ljava/util/function/Consumer;)V"))
	private static <T extends class_2378<?>> void create$ourRegistriesAreNotEmpty(class_2378<T> instance, Consumer<T> consumer, Operation<Void> original) {
		Consumer<T> callback = (t) -> {
			if (!t.method_30517().method_29177().method_12836().equals(Create.ID))
				consumer.accept(t);
		};

		original.call(instance, callback);
	}
}
