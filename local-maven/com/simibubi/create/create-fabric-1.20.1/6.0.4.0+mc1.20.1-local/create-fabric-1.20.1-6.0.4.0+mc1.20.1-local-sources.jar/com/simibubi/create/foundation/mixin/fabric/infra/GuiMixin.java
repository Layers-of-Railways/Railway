package com.simibubi.create.foundation.mixin.fabric.infra;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.simibubi.create.infrastructure.fabric.HelmetOverlay;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_329;
import net.minecraft.class_332;

@Mixin(class_329.class)
public abstract class GuiMixin {
	@Shadow
	@Final
	private class_310 minecraft;

	@Shadow
	protected abstract void renderTextureOverlay(class_332 guiGraphics, class_2960 shaderLocation, float alpha);

	@ModifyExpressionValue(
		method = "render",
		at = @At(
			value = "INVOKE",
			target = "Lnet/minecraft/world/entity/player/Inventory;getArmor(I)Lnet/minecraft/world/item/ItemStack;"
		)
	)
	private class_1799 renderCustomOverlay(class_1799 stack, class_332 guiGraphics, float partialTick) {
		HelmetOverlay overlay = HelmetOverlay.REGISTRY.get(stack.method_7909());
		if (overlay != null) {
			float opacity = overlay.calculateOpacity(stack, this.minecraft.field_1724, partialTick);
			if (opacity > 0) {
				this.renderTextureOverlay(guiGraphics, overlay.texture, opacity);
			}
		}

		return stack;
	}
}
