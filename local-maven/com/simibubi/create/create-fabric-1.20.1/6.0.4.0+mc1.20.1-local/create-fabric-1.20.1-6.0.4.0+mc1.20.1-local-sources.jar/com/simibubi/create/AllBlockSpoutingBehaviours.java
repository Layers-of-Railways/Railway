package com.simibubi.create;

import java.util.List;
import java.util.Optional;
import java.util.function.Predicate;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2344;
import net.minecraft.class_2591;
import net.minecraft.class_2960;
import net.minecraft.class_3611;
import net.minecraft.class_3612;
import net.minecraft.class_5556;
import net.minecraft.class_7923;
import com.simibubi.create.api.behaviour.spouting.BlockSpoutingBehaviour;
import com.simibubi.create.api.behaviour.spouting.CauldronSpoutingBehavior;
import com.simibubi.create.api.behaviour.spouting.StateChangingBehavior;
import com.simibubi.create.compat.Mods;
import com.simibubi.create.compat.botania.ApothecaryFilling;
import com.simibubi.create.compat.tconstruct.SpoutCasting;

public class AllBlockSpoutingBehaviours {
	static void registerDefaults() {
		Predicate<class_3611> isWater = fluid -> fluid.method_15780(class_3612.field_15910);
		BlockSpoutingBehaviour toMud = StateChangingBehavior.setTo(250, isWater, class_2246.field_37576);

		for (class_2248 dirt : List.of(class_2246.field_10566, class_2246.field_10253, class_2246.field_28685)) {
			BlockSpoutingBehaviour.BY_BLOCK.register(dirt, toMud);
		}

		BlockSpoutingBehaviour.BY_BLOCK.register(class_2246.field_10362, StateChangingBehavior.incrementingState(100, isWater, class_2344.field_11009));
		BlockSpoutingBehaviour.BY_BLOCK.register(class_2246.field_27097, StateChangingBehavior.incrementingState(250, isWater, class_5556.field_27206));
		BlockSpoutingBehaviour.BY_BLOCK.register(class_2246.field_10593, CauldronSpoutingBehavior.INSTANCE);

		if (Mods.BOTANIA.isLoaded()) {
			getTypeForCompat(Mods.BOTANIA, "altar").ifPresent(
				type -> BlockSpoutingBehaviour.BY_BLOCK_ENTITY.register(type, ApothecaryFilling.INSTANCE)
			);
		}

		if (!Mods.TCONSTRUCT.isLoaded())
			return;

		for (String name : List.of("table", "basin")) {
			getTypeForCompat(Mods.TCONSTRUCT, name).ifPresent(
				type -> BlockSpoutingBehaviour.BY_BLOCK_ENTITY.register(type, SpoutCasting.INSTANCE)
			);
		}
	}

	private static Optional<class_2591<?>> getTypeForCompat(Mods mod, String name) {
		class_2960 id = mod.rl(name);
		class_2591<?> type = class_7923.field_41181.method_10223(id);
		if (type != null) {
			return Optional.of(type);
		} else {
			Create.LOGGER.warn("Block entity {} wasn't found. Outdated compat?", id);
			return Optional.empty();
		}
	}
}
