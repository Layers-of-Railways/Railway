package com.simibubi.create.api.data.recipe;

import java.util.function.Supplier;

import com.simibubi.create.AllRecipeTypes;

import net.createmod.catnip.platform.CatnipServices;
import net.minecraft.class_1856;
import net.minecraft.class_1935;
import net.minecraft.class_7784;

/**
 * The base class for Haunting recipe generation.
 * Addons should extend this and use the {@link ProcessingRecipeGen#create} methods
 * or the helper methods contained in this class to make recipes.
 * For an example of how you might do this, see Create's implementation: {@link com.simibubi.create.foundation.data.recipe.CreateHauntingRecipeGen}.
 * Needs to be added to a registered recipe provider to do anything, see {@link com.simibubi.create.foundation.data.recipe.CreateRecipeProvider}
 */
public abstract class HauntingRecipeGen extends ProcessingRecipeGen {

	public GeneratedRecipe convert(class_1935 input, class_1935 result) {
		return convert(() -> class_1856.method_8091(input), () -> result);
	}

	public GeneratedRecipe convert(Supplier<class_1856> input, Supplier<class_1935> result) {
		return create(asResource(CatnipServices.REGISTRIES.getKeyOrThrow(result.get()
								.method_8389())
			.method_12832()),
			p -> p.withItemIngredients(input.get())
				.output(result.get()));
	}

	public HauntingRecipeGen(class_7784 output, String defaultNamespace) {
		super(output, defaultNamespace);
	}

	@Override
	protected AllRecipeTypes getRecipeType() {
		return AllRecipeTypes.HAUNTING;
	}

}
