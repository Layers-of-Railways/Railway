package com.simibubi.create.foundation.networking;

import org.jetbrains.annotations.Nullable;

import com.simibubi.create.foundation.mixin.fabric.BlockableEventLoopAccessor;

import me.pepperbell.simplenetworking.C2SPacket;
import me.pepperbell.simplenetworking.S2CPacket;
import me.pepperbell.simplenetworking.SimpleChannel;
import net.minecraft.class_1255;
import net.minecraft.class_2540;
import net.minecraft.class_2547;
import net.minecraft.class_310;
import net.minecraft.class_3222;
import net.minecraft.class_3244;
import net.minecraft.class_634;
import net.minecraft.server.MinecraftServer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.networking.v1.PacketSender;

public abstract class SimplePacketBase implements C2SPacket, S2CPacket {

	public abstract void write(class_2540 buffer);

	public abstract boolean handle(Context context);

	@Override
	public final void encode(class_2540 buffer) {
		write(buffer);
	}

	@Override
	@Environment(EnvType.CLIENT)
	public void handle(class_310 client, class_634 listener, PacketSender responseSender, SimpleChannel channel) {
		handle(new Context(client, listener, null));
	}

	@Override
	public void handle(MinecraftServer server, class_3222 player, class_3244 listener, PacketSender responseSender, SimpleChannel channel) {
		handle(new Context(server, listener, player));
	}

	public enum NetworkDirection {
		PLAY_TO_CLIENT,
		PLAY_TO_SERVER
	}

	public record Context(class_1255<? extends Runnable> executor, class_2547 listener, @Nullable class_3222 sender) {
		public void enqueueWork(Runnable runnable) {
			// Matches Forge's enqueueWork behavior.
			// MC will sometimes defer tasks even if already on the right thread.
			if (executor.method_18854()) {
				runnable.run();
			} else {
				// skip extra checks
				((BlockableEventLoopAccessor) executor).callSubmitAsync(runnable);
			}
		}

		@Nullable
		public class_3222 getSender() {
			return sender();
		}

		public NetworkDirection getDirection() {
			return sender() == null ? NetworkDirection.PLAY_TO_SERVER : NetworkDirection.PLAY_TO_CLIENT;
		}
	}
}
