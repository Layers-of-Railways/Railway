package com.simibubi.create.foundation.blockEntity;

import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_5558;

public class SmartBlockEntityTicker<T extends class_2586> implements class_5558<T> {

	@Override
	public void tick(class_1937 p_155253_, class_2338 p_155254_, class_2680 p_155255_, T p_155256_) {
		if (!p_155256_.method_11002())
			p_155256_.method_31662(p_155253_);
		((SmartBlockEntity) p_155256_).tick();
	}

}
