package com.simibubi.create.foundation.block.render;

import java.util.Set;
import net.minecraft.class_2338;
import org.jetbrains.annotations.Nullable;

public interface BlockDestructionProgressExtension {
	@Nullable
	Set<class_2338> create$getExtraPositions();

	void create$setExtraPositions(@Nullable Set<class_2338> positions);
}
