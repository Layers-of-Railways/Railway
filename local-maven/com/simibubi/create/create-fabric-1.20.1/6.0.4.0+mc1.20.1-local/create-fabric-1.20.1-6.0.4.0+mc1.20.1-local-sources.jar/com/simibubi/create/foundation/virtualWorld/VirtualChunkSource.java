package com.simibubi.create.foundation.virtualWorld;

import java.util.function.BooleanSupplier;
import net.minecraft.class_1923;
import net.minecraft.class_1937;
import net.minecraft.class_2791;
import net.minecraft.class_2802;
import net.minecraft.class_2806;
import net.minecraft.class_2818;
import net.minecraft.class_3568;
import org.jetbrains.annotations.Nullable;

import it.unimi.dsi.fastutil.longs.Long2ObjectMap;
import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;

public class VirtualChunkSource extends class_2802 {
	private final VirtualRenderWorld world;
	private final Long2ObjectMap<VirtualChunk> chunks = new Long2ObjectOpenHashMap<>();

	public VirtualChunkSource(VirtualRenderWorld world) {
		this.world = world;
	}

	@Override
	public class_1937 method_16399() {
		return world;
	}

	public class_2791 getChunk(int x, int z) {
		long pos = class_1923.method_8331(x, z);
		return chunks.computeIfAbsent(pos, $ -> new VirtualChunk(world, x, z));
	}

	@Override
	@Nullable
	public class_2818 method_12126(int x, int z, boolean load) {
		return null;
	}

	@Override
	@Nullable
	public class_2791 method_12121(int x, int z, class_2806 status, boolean load) {
		return getChunk(x, z);
	}

	@Override
	public void method_12127(BooleanSupplier hasTimeLeft, boolean tickChunks) {
	}

	@Override
	public String method_12122() {
		return "VirtualChunkSource";
	}

	@Override
	public int method_14151() {
		return 0;
	}

	@Override
	public class_3568 method_12130() {
		return world.method_22336();
	}
}
