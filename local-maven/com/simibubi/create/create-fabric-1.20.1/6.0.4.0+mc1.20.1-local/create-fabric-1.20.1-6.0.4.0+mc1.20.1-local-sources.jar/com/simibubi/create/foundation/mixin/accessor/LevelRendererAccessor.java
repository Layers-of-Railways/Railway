package com.simibubi.create.foundation.mixin.accessor;

import net.minecraft.class_4604;
import net.minecraft.class_761;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_761.class)
public interface LevelRendererAccessor {
	@Accessor("cullingFrustum")
	class_4604 create$getCullingFrustum();

	@Accessor("capturedFrustum")
	class_4604 create$getCapturedFrustum();
}
