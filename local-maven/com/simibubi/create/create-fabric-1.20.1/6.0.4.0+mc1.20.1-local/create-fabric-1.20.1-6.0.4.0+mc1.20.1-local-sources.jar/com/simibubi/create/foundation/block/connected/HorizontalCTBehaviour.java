package com.simibubi.create.foundation.block.connected;

import net.minecraft.class_1058;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import org.jetbrains.annotations.Nullable;

public class HorizontalCTBehaviour extends ConnectedTextureBehaviour.Base {

	protected CTSpriteShiftEntry topShift;
	protected CTSpriteShiftEntry layerShift;

	public HorizontalCTBehaviour(CTSpriteShiftEntry layerShift) {
		this(layerShift, null);
	}

	public HorizontalCTBehaviour(CTSpriteShiftEntry layerShift, CTSpriteShiftEntry topShift) {
		this.layerShift = layerShift;
		this.topShift = topShift;
	}

	@Override
	public CTSpriteShiftEntry getShift(class_2680 state, class_2350 direction, @Nullable class_1058 sprite) {
		return direction.method_10166()
			.method_10179() ? layerShift : topShift;
	}

}