package com.simibubi.create.foundation.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.simibubi.create.content.contraptions.AbstractContraptionEntity;
import com.simibubi.create.infrastructure.config.AllConfigs;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1937;

@Mixin(class_1657.class)
public abstract class PlayerMixin extends class_1309 {
	protected PlayerMixin(class_1299<? extends class_1309> entityType, class_1937 level) {
		super(entityType, level);
	}

	@ModifyExpressionValue(
		method = "aiStep",
		at = @At(
			value = "INVOKE",
			target = "Lnet/minecraft/world/entity/player/Player;isPassenger()Z"
		)
	)
	private boolean pretendNotPassenger(boolean isPassenger) {
		// avoid touching all items in the contraption's massive hitbox
		boolean shouldSync = AllConfigs.server().kinetics.syncPlayerPickupHitboxWithContraptionHitbox.get();
		if (isPassenger && !shouldSync && this.method_5854() instanceof AbstractContraptionEntity) {
			return false;
		}

		return isPassenger;
	}
}
