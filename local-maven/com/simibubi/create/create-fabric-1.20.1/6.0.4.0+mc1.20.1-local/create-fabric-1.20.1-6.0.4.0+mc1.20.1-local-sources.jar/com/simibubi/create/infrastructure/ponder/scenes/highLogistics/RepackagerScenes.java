package com.simibubi.create.infrastructure.ponder.scenes.highLogistics;

import java.util.List;

import com.simibubi.create.content.kinetics.crafter.MechanicalCrafterBlockEntity;
import com.simibubi.create.content.logistics.box.PackageItem;
import com.simibubi.create.foundation.ponder.CreateSceneBuilder;

import io.github.fabricators_of_create.porting_lib.transfer.TransferUtil;

import net.createmod.catnip.math.Pointing;
import net.createmod.ponder.api.PonderPalette;
import net.createmod.ponder.api.scene.SceneBuilder;
import net.createmod.ponder.api.scene.SceneBuildingUtil;
import net.createmod.ponder.api.scene.Selection;

import net.fabricmc.fabric.api.transfer.v1.item.ItemStorage;

import net.fabricmc.fabric.api.transfer.v1.item.ItemVariant;
import net.fabricmc.fabric.api.transfer.v1.storage.Storage;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_2586;

public class RepackagerScenes {

	public static void repackager(SceneBuilder builder, SceneBuildingUtil util) {
		CreateSceneBuilder scene = new CreateSceneBuilder(builder);
		scene.title("repackager", "Merging packages from a request");
		scene.configureBasePlate(1, 0, 7);
		scene.setSceneOffsetY(-.5f);
		scene.showBasePlate();

		Selection belt2 = util.select()
			.fromTo(7, 1, 2, 6, 1, 1);
		Selection belt1 = util.select()
			.fromTo(1, 1, 2, 4, 1, 1);
		Selection belt3 = util.select()
			.fromTo(5, 1, 1, 5, 1, 6)
			.add(util.select()
				.fromTo(6, 1, 5, 6, 1, 6));
		Selection crafterCogs = util.select()
			.fromTo(1, 1, 6, 0, 2, 6)
			.add(util.select()
				.position(0, 2, 5))
			.add(util.select()
				.fromTo(1, 1, 7, 2, 0, 7));
		Selection crafter = util.select()
			.fromTo(1, 2, 5, 3, 4, 5);
		Selection crafterScaff = util.select()
			.fromTo(3, 1, 5, 1, 1, 5);
		Selection packager = util.select()
			.fromTo(4, 1, 5, 4, 2, 5);
		class_2338 pack = util.grid()
			.at(4, 2, 5);
		Selection packFunnel = util.select()
			.position(5, 2, 5);
		Selection largeCog1 = util.select()
			.position(0, 0, 2);
		Selection largeCog2 = util.select()
			.position(8, 0, 2);
		class_2338 funnel1 = util.grid()
			.at(4, 2, 1);
		class_2338 funnel2 = util.grid()
			.at(6, 2, 1);
		Selection f3s = util.select()
			.position(5, 2, 3);
		Selection f2s = util.select()
			.position(funnel2);
		Selection f1s = util.select()
			.position(funnel1);
		Selection barrel = util.select()
			.position(5, 2, 1);
		class_2338 repack = util.grid()
			.at(5, 2, 2);
		Selection repackS = util.select()
			.fromTo(5, 2, 2, 5, 3, 2);
		Selection largeCog3 = util.select()
			.position(6, 0, 7);

		scene.world()
			.multiplyKineticSpeed(util.select()
				.everywhere(), 1 / 2f);

		scene.idle(10);

		scene.world()
			.showSection(crafterScaff, class_2350.field_11043);
		scene.idle(3);
		scene.world()
			.showSection(crafter, class_2350.field_11033);
		scene.idle(5);
		scene.world()
			.showSection(packager, class_2350.field_11039);
		scene.world()
			.showSection(crafterCogs, class_2350.field_11034);
		scene.idle(5);

		scene.overlay()
			.showText(120)
			.text("Sometimes, it is crucial for logistical requests to arrive as a single package")
			.attachKeyFrame()
			.placeNearTarget()
			.independent(130);

		scene.idle(90);
		scene.world()
			.showSection(belt3, class_2350.field_11039);
		scene.world()
			.showSection(largeCog3, class_2350.field_11036);
		scene.idle(5);
		scene.world()
			.showSection(belt2, class_2350.field_11039);
		scene.world()
			.showSection(largeCog2, class_2350.field_11036);
		scene.idle(5);
		scene.world()
			.showSection(belt1, class_2350.field_11034);
		scene.world()
			.showSection(largeCog1, class_2350.field_11036);
		scene.world()
			.showSection(packFunnel, class_2350.field_11033);
		scene.idle(20);

		scene.world()
			.setBlock(util.grid()
				.at(4, 2, 1), class_2246.field_10124.method_9564(), false);
		scene.world()
			.setBlock(util.grid()
				.at(6, 2, 1), class_2246.field_10124.method_9564(), false);

		class_1799 box1 = PackageItem.containing(List.of());
		class_1799 box2 = PackageItem.containing(List.of());
		class_1799 box3 = PackageItem.containing(List.of());
		scene.world()
			.createItemOnBelt(util.grid()
				.at(3, 1, 1), class_2350.field_11033, box1);
		scene.world()
			.createItemOnBelt(util.grid()
				.at(2, 1, 1), class_2350.field_11033, box2);
		scene.idle(13);
		scene.world()
			.createItemOnBelt(util.grid()
				.at(7, 1, 1), class_2350.field_11033, box3);
		scene.idle(3);
		scene.world()
			.multiplyKineticSpeed(util.select()
				.everywhere(), 1 / 16f);

		class_238 bb1 = new class_238(util.grid()
			.at(2, 2, 1)).method_35580(0.125, 0.5, 0.125)
				.method_1009(0.65, 0, 0)
				.method_989(1.05, -.5, 0);
		class_238 bb2 = new class_238(util.grid()
			.at(7, 2, 1)).method_35580(0.125, 0.5, 0.125)
				.method_989(-.25, -.5, 0);

		scene.overlay()
			.chaseBoundingBoxOutline(PonderPalette.INPUT, pack, new class_238(bb1.method_1005(), bb1.method_1005()), 1);
		scene.overlay()
			.chaseBoundingBoxOutline(PonderPalette.OUTPUT, repack, new class_238(bb2.method_1005(), bb2.method_1005()), 1);
		scene.idle(1);
		scene.overlay()
			.chaseBoundingBoxOutline(PonderPalette.INPUT, pack, bb1, 60);
		scene.overlay()
			.chaseBoundingBoxOutline(PonderPalette.OUTPUT, repack, bb2, 60);

		scene.overlay()
			.showText(60)
			.text("Order A")
			.attachKeyFrame()
			.colored(PonderPalette.INPUT)
			.pointAt(util.vector()
				.of(3, 2, 1.5))
			.placeNearTarget();

		scene.overlay()
			.showText(60)
			.text("Order B")
			.attachKeyFrame()
			.colored(PonderPalette.OUTPUT)
			.pointAt(util.vector()
				.of(7, 2, 1.5))
			.placeNearTarget();
		scene.idle(60);

		scene.world()
			.multiplyKineticSpeed(util.select()
				.everywhere(), 24f);
		scene.idle(60);

		scene.world()
			.multiplyKineticSpeed(util.select()
				.everywhere(), 1 / 24f);

		scene.overlay()
			.showText(60)
			.text("Otherwise, other packages could arrive inbetween")
			.attachKeyFrame()
			.colored(PonderPalette.RED)
			.pointAt(util.vector()
				.of(5.5, 2, 3))
			.placeNearTarget();
		scene.idle(60);

		scene.world()
			.multiplyKineticSpeed(util.select()
				.everywhere(), 16f);
		scene.idle(40);
		scene.world()
			.removeItemsFromBelt(util.grid()
				.at(5, 1, 5));
		PonderHilo.packagerUnpack(scene, pack, box1);
		scene.idle(15);
		insertItemsIntoCrafter(util, scene, new class_1799(class_1802.field_8620, 4));
		scene.idle(15);
		scene.world()
			.removeItemsFromBelt(util.grid()
				.at(5, 1, 5));
		PonderHilo.packagerUnpack(scene, pack, box2);
		scene.idle(15);
		insertItemsIntoCrafter(util, scene, new class_1799(class_1802.field_8118, 3));
		scene.idle(15);

		scene.overlay()
			.showControls(util.vector()
				.blockSurface(util.grid()
					.at(2, 3, 5), class_2350.field_11043),
				Pointing.DOWN, 40)
			.withItem(new class_1799(class_1802.field_8077));

		scene.idle(20);
		scene.world()
			.modifyBlockEntity(util.grid()
				.at(2, 2, 5), MechanicalCrafterBlockEntity.class, be -> be.ejectWholeGrid());
		scene.world()
			.removeItemsFromBelt(util.grid()
				.at(5, 1, 5));

		scene.idle(40);
		scene.world()
			.showSection(barrel, class_2350.field_11033);
		scene.world()
			.showSection(repackS, class_2350.field_11043);
		scene.rotateCameraY(-15);
		scene.idle(15);

		scene.overlay()
			.showText(80)
			.text("When this is the case, redirect packages to an inventory")
			.attachKeyFrame()
			.pointAt(util.vector()
				.blockSurface(util.grid()
					.at(5, 2, 1), class_2350.field_11039))
			.placeNearTarget();
		scene.idle(90);

		scene.overlay()
			.showText(60)
			.text("Attach a re-packager, and power it with redstone")
			.attachKeyFrame()
			.pointAt(util.vector()
				.blockSurface(util.grid()
					.at(5, 2, 2), class_2350.field_11039))
			.placeNearTarget();
		scene.idle(40);

		scene.world()
			.toggleRedstonePower(repackS);
		scene.effects()
			.indicateRedstone(util.grid()
				.at(5, 3, 2));
		scene.idle(40);

		scene.world()
			.restoreBlocks(f1s);
		scene.world()
			.restoreBlocks(f2s);
		scene.world()
			.showSection(f1s, class_2350.field_11033);
		scene.world()
			.showSection(f2s, class_2350.field_11033);
		scene.idle(5);
		scene.world()
			.showSection(f3s, class_2350.field_11033);
		scene.idle(20);

		scene.world()
			.createItemOnBelt(util.grid()
				.at(3, 1, 1), class_2350.field_11033, box1);
		scene.world()
			.createItemOnBelt(util.grid()
				.at(1, 1, 1), class_2350.field_11033, box2);
		scene.world()
			.createItemOnBelt(util.grid()
				.at(7, 1, 1), class_2350.field_11033, box3);
		scene.idle(23);
		scene.world()
			.removeItemsFromBelt(util.grid()
				.at(4, 1, 1));
		scene.world()
			.removeItemsFromBelt(util.grid()
				.at(6, 1, 1));
		scene.world()
			.flapFunnel(util.grid()
				.at(4, 2, 1), false);
		scene.idle(63);
		scene.world()
			.removeItemsFromBelt(util.grid()
				.at(4, 1, 1));
		scene.world()
			.flapFunnel(util.grid()
				.at(4, 2, 1), false);
		scene.idle(3);

		PonderHilo.packagerCreate(scene, repack, box3);
		scene.effects()
			.indicateSuccess(repack);
		scene.idle(20);

		scene.overlay()
			.showText(60)
			.text("Once all fragments arrived, they will be exported as a new package")
			.attachKeyFrame()
			.colored(PonderPalette.GREEN)
			.pointAt(util.vector()
				.of(5.5, 2, 3))
			.placeNearTarget();
		scene.idle(60);
		scene.world()
			.multiplyKineticSpeed(util.select()
				.everywhere(), 2f);
		scene.rotateCameraY(15);
		scene.world()
			.createItemOnBelt(util.grid()
				.at(5, 1, 3), class_2350.field_11043, box3);
		PonderHilo.packagerClear(scene, repack);
		scene.idle(20);
		PonderHilo.packagerCreate(scene, repack, box3);
		scene.idle(20);
		scene.world()
			.createItemOnBelt(util.grid()
				.at(5, 1, 3), class_2350.field_11043, box3);
		PonderHilo.packagerClear(scene, repack);
		scene.world()
			.removeItemsFromBelt(util.grid()
				.at(5, 1, 5));
		PonderHilo.packagerUnpack(scene, pack, box3);
		scene.idle(15);
		insertItemsIntoCrafter(util, scene, new class_1799(class_1802.field_8620, 9));
		scene.world()
			.setCraftingResult(util.grid()
				.at(2, 2, 5), new class_1799(class_1802.field_8773));
		scene.idle(15);

		scene.overlay()
			.showText(120)
			.text("Now, requested items arrive together and in a predictable order")
			.attachKeyFrame()
			.colored(PonderPalette.BLUE)
			.pointAt(util.vector()
				.blockSurface(util.grid()
					.at(2, 3, 5), class_2350.field_11043))
			.placeNearTarget();

		scene.idle(75);
		scene.world()
			.removeItemsFromBelt(util.grid()
				.at(5, 1, 5));
		PonderHilo.packagerUnpack(scene, pack, box3);
		scene.idle(15);
		insertItemsIntoCrafter(util, scene, new class_1799(class_1802.field_8118, 3));
		scene.world()
			.setCraftingResult(util.grid()
				.at(2, 2, 5), new class_1799(class_1802.field_8320));
		scene.idle(20);
		scene.world()
			.modifyBlockEntity(util.grid()
				.at(2, 2, 5), MechanicalCrafterBlockEntity.class, be -> be.checkCompletedRecipe(true));
	}

	private static void insertItemsIntoCrafter(SceneBuildingUtil util, CreateSceneBuilder scene, class_1799 stack) {
		scene.world()
			.modifyBlockEntity(util.grid()
				.at(3, 2, 5), class_2586.class, be -> {
					Storage<ItemVariant> storage = TransferUtil.getItemStorage(be);
					if (storage == null)
						return;
					TransferUtil.insertItem(storage, stack);
				});
	}

}
