package com.simibubi.create.foundation.block;

import com.simibubi.create.content.decoration.slidingDoor.SlidingDoorBlock;
import com.simibubi.create.content.trains.track.TrackBlock;
import net.minecraft.class_1922;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_4970;

/**
 * Implementing this interface will allow you to have bigger outlines when overriding {@link class_4970#method_9584(class_2680, class_1922, class_2338)}
 * <p>
 * For examples look at {@link TrackBlock} and {@link SlidingDoorBlock}
 */
public interface IHaveBigOutline { }
