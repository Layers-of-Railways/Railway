package com.simibubi.create;

import com.simibubi.create.content.equipment.armor.CapacityEnchantment;
import com.simibubi.create.content.equipment.potatoCannon.PotatoRecoveryEnchantment;
import com.simibubi.create.foundation.data.CreateRegistrate;
import com.tterrag.registrate.util.entry.RegistryEntry;
import net.minecraft.class_1304;
import net.minecraft.class_1886;
import net.minecraft.class_1887.class_1888;

public class AllEnchantments {
	private static final CreateRegistrate REGISTRATE = Create.registrate();

	public static final RegistryEntry<PotatoRecoveryEnchantment> POTATO_RECOVERY = REGISTRATE.object("potato_recovery")
		.enchantment(class_1886.field_9070, PotatoRecoveryEnchantment::new)
		.addSlots(class_1304.field_6173, class_1304.field_6171)
		.lang("Potato Recovery")
		.rarity(class_1888.field_9090)
		.register();

	public static final RegistryEntry<CapacityEnchantment> CAPACITY = REGISTRATE.object("capacity")
		.enchantment(class_1886.field_9071, CapacityEnchantment::new)
		.addSlots(class_1304.field_6174)
		.lang("Capacity")
		.rarity(class_1888.field_9087)
		.register();

	public static void register() {
	}

}
