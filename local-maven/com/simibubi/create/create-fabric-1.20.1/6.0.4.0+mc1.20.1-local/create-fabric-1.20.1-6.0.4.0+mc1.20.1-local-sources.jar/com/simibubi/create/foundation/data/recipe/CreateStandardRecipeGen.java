package com.simibubi.create.foundation.data.recipe;

import static com.simibubi.create.foundation.data.recipe.CompatMetals.ALUMINUM;
import static com.simibubi.create.foundation.data.recipe.CompatMetals.LEAD;
import static com.simibubi.create.foundation.data.recipe.CompatMetals.NICKEL;
import static com.simibubi.create.foundation.data.recipe.CompatMetals.OSMIUM;
import static com.simibubi.create.foundation.data.recipe.CompatMetals.PLATINUM;
import static com.simibubi.create.foundation.data.recipe.CompatMetals.QUICKSILVER;
import static com.simibubi.create.foundation.data.recipe.CompatMetals.SILVER;
import static com.simibubi.create.foundation.data.recipe.CompatMetals.TIN;
import static com.simibubi.create.foundation.data.recipe.CompatMetals.URANIUM;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.UnaryOperator;

import com.simibubi.create.api.data.recipe.BaseRecipeProvider;

import com.simibubi.create.api.data.recipe.CompactingRecipeGen;
import com.simibubi.create.foundation.data.recipe.CreateRecipeProvider.I;

import org.jetbrains.annotations.NotNull;

import com.google.common.base.Supplier;
import com.google.common.collect.ImmutableList;
import com.google.gson.JsonObject;
import com.simibubi.create.AllBlocks;
import com.simibubi.create.AllItems;
import com.simibubi.create.AllRecipeTypes;
import com.simibubi.create.AllTags;
import com.simibubi.create.AllTags.AllItemTags;
import com.simibubi.create.Create;
import com.simibubi.create.content.decoration.palettes.AllPaletteBlocks;
import com.simibubi.create.content.decoration.palettes.AllPaletteStoneTypes;
import com.tterrag.registrate.util.entry.BlockEntry;
import com.tterrag.registrate.util.entry.ItemEntry;
import com.tterrag.registrate.util.entry.ItemProviderEntry;

import net.createmod.catnip.platform.CatnipServices;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.resource.conditions.v1.ConditionJsonProvider;
import net.fabricmc.fabric.api.resource.conditions.v1.DefaultResourceConditions;
import net.minecraft.class_1767;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_1856;
import net.minecraft.class_1865;
import net.minecraft.class_1866;
import net.minecraft.class_1874;
import net.minecraft.class_1935;
import net.minecraft.class_2073;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2444;
import net.minecraft.class_2447;
import net.minecraft.class_2450;
import net.minecraft.class_2454;
import net.minecraft.class_2456;
import net.minecraft.class_2960;
import net.minecraft.class_3489;
import net.minecraft.class_6862;
import net.minecraft.class_7800;
import net.minecraft.class_8074;
import io.github.fabricators_of_create.porting_lib.tags.Tags;

/**
 * Create's own Data Generation for all vanilla recipe types.
 * @see class_2447
 * @see class_2450
 * @see class_2454
 * @see class_8074
 * @see class_2456
 * @see net.minecraftforge.common.crafting.ConditionalRecipe.Builder
 */
@SuppressWarnings("unused")
public final class CreateStandardRecipeGen extends BaseRecipeProvider {
	final List<GeneratedRecipe> all = new ArrayList<>();

	/*
	 * Recipes are added through fields, so one can navigate to the right one easily
	 *
	 * (Ctrl-o) in Eclipse
	 */

	private Marker MATERIALS = enterFolder("materials");

	GeneratedRecipe

	RAW_ZINC = create(AllItems.RAW_ZINC).returns(9)
		.unlockedBy(AllBlocks.RAW_ZINC_BLOCK::get)
		.viaShapeless(b -> b.method_10454(AllBlocks.RAW_ZINC_BLOCK.get())),

		RAW_ZINC_BLOCK = create(AllBlocks.RAW_ZINC_BLOCK).unlockedBy(AllItems.RAW_ZINC::get)
			.viaShaped(b -> b.method_10434('C', AllItems.RAW_ZINC.get())
				.method_10439("CCC")
				.method_10439("CCC")
				.method_10439("CCC")),

		COPPER_NUGGET = create(AllItems.COPPER_NUGGET).returns(9)
			.unlockedByTag(I::copper)
			.viaShapeless(b -> b.method_10446(I.copper())),

		COPPER_INGOT = create(() -> class_1802.field_27022).unlockedByTag(I::copperNugget)
			.viaShaped(b -> b.method_10433('C', I.copperNugget())
				.method_10439("CCC")
				.method_10439("CCC")
				.method_10439("CCC")),

		ANDESITE_ALLOY_FROM_BLOCK = create(AllItems.ANDESITE_ALLOY).withSuffix("_from_block")
			.returns(9)
			.unlockedBy(I::andesiteAlloy)
			.viaShapeless(b -> b.method_10454(AllBlocks.ANDESITE_ALLOY_BLOCK.get())),

		ANDESITE_ALLOY_BLOCK = create(AllBlocks.ANDESITE_ALLOY_BLOCK).unlockedBy(I::andesiteAlloy)
			.viaShaped(b -> b.method_10434('C', I.andesiteAlloy())
				.method_10439("CCC")
				.method_10439("CCC")
				.method_10439("CCC")),

		EXPERIENCE_FROM_BLOCK = create(AllItems.EXP_NUGGET).withSuffix("_from_block")
			.returns(9)
			.unlockedBy(AllItems.EXP_NUGGET::get)
			.viaShapeless(b -> b.method_10454(AllBlocks.EXPERIENCE_BLOCK.get())),

		EXPERIENCE_BLOCK = create(AllBlocks.EXPERIENCE_BLOCK).unlockedBy(AllItems.EXP_NUGGET::get)
			.viaShaped(b -> b.method_10434('C', AllItems.EXP_NUGGET.get())
				.method_10439("CCC")
				.method_10439("CCC")
				.method_10439("CCC")),

		CARDBOARD_BLOCK = create(AllBlocks.CARDBOARD_BLOCK).unlockedBy(I::cardboard)
			.viaShaped(b -> b.method_10434('C', I.cardboard())
				.method_10439("CC")
				.method_10439("CC")),

		BOUND_CARDBOARD_BLOCK = create(AllBlocks.BOUND_CARDBOARD_BLOCK).returns(1)
			.unlockedBy(I::cardboard)
			.viaShapeless(b -> b.method_10454(AllBlocks.CARDBOARD_BLOCK.get())
				.method_10454(class_1802.field_8276)),

		CARDBOARD_FROM_BLOCK = create(AllItems.CARDBOARD).withSuffix("_from_block")
			.returns(4)
			.unlockedBy(I::cardboard)
			.viaShapeless(b -> b.method_10454(AllBlocks.CARDBOARD_BLOCK.get())),

		CARDBOARD_FROM_BOUND_BLOCK = create(AllItems.CARDBOARD).withSuffix("_from_bound_block")
			.returns(4)
			.unlockedBy(I::cardboard)
			.viaShapeless(b -> b.method_10454(AllBlocks.BOUND_CARDBOARD_BLOCK.get())),

		BRASS_COMPACTING =
			metalCompacting(ImmutableList.of(AllItems.BRASS_NUGGET, AllItems.BRASS_INGOT, AllBlocks.BRASS_BLOCK),
				ImmutableList.of(I::brassNugget, I::brass, I::brassBlock)),

		ZINC_COMPACTING =
			metalCompacting(ImmutableList.of(AllItems.ZINC_NUGGET, AllItems.ZINC_INGOT, AllBlocks.ZINC_BLOCK),
				ImmutableList.of(I::zincNugget, I::zinc, I::zincBlock)),

		ROSE_QUARTZ_CYCLE =
			conversionCycle(ImmutableList.of(AllBlocks.ROSE_QUARTZ_TILES, AllBlocks.SMALL_ROSE_QUARTZ_TILES)),

		ANDESITE_ALLOY = create(AllItems.ANDESITE_ALLOY).unlockedByTag(I::iron)
			.viaShaped(b -> b.method_10434('A', class_2246.field_10115)
				.method_10433('B', Tags.Items.NUGGETS_IRON)
				.method_10439("BA")
				.method_10439("AB")),

		ANDESITE_ALLOY_FROM_ZINC = create(AllItems.ANDESITE_ALLOY).withSuffix("_from_zinc")
			.unlockedByTag(I::zinc)
			.viaShaped(b -> b.method_10434('A', class_2246.field_10115)
				.method_10433('B', I.zincNugget())
				.method_10439("BA")
				.method_10439("AB")),

		ELECTRON_TUBE = create(AllItems.ELECTRON_TUBE).unlockedBy(AllItems.ROSE_QUARTZ::get)
			.viaShaped(b -> b.method_10434('L', AllItems.POLISHED_ROSE_QUARTZ.get())
				.method_10433('N', I.ironSheet())
				.method_10439("L")
				.method_10439("N")),

		TRANSMITTER = create(AllItems.TRANSMITTER).unlockedByTag(I::copper)
			.viaShaped(b -> b.method_10433('L', I.copperSheet())
				.method_10434('N', class_1802.field_27051)
				.method_10433('R', I.redstone())
				.method_10439(" N ")
				.method_10439("LLL")
				.method_10439(" R ")),

		ROSE_QUARTZ = create(AllItems.ROSE_QUARTZ).unlockedBy(() -> class_1802.field_8725)
			.viaShapeless(b -> b.method_10446(Tags.Items.GEMS_QUARTZ)
				.method_10453(class_1856.method_8106(I.redstone()), 8)),

		SAND_PAPER = create(AllItems.SAND_PAPER).unlockedBy(() -> class_1802.field_8407)
			.viaShapeless(b -> b.method_10454(class_1802.field_8407)
				.method_10446(Tags.Items.SAND_COLORLESS)),

		RED_SAND_PAPER = create(AllItems.RED_SAND_PAPER).unlockedBy(() -> class_1802.field_8407)
			.viaShapeless(b -> b.method_10454(class_1802.field_8407)
				.method_10446(Tags.Items.SAND_RED))

	;

	private Marker CURIOSITIES = enterFolder("curiosities");

	GeneratedRecipe

	TOOLBOX = create(AllBlocks.TOOLBOXES.get(class_1767.field_7957)).unlockedByTag(I::goldSheet)
		.viaShaped(b -> b.method_10433('S', I.goldSheet())
			.method_10434('C', I.cog())
			.method_10433('W', Tags.Items.CHESTS_WOODEN)
			.method_10433('L', Tags.Items.LEATHER)
			.method_10439(" C ")
			.method_10439("SWS")
			.method_10439(" L ")),

		TOOLBOX_DYEING = createSpecial(AllRecipeTypes.TOOLBOX_DYEING::getSerializer, "crafting", "toolbox_dyeing"),
		ITEM_COPYING = createSpecial(AllRecipeTypes.ITEM_COPYING::getSerializer, "crafting", "item_copying"),

		MINECART_COUPLING = create(AllItems.MINECART_COUPLING).unlockedBy(I::andesiteAlloy)
			.viaShaped(b -> b.method_10434('E', I.andesiteAlloy())
				.method_10433('O', I.ironSheet())
				.method_10439("  E")
				.method_10439(" O ")
				.method_10439("E  ")),

		PECULIAR_BELL = create(AllBlocks.PECULIAR_BELL).unlockedByTag(I::brass)
			.viaShaped(b -> b.method_10433('I', I.brassBlock())
				.method_10433('P', I.brassSheet())
				.method_10439("I")
				.method_10439("P")),

		CAKE = create(() -> class_1802.field_17534).unlockedByTag(() -> AllTags.forgeItemTag("dough"))
			.viaShaped(b -> b.method_10433('E', Tags.Items.EGGS)
				.method_10434('S', class_1802.field_8479)
				.method_10433('P', AllTags.forgeItemTag("dough"))
				.method_10434('M', () -> class_1802.field_8103)
				.method_10439(" M ")
				.method_10439("SES")
				.method_10439(" P "))

	;

	private Marker KINETICS = enterFolder("kinetics");

	GeneratedRecipe BASIN = create(AllBlocks.BASIN).unlockedBy(I::andesiteAlloy)
		.viaShaped(b -> b.method_10434('A', I.andesiteAlloy())
			.method_10439("A A")
			.method_10439("AAA")),

		GOGGLES = create(AllItems.GOGGLES).unlockedBy(I::andesiteAlloy)
			.viaShaped(b -> b.method_10433('G', Tags.Items.GLASS)
				.method_10433('P', I.goldSheet())
				.method_10433('S', Tags.Items.STRING)
				.method_10439(" S ")
				.method_10439("GPG")),

		WRENCH = create(AllItems.WRENCH).unlockedBy(I::andesiteAlloy)
			.viaShaped(b -> b.method_10433('G', I.goldSheet())
				.method_10434('P', I.cog())
				.method_10433('S', Tags.Items.RODS_WOODEN)
				.method_10439("GG")
				.method_10439("GP")
				.method_10439(" S")),

		FILTER = create(AllItems.FILTER).unlockedBy(I::andesiteAlloy)
			.viaShaped(b -> b.method_10433('S', class_3489.field_15544)
				.method_10433('A', Tags.Items.NUGGETS_IRON)
				.method_10439("ASA")),

		ATTRIBUTE_FILTER = create(AllItems.ATTRIBUTE_FILTER).unlockedByTag(I::brass)
			.viaShaped(b -> b.method_10433('S', class_3489.field_15544)
				.method_10433('A', I.brassNugget())
				.method_10439("ASA")),

		PACKAGE_FILTER = create(AllItems.PACKAGE_FILTER).unlockedByTag(I::zinc)
			.viaShaped(b -> b.method_10433('S', class_3489.field_15544)
				.method_10433('A', I.zincNugget())
				.method_10439("ASA")),

		BRASS_HAND = create(AllItems.BRASS_HAND).unlockedByTag(I::brass)
			.viaShaped(b -> b.method_10434('A', I.andesiteAlloy())
				.method_10433('B', I.brassSheet())
				.method_10439(" A ")
				.method_10439("BBB")
				.method_10439(" B ")),

		SUPER_GLUE = create(AllItems.SUPER_GLUE).unlockedByTag(I::ironSheet)
			.viaShaped(b -> b.method_10433('A', Tags.Items.SLIMEBALLS)
				.method_10433('S', I.ironSheet())
				.method_10433('N', Tags.Items.NUGGETS_IRON)
				.method_10439("AS")
				.method_10439("NA")),

		CRAFTER_SLOT_COVER = create(AllItems.CRAFTER_SLOT_COVER).unlockedBy(AllBlocks.MECHANICAL_CRAFTER::get)
			.viaShaped(b -> b.method_10433('A', I.brassNugget())
				.method_10439("AAA")),

		COGWHEEL = create(AllBlocks.COGWHEEL).unlockedBy(I::andesiteAlloy)
			.viaShapeless(b -> b.method_10454(I.shaft())
				.method_10446(I.planks())),

		LARGE_COGWHEEL = create(AllBlocks.LARGE_COGWHEEL).unlockedBy(I::andesiteAlloy)
			.viaShapeless(b -> b.method_10454(I.shaft())
				.method_10446(I.planks())
				.method_10446(I.planks())),

		LARGE_COGWHEEL_FROM_LITTLE = create(AllBlocks.LARGE_COGWHEEL).withSuffix("_from_little")
			.unlockedBy(I::andesiteAlloy)
			.viaShapeless(b -> b.method_10454(I.cog())
				.method_10446(I.planks())),

		WATER_WHEEL = create(AllBlocks.WATER_WHEEL).unlockedBy(I::andesiteAlloy)
			.viaShaped(b -> b.method_10433('S', I.planks())
				.method_10434('C', I.shaft())
				.method_10439("SSS")
				.method_10439("SCS")
				.method_10439("SSS")),

		LARGE_WATER_WHEEL = create(AllBlocks.LARGE_WATER_WHEEL).unlockedBy(AllBlocks.WATER_WHEEL::get)
			.viaShaped(b -> b.method_10433('S', I.planks())
				.method_10434('C', AllBlocks.WATER_WHEEL.get())
				.method_10439("SSS")
				.method_10439("SCS")
				.method_10439("SSS")),

		SHAFT = create(AllBlocks.SHAFT).returns(8)
			.unlockedBy(I::andesiteAlloy)
			.viaShaped(b -> b.method_10434('A', I.andesiteAlloy())
				.method_10439("A")
				.method_10439("A")),

		MECHANICAL_PRESS = create(AllBlocks.MECHANICAL_PRESS).unlockedBy(I::andesiteCasing)
			.viaShaped(b -> b.method_10434('C', I.andesiteCasing())
				.method_10434('S', I.shaft())
				.method_10433('I', AllTags.forgeItemTag("iron_blocks"))
				.method_10439("S")
				.method_10439("C")
				.method_10439("I")),

		MILLSTONE = create(AllBlocks.MILLSTONE).unlockedBy(I::andesiteCasing)
			.viaShaped(b -> b.method_10434('C', I.cog())
				.method_10434('S', I.andesiteCasing())
				.method_10433('I', I.stone())
				.method_10439("C")
				.method_10439("S")
				.method_10439("I")),

		MECHANICAL_PISTON = create(AllBlocks.MECHANICAL_PISTON).unlockedBy(I::andesiteCasing)
			.viaShaped(b -> b.method_10433('B', class_3489.field_15534)
				.method_10434('C', I.andesiteCasing())
				.method_10434('I', AllBlocks.PISTON_EXTENSION_POLE.get())
				.method_10439("B")
				.method_10439("C")
				.method_10439("I")),

		STICKY_MECHANICAL_PISTON = create(AllBlocks.STICKY_MECHANICAL_PISTON).unlockedBy(I::andesiteAlloy)
			.viaShaped(b -> b.method_10433('S', Tags.Items.SLIMEBALLS)
				.method_10434('P', AllBlocks.MECHANICAL_PISTON.get())
				.method_10439("S")
				.method_10439("P")),

		TURNTABLE = create(AllBlocks.TURNTABLE).unlockedBy(I::andesiteAlloy)
			.viaShaped(b -> b.method_10434('S', I.shaft())
				.method_10433('P', class_3489.field_15534)
				.method_10439("P")
				.method_10439("S")),

		PISTON_EXTENSION_POLE = create(AllBlocks.PISTON_EXTENSION_POLE).returns(8)
			.unlockedBy(I::andesiteAlloy)
			.viaShaped(b -> b.method_10434('A', I.andesiteAlloy())
				.method_10433('P', class_3489.field_15537)
				.method_10439("P")
				.method_10439("A")
				.method_10439("P")),

		GANTRY_PINION = create(AllBlocks.GANTRY_CARRIAGE).unlockedBy(I::andesiteCasing)
			.viaShaped(b -> b.method_10433('B', class_3489.field_15534)
				.method_10434('C', I.andesiteCasing())
				.method_10434('I', I.cog())
				.method_10439("B")
				.method_10439("C")
				.method_10439("I")),

		GANTRY_SHAFT = create(AllBlocks.GANTRY_SHAFT).returns(8)
			.unlockedBy(I::andesiteAlloy)
			.viaShaped(b -> b.method_10434('A', I.andesiteAlloy())
				.method_10433('R', I.redstone())
				.method_10439("A")
				.method_10439("R")
				.method_10439("A")),

		PLACARD = create(AllBlocks.PLACARD).returns(1)
			.unlockedByTag(() -> I.brass())
			.viaShapeless(b -> b.method_10454(class_1802.field_8143)
				.method_10446(I.brassSheet())),

		TRAIN_DOOR = create(AllBlocks.TRAIN_DOOR).returns(1)
			.unlockedBy(() -> I.railwayCasing())
			.viaShapeless(b -> b.method_10446(class_3489.field_15552)
				.method_10454(I.railwayCasing())),

		ANDESITE_DOOR = create(AllBlocks.ANDESITE_DOOR).returns(1)
			.unlockedBy(() -> I.andesiteCasing())
			.viaShapeless(b -> b.method_10446(class_3489.field_15552)
				.method_10454(I.andesiteCasing())),

		BRASS_DOOR = create(AllBlocks.BRASS_DOOR).returns(1)
			.unlockedBy(() -> I.brassCasing())
			.viaShapeless(b -> b.method_10446(class_3489.field_15552)
				.method_10454(I.brassCasing())),

		COPPER_DOOR = create(AllBlocks.COPPER_DOOR).returns(1)
			.unlockedBy(() -> I.copperCasing())
			.viaShapeless(b -> b.method_10446(class_3489.field_15552)
				.method_10454(I.copperCasing())),

		TRAIN_TRAPDOOR = create(AllBlocks.TRAIN_TRAPDOOR).returns(1)
			.unlockedBy(() -> I.railwayCasing())
			.viaShapeless(b -> b.method_10446(class_3489.field_15550)
				.method_10454(I.railwayCasing())),

		FRAMED_GLASS_DOOR = create(AllBlocks.FRAMED_GLASS_DOOR).returns(1)
			.unlockedBy(AllPaletteBlocks.FRAMED_GLASS::get)
			.viaShapeless(b -> b.method_10446(class_3489.field_15552)
				.method_10454(AllPaletteBlocks.FRAMED_GLASS.get())),

		FRAMED_GLASS_TRAPDOOR = create(AllBlocks.FRAMED_GLASS_TRAPDOOR).returns(1)
			.unlockedBy(AllPaletteBlocks.FRAMED_GLASS::get)
			.viaShapeless(b -> b.method_10446(class_3489.field_15550)
				.method_10454(AllPaletteBlocks.FRAMED_GLASS.get())),

		ANALOG_LEVER = create(AllBlocks.ANALOG_LEVER).unlockedBy(I::andesiteAlloy)
			.viaShaped(b -> b.method_10434('S', I.andesiteCasing())
				.method_10433('P', Tags.Items.RODS_WOODEN)
				.method_10439("P")
				.method_10439("S")),

		ROSE_QUARTZ_LAMP = create(AllBlocks.ROSE_QUARTZ_LAMP).unlockedByTag(I::zinc)
			.viaShapeless(b -> b.method_10454(AllItems.POLISHED_ROSE_QUARTZ.get())
				.method_10446(I.redstone())
				.method_10446(I.zinc())),

		BELT_CONNECTOR = create(AllItems.BELT_CONNECTOR).unlockedBy(I::andesiteAlloy)
			.viaShaped(b -> b.method_10434('D', class_1802.field_8551)
				.method_10439("DDD")
				.method_10439("DDD")),

		ADJUSTABLE_PULLEY = create(AllBlocks.ADJUSTABLE_CHAIN_GEARSHIFT).unlockedBy(I::electronTube)
			.viaShapeless(b -> b.method_10454(AllBlocks.ENCASED_CHAIN_DRIVE.get())
				.method_10454(I.electronTube())),

		CART_ASSEMBLER = create(AllBlocks.CART_ASSEMBLER).unlockedBy(I::andesiteAlloy)
			.viaShaped(b -> b.method_10433('L', class_3489.field_15539)
				.method_10433('R', I.redstone())
				.method_10434('C', I.andesiteAlloy())
				.method_10439("CRC")
				.method_10439("L L")),

		CONTROLLER_RAIL = create(AllBlocks.CONTROLLER_RAIL).returns(6)
			.unlockedBy(() -> class_1802.field_8848)
			.viaShaped(b -> b.method_10433('A', I.gold())
				.method_10434('E', I.electronTube())
				.method_10433('S', Tags.Items.RODS_WOODEN)
				.method_10439("A A")
				.method_10439("ASA")
				.method_10439("AEA")),

		HAND_CRANK = create(AllBlocks.HAND_CRANK).unlockedBy(I::andesiteAlloy)
			.viaShaped(b -> b.method_10434('A', I.andesiteAlloy())
				.method_10433('C', class_3489.field_15537)
				.method_10439("CCC")
				.method_10439("  A")),

		COPPER_VALVE_HANDLE = create(AllBlocks.COPPER_VALVE_HANDLE).unlockedByTag(I::copper)
			.viaShaped(b -> b.method_10434('S', I.andesiteAlloy())
				.method_10433('C', I.copperSheet())
				.method_10439("CCC")
				.method_10439(" S ")),

		COPPER_VALVE_HANDLE_FROM_OTHER_HANDLES = create(AllBlocks.COPPER_VALVE_HANDLE).withSuffix("_from_others")
			.unlockedByTag(I::copper)
			.viaShapeless(b -> b.method_10446(AllItemTags.VALVE_HANDLES.tag)),

		NOZZLE = create(AllBlocks.NOZZLE).unlockedBy(AllBlocks.ENCASED_FAN::get)
			.viaShaped(b -> b.method_10434('S', I.andesiteAlloy())
				.method_10433('C', class_3489.field_15544)
				.method_10439(" S ")
				.method_10439(" C ")
				.method_10439("SSS")),

		PROPELLER = create(AllItems.PROPELLER).unlockedByTag(I::ironSheet)
			.viaShaped(b -> b.method_10433('S', I.ironSheet())
				.method_10434('C', I.andesiteAlloy())
				.method_10439(" S ")
				.method_10439("SCS")
				.method_10439(" S ")),

		WHISK = create(AllItems.WHISK).unlockedByTag(I::ironSheet)
			.viaShaped(b -> b.method_10433('S', I.ironSheet())
				.method_10434('C', I.andesiteAlloy())
				.method_10439(" C ")
				.method_10439("SCS")
				.method_10439("SSS")),

		ENCASED_FAN = create(AllBlocks.ENCASED_FAN).unlockedByTag(I::ironSheet)
			.viaShaped(b -> b.method_10434('A', I.andesiteCasing())
				.method_10434('S', I.shaft())
				.method_10434('P', AllItems.PROPELLER.get())
				.method_10439("S")
				.method_10439("A")
				.method_10439("P")),

		CUCKOO_CLOCK = create(AllBlocks.CUCKOO_CLOCK).unlockedBy(I::andesiteAlloy)
			.viaShaped(b -> b.method_10433('S', class_3489.field_15537)
				.method_10434('A', class_1802.field_8557)
				.method_10434('C', I.andesiteCasing())
				.method_10439("S")
				.method_10439("C")
				.method_10439("A")),

		MECHANICAL_CRAFTER = create(AllBlocks.MECHANICAL_CRAFTER).returns(3)
			.unlockedBy(I::brassCasing)
			.viaShaped(b -> b.method_10434('B', I.electronTube())
				.method_10434('R', class_2246.field_9980)
				.method_10434('C', I.brassCasing())
				.method_10439("B")
				.method_10439("C")
				.method_10439("R")),

		WINDMILL_BEARING = create(AllBlocks.WINDMILL_BEARING).unlockedBy(I::andesiteAlloy)
			.viaShaped(b -> b.method_10433('B', class_3489.field_15534)
				.method_10433('C', I.stone())
				.method_10434('I', I.shaft())
				.method_10439("B")
				.method_10439("C")
				.method_10439("I")),

		MECHANICAL_BEARING = create(AllBlocks.MECHANICAL_BEARING).unlockedBy(I::andesiteCasing)
			.viaShaped(b -> b.method_10433('B', class_3489.field_15534)
				.method_10434('C', I.andesiteCasing())
				.method_10434('I', I.shaft())
				.method_10439("B")
				.method_10439("C")
				.method_10439("I")),

		CLOCKWORK_BEARING = create(AllBlocks.CLOCKWORK_BEARING).unlockedBy(I::brassCasing)
			.viaShaped(b -> b.method_10434('S', I.electronTube())
				.method_10433('B', I.woodSlab())
				.method_10434('C', I.brassCasing())
				.method_10439("B")
				.method_10439("C")
				.method_10439("S")),

		WOODEN_BRACKET = create(AllBlocks.WOODEN_BRACKET).returns(4)
			.unlockedBy(I::andesiteAlloy)
			.viaShaped(b -> b.method_10433('S', Tags.Items.RODS_WOODEN)
				.method_10433('P', I.planks())
				.method_10434('C', I.andesiteAlloy())
				.method_10439("SSS")
				.method_10439("PCP")),

		METAL_BRACKET = create(AllBlocks.METAL_BRACKET).returns(4)
			.unlockedBy(I::andesiteAlloy)
			.viaShaped(b -> b.method_10433('S', Tags.Items.NUGGETS_IRON)
				.method_10433('P', I.iron())
				.method_10434('C', I.andesiteAlloy())
				.method_10439("SSS")
				.method_10439("PCP")),

		METAL_GIRDER = create(AllBlocks.METAL_GIRDER).returns(8)
			.unlockedBy(I::andesiteAlloy)
			.viaShaped(b -> b.method_10433('P', I.ironSheet())
				.method_10434('C', I.andesiteAlloy())
				.method_10439("PPP")
				.method_10439("CCC")),

		DISPLAY_BOARD = create(AllBlocks.DISPLAY_BOARD).returns(2)
			.unlockedBy(I::andesiteAlloy)
			.viaShaped(b -> b.method_10434('A', I.electronTube())
				.method_10434('P', I.andesiteAlloy())
				.method_10439("PAP")),

		STEAM_WHISTLE = create(AllBlocks.STEAM_WHISTLE).unlockedByTag(I::copper)
			.viaShaped(b -> b.method_10433('P', I.goldSheet())
				.method_10433('C', I.copper())
				.method_10439("P")
				.method_10439("C")),

		STEAM_ENGINE = create(AllBlocks.STEAM_ENGINE).unlockedByTag(I::copper)
			.viaShaped(b -> b.method_10433('P', I.goldSheet())
				.method_10433('C', I.copperBlock())
				.method_10434('A', I.andesiteAlloy())
				.method_10439("P")
				.method_10439("A")
				.method_10439("C")),

		FLUID_PIPE = create(AllBlocks.FLUID_PIPE).returns(4)
			.unlockedByTag(I::copper)
			.viaShaped(b -> b.method_10433('S', I.copperSheet())
				.method_10433('C', I.copper())
				.method_10439("SCS")),

		FLUID_PIPE_2 = create(AllBlocks.FLUID_PIPE).withSuffix("_vertical")
			.returns(4)
			.unlockedByTag(I::copper)
			.viaShaped(b -> b.method_10433('S', I.copperSheet())
				.method_10433('C', I.copper())
				.method_10439("S")
				.method_10439("C")
				.method_10439("S")),

		MECHANICAL_PUMP = create(AllBlocks.MECHANICAL_PUMP).unlockedByTag(I::copper)
			.viaShapeless(b -> b.method_10454(I.cog())
				.method_10454(AllBlocks.FLUID_PIPE.get())),

		SMART_FLUID_PIPE = create(AllBlocks.SMART_FLUID_PIPE).unlockedByTag(I::copper)
			.viaShaped(b -> b.method_10434('P', I.electronTube())
				.method_10434('S', AllBlocks.FLUID_PIPE.get())
				.method_10433('I', I.brassSheet())
				.method_10439("I")
				.method_10439("S")
				.method_10439("P")),

		FLUID_VALVE = create(AllBlocks.FLUID_VALVE).unlockedByTag(I::copper)
			.viaShapeless(b -> b.method_10446(I.ironSheet())
				.method_10454(AllBlocks.FLUID_PIPE.get())),

		SPOUT = create(AllBlocks.SPOUT).unlockedBy(I::copperCasing)
			.viaShaped(b -> b.method_10434('T', I.copperCasing())
				.method_10434('P', class_1802.field_8551)
				.method_10439("T")
				.method_10439("P")),

		ITEM_DRAIN = create(AllBlocks.ITEM_DRAIN).unlockedBy(I::copperCasing)
			.viaShaped(b -> b.method_10434('P', class_2246.field_10576)
				.method_10434('S', I.copperCasing())
				.method_10439("P")
				.method_10439("S")),

		FLUID_TANK = create(AllBlocks.FLUID_TANK).unlockedByTag(() -> Tags.Items.BARRELS_WOODEN)
			.viaShaped(b -> b.method_10433('B', I.copperSheet())
				.method_10433('C', Tags.Items.BARRELS_WOODEN)
				.method_10439("B")
				.method_10439("C")
				.method_10439("B")),

		ITEM_VAULT = create(AllBlocks.ITEM_VAULT).unlockedByTag(() -> Tags.Items.BARRELS_WOODEN)
			.viaShaped(b -> b.method_10433('B', I.ironSheet())
				.method_10433('C', Tags.Items.BARRELS_WOODEN)
				.method_10439("B")
				.method_10439("C")
				.method_10439("B")),

		TRAIN_SIGNAL = create(AllBlocks.TRACK_SIGNAL).unlockedBy(I::railwayCasing)
			.returns(4)
			.viaShapeless(b -> b.method_10454(I.railwayCasing())
				.method_10454(I.electronTube())),

		TRAIN_OBSERVER = create(AllBlocks.TRACK_OBSERVER).unlockedBy(I::railwayCasing)
			.returns(2)
			.viaShapeless(b -> b.method_10454(I.railwayCasing())
				.method_10446(class_3489.field_15540)),

		TRAIN_OBSERVER_2 = create(AllBlocks.TRACK_OBSERVER).withSuffix("_from_other_plates")
			.unlockedBy(I::railwayCasing)
			.returns(2)
			.viaShapeless(b -> b.method_10454(I.railwayCasing())
				.method_10451(class_1856.method_8091(class_1802.field_8667, class_1802.field_23835,
					class_1802.field_8592, class_1802.field_8721))),

		TRAIN_SCHEDULE = create(AllItems.SCHEDULE).unlockedByTag(I::sturdySheet)
			.returns(4)
			.viaShapeless(b -> b.method_10446(I.sturdySheet())
				.method_10454(class_1802.field_8407)),

		TRAIN_STATION = create(AllBlocks.TRACK_STATION).unlockedBy(I::railwayCasing)
			.returns(2)
			.viaShapeless(b -> b.method_10454(I.railwayCasing())
				.method_10454(class_1802.field_8251)),

		TRAIN_CONTROLS = create(AllBlocks.TRAIN_CONTROLS).unlockedBy(I::railwayCasing)
			.viaShaped(b -> b.method_10434('I', I.precisionMechanism())
				.method_10434('B', class_1802.field_8865)
				.method_10434('C', I.railwayCasing())
				.method_10439("B")
				.method_10439("C")
				.method_10439("I")),

		DEPLOYER = create(AllBlocks.DEPLOYER).unlockedBy(I::electronTube)
			.viaShaped(b -> b.method_10434('I', AllItems.BRASS_HAND.get())
				.method_10434('B', I.electronTube())
				.method_10434('C', I.andesiteCasing())
				.method_10439("B")
				.method_10439("C")
				.method_10439("I")),

		PORTABLE_STORAGE_INTERFACE = create(AllBlocks.PORTABLE_STORAGE_INTERFACE).unlockedBy(I::andesiteCasing)
			.viaShapeless(b -> b.method_10454(I.andesiteCasing())
				.method_10454(AllBlocks.CHUTE.get())),

		PORTABLE_FLUID_INTERFACE = create(AllBlocks.PORTABLE_FLUID_INTERFACE).unlockedBy(I::copperCasing)
			.viaShapeless(b -> b.method_10454(I.copperCasing())
				.method_10454(AllBlocks.CHUTE.get())),

		ROPE_PULLEY = create(AllBlocks.ROPE_PULLEY).unlockedBy(I::andesiteAlloy)
			.viaShaped(b -> b.method_10434('B', I.andesiteCasing())
				.method_10433('C', class_3489.field_15544)
				.method_10433('I', I.ironSheet())
				.method_10439("B")
				.method_10439("C")
				.method_10439("I")),

		HOSE_PULLEY = create(AllBlocks.HOSE_PULLEY).unlockedByTag(I::copper)
			.viaShaped(b -> b.method_10434('B', I.copperCasing())
				.method_10434('C', class_1802.field_17533)
				.method_10433('I', I.copperSheet())
				.method_10439("B")
				.method_10439("C")
				.method_10439("I")),

		ELEVATOR_PULLEY = create(AllBlocks.ELEVATOR_PULLEY).unlockedByTag(I::brass)
			.viaShaped(b -> b.method_10434('B', I.brassCasing())
				.method_10434('C', class_1802.field_17533)
				.method_10433('I', I.ironSheet())
				.method_10439("B")
				.method_10439("C")
				.method_10439("I")),

		CONTRAPTION_CONTROLS = create(AllBlocks.CONTRAPTION_CONTROLS).unlockedBy(I::andesiteAlloy)
			.viaShaped(b -> b.method_10433('B', class_3489.field_15551)
				.method_10434('C', I.andesiteCasing())
				.method_10434('I', I.electronTube())
				.method_10439("B")
				.method_10439("C")
				.method_10439("I")),

		EMPTY_BLAZE_BURNER = create(AllItems.EMPTY_BLAZE_BURNER).unlockedByTag(I::iron)
			.viaShaped(b -> b.method_10433('A', Tags.Items.NETHERRACK)
				.method_10433('I', I.ironSheet())
				.method_10439(" I ")
				.method_10439("IAI")
				.method_10439(" I ")),

		CHUTE = create(AllBlocks.CHUTE).unlockedBy(I::andesiteAlloy)
			.returns(4)
			.viaShaped(b -> b.method_10433('A', I.ironSheet())
				.method_10433('I', I.iron())
				.method_10439("A")
				.method_10439("I")
				.method_10439("A")),

		SMART_CHUTE = create(AllBlocks.SMART_CHUTE).unlockedBy(AllBlocks.CHUTE::get)
			.viaShaped(b -> b.method_10434('P', I.electronTube())
				.method_10434('S', AllBlocks.CHUTE.get())
				.method_10433('I', I.brassSheet())
				.method_10439("I")
				.method_10439("S")
				.method_10439("P")),

		DEPOT = create(AllBlocks.DEPOT).unlockedBy(I::andesiteCasing)
			.viaShapeless(b -> b.method_10454(I.andesiteAlloy())
				.method_10454(I.andesiteCasing())),

		WEIGHTED_EJECTOR = create(AllBlocks.WEIGHTED_EJECTOR).unlockedBy(I::andesiteCasing)
			.viaShaped(b -> b.method_10433('A', I.goldSheet())
				.method_10434('D', AllBlocks.DEPOT.get())
				.method_10434('I', I.cog())
				.method_10439("A")
				.method_10439("D")
				.method_10439("I")),

		MECHANICAL_ARM = create(AllBlocks.MECHANICAL_ARM::get).unlockedBy(I::brassCasing)
			.returns(1)
			.viaShaped(b -> b.method_10433('L', I.brassSheet())
				.method_10434('I', I.precisionMechanism())
				.method_10434('A', I.andesiteAlloy())
				.method_10434('C', I.brassCasing())
				.method_10439("LLA")
				.method_10439("L  ")
				.method_10439("IC ")),

		MECHANICAL_MIXER = create(AllBlocks.MECHANICAL_MIXER).unlockedBy(I::andesiteAlloy)
			.viaShaped(b -> b.method_10434('C', I.andesiteCasing())
				.method_10434('S', I.cog())
				.method_10434('I', AllItems.WHISK.get())
				.method_10439("S")
				.method_10439("C")
				.method_10439("I")),

		CLUTCH = create(AllBlocks.CLUTCH).unlockedBy(I::andesiteCasing)
			.viaShapeless(b -> b.method_10454(I.andesiteCasing())
				.method_10454(I.shaft())
				.method_10446(I.redstone())),

		GEARSHIFT = create(AllBlocks.GEARSHIFT).unlockedBy(I::andesiteCasing)
			.viaShapeless(b -> b.method_10454(I.andesiteCasing())
				.method_10454(I.cog())
				.method_10446(I.redstone())),

		SAIL = create(AllBlocks.SAIL).returns(2)
			.unlockedBy(I::andesiteAlloy)
			.viaShaped(b -> b.method_10433('W', class_3489.field_15544)
				.method_10433('S', Tags.Items.RODS_WOODEN)
				.method_10434('A', I.andesiteAlloy())
				.method_10439("WS")
				.method_10439("SA")),

		SAIL_CYCLE = conversionCycle(ImmutableList.of(AllBlocks.SAIL_FRAME, AllBlocks.SAIL)),

		RADIAL_CHASIS = create(AllBlocks.RADIAL_CHASSIS).returns(3)
			.unlockedBy(I::andesiteAlloy)
			.viaShaped(b -> b.method_10434('P', I.andesiteAlloy())
				.method_10433('L', class_3489.field_15539)
				.method_10439(" L ")
				.method_10439("PLP")
				.method_10439(" L ")),

		LINEAR_CHASIS = create(AllBlocks.LINEAR_CHASSIS).returns(3)
			.unlockedBy(I::andesiteAlloy)
			.viaShaped(b -> b.method_10434('P', I.andesiteAlloy())
				.method_10433('L', class_3489.field_15539)
				.method_10439(" P ")
				.method_10439("LLL")
				.method_10439(" P ")),

		LINEAR_CHASSIS_CYCLE =
			conversionCycle(ImmutableList.of(AllBlocks.LINEAR_CHASSIS, AllBlocks.SECONDARY_LINEAR_CHASSIS)),

		STICKER = create(AllBlocks.STICKER).returns(1)
			.unlockedBy(I::andesiteAlloy)
			.viaShaped(b -> b.method_10434('I', I.andesiteAlloy())
				.method_10433('C', Tags.Items.COBBLESTONE)
				.method_10433('R', I.redstone())
				.method_10433('S', Tags.Items.SLIMEBALLS)
				.method_10439("ISI")
				.method_10439("CRC")),

		MINECART = create(() -> class_1802.field_8045).withSuffix("_from_contraption_cart")
			.unlockedBy(AllBlocks.CART_ASSEMBLER::get)
			.viaShapeless(b -> b.method_10454(AllItems.MINECART_CONTRAPTION.get())),

		FURNACE_MINECART = create(() -> class_1802.field_8063).withSuffix("_from_contraption_cart")
			.unlockedBy(AllBlocks.CART_ASSEMBLER::get)
			.viaShapeless(b -> b.method_10454(AllItems.FURNACE_MINECART_CONTRAPTION.get())),

		GEARBOX = create(AllBlocks.GEARBOX).unlockedBy(I::cog)
			.viaShaped(b -> b.method_10434('C', I.cog())
				.method_10434('B', I.andesiteCasing())
				.method_10439(" C ")
				.method_10439("CBC")
				.method_10439(" C ")),

		VERTICAL_GEARBOX = create(AllItems.VERTICAL_GEARBOX).unlockedBy(I::cog)
			.viaShaped(b -> b.method_10434('C', I.cog())
				.method_10434('B', I.andesiteCasing())
				.method_10439("C C")
				.method_10439(" B ")
				.method_10439("C C")),

		GEARBOX_CYCLE = conversionCycle(ImmutableList.of(AllBlocks.GEARBOX, AllItems.VERTICAL_GEARBOX)),

		MYSTERIOUS_CUCKOO_CLOCK = create(AllBlocks.MYSTERIOUS_CUCKOO_CLOCK).unlockedBy(AllBlocks.CUCKOO_CLOCK::get)
			.viaShaped(b -> b.method_10433('C', Tags.Items.GUNPOWDER)
				.method_10434('B', AllBlocks.CUCKOO_CLOCK.get())
				.method_10439(" C ")
				.method_10439("CBC")
				.method_10439(" C ")),

		ENCASED_CHAIN_DRIVE = create(AllBlocks.ENCASED_CHAIN_DRIVE).unlockedBy(I::andesiteCasing)
			.viaShapeless(b -> b.method_10454(I.andesiteCasing())
				.method_10446(I.ironNugget())
				.method_10446(I.ironNugget())
				.method_10446(I.ironNugget())),

		ENCASED_CHAIN_DRIVE_ZINC = create(AllBlocks.ENCASED_CHAIN_DRIVE).withSuffix("_from_zinc").unlockedBy(I::andesiteCasing)
			.viaShapeless(b -> b.method_10454(I.andesiteCasing())
				.method_10446(I.zincNugget())
				.method_10446(I.zincNugget())
				.method_10446(I.zincNugget())),

		FLYWHEEL = create(AllBlocks.FLYWHEEL).unlockedByTag(I::brass)
			.viaShaped(b -> b.method_10433('C', I.brass())
				.method_10434('A', I.shaft())
				.method_10439("CCC")
				.method_10439("CAC")
				.method_10439("CCC")),

		SPEEDOMETER = create(AllBlocks.SPEEDOMETER).unlockedBy(I::andesiteAlloy)
			.viaShaped(b -> b.method_10434('C', class_1802.field_8251)
				.method_10434('A', I.andesiteCasing())
				.method_10439("C")
				.method_10439("A")),

		GAUGE_CYCLE = conversionCycle(ImmutableList.of(AllBlocks.SPEEDOMETER, AllBlocks.STRESSOMETER)),

		ROTATION_SPEED_CONTROLLER = create(AllBlocks.ROTATION_SPEED_CONTROLLER).unlockedBy(I::brassCasing)
			.viaShaped(b -> b.method_10434('B', I.precisionMechanism())
				.method_10434('C', I.brassCasing())
				.method_10439("B")
				.method_10439("C")),

		NIXIE_TUBE = create(AllBlocks.ORANGE_NIXIE_TUBE).returns(4)
			.unlockedBy(I::brassCasing)
			.viaShapeless(b -> b.method_10454(I.electronTube())
				.method_10454(I.electronTube())),

		MECHANICAL_SAW = create(AllBlocks.MECHANICAL_SAW).unlockedBy(I::andesiteCasing)
			.viaShaped(b -> b.method_10434('C', I.andesiteCasing())
				.method_10433('A', I.ironSheet())
				.method_10433('I', I.iron())
				.method_10439(" A ")
				.method_10439("AIA")
				.method_10439(" C ")),

		MECHANICAL_HARVESTER = create(AllBlocks.MECHANICAL_HARVESTER).unlockedBy(I::andesiteCasing)
			.viaShaped(b -> b.method_10434('C', I.andesiteCasing())
				.method_10434('A', I.andesiteAlloy())
				.method_10433('I', I.ironSheet())
				.method_10439("AIA")
				.method_10439("AIA")
				.method_10439(" C ")),

		MECHANICAL_PLOUGH = create(AllBlocks.MECHANICAL_PLOUGH).unlockedBy(I::andesiteCasing)
			.viaShaped(b -> b.method_10434('C', I.andesiteCasing())
				.method_10434('A', I.andesiteAlloy())
				.method_10433('I', I.ironSheet())
				.method_10439("III")
				.method_10439("AAA")
				.method_10439(" C ")),

		MECHANICAL_ROLLER = create(AllBlocks.MECHANICAL_ROLLER).unlockedBy(I::andesiteCasing)
			.viaShaped(b -> b.method_10434('C', I.andesiteCasing())
				.method_10434('A', I.electronTube())
				.method_10434('I', AllBlocks.CRUSHING_WHEEL.get())
				.method_10439("A")
				.method_10439("C")
				.method_10439("I")),

		MECHANICAL_DRILL = create(AllBlocks.MECHANICAL_DRILL).unlockedBy(I::andesiteCasing)
			.viaShaped(b -> b.method_10434('C', I.andesiteCasing())
				.method_10434('A', I.andesiteAlloy())
				.method_10433('I', I.iron())
				.method_10439(" A ")
				.method_10439("AIA")
				.method_10439(" C ")),

		CHAIN_CONVEYOR = create(AllBlocks.CHAIN_CONVEYOR).unlockedBy(I::andesiteCasing)
			.returns(2)
			.viaShaped(b -> b.method_10434('C', I.andesiteCasing())
				.method_10434('A', I.largeCog())
				.method_10439(" C ")
				.method_10439("CAC")
				.method_10439(" C ")),

		SEQUENCED_GEARSHIFT = create(AllBlocks.SEQUENCED_GEARSHIFT).unlockedBy(I::brassCasing)
			.viaShapeless(b -> b.method_10454(I.brassCasing())
				.method_10454(I.cog())
				.method_10454(I.electronTube()))

	;

	private Marker LOGISTICS = enterFolder("logistics");

	GeneratedRecipe

	REDSTONE_CONTACT = create(AllBlocks.REDSTONE_CONTACT).returns(2)
		.unlockedBy(I::brassCasing)
		.viaShaped(b -> b.method_10433('W', I.redstone())
			.method_10434('C', class_2246.field_10445)
			.method_10433('S', I.ironSheet())
			.method_10439(" S ")
			.method_10439("CWC")
			.method_10439("CCC")),

		ANDESITE_FUNNEL = create(AllBlocks.ANDESITE_FUNNEL).returns(2)
			.unlockedBy(I::andesiteAlloy)
			.viaShaped(b -> b.method_10434('A', I.andesiteAlloy())
				.method_10434('K', class_1802.field_8551)
				.method_10439("A")
				.method_10439("K")),

		BRASS_FUNNEL = create(AllBlocks.BRASS_FUNNEL).returns(2)
			.unlockedByTag(I::brass)
			.viaShaped(b -> b.method_10433('A', I.brass())
				.method_10434('K', class_1802.field_8551)
				.method_10434('E', I.electronTube())
				.method_10439("E")
				.method_10439("A")
				.method_10439("K")),

		ANDESITE_TUNNEL = create(AllBlocks.ANDESITE_TUNNEL).returns(2)
			.unlockedBy(I::andesiteAlloy)
			.viaShaped(b -> b.method_10434('A', I.andesiteAlloy())
				.method_10434('K', class_1802.field_8551)
				.method_10439("AA")
				.method_10439("KK")),

		BRASS_TUNNEL = create(AllBlocks.BRASS_TUNNEL).returns(2)
			.unlockedByTag(I::brass)
			.viaShaped(b -> b.method_10433('A', I.brass())
				.method_10434('K', class_1802.field_8551)
				.method_10434('E', I.electronTube())
				.method_10439("E ")
				.method_10439("AA")
				.method_10439("KK")),

		SMART_OBSERVER = create(AllBlocks.SMART_OBSERVER).unlockedBy(I::brassCasing)
			.viaShaped(b -> b.method_10434('B', I.brassCasing())
				.method_10434('R', I.electronTube())
				.method_10434('I', class_2246.field_10282)
				.method_10439("R")
				.method_10439("B")
				.method_10439("I")),

		THRESHOLD_SWITCH = create(AllBlocks.THRESHOLD_SWITCH).unlockedBy(I::brassCasing)
			.viaShaped(b -> b.method_10434('B', I.brassCasing())
				.method_10434('R', I.electronTube())
				.method_10434('I', class_2246.field_10377)
				.method_10439("R")
				.method_10439("B")
				.method_10439("I")),

		PULSE_EXTENDER = create(AllBlocks.PULSE_EXTENDER).unlockedByTag(I::redstone)
			.viaShaped(b -> b.method_10434('T', class_2246.field_10523)
				.method_10433('C', I.brassSheet())
				.method_10433('R', I.redstone())
				.method_10433('S', I.stone())
				.method_10439("  T")
				.method_10439("RCT")
				.method_10439("SSS")),

		PULSE_REPEATER = create(AllBlocks.PULSE_REPEATER).unlockedByTag(I::redstone)
			.viaShaped(b -> b.method_10434('T', class_2246.field_10523)
				.method_10433('C', I.brassSheet())
				.method_10433('R', I.redstone())
				.method_10433('S', I.stone())
				.method_10439("RCT")
				.method_10439("SSS")),

		PULSE_TIMER = create(AllBlocks.PULSE_TIMER).unlockedByTag(I::redstone)
			.viaShaped(b -> b.method_10434('T', class_2246.field_10523)
				.method_10433('C', I.brassSheet())
				.method_10434('R', class_1802.field_27063)
				.method_10433('S', I.stone())
				.method_10439("RCT")
				.method_10439("SSS")),

		POWERED_TOGGLE_LATCH = create(AllBlocks.POWERED_TOGGLE_LATCH).unlockedByTag(I::redstone)
			.viaShaped(b -> b.method_10434('T', class_2246.field_10523)
				.method_10434('C', class_2246.field_10363)
				.method_10433('S', I.stone())
				.method_10439(" T ")
				.method_10439(" C ")
				.method_10439("SSS")),

		POWERED_LATCH = create(AllBlocks.POWERED_LATCH).unlockedByTag(I::redstone)
			.viaShaped(b -> b.method_10434('T', class_2246.field_10523)
				.method_10434('C', class_2246.field_10363)
				.method_10433('R', I.redstone())
				.method_10433('S', I.stone())
				.method_10439(" T ")
				.method_10439("RCR")
				.method_10439("SSS")),

		REDSTONE_LINK = create(AllBlocks.REDSTONE_LINK).returns(2)
			.unlockedBy(I::andesiteCasing)
			.viaShaped(b -> b.method_10434('C', AllItems.TRANSMITTER)
				.method_10434('S', I.andesiteCasing())
				.method_10439("C")
				.method_10439("S")),

		ITEM_HATCH = create(AllBlocks.ITEM_HATCH).unlockedBy(I::andesiteAlloy)
			.viaShapeless(b -> b.method_10454(I.andesiteAlloy())
				.method_10454(class_1802.field_8241)),

		PACKAGER = create(AllBlocks.PACKAGER).unlockedBy(I::cardboard)
			.viaShaped(b -> b.method_10433('C', I.iron())
				.method_10434('A', AllBlocks.CARDBOARD_BLOCK)
				.method_10433('R', I.redstone())
				.method_10439(" C ")
				.method_10439("CAC")
				.method_10439("RCR")),

		PACKAGER_CYCLE = conversionCycle(ImmutableList.of(AllBlocks.PACKAGER, AllBlocks.REPACKAGER)),

		PACKAGE_FROGPORT = create(AllBlocks.PACKAGE_FROGPORT).unlockedBy(I::cardboard)
			.viaShaped(b -> b.method_10434('C', I.andesiteAlloy())
				.method_10433('B', Tags.Items.SLIMEBALLS)
				.method_10434('A', I.vault())
				.method_10439("B")
				.method_10439("A")
				.method_10439("C")),

		STOCK_LINK = create(AllBlocks.STOCK_LINK).unlockedBy(I::cardboard)
			.viaShaped(b -> b.method_10434('C', AllItems.TRANSMITTER.get())
				.method_10434('B', I.vault())
				.method_10439("C")
				.method_10439("B")),

		STOCK_TICKER = create(AllBlocks.STOCK_TICKER).unlockedBy(I::cardboard)
			.viaShaped(b -> b.method_10433('C', Tags.Items.GLASS)
				.method_10433('B', I.gold())
				.method_10434('A', I.stockLink())
				.method_10439("C")
				.method_10439("A")
				.method_10439("B")),

		REDSTONE_REQUESTER = create(AllBlocks.REDSTONE_REQUESTER).unlockedBy(I::cardboard)
			.viaShaped(b -> b.method_10433('C', I.redstone())
				.method_10433('B', I.iron())
				.method_10434('A', I.stockLink())
				.method_10439("C")
				.method_10439("A")
				.method_10439("B")),

		FACTORY_GAUGE = create(AllBlocks.FACTORY_GAUGE).unlockedBy(I::stockLink)
			.returns(2)
			.viaShapeless(b -> b.method_10454(I.stockLink())
				.method_10454(I.precisionMechanism())),

		DESK_BELL = create(AllBlocks.DESK_BELL).unlockedBy(I::andesiteCasing)
			.viaShapeless(b -> b.method_10454(I.andesiteCasing())
				.method_10446(I.goldSheet())),

		LOGISTICS_LINK_CLEAR = clearData(AllBlocks.STOCK_LINK), STOCK_TICKER_CLEAR = clearData(AllBlocks.STOCK_TICKER),
		REDSTONE_REQUESTER_CLEAR = clearData(AllBlocks.REDSTONE_REQUESTER),
		FACTORY_PANEL_CLEAR = clearData(AllBlocks.FACTORY_GAUGE),

		DISPLAY_LINK = create(AllBlocks.DISPLAY_LINK).unlockedBy(I::brassCasing)
			.viaShaped(b -> b.method_10434('C', AllItems.TRANSMITTER.get())
				.method_10434('S', I.brassCasing())
				.method_10439("C")
				.method_10439("S"))

	;

	private Marker SCHEMATICS = enterFolder("schematics");

	GeneratedRecipe

	SCHEMATIC_TABLE = create(AllBlocks.SCHEMATIC_TABLE).unlockedBy(AllItems.EMPTY_SCHEMATIC::get)
		.viaShaped(b -> b.method_10433('W', class_3489.field_15534)
			.method_10434('S', class_2246.field_10360)
			.method_10439("WWW")
			.method_10439(" S ")
			.method_10439(" S ")),

		SCHEMATICANNON = create(AllBlocks.SCHEMATICANNON).unlockedBy(AllItems.EMPTY_SCHEMATIC::get)
			.viaShaped(b -> b.method_10433('L', class_3489.field_15539)
				.method_10434('D', class_2246.field_10200)
				.method_10434('S', class_2246.field_10360)
				.method_10434('I', class_2246.field_10085)
				.method_10439(" I ")
				.method_10439("LIL")
				.method_10439("SDS")),

		EMPTY_SCHEMATIC = create(AllItems.EMPTY_SCHEMATIC).unlockedBy(() -> class_1802.field_8407)
			.viaShapeless(b -> b.method_10454(class_1802.field_8407)
				.method_10446(Tags.Items.DYES_LIGHT_BLUE)),

		SCHEMATIC_AND_QUILL = create(AllItems.SCHEMATIC_AND_QUILL).unlockedBy(() -> class_1802.field_8407)
			.viaShapeless(b -> b.method_10454(AllItems.EMPTY_SCHEMATIC.get())
				.method_10446(Tags.Items.FEATHERS))

	;

	private Marker PALETTES = enterFolder("palettes");

	GeneratedRecipe

	SCORCHIA = create(AllPaletteStoneTypes.SCORCHIA.getBaseBlock()::get).returns(8)
		.unlockedBy(AllPaletteStoneTypes.SCORIA.getBaseBlock()::get)
		.viaShaped(b -> b.method_10434('#', AllPaletteStoneTypes.SCORIA.getBaseBlock()
			.get())
			.method_10433('D', Tags.Items.DYES_BLACK)
			.method_10439("###")
			.method_10439("#D#")
			.method_10439("###"))

	;

	private Marker APPLIANCES = enterFolder("appliances");

	GeneratedRecipe

	DOUGH = create(AllItems.DOUGH).unlockedByTag(I::wheatFlour)
		.viaShapeless(b -> b.method_10446(I.wheatFlour())
			.method_10454(class_1802.field_8705)),

		CHAIN_FROM_ZINC = create(() -> class_1802.field_23983).withSuffix("_from_zinc")
			.unlockedByTag(I::zinc)
			.viaShaped(b -> b.method_10433('C', I.zinc())
				.method_10433('S', I.zincNugget())
				.method_10439("S")
				.method_10439("C")
				.method_10439("S")),

		CLIPBOARD = create(AllBlocks.CLIPBOARD).unlockedBy(I::andesiteAlloy)
			.viaShaped(b -> b.method_10433('G', I.planks())
				.method_10434('P', class_1802.field_8407)
				.method_10434('A', I.andesiteAlloy())
				.method_10439("A")
				.method_10439("P")
				.method_10439("G")),

		CLIPBOARD_CLEAR = clearData(AllBlocks.CLIPBOARD), SCHEDULE_CLEAR = clearData(AllItems.SCHEDULE),
		FILTER_CLEAR = clearData(AllItems.FILTER), ATTRIBUTE_FILTER_CLEAR = clearData(AllItems.ATTRIBUTE_FILTER),
		PACKAGE_FILTER_CLEAR = clearData(AllItems.PACKAGE_FILTER),

		CARDBOARD_SWORD = create(AllItems.CARDBOARD_SWORD).unlockedBy(I::cardboard)
			.viaShaped(b -> b.method_10434('P', I.cardboard())
				.method_10433('S', Tags.Items.RODS_WOODEN)
				.method_10439("P")
				.method_10439("P")
				.method_10439("S")),

		CARDBOARD_HELMET = create(AllItems.CARDBOARD_HELMET).unlockedBy(I::cardboard)
			.viaShaped(b -> b.method_10434('P', I.cardboard())
				.method_10439("PPP")
				.method_10439("P P")),

		CARDBOARD_CHESTPLATE = create(AllItems.CARDBOARD_CHESTPLATE).unlockedBy(I::cardboard)
			.viaShaped(b -> b.method_10434('P', I.cardboard())
				.method_10439("P P")
				.method_10439("PPP")
				.method_10439("PPP")),

		CARDBOARD_LEGGINGS = create(AllItems.CARDBOARD_LEGGINGS).unlockedBy(I::cardboard)
			.viaShaped(b -> b.method_10434('P', I.cardboard())
				.method_10439("PPP")
				.method_10439("P P")
				.method_10439("P P")),

		CARDBOARD_BOOTS = create(AllItems.CARDBOARD_BOOTS).unlockedBy(I::cardboard)
			.viaShaped(b -> b.method_10434('P', I.cardboard())
				.method_10439("P P")
				.method_10439("P P")),

		DIVING_HELMET = create(AllItems.COPPER_DIVING_HELMET).unlockedByTag(I::copper)
			.viaShaped(b -> b.method_10433('G', Tags.Items.GLASS)
				.method_10433('P', I.copper())
				.method_10439("PPP")
				.method_10439("PGP")),

		COPPER_BACKTANK = create(AllItems.COPPER_BACKTANK).unlockedByTag(I::copper)
			.viaShaped(b -> b.method_10434('G', I.shaft())
				.method_10434('A', I.andesiteAlloy())
				.method_10433('B', I.copperBlock())
				.method_10433('P', I.copper())
				.method_10439("AGA")
				.method_10439("PBP")
				.method_10439(" P ")),

		DIVING_BOOTS = create(AllItems.COPPER_DIVING_BOOTS).unlockedByTag(I::copper)
			.viaShaped(b -> b.method_10434('G', I.andesiteAlloy())
				.method_10433('P', I.copper())
				.method_10439("P P")
				.method_10439("P P")
				.method_10439("G G")),

		LINKED_CONTROLLER = create(AllItems.LINKED_CONTROLLER).unlockedBy(AllBlocks.REDSTONE_LINK::get)
			.viaShaped(b -> b.method_10433('S', class_3489.field_15555)
				.method_10434('P', AllBlocks.REDSTONE_LINK.get())
				.method_10439("SSS")
				.method_10439(" P ")
				.method_10439("SSS")),

		CRAFTING_BLUEPRINT = create(AllItems.CRAFTING_BLUEPRINT).unlockedBy(() -> class_1802.field_8465)
			.viaShapeless(b -> b.method_10454(class_1802.field_8892)
				.method_10454(class_1802.field_8465)),

		SLIME_BALL = create(() -> class_1802.field_8777).unlockedBy(AllItems.DOUGH::get)
			.viaShapeless(b -> b.method_10454(AllItems.DOUGH.get())
				.method_10446(Tags.Items.DYES_LIME)),

		BOOK = create(() -> class_1802.field_8529).unlockedBy(I::cardboard)
			.viaShapeless(b -> b.method_10454(I.cardboard())
				.method_10454(class_1802.field_8407)
				.method_10454(class_1802.field_8407)
				.method_10454(class_1802.field_8407)),

		NAME_TAG = create(() -> class_1802.field_8448).unlockedBy(I::cardboard)
			.viaShapeless(b -> b.method_10446(Tags.Items.DYES_BLACK)
				.method_10446(Tags.Items.STRING)
				.method_10454(I.cardboard())),

		ITEM_FRAME = create(() -> class_1802.field_8143).unlockedBy(I::cardboard)
			.viaShaped(b -> b.method_10433('S', Tags.Items.RODS_WOODEN)
				.method_10434('P', I.cardboard())
				.method_10439("SSS")
				.method_10439("SPS")
				.method_10439("SSS")),

		TREE_FERTILIZER = create(AllItems.TREE_FERTILIZER).returns(2)
			.unlockedBy(() -> class_1802.field_8324)
			.viaShapeless(b -> b.method_10453(class_1856.method_8106(class_3489.field_15543), 2)
				.method_10451(class_1856.method_8091(class_1802.field_8723, class_1802.field_8616, class_1802.field_8847, class_1802.field_8538,
					class_1802.field_8546))
				.method_10454(class_1802.field_8324)),

		NETHERITE_DIVING_HELMET = create(AllItems.NETHERITE_DIVING_HELMET)
			.viaNetheriteSmithing(AllItems.COPPER_DIVING_HELMET::get, I::netherite),
		NETHERITE_BACKTANK =
			create(AllItems.NETHERITE_BACKTANK).viaNetheriteSmithing(AllItems.COPPER_BACKTANK::get, I::netherite),
		NETHERITE_DIVING_BOOTS = create(AllItems.NETHERITE_DIVING_BOOTS)
			.viaNetheriteSmithing(AllItems.COPPER_DIVING_BOOTS::get, I::netherite),

		NETHERITE_DIVING_HELMET_2 = create(AllItems.NETHERITE_DIVING_HELMET).withSuffix("_from_netherite")
			.viaNetheriteSmithing(() -> class_1802.field_22027,
				() -> class_1856.method_8091(AllItems.COPPER_DIVING_HELMET.get())),
		NETHERITE_BACKTANK_2 = create(AllItems.NETHERITE_BACKTANK).withSuffix("_from_netherite")
			.viaNetheriteSmithing(() -> class_1802.field_22028,
				() -> class_1856.method_8091(AllItems.COPPER_BACKTANK.get())),
		NETHERITE_DIVING_BOOTS_2 = create(AllItems.NETHERITE_DIVING_BOOTS).withSuffix("_from_netherite")
			.viaNetheriteSmithing(() -> class_1802.field_22030, () -> class_1856.method_8091(AllItems.COPPER_DIVING_BOOTS.get()))

	;

	private Marker COOKING = enterFolder("/");

	GeneratedRecipe

	DOUGH_TO_BREAD = create(() -> class_1802.field_8229).viaCooking(AllItems.DOUGH::get)
		.inSmoker(),

		SOUL_SAND = create(AllPaletteStoneTypes.SCORIA.getBaseBlock()::get).viaCooking(() -> class_2246.field_10114)
			.inFurnace(),

		FRAMED_GLASS = recycleGlass(AllPaletteBlocks.FRAMED_GLASS),
		TILED_GLASS = recycleGlass(AllPaletteBlocks.TILED_GLASS),
		VERTICAL_FRAMED_GLASS = recycleGlass(AllPaletteBlocks.VERTICAL_FRAMED_GLASS),
		HORIZONTAL_FRAMED_GLASS = recycleGlass(AllPaletteBlocks.HORIZONTAL_FRAMED_GLASS),
		FRAMED_GLASS_PANE = recycleGlassPane(AllPaletteBlocks.FRAMED_GLASS_PANE),
		TILED_GLASS_PANE = recycleGlassPane(AllPaletteBlocks.TILED_GLASS_PANE),
		VERTICAL_FRAMED_GLASS_PANE = recycleGlassPane(AllPaletteBlocks.VERTICAL_FRAMED_GLASS_PANE),
		HORIZONTAL_FRAMED_GLASS_PANE = recycleGlassPane(AllPaletteBlocks.HORIZONTAL_FRAMED_GLASS_PANE),

		CRUSHED_IRON = blastCrushedMetal(() -> class_1802.field_8620, AllItems.CRUSHED_IRON::get),
		CRUSHED_GOLD = blastCrushedMetal(() -> class_1802.field_8695, AllItems.CRUSHED_GOLD::get),
		CRUSHED_COPPER = blastCrushedMetal(() -> class_1802.field_27022, AllItems.CRUSHED_COPPER::get),
		CRUSHED_ZINC = blastCrushedMetal(AllItems.ZINC_INGOT::get, AllItems.CRUSHED_ZINC::get),

		CRUSHED_OSMIUM = blastModdedCrushedMetal(AllItems.CRUSHED_OSMIUM, OSMIUM),
		CRUSHED_PLATINUM = blastModdedCrushedMetal(AllItems.CRUSHED_PLATINUM, PLATINUM),
		CRUSHED_SILVER = blastModdedCrushedMetal(AllItems.CRUSHED_SILVER, SILVER),
		CRUSHED_TIN = blastModdedCrushedMetal(AllItems.CRUSHED_TIN, TIN),
		CRUSHED_LEAD = blastModdedCrushedMetal(AllItems.CRUSHED_LEAD, LEAD),
		CRUSHED_QUICKSILVER = blastModdedCrushedMetal(AllItems.CRUSHED_QUICKSILVER, QUICKSILVER),
		CRUSHED_BAUXITE = blastModdedCrushedMetal(AllItems.CRUSHED_BAUXITE, ALUMINUM),
		CRUSHED_URANIUM = blastModdedCrushedMetal(AllItems.CRUSHED_URANIUM, URANIUM),
		CRUSHED_NICKEL = blastModdedCrushedMetal(AllItems.CRUSHED_NICKEL, NICKEL),

		ZINC_ORE = create(AllItems.ZINC_INGOT::get).withSuffix("_from_ore")
			.viaCookingTag(() -> AllTags.forgeItemTag("zinc_ores"))
			.rewardXP(1)
			.inBlastFurnace(),

		RAW_ZINC_ORE = create(AllItems.ZINC_INGOT::get).withSuffix("_from_raw_ore")
			.viaCookingTag(() -> AllTags.forgeItemTag("raw_zinc_ores"))
			.rewardXP(.7f)
			.inBlastFurnace(),

		UA_TREE_FERTILIZER = create(AllItems.TREE_FERTILIZER::get).returns(2)
			.unlockedBy(() -> class_1802.field_8324)
			.whenModLoaded(Mods.UA.getId())
			.viaShapeless(b -> b.method_10453(class_1856.method_8106(class_3489.field_15543), 2)
				.method_10446(AllItemTags.UA_CORAL.tag)
				.method_10454(class_1802.field_8324))

	;

	/*
	 * End of recipe list
	 */

	static class Marker {
	}

	String currentFolder = "";

	Marker enterFolder(String folder) {
		currentFolder = folder;
		return new Marker();
	}

	GeneratedRecipeBuilder create(Supplier<class_1935> result) {
		return new GeneratedRecipeBuilder(currentFolder, result);
	}

	GeneratedRecipeBuilder create(class_2960 result) {
		return new GeneratedRecipeBuilder(currentFolder, result);
	}

	GeneratedRecipeBuilder create(ItemProviderEntry<? extends class_1935> result) {
		return create(result::get);
	}

	GeneratedRecipe createSpecial(Supplier<? extends class_1866<?>> serializer, String recipeType,
															 String path) {
		class_2960 location = Create.asResource(recipeType + "/" + currentFolder + "/" + path);
		return register(consumer -> {
			class_2456 b = class_2456.method_10476(serializer.get());
			b.method_10475(consumer, location.toString());
		});
	}

	GeneratedRecipe blastCrushedMetal(Supplier<? extends class_1935> result, Supplier<? extends class_1935> ingredient) {
		return create(result::get).withSuffix("_from_crushed")
			.viaCooking(ingredient::get)
			.rewardXP(.1f)
			.inBlastFurnace();
	}

	GeneratedRecipe blastModdedCrushedMetal(ItemEntry<? extends class_1792> ingredient, CompatMetals metal) {
		for (Mods mod : metal.getMods()) {
			String metalName = metal.getName(mod);
			class_2960 ingot = mod.ingotOf(metalName);
			String modId = mod.getId();
			create(ingot).withSuffix("_compat_" + modId)
				.whenModLoaded(modId)
				.viaCooking(ingredient::get)
				.rewardXP(.1f)
				.inBlastFurnace();
		}
		return null;
	}

	GeneratedRecipe recycleGlass(BlockEntry<? extends class_2248> ingredient) {
		return create(() -> class_2246.field_10033).withSuffix("_from_" + ingredient.getId()
			.method_12832())
			.viaCooking(ingredient::get)
			.forDuration(50)
			.inFurnace();
	}

	GeneratedRecipe recycleGlassPane(BlockEntry<? extends class_2248> ingredient) {
		return create(() -> class_2246.field_10285).withSuffix("_from_" + ingredient.getId()
			.method_12832())
			.viaCooking(ingredient::get)
			.forDuration(50)
			.inFurnace();
	}

	GeneratedRecipe metalCompacting(List<ItemProviderEntry<? extends class_1935>> variants,
															   List<Supplier<class_6862<class_1792>>> ingredients) {
		GeneratedRecipe result = null;
		for (int i = 0; i + 1 < variants.size(); i++) {
			ItemProviderEntry<? extends class_1935> currentEntry = variants.get(i);
			ItemProviderEntry<? extends class_1935> nextEntry = variants.get(i + 1);
			Supplier<class_6862<class_1792>> currentIngredient = ingredients.get(i);
			Supplier<class_6862<class_1792>> nextIngredient = ingredients.get(i + 1);

			result = create(nextEntry).withSuffix("_from_compacting")
				.unlockedBy(currentEntry::get)
				.viaShaped(b -> b.method_10439("###")
					.method_10439("###")
					.method_10439("###")
					.method_10433('#', currentIngredient.get()));

			result = create(currentEntry).returns(9)
				.withSuffix("_from_decompacting")
				.unlockedBy(nextEntry::get)
				.viaShapeless(b -> b.method_10446(nextIngredient.get()));
		}
		return result;
	}

	GeneratedRecipe conversionCycle(List<ItemProviderEntry<? extends class_1935>> cycle) {
		GeneratedRecipe result = null;
		for (int i = 0; i < cycle.size(); i++) {
			ItemProviderEntry<? extends class_1935> currentEntry = cycle.get(i);
			ItemProviderEntry<? extends class_1935> nextEntry = cycle.get((i + 1) % cycle.size());
			result = create(nextEntry).withSuffix("_from_conversion")
				.unlockedBy(currentEntry::get)
				.viaShapeless(b -> b.method_10454(currentEntry.get()));
		}
		return result;
	}

	GeneratedRecipe clearData(ItemProviderEntry<? extends class_1935> item) {
		return create(item).withSuffix("_clear")
			.unlockedBy(item::get)
			.viaShapeless(b -> b.method_10454(item.get()));
	}

	@Override
	public void method_10419(Consumer<class_2444> p_200404_1_) {
		all.forEach(c -> c.register(p_200404_1_));
		Create.LOGGER.info(method_10321() + " registered " + all.size() + " recipe" + (all.size() == 1 ? "" : "s"));
	}

	protected GeneratedRecipe register(GeneratedRecipe recipe) {
		all.add(recipe);
		return recipe;
	}

	class GeneratedRecipeBuilder {

		private String path;
		private String suffix;
		private Supplier<? extends class_1935> result;
		private class_2960 compatDatagenOutput;
		List<ConditionJsonProvider> recipeConditions;

		private Supplier<class_2073> unlockedBy;
		private int amount;

		private GeneratedRecipeBuilder(String path) {
			this.path = path;
			this.recipeConditions = new ArrayList<>();
			this.suffix = "";
			this.amount = 1;
		}

		public GeneratedRecipeBuilder(String path, Supplier<? extends class_1935> result) {
			this(path);
			this.result = result;
		}

		public GeneratedRecipeBuilder(String path, class_2960 result) {
			this(path);
			this.compatDatagenOutput = result;
		}

		GeneratedRecipeBuilder returns(int amount) {
			this.amount = amount;
			return this;
		}

		GeneratedRecipeBuilder unlockedBy(Supplier<? extends class_1935> item) {
			this.unlockedBy = () -> class_2073.class_2074.method_8973()
				.method_8977(item.get())
				.method_8976();
			return this;
		}

		GeneratedRecipeBuilder unlockedByTag(Supplier<class_6862<class_1792>> tag) {
			this.unlockedBy = () -> class_2073.class_2074.method_8973()
				.method_8975(tag.get())
				.method_8976();
			return this;
		}

		GeneratedRecipeBuilder whenModLoaded(String modid) {
			return withCondition(DefaultResourceConditions.allModsLoaded(modid));
		}

		GeneratedRecipeBuilder whenModMissing(String modid) {
			return withCondition(DefaultResourceConditions.not(DefaultResourceConditions.allModsLoaded(modid)));
		}

		GeneratedRecipeBuilder withCondition(ConditionJsonProvider condition) {
			recipeConditions.add(condition);
			return this;
		}

		GeneratedRecipeBuilder withSuffix(String suffix) {
			this.suffix = suffix;
			return this;
		}

		// FIXME 5.1 refactor - recipe categories as markers instead of sections?
		GeneratedRecipe viaShaped(UnaryOperator<class_2447> builder) {
			return register(consumer -> {
				class_2447 b =
					builder.apply(class_2447.method_10436(class_7800.field_40642, result.get(), amount));
				if (unlockedBy != null)
					b.method_10429("has_item", method_10423(unlockedBy.get()));
				b.method_17972(consumer, createLocation("crafting"));
			});
		}

		GeneratedRecipe viaShapeless(UnaryOperator<class_2450> builder) {
			return register(consumer -> {
				class_2450 b =
					builder.apply(class_2450.method_10448(class_7800.field_40642, result.get(), amount));
				if (unlockedBy != null)
					b.method_10442("has_item", method_10423(unlockedBy.get()));

				b.method_17972(result -> {
					consumer.accept(!recipeConditions.isEmpty()
						? new ConditionSupportingShapelessRecipeResult(result, recipeConditions)
						: result);
				}, createLocation("crafting"));
			});
		}

		GeneratedRecipe viaNetheriteSmithing(Supplier<? extends class_1792> base, Supplier<class_1856> upgradeMaterial) {
			return register(consumer -> {
				class_8074 b =
					class_8074.method_48535(class_1856.method_8091(class_1802.field_41946),
						class_1856.method_8091(base.get()), upgradeMaterial.get(), class_7800.field_40639, result.get()
							.method_8389());
				b.method_48536("has_item", method_10423(class_2073.class_2074.method_8973()
					.method_8977(base.get())
					.method_8976()));
				b.method_48537(consumer, createLocation("crafting"));
			});
		}

		private class_2960 createSimpleLocation(String recipeType) {
			return Create.asResource(recipeType + "/" + getRegistryName().method_12832() + suffix);
		}

		private class_2960 createLocation(String recipeType) {
			return Create.asResource(recipeType + "/" + path + "/" + getRegistryName().method_12832() + suffix);
		}

		private class_2960 getRegistryName() {
			return compatDatagenOutput == null ? CatnipServices.REGISTRIES.getKeyOrThrow(result.get()
				.method_8389()) : compatDatagenOutput;
		}

		GeneratedCookingRecipeBuilder viaCooking(Supplier<? extends class_1935> item) {
			return unlockedBy(item).viaCookingIngredient(() -> class_1856.method_8091(item.get()));
		}

		GeneratedCookingRecipeBuilder viaCookingTag(Supplier<class_6862<class_1792>> tag) {
			return unlockedByTag(tag).viaCookingIngredient(() -> class_1856.method_8106(tag.get()));
		}

		GeneratedCookingRecipeBuilder viaCookingIngredient(Supplier<class_1856> ingredient) {
			return new GeneratedCookingRecipeBuilder(ingredient);
		}

		class GeneratedCookingRecipeBuilder {

			private Supplier<class_1856> ingredient;
			private float exp;
			private int cookingTime;

			private final class_1865<? extends class_1874> FURNACE = class_1865.field_9042,
				SMOKER = class_1865.field_17085, BLAST = class_1865.field_17084,
				CAMPFIRE = class_1865.field_17347;

			GeneratedCookingRecipeBuilder(Supplier<class_1856> ingredient) {
				this.ingredient = ingredient;
				cookingTime = 200;
				exp = 0;
			}

			GeneratedCookingRecipeBuilder forDuration(int duration) {
				cookingTime = duration;
				return this;
			}

			GeneratedCookingRecipeBuilder rewardXP(float xp) {
				exp = xp;
				return this;
			}

			GeneratedRecipe inFurnace() {
				return inFurnace(b -> b);
			}

			GeneratedRecipe inFurnace(UnaryOperator<class_2454> builder) {
				return create(FURNACE, builder, 1);
			}

			GeneratedRecipe inSmoker() {
				return inSmoker(b -> b);
			}

			GeneratedRecipe inSmoker(UnaryOperator<class_2454> builder) {
				create(FURNACE, builder, 1);
				create(CAMPFIRE, builder, 3);
				return create(SMOKER, builder, .5f);
			}

			GeneratedRecipe inBlastFurnace() {
				return inBlastFurnace(b -> b);
			}

			GeneratedRecipe inBlastFurnace(UnaryOperator<class_2454> builder) {
				create(FURNACE, builder, 1);
				return create(BLAST, builder, .5f);
			}

			private GeneratedRecipe create(class_1865<? extends class_1874> serializer,
																	  UnaryOperator<class_2454> builder, float cookingTimeModifier) {
				return register(consumer -> {
					boolean isOtherMod = compatDatagenOutput != null;

					class_2454 b = builder.apply(class_2454.method_17801(ingredient.get(),
						class_7800.field_40642, isOtherMod ? class_1802.field_8831 : result.get(), exp,
						(int) (cookingTime * cookingTimeModifier), serializer));

					if (unlockedBy != null)
						b.method_10469("has_item", method_10423(unlockedBy.get()));

					b.method_17972(result -> {
						consumer.accept(
							isOtherMod ? new ModdedCookingRecipeResult(result, compatDatagenOutput, recipeConditions)
								: result);
					}, createSimpleLocation(CatnipServices.REGISTRIES.getKeyOrThrow(serializer)
						.method_12832()));
				});
			}
		}
	}

	@Override
	public String method_10321() {
		return "Create's Standard Recipes";
	}

	public CreateStandardRecipeGen(FabricDataOutput p_i48262_1_) {
		super(p_i48262_1_, Create.ID);
	}

	private record ModdedCookingRecipeResult(class_2444 wrapped, class_2960 outputOverride,
		List<ConditionJsonProvider> conditions) implements class_2444 {
		@Override
		public class_2960 method_10417() {
			return wrapped.method_10417();
		}

		@Override
		public class_1865<?> method_17800() {
			return wrapped.method_17800();
		}

		@Override
		public JsonObject method_10415() {
			return wrapped.method_10415();
		}

		@Override
		public class_2960 method_10418() {
			return wrapped.method_10418();
		}

		@Override
		public void method_10416(JsonObject object) {
			wrapped.method_10416(object);
			object.addProperty("result", outputOverride.toString());

			ConditionJsonProvider.write(object, conditions.toArray(new ConditionJsonProvider[0]));
		}
	}

	private record ConditionSupportingShapelessRecipeResult(class_2444 wrapped, List<ConditionJsonProvider> conditions)
		implements class_2444 {
		@Override
		public class_2960 method_10417() {
			return wrapped.method_10417();
		}

		@Override
		public class_1865<?> method_17800() {
			return wrapped.method_17800();
		}

		@Override
		public JsonObject method_10415() {
			return wrapped.method_10415();
		}

		@Override
		public class_2960 method_10418() {
			return wrapped.method_10418();
		}

		@Override
		public void method_10416(@NotNull JsonObject pJson) {
			wrapped.method_10416(pJson);

			ConditionJsonProvider.write(pJson, conditions.toArray(new ConditionJsonProvider[0]));
		}
	}
}
