package com.simibubi.create.foundation.blockEntity.behaviour.scrollValue;

import java.util.ArrayList;
import java.util.List;

import com.simibubi.create.AllItems;
import com.simibubi.create.AllKeys;
import com.simibubi.create.CreateClient;
import com.simibubi.create.foundation.blockEntity.SmartBlockEntity;
import com.simibubi.create.foundation.blockEntity.behaviour.BlockEntityBehaviour;
import com.simibubi.create.foundation.blockEntity.behaviour.ValueBox;
import com.simibubi.create.foundation.blockEntity.behaviour.ValueBox.IconValueBox;
import com.simibubi.create.foundation.blockEntity.behaviour.ValueBox.TextValueBox;
import com.simibubi.create.foundation.utility.AdventureUtil;
import com.simibubi.create.foundation.utility.CreateLang;

import net.createmod.catnip.outliner.Outliner;
import net.minecraft.class_1268;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_3965;
import net.minecraft.class_5250;
import net.minecraft.class_638;

public class ScrollValueRenderer {

	public static void tick() {
		class_310 mc = class_310.method_1551();
		class_239 target = mc.field_1765;
		if (target == null || !(target instanceof class_3965 result))
			return;

		class_638 world = mc.field_1687;
		class_2338 pos = result.method_17777();
		class_2350 face = result.method_17780();
		boolean highlightFound = false;

		if (!(world.method_8321(pos) instanceof SmartBlockEntity sbe))
			return;

		for (BlockEntityBehaviour blockEntityBehaviour : sbe.getAllBehaviours()) {
			if (!(blockEntityBehaviour instanceof ScrollValueBehaviour behaviour))
				continue;

			if (!behaviour.isActive()) {
				Outliner.getInstance().remove(behaviour);
				continue;
			}

			class_1799 mainhandItem = mc.field_1724.method_5998(class_1268.field_5808);
			boolean clipboard = behaviour.bypassesInput(mainhandItem);
			if (behaviour.needsWrench && !AllItems.WRENCH.isIn(mainhandItem) && !clipboard)
				continue;
			boolean highlight = behaviour.testHit(target.method_17784()) && !clipboard && !highlightFound;

			if (behaviour instanceof BulkScrollValueBehaviour bulkScrolling && AllKeys.ctrlDown()) {
				for (SmartBlockEntity smartBlockEntity : bulkScrolling.getBulk()) {
					ScrollValueBehaviour other = smartBlockEntity.getBehaviour(ScrollValueBehaviour.TYPE);
					if (other != null)
						addBox(world, smartBlockEntity.method_11016(), face, other, highlight);
				}
			} else
				addBox(world, pos, face, behaviour, highlight);

			if (!highlight)
				continue;

			highlightFound = true;
			List<class_5250> tip = new ArrayList<>();
			tip.add(behaviour.label.method_27661());
			tip.add(CreateLang.translateDirect("gui.value_settings.hold_to_edit"));
			CreateClient.VALUE_SETTINGS_HANDLER.showHoverTip(tip);
		}
	}

	protected static void addBox(class_638 world, class_2338 pos, class_2350 face, ScrollValueBehaviour behaviour,
								 boolean highlight) {
		class_238 bb = new class_238(class_243.field_1353, class_243.field_1353).method_1014(.5f)
			.method_1002(0, 0, -.5f)
			.method_989(0, 0, -.125f);
		class_2561 label = behaviour.label;
		ValueBox box;

		if (behaviour instanceof ScrollOptionBehaviour) {
			box = new IconValueBox(label, ((ScrollOptionBehaviour<?>) behaviour).getIconForSelected(), bb, pos);
		} else {
			box = new TextValueBox(label, bb, pos, class_2561.method_43470(behaviour.formatValue()));
		}

		if (!AdventureUtil.isAdventure(class_310.method_1551().field_1724))
			box.passive(!highlight)
			.wideOutline();

		Outliner.getInstance().showOutline(behaviour, box.transform(behaviour.slotPositioning))
			.highlightFace(face);
	}

}
