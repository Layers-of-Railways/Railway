package com.simibubi.create.infrastructure.ponder.scenes.fluid;

import com.simibubi.create.AllFluids;
import com.simibubi.create.content.fluids.FluidFX;
import com.simibubi.create.content.fluids.pump.PumpBlock;
import com.simibubi.create.content.fluids.spout.SpoutBlockEntity;
import com.simibubi.create.foundation.fluid.FluidHelper;
import com.simibubi.create.foundation.gui.AllIcons;
import com.simibubi.create.foundation.ponder.CreateSceneBuilder;
import com.simibubi.create.foundation.ponder.element.BeltItemElement;

import net.createmod.catnip.math.Pointing;
import net.createmod.catnip.math.VecHelper;
import net.createmod.ponder.api.PonderPalette;
import net.createmod.ponder.api.element.ElementLink;
import net.createmod.ponder.api.scene.SceneBuilder;
import net.createmod.ponder.api.scene.SceneBuildingUtil;
import net.createmod.ponder.api.scene.Selection;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidConstants;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2394;
import net.minecraft.class_243;
import net.minecraft.class_5819;
import io.github.fabricators_of_create.porting_lib.fluids.FluidStack;

public class SpoutScenes {

	public static void filling(SceneBuilder builder, SceneBuildingUtil util) {
		CreateSceneBuilder scene = new CreateSceneBuilder(builder);
		class_5819 random = class_5819.method_43047();

		scene.title("spout_filling", "Filling Items using a Spout");
		scene.configureBasePlate(0, 0, 5);
		scene.showBasePlate();
		scene.idle(5);

		ElementLink<net.createmod.ponder.api.element.WorldSectionElement> depot =
			scene.world().showIndependentSection(util.select().position(2, 1, 1), class_2350.field_11033);
		scene.world().moveSection(depot, util.vector().of(0, 0, 1), 0);
		scene.idle(10);

		scene.world().modifyBlock(util.grid().at(2, 3, 3), s -> s.method_11657(PumpBlock.FACING, class_2350.field_11043), false);

		Selection largeCog = util.select().position(3, 0, 5);
		Selection kinetics = util.select().fromTo(2, 1, 5, 2, 2, 3);
		Selection tank = util.select().fromTo(1, 1, 4, 1, 2, 4);
		Selection pipes = util.select().fromTo(1, 3, 4, 2, 3, 3);

		Selection spoutS = util.select().position(2, 3, 2);
		class_2338 spoutPos = util.grid().at(2, 3, 2);
		class_2338 depotPos = util.grid().at(2, 1, 1);
		scene.world().showSection(spoutS, class_2350.field_11033);
		scene.idle(10);

		class_243 spoutSide = util.vector().blockSurface(spoutPos, class_2350.field_11039);
		scene.overlay().showText(60)
			.pointAt(spoutSide)
			.placeNearTarget()
			.attachKeyFrame()
			.text("The Spout can fill fluid holding items provided beneath it");

		scene.idle(50);

		scene.world().showSection(tank, class_2350.field_11033);
		scene.idle(5);
		scene.world().showSection(largeCog, class_2350.field_11036);
		scene.world().showSection(kinetics, class_2350.field_11043);
		scene.world().showSection(pipes, class_2350.field_11043);

		scene.idle(20);
		FluidStack honey = new FluidStack(FluidHelper.convertToStill(AllFluids.HONEY.get()), FluidConstants.BUCKET);
		class_1799 bucket = new class_1799(AllFluids.HONEY.get().method_15774());
//			.getAttributes()
//			.getBucket(honey);
		scene.overlay().showControls(util.vector().blockSurface(util.grid().at(2, 3, 2), class_2350.field_11043), Pointing.RIGHT, 40)
				.showing(AllIcons.I_MTD_CLOSE)
				.withItem(bucket);
		scene.idle(7);
		scene.overlay().showOutlineWithText(util.select().position(2, 3, 2), 50)
			.pointAt(util.vector().blockSurface(util.grid().at(2, 3, 2), class_2350.field_11039))
			.attachKeyFrame()
			.colored(PonderPalette.RED)
			.placeNearTarget()
			.text("The content of a Spout cannot be accessed manually");
		scene.idle(60);
		scene.overlay().showText(70)
			.pointAt(util.vector().blockSurface(util.grid().at(2, 3, 3), class_2350.field_11039))
			.colored(PonderPalette.GREEN)
			.placeNearTarget()
			.text("Instead, Pipes can be used to supply it with fluids");

		scene.idle(90);
		scene.overlay().showText(60)
			.pointAt(spoutSide.method_1023(0, 2, 0))
			.attachKeyFrame()
			.placeNearTarget()
			.text("The Input items can be placed on a Depot under the Spout");
		scene.idle(50);
		class_1799 bottle = new class_1799(class_1802.field_8469);
		scene.world().createItemOnBeltLike(depotPos, class_2350.field_11043, bottle);
		class_243 depotCenter = util.vector().centerOf(depotPos.method_10072());
		scene.overlay().showControls(depotCenter, Pointing.UP, 30).withItem(bottle);
		scene.idle(10);

		scene.idle(20);
		scene.world().modifyBlockEntityNBT(spoutS, SpoutBlockEntity.class, nbt -> nbt.method_10569("ProcessingTicks", 20));
		scene.idle(20);
		scene.world().removeItemsFromBelt(depotPos);
		class_1799 potion = new class_1799(class_1802.field_20417);
		scene.world().createItemOnBeltLike(depotPos, class_2350.field_11036, potion);
		class_2394 fluidParticle = FluidFX.getFluidParticle(new FluidStack(AllFluids.HONEY.get(), FluidConstants.BUCKET));
		for (int i = 0; i < 10; i++) {
			scene.effects().emitParticles(util.vector().topOf(depotPos.method_10072())
				.method_1031(0, 1 / 16f, 0),
					scene.effects().simpleParticleEmitter(fluidParticle, VecHelper.offsetRandomly(class_243.field_1353, random, .1f)), 1, 1);
		}
		scene.idle(10);
		scene.overlay().showControls(depotCenter, Pointing.UP, 50).withItem(potion);
		scene.idle(60);

		scene.world().hideIndependentSection(depot, class_2350.field_11043);
		scene.idle(5);
		scene.world().showSection(util.select().fromTo(0, 1, 3, 0, 2, 3), class_2350.field_11033);
		scene.idle(10);
		scene.world().showSection(util.select().fromTo(4, 1, 2, 0, 2, 2), class_2350.field_11035);
		scene.idle(20);
		class_2338 beltPos = util.grid().at(0, 1, 2);
		scene.overlay().showText(40)
			.pointAt(util.vector().blockSurface(beltPos, class_2350.field_11039))
			.placeNearTarget()
			.attachKeyFrame()
			.text("When items are provided on a belt...");
		scene.idle(30);

		ElementLink<BeltItemElement> ingot = scene.world().createItemOnBelt(beltPos, class_2350.field_11035, bottle);
		scene.idle(15);
		ElementLink<BeltItemElement> ingot2 = scene.world().createItemOnBelt(beltPos, class_2350.field_11035, bottle);
		scene.idle(15);
		scene.world().stallBeltItem(ingot, true);
		scene.world().modifyBlockEntityNBT(spoutS, SpoutBlockEntity.class, nbt -> nbt.method_10569("ProcessingTicks", 20));

		scene.overlay().showText(50)
			.pointAt(spoutSide)
			.placeNearTarget()
			.attachKeyFrame()
			.text("The Spout will hold and process them automatically");

		scene.idle(20);
		for (int i = 0; i < 10; i++) {
			scene.effects().emitParticles(util.vector().topOf(depotPos.method_10072())
				.method_1031(0, 1 / 16f, 0),
					scene.effects().simpleParticleEmitter(fluidParticle, VecHelper.offsetRandomly(class_243.field_1353, random, .1f)), 1, 1);
		}
		scene.world().removeItemsFromBelt(spoutPos.method_10087(2));
		ingot = scene.world().createItemOnBelt(spoutPos.method_10087(2), class_2350.field_11036, potion);
		scene.world().stallBeltItem(ingot, true);
		scene.idle(5);
		scene.world().stallBeltItem(ingot, false);
		scene.idle(15);
		scene.world().stallBeltItem(ingot2, true);
		scene.world().modifyBlockEntityNBT(spoutS, SpoutBlockEntity.class, nbt -> nbt.method_10569("ProcessingTicks", 20));
		scene.idle(20);
		for (int i = 0; i < 10; i++) {
			scene.effects().emitParticles(util.vector().topOf(depotPos.method_10072())
				.method_1031(0, 1 / 16f, 0),
					scene.effects().simpleParticleEmitter(fluidParticle, VecHelper.offsetRandomly(class_243.field_1353, random, .1f)), 1, 1);
		}
		scene.world().removeItemsFromBelt(spoutPos.method_10087(2));
		ingot2 = scene.world().createItemOnBelt(spoutPos.method_10087(2), class_2350.field_11036, potion);
		scene.world().stallBeltItem(ingot2, true);
		scene.idle(5);
		scene.world().stallBeltItem(ingot2, false);

	}

}
