package com.simibubi.create.foundation.fluid;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import javax.annotation.Nullable;

import com.google.common.collect.ImmutableList;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonSyntaxException;

import net.createmod.catnip.platform.CatnipServices;
import net.minecraft.class_2487;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_3518;
import net.minecraft.class_3609;
import net.minecraft.class_3611;
import net.minecraft.class_6862;
import net.minecraft.class_6880;
import net.minecraft.class_6885;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import io.github.fabricators_of_create.porting_lib.fluids.FluidStack;

public abstract class FluidIngredient implements Predicate<FluidStack> {

	public static final FluidIngredient EMPTY = new FluidStackIngredient();

	public List<FluidStack> matchingFluidStacks;

	public static FluidIngredient fromTag(class_6862<class_3611> tag, long amount) {
		FluidTagIngredient ingredient = new FluidTagIngredient();
		ingredient.tag = tag;
		ingredient.amountRequired = amount;
		return ingredient;
	}

	public static FluidIngredient fromFluid(class_3611 fluid, long amount) {
		FluidStackIngredient ingredient = new FluidStackIngredient();
		ingredient.fluid = fluid;
		ingredient.amountRequired = amount;
		ingredient.fixFlowing();
		return ingredient;
	}

	public static FluidIngredient fromFluidStack(FluidStack fluidStack) {
		FluidStackIngredient ingredient = new FluidStackIngredient();
		ingredient.fluid = fluidStack.getFluid();
		ingredient.amountRequired = fluidStack.getAmount();
		ingredient.fixFlowing();
		if (fluidStack.hasTag())
			ingredient.tagToMatch = fluidStack.getTag();
		return ingredient;
	}

	protected long amountRequired;

	protected abstract boolean testInternal(FluidStack t);

	protected abstract void readInternal(class_2540 buffer);

	protected abstract void writeInternal(class_2540 buffer);

	protected abstract void readInternal(JsonObject json);

	protected abstract void writeInternal(JsonObject json);

	protected abstract List<FluidStack> determineMatchingFluidStacks();

	public long getRequiredAmount() {
		return amountRequired;
	}

	public List<FluidStack> getMatchingFluidStacks() {
		if (matchingFluidStacks != null)
			return matchingFluidStacks;
		return matchingFluidStacks = determineMatchingFluidStacks();
	}

	@Override
	public boolean test(FluidStack t) {
		if (t == null)
			throw new IllegalArgumentException("FluidStack cannot be null");
		return testInternal(t);
	}

	public void write(class_2540 buffer) {
		buffer.writeBoolean(this instanceof FluidTagIngredient);
		buffer.method_10791(amountRequired);
		writeInternal(buffer);
	}

	public static FluidIngredient read(class_2540 buffer) {
		boolean isTagIngredient = buffer.readBoolean();
		FluidIngredient ingredient = isTagIngredient ? new FluidTagIngredient() : new FluidStackIngredient();
		ingredient.amountRequired = buffer.method_10816();
		ingredient.readInternal(buffer);
		return ingredient;
	}

	public JsonObject serialize() {
		JsonObject json = new JsonObject();
		writeInternal(json);
		json.addProperty("amount", amountRequired);
		return json;
	}

	public static boolean isFluidIngredient(@Nullable JsonElement je) {
		if (je == null || je.isJsonNull())
			return false;
		if (!je.isJsonObject())
			return false;
		JsonObject json = je.getAsJsonObject();
		if (json.has("fluidTag"))
			return true;
		else if (json.has("fluid"))
			return true;
		return false;
	}

	public static FluidIngredient deserialize(@Nullable JsonElement je) {
		if (!isFluidIngredient(je))
			throw new JsonSyntaxException("Invalid fluid ingredient: " + je);

		JsonObject json = je.getAsJsonObject();
		FluidIngredient ingredient = json.has("fluidTag") ? new FluidTagIngredient() : new FluidStackIngredient();
		ingredient.readInternal(json);

		if (!json.has("amount"))
			throw new JsonSyntaxException("Fluid ingredient has to define an amount");
		ingredient.amountRequired = class_3518.method_15260(json, "amount");
		return ingredient;
	}

	public static class FluidStackIngredient extends FluidIngredient {

		protected class_3611 fluid;
		protected class_2487 tagToMatch;

		public FluidStackIngredient() {
			tagToMatch = new class_2487();
		}

		void fixFlowing() {
			if (fluid instanceof class_3609)
				fluid = ((class_3609) fluid).method_15751();
		}

		@Override
		protected boolean testInternal(FluidStack t) {
			if (!FluidHelper.isSame(t, fluid))
				return false;
			if (tagToMatch.method_33133())
				return true;
			class_2487 tag = t.getOrCreateTag();
			return tag.method_10553()
				.method_10543(tagToMatch)
				.equals(tag);
		}

		@Override
		protected void readInternal(class_2540 buffer) {
			fluid = buffer.method_42064(class_7923.field_41173);
			tagToMatch = buffer.method_10798();
		}

		@Override
		protected void writeInternal(class_2540 buffer) {
			buffer.method_42065(class_7923.field_41173, fluid);
			buffer.method_10794(tagToMatch);
		}

		@Override
		protected void readInternal(JsonObject json) {
			FluidStack stack = FluidHelper.deserializeFluidStack(json);
			fluid = stack.getFluid();
			tagToMatch = stack.getOrCreateTag();
		}

		@Override
		protected void writeInternal(JsonObject json) {
			json.addProperty("fluid", CatnipServices.REGISTRIES.getKeyOrThrow(fluid)
				.toString());
			json.add("nbt", JsonParser.parseString(tagToMatch.toString()));
		}

		@Override
		protected List<FluidStack> determineMatchingFluidStacks() {
			return ImmutableList.of(tagToMatch.method_33133() ? new FluidStack(fluid, amountRequired)
				: new FluidStack(fluid, amountRequired, tagToMatch));
		}

	}

	public static class FluidTagIngredient extends FluidIngredient {

		protected class_6862<class_3611> tag;

		@Override
		protected boolean testInternal(FluidStack t) {
			if (tag != null)
				return FluidHelper.isTag(t, tag);
			for (FluidStack accepted : getMatchingFluidStacks())
				if (FluidHelper.isSame(accepted, t))
					return true;
			return false;
		}

		@Override
		protected void readInternal(class_2540 buffer) {
			int size = buffer.method_10816();
			matchingFluidStacks = new ArrayList<>(size);
			for (int i = 0; i < size; i++)
				matchingFluidStacks.add(FluidStack.readFromPacket(buffer));
		}

		@Override
		protected void writeInternal(class_2540 buffer) {
			// Tag has to be resolved on the server before sending
			List<FluidStack> matchingFluidStacks = getMatchingFluidStacks();
			buffer.method_10804(matchingFluidStacks.size());
			matchingFluidStacks.stream()
				.forEach(stack -> stack.writeToPacket(buffer));
		}

		@Override
		protected void readInternal(JsonObject json) {
			class_2960 name = new class_2960(class_3518.method_15265(json, "fluidTag"));
			tag = class_6862.method_40092(class_7924.field_41270, name);
		}

		@Override
		protected void writeInternal(JsonObject json) {
			json.addProperty("fluidTag", tag.comp_327()
				.toString());
		}

		@Override
		protected List<FluidStack> determineMatchingFluidStacks() {
			return class_7923.field_41173
				.method_40266(tag)
				.stream()
				.flatMap(class_6885::method_40239)
				.map(class_6880::comp_349)
				.map(f -> {
					if (f instanceof class_3609)
						return ((class_3609) f).method_15751();
					return f;
				})
				.distinct()
				.map(f -> new FluidStack(f, amountRequired))
				.collect(Collectors.toList());
		}

	}

}
