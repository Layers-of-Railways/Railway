package com.simibubi.create.infrastructure.ponder.scenes;

import com.simibubi.create.foundation.ponder.CreateSceneBuilder;

import net.createmod.catnip.math.Pointing;
import net.createmod.ponder.api.element.ElementLink;
import net.createmod.ponder.api.element.EntityElement;
import net.createmod.ponder.api.element.WorldSectionElement;
import net.createmod.ponder.api.scene.SceneBuilder;
import net.createmod.ponder.api.scene.SceneBuildingUtil;
import net.createmod.ponder.api.scene.Selection;
import net.minecraft.class_1297;
import net.minecraft.class_1542;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;

public class MechanicalDrillScenes {

	public static void breaker(SceneBuilder builder, SceneBuildingUtil util) {
		CreateSceneBuilder scene = new CreateSceneBuilder(builder);
		scene.title("mechanical_drill", "Breaking Blocks with the Mechanical Drill");
		scene.configureBasePlate(0, 0, 5);

		scene.world().setKineticSpeed(util.select().layer(0), -8);
		scene.world().setKineticSpeed(util.select().layer(1), 16);

		scene.world().showSection(util.select().layer(0), class_2350.field_11036);
		scene.idle(5);
		scene.world().showSection(util.select().fromTo(4, 1, 2, 5, 1, 2), class_2350.field_11033);
		scene.idle(10);
		scene.world().showSection(util.select().position(3, 1, 2), class_2350.field_11034);
		scene.idle(20);

		class_2338 breakingPos = util.grid().at(2, 1, 2);

		scene.world().showSection(util.select().position(2, 1, 2), class_2350.field_11033);
		scene.idle(5);
		for (int i = 0; i < 10; i++) {
			scene.idle(10);
			scene.world().incrementBlockBreakingProgress(breakingPos);
			if (i == 1) {
				scene.overlay().showText(80)
					.attachKeyFrame()
					.placeNearTarget()
					.pointAt(util.vector().topOf(breakingPos))
					.text("When given Rotational Force, a Mechanical Drill will break blocks directly in front of it");
			}
		}

		scene.world().hideSection(util.select().position(breakingPos), class_2350.field_11036);
		ElementLink<EntityElement> plankEntity = scene.world().createItemEntity(util.vector().centerOf(breakingPos),
																				util.vector().of(0, .1f, 0), new class_1799(class_1802.field_8118));
		scene.idle(20);
		scene.idle(15);

		scene.world().modifyEntity(plankEntity, class_1297::method_31472);
		scene.world().modifyKineticSpeed(util.select().everywhere(), f -> 4 * f);
		scene.effects().rotationSpeedIndicator(breakingPos.method_10089(3));
		scene.idle(5);
		scene.world().setBlock(breakingPos, class_2246.field_10161.method_9564(), false);
		scene.world().showSection(util.select().position(breakingPos), class_2350.field_11033);

		scene.idle(5);
		for (int i = 0; i < 10; i++) {
			scene.idle(3);
			scene.world().incrementBlockBreakingProgress(breakingPos);
			if (i == 2) {
				scene.overlay().showText(80)
					.attachKeyFrame()
					.placeNearTarget()
					.pointAt(util.vector().topOf(breakingPos.method_10078()))
					.text("Its mining speed depends on the Rotational Input");
			}
		}

		scene.world().createItemEntity(util.vector().centerOf(breakingPos), util.vector().of(0, .1f, 0),
									   new class_1799(class_1802.field_8118));
		scene.idle(50);
	}

	public static void contraption(SceneBuilder builder, SceneBuildingUtil util) {
		CreateSceneBuilder scene = new CreateSceneBuilder(builder);
		scene.title("mechanical_drill_contraption", "Using Mechanical Drills on Contraptions");
		scene.configureBasePlate(0, 0, 6);
		scene.world().showSection(util.select().layer(0), class_2350.field_11036);

		Selection kinetics = util.select().fromTo(5, 1, 2, 5, 1, 6);

		scene.idle(5);
		ElementLink<WorldSectionElement> pistonHead =
			scene.world().showIndependentSection(util.select().fromTo(5, 1, 1, 7, 1, 1), class_2350.field_11033);
		scene.world().moveSection(pistonHead, util.vector().of(0, 0, 1), 0);
		scene.world().showSection(kinetics, class_2350.field_11033);
		scene.idle(5);
		ElementLink<WorldSectionElement> contraption =
			scene.world().showIndependentSection(util.select().fromTo(4, 2, 3, 4, 1, 2), class_2350.field_11033);
		scene.idle(5);
		scene.world().showSectionAndMerge(util.select().position(3, 1, 3), class_2350.field_11034, contraption);
		scene.idle(5);
		scene.world().showSectionAndMerge(util.select().position(3, 1, 2), class_2350.field_11034, contraption);
		scene.world().showSectionAndMerge(util.select().position(3, 2, 3), class_2350.field_11034, contraption);
		scene.idle(5);
		scene.world().showSectionAndMerge(util.select().position(3, 2, 2), class_2350.field_11034, contraption);

		scene.overlay().showText(60)
			.attachKeyFrame()
			.placeNearTarget()
			.pointAt(util.vector().topOf(util.grid().at(3, 2, 3)))
			.text("Whenever Drills are moved as part of an animated Contraption...");
		scene.idle(70);

		Selection drills = util.select().fromTo(3, 1, 2, 3, 2, 3);

		Selection planks = util.select().fromTo(1, 1, 2, 1, 2, 3);
		scene.world().showSection(planks, class_2350.field_11033);
		scene.world().setKineticSpeed(util.select().position(4, 0, 6), -8);
		scene.world().setKineticSpeed(kinetics, 16);
		scene.world().setKineticSpeed(drills, 16);
		scene.world().moveSection(pistonHead, util.vector().of(-1, 0, 0), 20);
		scene.world().moveSection(contraption, util.vector().of(-1, 0, 0), 20);
		scene.idle(20);
		scene.world().setKineticSpeed(drills, 64);

		class_2338 p1 = util.grid().at(1, 1, 2);
		class_2338 p2 = util.grid().at(1, 1, 3);
		class_2338 p3 = util.grid().at(1, 2, 2);
		class_2338 p4 = util.grid().at(1, 2, 3);

		for (int i = 0; i < 10; i++) {
			scene.idle(3);
			scene.world().incrementBlockBreakingProgress(p1);
			scene.world().incrementBlockBreakingProgress(p2);
			scene.world().incrementBlockBreakingProgress(p3);
			scene.world().incrementBlockBreakingProgress(p4);
			if (i == 2) {
				scene.overlay().showText(80)
					.placeNearTarget()
					.pointAt(util.vector().topOf(p3))
					.text("...they will break blocks the contraption runs them into");
			}
		}

		class_243 m = util.vector().of(-.1, 0, 0);
		class_1799 item = new class_1799(class_1802.field_8118);
		scene.world().createItemEntity(util.vector().centerOf(p1), m, item);
		scene.world().createItemEntity(util.vector().centerOf(p2), m, item);
		scene.world().createItemEntity(util.vector().centerOf(p3), m, item);
		scene.world().createItemEntity(util.vector().centerOf(p4), m, item);

		scene.world().setKineticSpeed(drills, 16);
		scene.world().moveSection(pistonHead, util.vector().of(-1, 0, 0), 20);
		scene.world().moveSection(contraption, util.vector().of(-1, 0, 0), 20);
		scene.idle(20);
		scene.world().setKineticSpeed(drills, 0);
		scene.idle(20);

		scene.world().modifyKineticSpeed(util.select().everywhere(), f -> -f);
		scene.world().moveSection(pistonHead, util.vector().of(2, 0, 0), 40);
		scene.world().moveSection(contraption, util.vector().of(2, 0, 0), 40);
		scene.world().hideSection(planks, class_2350.field_11036);
		scene.idle(40);

		scene.world().setBlocks(planks, class_2246.field_10161.method_9564(), false);
		scene.world().modifyEntities(class_1542.class, class_1297::method_31472);
		scene.world().glueBlockOnto(util.grid().at(4, 3, 2), class_2350.field_11033, contraption);

		scene.overlay().showText(60)
			.attachKeyFrame()
			.placeNearTarget()
			.pointAt(util.vector().blockSurface(util.grid().at(4, 3, 2), class_2350.field_11039))
			.sharedText("storage_on_contraption");
		scene.idle(70);

		scene.world().showSection(planks, class_2350.field_11033);
		scene.world().modifyKineticSpeed(util.select().everywhere(), f -> -f);
		scene.world().setKineticSpeed(drills, 16);
		scene.world().moveSection(pistonHead, util.vector().of(-1, 0, 0), 20);
		scene.world().moveSection(contraption, util.vector().of(-1, 0, 0), 20);

		scene.idle(20);
		scene.world().setKineticSpeed(drills, 64);

		for (int i = 0; i < 10; i++) {
			scene.idle(3);
			scene.world().incrementBlockBreakingProgress(p1);
			scene.world().incrementBlockBreakingProgress(p2);
			scene.world().incrementBlockBreakingProgress(p3);
			scene.world().incrementBlockBreakingProgress(p4);
		}

		scene.world().setKineticSpeed(drills, 16);
		scene.world().moveSection(pistonHead, util.vector().of(-1, 0, 0), 20);
		scene.world().moveSection(contraption, util.vector().of(-1, 0, 0), 20);
		scene.idle(20);
		scene.world().setKineticSpeed(drills, 0);
		scene.idle(10);
		scene.overlay().showControls(util.vector().topOf(2, 3, 2), Pointing.DOWN, 60)
			.withItem(new class_1799(class_2246.field_10161));
		scene.idle(20);
	}

}
