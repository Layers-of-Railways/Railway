package com.simibubi.create.api.data.recipe;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import net.minecraft.class_2444;
import net.minecraft.class_2446;
import net.minecraft.class_2960;
import net.minecraft.class_7784;
import com.simibubi.create.Create;

/**
 * A class containing some basic setup for other recipe generators to use.
 * Addons should extend this if they add a custom recipe type that is not
 * a processing recipe type and want to use Create's helpers.
 * For processing recipes extend {@link ProcessingRecipeGen}.
 */
public abstract class BaseRecipeProvider extends class_2446 {
	protected final String modid;
	protected final List<GeneratedRecipe> all = new ArrayList<>();

	public BaseRecipeProvider(class_7784 output, String defaultNamespace) {
		super(output);
		this.modid = defaultNamespace;
	}

	protected class_2960 asResource(String path) {
		return new class_2960(modid, path);
	}

	protected GeneratedRecipe register(GeneratedRecipe recipe) {
		all.add(recipe);
		return recipe;
	}

	@Override
	public void method_10419(Consumer<class_2444> p_200404_1_) {
		all.forEach(c -> c.register(p_200404_1_));
		Create.LOGGER.info(method_10321() + " registered " + all.size() + " recipe" + (all.size() == 1 ? "" : "s"));
	}

	@FunctionalInterface
	public interface GeneratedRecipe {
		void register(Consumer<class_2444> consumer);
	}
}
