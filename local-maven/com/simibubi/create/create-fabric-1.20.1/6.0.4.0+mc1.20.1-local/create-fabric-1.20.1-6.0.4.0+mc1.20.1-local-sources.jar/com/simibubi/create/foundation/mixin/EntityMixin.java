package com.simibubi.create.foundation.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import com.llamalad7.mixinextras.sugar.Local;
import com.simibubi.create.content.equipment.armor.CardboardArmorHandler;
import com.simibubi.create.content.equipment.armor.NetheriteDivingHandler;
import net.minecraft.class_1297;
import net.minecraft.class_4050;

@Mixin(value = class_1297.class, priority = 1500)
public class EntityMixin {
@ModifyExpressionValue(method = "canEnterPose", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/Level;noCollision(Lnet/minecraft/world/entity/Entity;Lnet/minecraft/world/phys/AABB;)Z"))
	public boolean create$playerHidingAsBoxIsCrouchingNotSwimming(boolean original, @Local(argsOnly = true) class_4050 pose) {
		return original || (pose == class_4050.field_18081 && CardboardArmorHandler.testForStealth((class_1297) (Object) this));
	}

	@ModifyReturnValue(method = "fireImmune()Z", at = @At("RETURN"))
	public boolean create$onFireImmune(boolean original) {
		return ((class_1297) (Object) this).getCustomData().method_10577(NetheriteDivingHandler.FIRE_IMMUNE_KEY) || original;
	}
}
