package com.simibubi.create.foundation.data;

import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_6328;

@class_6328
public class SharedProperties {

	public static class_2248 wooden() {
		return class_2246.field_10558;
	}

	public static class_2248 stone() {
		return class_2246.field_10115;
	}

	public static class_2248 softMetal() {
		return class_2246.field_10205;
	}

	public static class_2248 copperMetal() {
		return class_2246.field_27119;
	}

	public static class_2248 netheriteMetal() {
		return class_2246.field_22108;
	}
}
