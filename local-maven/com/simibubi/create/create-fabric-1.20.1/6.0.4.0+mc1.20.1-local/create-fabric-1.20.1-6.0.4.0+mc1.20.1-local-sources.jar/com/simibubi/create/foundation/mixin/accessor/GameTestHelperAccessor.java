package com.simibubi.create.foundation.mixin.accessor;

import net.minecraft.class_4516;
import net.minecraft.class_4517;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_4516.class)
public interface GameTestHelperAccessor {
	@Accessor
	class_4517 getTestInfo();
	@Accessor
	boolean getFinalCheckAdded();
	@Accessor
	void setFinalCheckAdded(boolean value);
}
