package com.simibubi.create.foundation.mixin.accessor;

import java.util.List;
import net.minecraft.class_4915;
import net.minecraft.class_4915.class_8072;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_4915.class)
public interface ItemModelGeneratorsAccessor {
	@Accessor("GENERATED_TRIM_MODELS")
	static List<class_8072> create$getGENERATED_TRIM_MODELS() {
		throw new AssertionError();
	}
}
