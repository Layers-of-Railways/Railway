package com.simibubi.create.api.contraption.dispenser;

import com.simibubi.create.content.contraptions.behaviour.MovementContext;
import net.minecraft.class_1263;
import net.minecraft.class_1542;
import net.minecraft.class_1799;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2347;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2614;
import net.minecraft.class_6088;

/**
 * A parallel to {@link class_2347}, providing a common, default, extendable dispense implementation.
 */
public class DefaultMountedDispenseBehavior implements MountedDispenseBehavior {
	/**
	 * A reusable instance of the default behavior.
	 */
	public static final MountedDispenseBehavior INSTANCE = new DefaultMountedDispenseBehavior();

	@Override
	public class_1799 dispense(class_1799 stack, MovementContext context, class_2338 pos) {
		class_243 normal = MountedDispenseBehavior.getDispenserNormal(context);

		class_2350 closestToFacing = MountedDispenseBehavior.getClosestFacingDirection(normal);
		class_1263 inventory = class_2614.method_11250(context.world, pos.method_10093(closestToFacing));
		if (inventory == null) {
			class_1799 remainder = this.execute(stack, context, pos, normal);
			this.playSound(context.world, pos);
			this.playAnimation(context.world, pos, closestToFacing);
			return remainder;
		} else {
			class_1799 toInsert = stack.method_46651(1);
			class_1799 remainder = class_2614.method_11260(null, inventory, toInsert, closestToFacing.method_10153());
			if (remainder.method_7960()) {
				stack.method_7934(1);
			}
		}
		return stack;
	}

	/**
	 * Dispense the given item. Sounds and particles are already handled.
	 * @return the remaining items after dispensing one
	 */
	protected class_1799 execute(class_1799 stack, MovementContext context, class_2338 pos, class_243 facing) {
		class_1799 toDispense = stack.method_7971(1);
		spawnItem(context.world, toDispense, 6, facing, pos, context);
		return stack;
	}

	protected void playSound(class_1936 level, class_2338 pos) {
		level.method_20290(class_6088.field_31140, pos, 0);
	}

	protected void playAnimation(class_1936 level, class_2338 pos, class_243 facing) {
		this.playAnimation(level, pos, MountedDispenseBehavior.getClosestFacingDirection(facing));
	}

	protected void playAnimation(class_1936 level, class_2338 pos, class_2350 direction) {
		level.method_20290(class_6088.field_31143, pos, direction.method_10146());
	}

	public static void spawnItem(class_1937 level, class_1799 stack, int speed, class_243 facing, class_2338 pos, MovementContext context) {
		double x = pos.method_10263() + facing.field_1352 + .5;
		double y = pos.method_10264() + facing.field_1351 + .5;
		double z = pos.method_10260() + facing.field_1350 + .5;
		if (MountedDispenseBehavior.getClosestFacingDirection(facing).method_10166() == class_2350.class_2351.field_11052) {
			y = y - 0.125;
		} else {
			y = y - 0.15625;
		}

		class_1542 entity = new class_1542(level, x, y, z, stack);
		double d3 = level.field_9229.method_43058() * 0.1 + 0.2;
		entity.method_18800(
			level.field_9229.method_43059() * 0.0075 * speed + facing.method_10216() * d3 + context.motion.field_1352,
			level.field_9229.method_43059() * 0.0075 * speed + facing.method_10214() * d3 + context.motion.field_1351,
			level.field_9229.method_43059() * 0.0075 * speed + facing.method_10215() * d3 + context.motion.field_1350
		);
		level.method_8649(entity);
	}
}
