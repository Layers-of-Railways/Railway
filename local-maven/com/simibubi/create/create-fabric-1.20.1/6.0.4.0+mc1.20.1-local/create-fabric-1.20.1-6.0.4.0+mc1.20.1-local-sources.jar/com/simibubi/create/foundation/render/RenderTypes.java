package com.simibubi.create.foundation.render;

import java.io.IOException;
import java.util.function.BiFunction;
import java.util.function.Function;
import com.simibubi.create.Create;
import net.fabricmc.fabric.api.client.rendering.v1.CoreShaderRegistrationCallback;
import net.minecraft.class_156;
import net.minecraft.class_1921;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_2960;
import net.minecraft.class_4668;
import net.minecraft.class_5944;
import io.github.fabricators_of_create.porting_lib.mixin.accessors.client.accessor.RenderTypeAccessor;

public class RenderTypes extends class_4668 {
	public static final class_4668.class_5942 GLOWING_SHADER = new class_4668.class_5942(() -> Shaders.glowingShader);

	private static final class_1921 ENTITY_SOLID_BLOCK_MIPPED = class_1921.method_24049(createLayerName("entity_solid_block_mipped"),
			class_290.field_1580, class_293.class_5596.field_27382, 256, true, false,
			class_1921.class_4688.method_23598()
				.method_34578(field_29450)
				.method_34577(field_21376)
				.method_23615(field_21364)
				.method_23608(field_21383)
				.method_23611(field_21385)
				.method_23617(true));

	private static final class_1921 ENTITY_CUTOUT_BLOCK_MIPPED = class_1921.method_24049(createLayerName("entity_cutout_block_mipped"),
			class_290.field_1580, class_293.class_5596.field_27382, 256, true, false,
			class_1921.class_4688.method_23598()
				.method_34578(field_29451)
				.method_34577(field_21376)
				.method_23615(field_21364)
				.method_23608(field_21383)
				.method_23611(field_21385)
				.method_23617(true));

	private static final class_1921 ENTITY_TRANSLUCENT_BLOCK_MIPPED = class_1921.method_24049(createLayerName("entity_translucent_block_mipped"),
			class_290.field_1580, class_293.class_5596.field_27382, 256, true, true,
			class_1921.class_4688.method_23598()
				.method_34578(field_29406)
				.method_34577(field_21376)
				.method_23615(field_21370)
				.method_23608(field_21383)
				.method_23611(field_21385)
				.method_23617(true));

	private static final class_1921 ADDITIVE = class_1921.method_24049(createLayerName("additive"), class_290.field_1590,
		class_293.class_5596.field_27382, 256, true, true, class_1921.class_4688.method_23598()
			.method_34578(field_29443)
			.method_34577(field_21377)
			.method_23615(field_21366)
			.method_23603(field_21345)
			.method_23608(field_21383)
			.method_23611(field_21385)
			.method_23617(true));

	private static final class_1921 ITEM_GLOWING_SOLID = class_1921.method_24049(createLayerName("item_glowing_solid"),
		class_290.field_1580, class_293.class_5596.field_27382, 256, true, false, class_1921.class_4688.method_23598()
			.method_34578(GLOWING_SHADER)
			.method_34577(field_21377)
			.method_23608(field_21383)
			.method_23611(field_21385)
			.method_23617(true));

	private static final class_1921 ITEM_GLOWING_TRANSLUCENT = RenderTypeAccessor.port_lib$create(createLayerName("item_glowing_translucent"),
		class_290.field_1580, class_293.class_5596.field_27382, 256, true, true, class_1921.class_4688.method_23598()
			.method_34578(GLOWING_SHADER)
			.method_34577(field_21377)
			.method_23615(field_21370)
			.method_23608(field_21383)
			.method_23611(field_21385)
			.method_23617(true));

	private static final Function<class_2960, class_1921> CHAIN = class_156.method_34866((p_234330_) -> {
		return class_1921.method_24049("chain_conveyor_chain", class_290.field_1590, class_293.class_5596.field_27382, 256, false,
			true, class_1921.class_4688.method_23598()
				.method_34578(field_29444)
				.method_34577(new class_4668.class_4683(p_234330_, false, true))
				.method_23615(field_21364)
				.method_23616(field_21349)
				.method_23608(field_21383)
				.method_23611(field_21385)
				.method_23617(false));
	});

	public static class_1921 entitySolidBlockMipped() {
		return ENTITY_SOLID_BLOCK_MIPPED;
	}

	public static class_1921 entityCutoutBlockMipped() {
		return ENTITY_CUTOUT_BLOCK_MIPPED;
	}

	public static class_1921 entityTranslucentBlockMipped() {
		return ENTITY_TRANSLUCENT_BLOCK_MIPPED;
	}

	public static class_1921 additive() {
		return ADDITIVE;
	}

	public static BiFunction<class_2960, Boolean, class_1921> TRAIN_MAP = class_156.method_34865(RenderTypes::getTrainMap);

	private static class_1921 getTrainMap(class_2960 locationIn, boolean linearFiltering) {
		class_1921.class_4688 rendertype$state = class_1921.class_4688.method_23598()
			.method_34578(field_29427)
			.method_34577(new class_4668.class_4683(locationIn, linearFiltering, false))
			.method_23615(field_21364)
			.method_23608(field_21383)
			.method_23617(false);
		return class_1921.method_24049("create_train_map", class_290.field_20888,
			class_293.class_5596.field_27382, 256, false, true, rendertype$state);
	}

	public static class_1921 itemGlowingSolid() {
		return ITEM_GLOWING_SOLID;
	}

	public static class_1921 itemGlowingTranslucent() {
		return ITEM_GLOWING_TRANSLUCENT;
	}

	public static class_1921 chain(class_2960 pLocation) {
		return CHAIN.apply(pLocation);
	}

	private static String createLayerName(String name) {
		return Create.ID + ":" + name;
	}

	// Mmm gimme those protected fields
	private RenderTypes() {
		super(null, null, null);
	}

	public static void init() {
		CoreShaderRegistrationCallback.EVENT.register(Shaders::onRegisterShaders);
	}

	private static class Shaders {
		private static class_5944 glowingShader;

		public static void onRegisterShaders(CoreShaderRegistrationCallback.RegistrationContext ctx) throws IOException {
			ctx.register(Create.asResource("glowing_shader"),
				class_290.field_1580, shader -> glowingShader = shader);
		}
	}
}
