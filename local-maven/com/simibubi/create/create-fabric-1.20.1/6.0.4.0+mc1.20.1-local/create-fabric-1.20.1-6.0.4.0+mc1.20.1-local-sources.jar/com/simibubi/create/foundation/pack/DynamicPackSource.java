package com.simibubi.create.foundation.pack;

import java.util.function.Consumer;
import net.minecraft.class_2561;
import net.minecraft.class_3262;
import net.minecraft.class_3264;
import net.minecraft.class_3285;
import net.minecraft.class_3288;
import net.minecraft.class_5352;
import org.jetbrains.annotations.NotNull;

// TODO - Move into catnip
public record DynamicPackSource(String packId, class_3264 packType, class_3288.class_3289 packPosition,
								class_3262 packResources) implements class_3285 {
	@Override
	public void method_14453(@NotNull Consumer<class_3288> onLoad) {
		onLoad.accept(class_3288.method_45275(packId, class_2561.method_43470(packId), true, id -> packResources, packType, packPosition, class_5352.field_25348));
	}
}
