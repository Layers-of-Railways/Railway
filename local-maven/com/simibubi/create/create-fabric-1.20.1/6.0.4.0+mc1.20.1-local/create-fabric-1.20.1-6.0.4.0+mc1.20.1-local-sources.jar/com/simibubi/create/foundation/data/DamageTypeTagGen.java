package com.simibubi.create.foundation.data;

import java.util.concurrent.CompletableFuture;

import com.simibubi.create.AllDamageTypes;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricTagProvider;
import net.minecraft.class_7225;
import net.minecraft.class_7924;
import net.minecraft.class_8103;
import net.minecraft.class_8110;

public class DamageTypeTagGen extends FabricTagProvider<class_8110> {
	public DamageTypeTagGen(FabricDataOutput output, CompletableFuture<class_7225.class_7874> lookupProvider) {
		super(output, class_7924.field_42534, lookupProvider);
	}

	@Override
	protected void method_10514(class_7225.class_7874 provider) {
		method_10512(class_8103.field_42241)
				.method_40565(AllDamageTypes.CRUSH, AllDamageTypes.FAN_FIRE, AllDamageTypes.FAN_LAVA, AllDamageTypes.DRILL, AllDamageTypes.SAW);
		method_10512(class_8103.field_42246)
				.method_40565(AllDamageTypes.FAN_FIRE, AllDamageTypes.FAN_LAVA);
		method_10512(class_8103.field_42249)
				.method_46835(AllDamageTypes.CUCKOO_SURPRISE);
	}

	@Override
	public String method_10321() {
		return "Create's Damage Type Tags";
	}
}
