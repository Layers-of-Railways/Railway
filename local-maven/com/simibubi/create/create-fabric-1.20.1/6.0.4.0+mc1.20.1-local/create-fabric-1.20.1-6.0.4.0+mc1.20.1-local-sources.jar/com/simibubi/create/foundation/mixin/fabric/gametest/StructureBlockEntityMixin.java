package com.simibubi.create.foundation.mixin.fabric.gametest;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import com.simibubi.create.foundation.ponder.FabricStructureProcessing;
import com.simibubi.create.foundation.utility.fabric.StructureBlockEntityExtensions;

import net.createmod.catnip.nbt.NBTHelper;
import net.minecraft.class_2487;
import net.minecraft.class_2633;
import net.minecraft.class_2960;
import net.minecraft.class_3492;

@Mixin(class_2633.class)
public abstract class StructureBlockEntityMixin implements StructureBlockEntityExtensions {
	@Shadow
	public abstract String getStructureName();

	@Unique
	private boolean isGameTest;

	@Override
	public void create$markGameTest() {
		this.isGameTest = true;
	}

	@Inject(method = "saveAdditional", at = @At("TAIL"))
	private void saveIsGameTest(class_2487 tag, CallbackInfo ci) {
		if (this.isGameTest) {
			NBTHelper.putMarker(tag, "create:is_game_test");
		}
	}

	@Inject(method = "load", at = @At("TAIL"))
	private void loadIsGameTest(class_2487 tag, CallbackInfo ci) {
		this.isGameTest = tag.method_10545("create:is_game_test");
	}

	@ModifyArg(
		method = "loadStructure(Lnet/minecraft/server/level/ServerLevel;ZLnet/minecraft/world/level/levelgen/structure/templatesystem/StructureTemplate;)Z",
		at = @At(
			value = "INVOKE",
			target = "Lnet/minecraft/world/level/levelgen/structure/templatesystem/StructureTemplate;placeInWorld(Lnet/minecraft/world/level/ServerLevelAccessor;Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/levelgen/structure/templatesystem/StructurePlaceSettings;Lnet/minecraft/util/RandomSource;I)Z"
		)
	)
	private class_3492 addProcessorToGameTests(class_3492 settings) {
		if (this.isGameTest) {
			String name = this.getStructureName();
			class_2960 id = class_2960.method_12829(name);
			if (id != null) {
				settings.method_16184(new FabricStructureProcessing.Processor(id));
			}
		}

		return settings;
	}
}
