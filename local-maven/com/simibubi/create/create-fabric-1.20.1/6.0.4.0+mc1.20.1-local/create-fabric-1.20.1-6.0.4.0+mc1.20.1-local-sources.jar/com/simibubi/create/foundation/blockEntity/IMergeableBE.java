package com.simibubi.create.foundation.blockEntity;

import net.minecraft.class_2586;

public interface IMergeableBE {
	
	public void accept(class_2586 other);

}
