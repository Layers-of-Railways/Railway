package com.simibubi.create.foundation.render.fabric;

import java.util.function.Supplier;
import net.fabricmc.fabric.api.renderer.v1.material.BlendMode;
import net.fabricmc.fabric.api.renderer.v1.mesh.QuadView;
import net.fabricmc.fabric.api.renderer.v1.model.ForwardingBakedModel;
import net.fabricmc.fabric.api.renderer.v1.render.RenderContext;
import net.minecraft.class_1087;
import net.minecraft.class_1799;
import net.minecraft.class_1920;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_5819;

public class DefaultLayerFilteringBakedModel extends ForwardingBakedModel {
	private static final ThreadLocal<DefaultLayerFilteringBakedModel> THREAD_LOCAL = ThreadLocal.withInitial(DefaultLayerFilteringBakedModel::new);

	public static class_1087 wrap(class_1087 model) {
		if (!model.isVanillaAdapter()) {
			DefaultLayerFilteringBakedModel wrapper = THREAD_LOCAL.get();
			wrapper.wrapped = model;
			return wrapper;
		}
		return model;
	}

	protected DefaultLayerFilteringBakedModel() {
	}

	@Override
	public void emitBlockQuads(class_1920 blockView, class_2680 state, class_2338 pos, Supplier<class_5819> randomSupplier, RenderContext context) {
		context.pushTransform(DefaultLayerFilteringBakedModel::hasDefaultBlendMode);
		super.emitBlockQuads(blockView, state, pos, randomSupplier, context);
		context.popTransform();
	}

	@Override
	public void emitItemQuads(class_1799 stack, Supplier<class_5819> randomSupplier, RenderContext context) {
		context.pushTransform(DefaultLayerFilteringBakedModel::hasDefaultBlendMode);
		super.emitItemQuads(stack, randomSupplier, context);
		context.popTransform();
	}

	public static boolean hasDefaultBlendMode(QuadView quad) {
		return quad.material().blendMode() == BlendMode.DEFAULT;
	}
}
