package com.simibubi.create.foundation.utility;

import net.createmod.catnip.animation.LerpedFloat;
import net.createmod.catnip.math.AngleHelper;
import net.minecraft.class_310;
import net.minecraft.class_3532;

public class CameraAngleAnimationService {

	private static final LerpedFloat yRotation = LerpedFloat.angular().startWithValue(0);
	private static final LerpedFloat xRotation = LerpedFloat.angular().startWithValue(0);

	private static Mode animationMode = Mode.LINEAR;
	private static float animationSpeed = -1;

	public static void tick() {

		yRotation.tickChaser();
		xRotation.tickChaser();

		if (class_310.method_1551().field_1724 != null) {
			if (!yRotation.settled())
				class_310.method_1551().field_1724.method_36456(yRotation.getValue(1));

			if (!xRotation.settled())
				class_310.method_1551().field_1724.method_36457(xRotation.getValue(1));
		}
	}

	public static boolean isYawAnimating() {
		return !yRotation.settled();
	}

	public static boolean isPitchAnimating() {
		return !xRotation.settled();
	}

	public static float getYaw(float partialTicks) {
		return yRotation.getValue(partialTicks);
	}

	public static float getPitch(float partialTicks) {
		return xRotation.getValue(partialTicks);
	}

	public static void setAnimationMode(Mode mode) {
		animationMode = mode;
	}

	public static void setAnimationSpeed(float speed) {
		animationSpeed = speed;
	}

	public static void setYawTarget(float yaw) {
		float currentYaw = getCurrentYaw();
		yRotation.startWithValue(currentYaw);
		setupChaser(yRotation, currentYaw + AngleHelper.getShortestAngleDiff(currentYaw, class_3532.method_15393(yaw)));
	}

	public static void setPitchTarget(float pitch) {
		float currentPitch = getCurrentPitch();
		xRotation.startWithValue(currentPitch);
		setupChaser(xRotation, currentPitch + AngleHelper.getShortestAngleDiff(currentPitch, class_3532.method_15393(pitch)));
	}

	private static float getCurrentYaw() {
		if (class_310.method_1551().field_1724 == null)
			return 0;
		return class_3532.method_15393(class_310.method_1551().field_1724.method_36454());
	}

	private static float getCurrentPitch() {
		if (class_310.method_1551().field_1724 == null)
			return 0;

		return class_3532.method_15393(class_310.method_1551().field_1724.method_36455());
	}

	private static void setupChaser(LerpedFloat rotation, float target) {
		if (animationMode == Mode.LINEAR) {
			rotation.chase(target, animationSpeed > 0 ? animationSpeed : 2, LerpedFloat.Chaser.LINEAR);
		} else if (animationMode == Mode.EXPONENTIAL) {
			rotation.chase(target, animationSpeed > 0 ? animationSpeed : 0.25, LerpedFloat.Chaser.EXP);
		}
	}

	public enum Mode {
		LINEAR,
		EXPONENTIAL
	}
}
