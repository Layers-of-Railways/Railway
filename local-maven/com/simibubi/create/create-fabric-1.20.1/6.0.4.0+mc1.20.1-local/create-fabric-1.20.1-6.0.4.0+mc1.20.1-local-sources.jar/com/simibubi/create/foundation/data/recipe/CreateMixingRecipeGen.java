package com.simibubi.create.foundation.data.recipe;

import com.simibubi.create.AllFluids;
import com.simibubi.create.AllItems;
import com.simibubi.create.AllTags.AllItemTags;
import com.simibubi.create.Create;
import com.simibubi.create.api.data.recipe.BaseRecipeProvider.GeneratedRecipe;
import com.simibubi.create.api.data.recipe.MixingRecipeGen;
import com.simibubi.create.content.processing.recipe.HeatCondition;
import com.simibubi.create.foundation.recipe.BlockTagIngredient;
import io.github.fabricators_of_create.porting_lib.tags.Tags;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_3481;
import net.minecraft.class_3489;
import net.minecraft.class_3612;
import net.minecraft.class_7784;

/**
 * Create's own Data Generation for Mixing recipes
 * @see MixingRecipeGen
 */
@SuppressWarnings("unused")
public final class CreateMixingRecipeGen extends MixingRecipeGen {

	GeneratedRecipe

	TEMP_LAVA = create("lava_from_cobble", b -> b.require(Tags.Items.COBBLESTONE)
		.output(class_3612.field_15908, 50)
		.requiresHeat(HeatCondition.SUPERHEATED)),

	TEA = create("tea", b -> b.require(class_3612.field_15910, 250)
		.require(Tags.Fluids.MILK, 250)
		.require(class_3489.field_15558)
		.output(AllFluids.TEA.get(), 500)
		.requiresHeat(HeatCondition.HEATED)),

	CHOCOLATE = create("chocolate", b -> b.require(Tags.Fluids.MILK, 250)
		.require(class_1802.field_8479)
		.require(class_1802.field_8116)
		.output(AllFluids.CHOCOLATE.get(), 250)
		.requiresHeat(HeatCondition.HEATED)),

	CHOCOLATE_MELTING = create("chocolate_melting", b -> b.require(AllItems.BAR_OF_CHOCOLATE.get())
		.output(AllFluids.CHOCOLATE.get(), 250)
		.requiresHeat(HeatCondition.HEATED)),

	HONEY = create("honey", b -> b.require(class_1802.field_21086)
		.output(AllFluids.HONEY.get(), 1000)
		.requiresHeat(HeatCondition.HEATED)),

	DOUGH = create("dough_by_mixing", b -> b.require(CreateRecipeProvider.I.wheatFlour())
		.require(class_3612.field_15910, 1000)
		.output(AllItems.DOUGH.get(), 1)),

	BRASS_INGOT = create("brass_ingot", b -> b.require(CreateRecipeProvider.I.copper())
		.require(CreateRecipeProvider.I.zinc())
		.output(AllItems.BRASS_INGOT.get(), 2)
		.requiresHeat(HeatCondition.HEATED)),

	ANDESITE_ALLOY = create("andesite_alloy", b -> b.require(class_2246.field_10115)
		.require(CreateRecipeProvider.I.ironNugget())
		.output(CreateRecipeProvider.I.andesiteAlloy(), 1)),

	ANDESITE_ALLOY_FROM_ZINC = create("andesite_alloy_from_zinc", b -> b.require(class_2246.field_10115)
		.require(CreateRecipeProvider.I.zincNugget())
		.output(CreateRecipeProvider.I.andesiteAlloy(), 1)),

	MUD = create("mud_by_mixing", b -> b.require(BlockTagIngredient.create(class_3481.field_37397))
		.require(class_3612.field_15910, 250)
		.output(class_2246.field_37576, 1)),

	PULP = create("cardboard_pulp", b -> b
		.require(AllItemTags.PULPIFIABLE.tag)
		.require(AllItemTags.PULPIFIABLE.tag)
		.require(AllItemTags.PULPIFIABLE.tag)
		.require(AllItemTags.PULPIFIABLE.tag)
		.require(class_3612.field_15910, 250)
		.output(AllItems.PULP, 1)),

	// AE2

	AE2_FLUIX = create(Mods.AE2.recipeId("fluix_crystal"), b -> b.require(Tags.Items.DUSTS_REDSTONE)
		.require(class_3612.field_15910, 250)
		.require(Mods.AE2, "charged_certus_quartz_crystal")
		.require(Tags.Items.GEMS_QUARTZ)
		.output(1f, Mods.AE2, "fluix_crystal", 2)
		.whenModLoaded(Mods.AE2.getId())),

	// Regions Unexplored

	RU_PEAT_MUD = moddedMud(Mods.RU, "peat"),
	RU_SILT_MUD = moddedMud(Mods.RU, "silt")

	;

	public CreateMixingRecipeGen(class_7784 output) {
		super(output, Create.ID);
	}

	public GeneratedRecipe moddedMud(Mods mod, String name) {
		String mud = name + "_mud";
		return create(mod.recipeId(mud), b -> b.require(class_3612.field_15910, 250)
				.require(mod, name + "_dirt")
				.output(mod, mud)
				.whenModLoaded(mod.getId()));
	}
}
