package com.simibubi.create.foundation.mixin.accessor;

import net.minecraft.class_1676;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2374;
import net.minecraft.class_2965;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_2965.class)
public interface AbstractProjectileDispenseBehaviorAccessor {
	@Invoker("getProjectile")
	class_1676 create$callGetProjectile(class_1937 level, class_2374 position, class_1799 stack);

	@Invoker("getUncertainty")
	float create$callGetUncertainty();

	@Invoker("getPower")
	float create$callGetPower();
}
