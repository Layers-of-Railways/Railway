package com.simibubi.create.foundation.block.render;

import java.util.Set;

import org.jetbrains.annotations.Nullable;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_638;

public interface MultiPosDestructionHandler {
	/**
	 * Returned set must be mutable and must not be changed after it is returned.
	 */
	@Nullable
	@Environment(EnvType.CLIENT)
	Set<class_2338> getExtraPositions(class_638 level, class_2338 pos, class_2680 blockState, int progress);
}
