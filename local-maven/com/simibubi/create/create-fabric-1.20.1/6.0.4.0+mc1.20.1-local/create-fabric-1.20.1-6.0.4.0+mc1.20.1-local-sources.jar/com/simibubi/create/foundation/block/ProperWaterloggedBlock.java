package com.simibubi.create.foundation.block;

import net.minecraft.class_1750;
import net.minecraft.class_1936;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_3610;
import net.minecraft.class_3612;
import net.minecraft.class_3737;

/**
 * Waterlog checklist: <br>
 * 1. createBlockStateDefinition -> add WATERLOGGED <br>
 * 2. constructor -> default WATERLOGGED to false <br>
 * 3. getFluidState -> return fluidState <br>
 * 4. getStateForPlacement -> call withWater <br>
 * 5. updateShape -> call updateWater
 */
public interface ProperWaterloggedBlock extends class_3737 {

	class_2746 WATERLOGGED = class_2741.field_12508;

	default class_3610 fluidState(class_2680 state) {
		return state.method_11654(WATERLOGGED) ? class_3612.field_15910.method_15729(false) : class_3612.field_15906.method_15785();
	}

	default void updateWater(class_1936 level, class_2680 state, class_2338 pos) {
		if (state.method_11654(class_2741.field_12508))
			level.method_39281(pos, class_3612.field_15910, class_3612.field_15910.method_15789(level));
	}

	default class_2680 withWater(class_2680 placementState, class_1750 ctx) {
		return withWater(ctx.method_8045(), placementState, ctx.method_8037());
	}

	static class_2680 withWater(class_1936 level, class_2680 placementState, class_2338 pos) {
		if (placementState == null)
			return null;
		class_3610 ifluidstate = level.method_8316(pos);
		if (placementState.method_26215())
			return ifluidstate.method_15772() == class_3612.field_15910 ? ifluidstate.method_15759() : placementState;
		if (!(placementState.method_26204() instanceof class_3737))
			return placementState;
		return placementState.method_11657(class_2741.field_12508, ifluidstate.method_15772() == class_3612.field_15910);
	}

}
