package com.simibubi.create.infrastructure.ponder.scenes.highLogistics;

import java.util.Iterator;
import java.util.function.Supplier;
import com.simibubi.create.AllBlocks;
import com.simibubi.create.AllItems;
import com.simibubi.create.content.kinetics.chainConveyor.ChainConveyorBlockEntity;
import com.simibubi.create.content.kinetics.chainConveyor.ChainConveyorPackage;
import com.simibubi.create.content.logistics.box.PackageItem;
import com.simibubi.create.content.logistics.box.PackageStyles;
import com.simibubi.create.content.logistics.packagePort.frogport.FrogportBlockEntity;
import com.simibubi.create.content.logistics.packager.PackagerBlockEntity;
import com.simibubi.create.foundation.ponder.CreateSceneBuilder;

import net.createmod.catnip.math.AngleHelper;
import net.createmod.catnip.math.Pointing;
import net.createmod.ponder.api.PonderPalette;
import net.createmod.ponder.api.element.ElementLink;
import net.createmod.ponder.api.element.ParrotElement;
import net.createmod.ponder.api.element.ParrotPose;
import net.createmod.ponder.api.element.WorldSectionElement;
import net.createmod.ponder.api.level.PonderLevel;
import net.createmod.ponder.api.scene.SceneBuilder;
import net.createmod.ponder.api.scene.SceneBuildingUtil;
import net.createmod.ponder.api.scene.Selection;
import net.createmod.ponder.foundation.element.ElementLinkImpl;
import net.createmod.ponder.foundation.element.ParrotElementImpl;
import net.createmod.ponder.foundation.instruction.CreateParrotInstruction;
import net.minecraft.class_1087;
import net.minecraft.class_1309;
import net.minecraft.class_1542;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_7833;
import net.minecraft.class_811;
import net.minecraft.class_898;

public class FrogAndConveyorScenes {

	public static void conveyor(SceneBuilder builder, SceneBuildingUtil util) {
		CreateSceneBuilder scene = new CreateSceneBuilder(builder);
		scene.title("chain_conveyor", "Relaying rotational force using Chain Conveyors");
		scene.configureBasePlate(0, 0, 9);
		scene.scaleSceneView(.75f);
		scene.setSceneOffsetY(-1);
		scene.world()
			.showSection(util.select()
				.layer(0), class_2350.field_11036);

		Selection pole = util.select()
			.fromTo(1, 1, 6, 1, 3, 6);
		Selection cogs = util.select()
			.position(8, 1, 2);
		Selection cogs2 = util.select()
			.fromTo(7, 1, 1, 7, 3, 1);

		class_2338 conv1 = util.grid()
			.at(7, 4, 1);
		class_2338 conv2 = util.grid()
			.at(1, 4, 7);
		class_2338 conv3 = util.grid()
			.at(1, 2, 4);
		class_2338 conv4 = util.grid()
			.at(7, 4, 7);

		connection(builder, conv1, conv2, false);
		connection(builder, conv1, conv3, false);
		connection(builder, conv1, conv4, false);

		Selection pole3 = util.select()
			.position(1, 1, 4);
		Selection pole4 = util.select()
			.fromTo(7, 1, 7, 7, 3, 7);
		Selection cogsBelow = util.select()
			.fromTo(1, 2, 7, 1, 3, 7);
		Selection cogsAbove = util.select()
			.position(1, 5, 7);

		Selection conv1S = util.select()
			.position(conv1);
		Selection conv2S = util.select()
			.position(conv2);
		Selection conv3S = util.select()
			.position(conv3);
		Selection conv4S = util.select()
			.position(conv4);

		scene.world()
			.setKineticSpeed(conv2S, 0);

		scene.idle(5);
		scene.world()
			.showSection(cogs, class_2350.field_11034);
		scene.idle(5);
		scene.world()
			.showSection(cogs2, class_2350.field_11033);
		scene.idle(5);
		scene.world()
			.showSection(conv1S, class_2350.field_11033);
		ElementLink<WorldSectionElement> poleE = scene.world()
			.showIndependentSection(pole, class_2350.field_11033);
		scene.world()
			.moveSection(poleE, util.vector()
				.of(0, 0, 1), 0);
		scene.idle(5);
		scene.world()
			.showSection(conv2S, class_2350.field_11033);
		scene.idle(20);

		class_1799 chainItem = new class_1799(class_1802.field_23983);
		scene.overlay()
			.showControls(util.vector()
				.topOf(conv1), Pointing.DOWN, 117)
			.rightClick()
			.withItem(chainItem);

		class_243 c1 = util.vector()
			.centerOf(conv1);
		class_238 bb1 = new class_238(c1, c1);
		scene.overlay()
			.chaseBoundingBoxOutline(PonderPalette.GREEN, conv1, bb1, 10);
		scene.idle(1);
		scene.overlay()
			.chaseBoundingBoxOutline(PonderPalette.GREEN, conv1, bb1.method_1009(1, 0.5, 1), 117);
		scene.idle(16);

		scene.overlay()
			.showControls(util.vector()
				.topOf(conv2), Pointing.DOWN, 100)
			.rightClick()
			.withItem(chainItem);

		class_243 c2 = util.vector()
			.centerOf(conv2);
		class_238 bb2 = new class_238(c2, c2);
		scene.overlay()
			.chaseBoundingBoxOutline(PonderPalette.GREEN, conv2, bb2, 10);
		scene.idle(1);
		scene.overlay()
			.chaseBoundingBoxOutline(PonderPalette.GREEN, conv2, bb2.method_1009(1, 0.5, 1), 100);
		scene.idle(10);

		connection(builder, conv1, conv2, true);
		scene.world()
			.setKineticSpeed(conv2S, -32);

		scene.overlay()
			.showText(80)
			.text("Right-click two conveyors with chains to connect them")
			.attachKeyFrame()
			.placeNearTarget()
			.pointAt(util.vector()
				.topOf(conv1.method_10069(-1, 0, -1)));
		scene.idle(90);

		scene.world()
			.showSection(pole3, class_2350.field_11033);
		scene.idle(3);
		scene.world()
			.showSection(pole4, class_2350.field_11033);
		scene.idle(6);
		scene.world()
			.showSection(conv3S, class_2350.field_11033);
		scene.idle(3);
		scene.world()
			.showSection(conv4S, class_2350.field_11033);
		scene.idle(12);
		connection(builder, conv1, conv3, true);
		scene.idle(3);
		connection(builder, conv1, conv4, true);
		scene.idle(20);

		scene.overlay()
			.showText(70)
			.text("Chain conveyors relay rotational power between each other..")
			.attachKeyFrame()
			.placeNearTarget()
			.pointAt(util.vector()
				.topOf(conv3.method_10069(-1, 0, -1)));
		scene.idle(60);

		scene.world()
			.hideIndependentSection(poleE, class_2350.field_11035);
		scene.idle(20);
		scene.world()
			.showSection(cogsAbove, class_2350.field_11033);
		scene.idle(3);
		scene.world()
			.showSection(cogsBelow, class_2350.field_11036);
		scene.idle(12);

		scene.effects()
			.rotationDirectionIndicator(conv2.method_10084());
		scene.idle(3);
		scene.effects()
			.rotationDirectionIndicator(conv2.method_10087(2));
		scene.idle(10);

		scene.overlay()
			.showText(60)
			.text("..and connect to shafts above or below them")
			.attachKeyFrame()
			.placeNearTarget()
			.pointAt(util.vector()
				.centerOf(util.grid()
					.at(1, 2, 7)));
		scene.idle(60);
		scene.world()
			.hideSection(cogsBelow, class_2350.field_11035);
		scene.idle(15);
		ElementLink<WorldSectionElement> poleE2 = scene.world()
			.showIndependentSection(pole, class_2350.field_11034);
		scene.world()
			.moveSection(poleE2, util.vector()
				.of(0, 0, 1), 0);
		scene.idle(10);

		scene.overlay()
			.showText(80)
			.text("Right-click holding a wrench to start travelling on the chain")
			.attachKeyFrame()
			.independent(30);

		scene.idle(40);
		ElementLink<ParrotElement> parrot = new ElementLinkImpl<>(ParrotElement.class);
		class_243 parrotStart = util.vector()
			.centerOf(conv2)
			.method_1031(0, -1.45, 1);
		ChainConveyorParrotElement element =
			new ChainConveyorParrotElement(parrotStart, ParrotPose.FacePointOfInterestPose::new);
		scene.addInstruction(new CreateParrotInstruction(0, class_2350.field_11033, element));
		scene.addInstruction(s -> s.linkElement(element, parrot));
		scene.special()
			.movePointOfInterest(util.grid()
				.at(0, 3, 2));

		scene.idle(20);
		scene.special()
			.moveParrot(parrot, util.vector()
				.of(-1, 0, -1), 14);
		scene.idle(14);
		scene.special()
			.movePointOfInterest(util.grid()
				.at(7, 3, 0));
		scene.special()
			.moveParrot(parrot, util.vector()
				.of(5.75, 0, -5.75), 90);
		scene.idle(65);

		scene.overlay()
			.showText(60)
			.text("At a junction, face towards a chain to follow it")
			.attachKeyFrame()
			.placeNearTarget()
			.pointAt(util.vector()
				.topOf(conv1));

		scene.idle(25);
		scene.special()
			.movePointOfInterest(util.grid()
				.at(9, 3, 1));
		scene.special()
			.moveParrot(parrot, util.vector()
				.of(1, 0, -1), 14);
		scene.idle(14);
		scene.special()
			.movePointOfInterest(util.grid()
				.at(9, 3, 3));
		scene.special()
			.moveParrot(parrot, util.vector()
				.of(0.5, 0, 0), 6);
		scene.idle(6);
		scene.special()
			.movePointOfInterest(util.grid()
				.at(8, 3, 10));
		scene.special()
			.moveParrot(parrot, util.vector()
				.of(0.5, 0, 0.5), 14);
		scene.idle(14);
		scene.special()
			.moveParrot(parrot, util.vector()
				.of(0, 0, 7), 78);
		scene.idle(78);
		scene.special()
			.hideElement(parrot, class_2350.field_11035);
	}

	private static void connection(SceneBuilder builder, class_2338 p1, class_2338 p2, boolean connect) {
		builder.world()
			.modifyBlockEntity(p1, ChainConveyorBlockEntity.class, be -> {
				if (connect)
					be.connections.add(p2.method_10059(p1));
				else
					be.connections.remove(p2.method_10059(p1));
			});
		builder.world()
			.modifyBlockEntity(p2, ChainConveyorBlockEntity.class, be -> {
				if (connect)
					be.connections.add(p1.method_10059(p2));
				else
					be.connections.remove(p1.method_10059(p2));
			});
	}

	public static class ChainConveyorParrotElement extends ParrotElementImpl {

		private class_1542 wrench;

		public ChainConveyorParrotElement(class_243 location, Supplier<? extends ParrotPose> pose) {
			super(location, pose);
		}

		@Override
		protected void renderLast(PonderLevel world, class_4597 buffer, class_332 graphics, float fade,
			float pt) {
			class_4587 poseStack = graphics.method_51448();
			class_898 entityrenderermanager = class_310.method_1551()
				.method_1561();

			if (entity == null) {
				entity = pose.create(world);
				entity.method_36456(entity.field_5982 = 180);
			}

			if (wrench == null) {
				wrench = new class_1542(world, 0, 0, 0, AllItems.WRENCH.asStack());
				wrench.method_36456(wrench.field_5982 = 180);
			}

			double lx = class_3532.method_16436(pt, entity.field_6014, entity.method_23317());
			double ly = class_3532.method_16436(pt, entity.field_6036, entity.method_23318());
			double lz = class_3532.method_16436(pt, entity.field_5969, entity.method_23321());
			float angle = AngleHelper.angleLerp(pt, entity.field_5982, entity.method_36454());

			poseStack.method_22903();
			poseStack.method_22904(location.field_1352, location.field_1351, location.field_1350);
			poseStack.method_22904(lx, ly, lz);
			poseStack.method_22907(class_7833.field_40716.rotationDegrees(angle));

			poseStack.method_46416(0, 1.5f, 0);
			poseStack.method_22907(class_7833.field_40718.rotationDegrees(class_3532.method_15374((world.scene.getCurrentTime() + pt) * 0.2f) * 10));
			poseStack.method_46416(0, -1.5f, 0);

			poseStack.method_22903();
			poseStack.method_22907(class_7833.field_40716.rotationDegrees(90));
			poseStack.method_22907(class_7833.field_40714.rotationDegrees(90));
			poseStack.method_22907(class_7833.field_40718.rotationDegrees(90));
			poseStack.method_22905(1.5f, 1.5f, 1.5f);
			poseStack.method_22904(-0.1, 0.2, -0.6);
			class_1087 bakedmodel = class_310.method_1551()
				.method_1480()
				.method_4019(wrench.method_6983(), world, (class_1309) null, 0);
			class_310.method_1551()
				.method_1480()
				.method_23179(wrench.method_6983(), class_811.field_4318, false, poseStack, buffer,
					lightCoordsFromFade(fade), class_4608.field_21444, bakedmodel);
			poseStack.method_22909();

			entity.field_6819 = 2;
			entityrenderermanager.method_3954(entity, 0, 0, 0, 0, pt, poseStack, buffer, lightCoordsFromFade(fade));
			poseStack.method_22909();
		}

	}

	public static void frogPort(SceneBuilder builder, SceneBuildingUtil util) {
		CreateSceneBuilder scene = new CreateSceneBuilder(builder);
		scene.title("package_frogport", "Transporting packages between Frogports");
		scene.configureBasePlate(0, 0, 9);
		scene.scaleSceneView(.75f);
		scene.setSceneOffsetY(-1);

		class_2338 conv1 = util.grid()
			.at(1, 4, 7);
		class_2338 conv2 = util.grid()
			.at(7, 4, 7);
		class_2338 conv3 = util.grid()
			.at(7, 4, 1);
		Selection conv1S = util.select()
			.position(conv1);
		Selection conv2S = util.select()
			.position(conv2);
		Selection conv3S = util.select()
			.position(conv3);
		Selection largeCog = util.select()
			.position(2, 1, 8);
		Selection shaftPole = util.select()
			.fromTo(1, 1, 7, 1, 3, 7);
		Selection pole2 = util.select()
			.fromTo(7, 1, 7, 7, 3, 7);
		Selection pole3 = util.select()
			.fromTo(7, 1, 1, 7, 3, 1);
		Selection largeCog2 = util.select()
			.position(9, 0, 1);
		Selection fromBelt = util.select()
			.fromTo(9, 1, 0, 6, 1, 0)
			.add(util.select()
				.fromTo(5, 1, 0, 5, 1, 1));
		class_2338 fromFunnel = util.grid()
			.at(5, 2, 1);
		Selection logistics = util.select()
			.fromTo(2, 1, 2, 1, 1, 2);
		Selection toBelt = util.select()
			.fromTo(1, 1, 9, 0, 1, 9)
			.add(util.select()
				.fromTo(0, 1, 8, 0, 1, 6))
			.add(util.select()
				.fromTo(1, 1, 5, 0, 1, 5));
		class_2338 toFunnel = util.grid()
			.at(1, 2, 5);

		class_2338 fromFrog = util.grid()
			.at(5, 2, 2);
		class_2338 toFrog = util.grid()
			.at(2, 2, 5);
		Selection fromFrogS = util.select()
			.position(fromFrog);
		Selection toFrogS = util.select()
			.position(toFrog);

		Selection casing = util.select()
			.position(5, 1, 4);
		Selection fromBarrel = util.select()
			.position(5, 1, 3);
		Selection toBarrel = util.select()
			.position(3, 1, 5);
		Selection fromPackager = util.select()
			.fromTo(7, 1, 2, 5, 1, 2);
		Selection sign = util.select()
			.position(4, 1, 2);
		class_2338 lever = util.grid()
			.at(6, 1, 1);
		Selection toPackager = util.select()
			.fromTo(2, 1, 4, 0, 1, 4);

		scene.world()
			.showSection(util.select()
				.layer(0)
				.substract(largeCog2), class_2350.field_11036);
		scene.idle(10);
		scene.world()
			.showSection(largeCog, class_2350.field_11035);
		scene.idle(2);
		scene.world()
			.showSection(shaftPole, class_2350.field_11033);
		scene.idle(2);
		scene.world()
			.showSection(pole2, class_2350.field_11033);
		scene.idle(2);
		scene.world()
			.showSection(pole3, class_2350.field_11033);
		scene.idle(5);
		scene.world()
			.showSection(conv1S, class_2350.field_11033);
		scene.world()
			.showSection(conv2S, class_2350.field_11033);
		scene.world()
			.showSection(conv3S, class_2350.field_11033);
		scene.idle(25);

		class_243 fromTarget = util.vector()
			.of(6.78, 4.37, 3.5);

		class_1799 frogItem = AllBlocks.PACKAGE_FROGPORT.asStack();
		scene.overlay()
			.showControls(fromTarget, Pointing.UP, 50)
			.rightClick()
			.withItem(frogItem);
		scene.idle(5);

		class_238 bb1 = new class_238(fromTarget, fromTarget);
		scene.overlay()
			.chaseBoundingBoxOutline(PonderPalette.WHITE, conv1, bb1, 10);
		scene.idle(1);
		scene.overlay()
			.chaseBoundingBoxOutline(PonderPalette.WHITE, conv1, bb1.method_1009(0.025, 0.025, 0.025), 50);
		scene.idle(26);

		scene.overlay()
			.showText(80)
			.text("Right-click a Chain Conveyor and place the Frogport nearby")
			.attachKeyFrame()
			.placeNearTarget()
			.pointAt(fromTarget);

		scene.idle(40);

		ElementLink<WorldSectionElement> fromFrogE = scene.world()
			.showIndependentSection(fromFrogS, class_2350.field_11033);
		scene.world()
			.moveSection(fromFrogE, util.vector()
				.of(0, -1, 0), 0);

		scene.idle(15);
		scene.overlay()
			.chaseBoundingBoxOutline(PonderPalette.GREEN, conv1, bb1.method_1009(0.025, 0.025, 0.025), 50);

		class_238 bb2 = new class_238(fromFrog.method_10074()).method_1002(0, 0.75, 0);

		scene.overlay()
			.chaseBoundingBoxOutline(PonderPalette.GREEN, conv2, bb2, 50);
		scene.idle(10);
		scene.overlay()
			.showLine(PonderPalette.GREEN, util.vector()
				.topOf(fromFrog.method_10074()), fromTarget, 40);
		scene.idle(45);

		scene.overlay()
			.showControls(util.vector()
				.topOf(fromFrog.method_10074()), Pointing.DOWN, 40)
			.rightClick();
		scene.idle(7);
		scene.overlay()
			.showOutlineWithText(util.select()
				.position(fromFrog.method_10074()), 70)
			.attachKeyFrame()
			.colored(PonderPalette.BLUE)
			.text("Assign it an address in the inventory UI")
			.pointAt(util.vector()
				.topOf(fromFrog.method_10074()))
			.placeNearTarget();
		scene.idle(80);

		scene.world()
			.moveSection(fromFrogE, util.vector()
				.of(0, 1, 0), 10);
		scene.idle(10);
		ElementLink<WorldSectionElement> casingE = scene.world()
			.showIndependentSection(casing, class_2350.field_11043);
		scene.world()
			.moveSection(casingE, util.vector()
				.of(0, 0, -2), 0);
		scene.idle(5);
		scene.world()
			.showSection(largeCog2, class_2350.field_11036);
		scene.world()
			.showSection(fromBelt, class_2350.field_11035);
		scene.idle(5);
		scene.world()
			.showSection(util.select()
				.position(fromFunnel), class_2350.field_11033);
		scene.idle(10);

		class_1799 box = PackageStyles.getDefaultBox()
			.method_7972();
		PackageItem.addAddress(box, "Peter");

		scene.world()
			.createItemOnBelt(util.grid()
				.at(5, 1, 0), class_2350.field_11043, box);
		scene.idle(5);

		scene.world()
			.multiplyKineticSpeed(util.select()
				.fromTo(9, 0, 1, 5, 1, 0), 1 / 32f);

		scene.overlay()
			.showText(60)
			.attachKeyFrame()
			.text("If the address of an inserted package does not match it..")
			.pointAt(util.vector()
				.topOf(5, 0, 3))
			.placeNearTarget();

		scene.idle(70);

		scene.overlay()
			.showText(40)
			.colored(PonderPalette.BLUE)
			.text("Albert")
			.pointAt(util.vector()
				.topOf(fromFrog))
			.placeNearTarget();
		scene.idle(5);
		scene.overlay()
			.showText(40)
			.colored(PonderPalette.OUTPUT)
			.text("\u2192 Peter")
			.pointAt(util.vector()
				.centerOf(util.grid()
					.at(5, 2, 0)))
			.placeNearTarget();

		scene.idle(50);

		scene.world()
			.multiplyKineticSpeed(util.select()
				.fromTo(9, 0, 1, 5, 1, 0), 32f);
		scene.idle(13);
		scene.world()
			.removeItemsFromBelt(util.grid()
				.at(5, 1, 1));
		scene.world()
			.flapFunnel(fromFunnel, false);
		scene.idle(15);
		scene.world()
			.modifyBlockEntity(fromFrog, FrogportBlockEntity.class, be -> be.startAnimation(box, true));
		scene.idle(15);

		scene.overlay()
			.showText(60)
			.text("..the Frogport will place the package on the conveyor")
			.pointAt(fromTarget.method_1031(0, 0, 1.5))
			.placeNearTarget();
		scene.idle(95);

		scene.overlay()
			.showText(60)
			.attachKeyFrame()
			.colored(PonderPalette.RED)
			.text("Packages spin in place if they have no valid destination")
			.pointAt(util.vector()
				.of(6.5, 4.25, 7.5))
			.placeNearTarget();
		scene.idle(60);

		scene.world()
			.showSection(util.select()
				.position(toFrog.method_10074()), class_2350.field_11035);
		scene.idle(5);
		scene.world()
			.showSection(toFrogS, class_2350.field_11033);
		scene.idle(15);

		class_243 toTarget = util.vector()
			.of(3.5, 4.37, 6.78);
		class_238 bb3 = new class_238(toTarget, toTarget);
		class_238 bb4 = new class_238(toFrog).method_1002(0, 0.75, 0);

		scene.overlay()
			.chaseBoundingBoxOutline(PonderPalette.GREEN, conv3, bb3.method_1009(0.025, 0.025, 0.025), 80);
		scene.overlay()
			.chaseBoundingBoxOutline(PonderPalette.GREEN, lever, bb4, 80);
		scene.overlay()
			.showLine(PonderPalette.GREEN, util.vector()
				.topOf(toFrog), toTarget, 80);

		scene.idle(10);

		scene.overlay()
			.showText(70)
			.text("More Frogports can be added anywhere on the chain network")
			.attachKeyFrame()
			.placeNearTarget()
			.pointAt(toTarget);

		scene.idle(75);

		scene.overlay()
			.showText(70)
			.colored(PonderPalette.BLUE)
			.text("Peter")
			.pointAt(util.vector()
				.topOf(toFrog))
			.placeNearTarget();
		scene.idle(30);

		scene.world()
			.modifyBlockEntity(conv2, ChainConveyorBlockEntity.class, be -> boxTransfer(conv1, conv2, be));

		scene.idle(50);
		scene.overlay()
			.showText(70)
			.attachKeyFrame()
			.text("Packages find their path to a matching frog on the chain network")
			.pointAt(util.vector()
				.topOf(toFrog))
			.placeNearTarget();
		scene.idle(40);

		scene.world()
			.showSection(toBelt, class_2350.field_11035);
		scene.idle(10);
		scene.world()
			.showSection(util.select()
				.position(toFunnel), class_2350.field_11033);
		scene.idle(15);

		scene.world()
			.createItemOnBelt(util.grid()
				.at(1, 1, 5), class_2350.field_11034, box);
		scene.idle(20);
		scene.world()
			.hideSection(util.select()
				.fromTo(0, 1, 6, 0, 1, 9)
				.add(util.select()
					.position(1, 1, 9)),
				class_2350.field_11035);
		scene.world()
			.setKineticSpeed(util.select()
				.fromTo(1, 1, 5, 0, 1, 5), 0);

		scene.overlay()
			.showText(50)
			.colored(PonderPalette.BLUE)
			.text("Peter")
			.pointAt(util.vector()
				.topOf(toFrog))
			.placeNearTarget();
		scene.idle(5);
		scene.overlay()
			.showText(55)
			.colored(PonderPalette.OUTPUT)
			.text("\u2192 Peter")
			.pointAt(util.vector()
				.centerOf(util.grid()
					.at(0, 2, 5)))
			.placeNearTarget();

		scene.idle(60);

		scene.world()
			.hideSection(util.select()
				.fromTo(1, 2, 5, 0, 1, 5), class_2350.field_11039);
		scene.world()
			.hideSection(util.select()
				.fromTo(5, 2, 1, 5, 1, 0)
				.add(util.select()
					.fromTo(6, 1, 0, 9, 1, 0)),
				class_2350.field_11043);
		scene.world()
			.hideSection(util.select()
				.position(9, 0, 1), class_2350.field_11033);

		scene.idle(15);

		scene.world()
			.hideIndependentSection(casingE, class_2350.field_11039);
		scene.world()
			.hideSection(util.select()
				.position(2, 1, 5), class_2350.field_11039);
		scene.idle(15);
		ElementLink<WorldSectionElement> fromBarrelE = scene.world()
			.showIndependentSection(fromBarrel, class_2350.field_11039);
		scene.world()
			.moveSection(fromBarrelE, util.vector()
				.of(0, 0, -1), 0);
		ElementLink<WorldSectionElement> toBarrelE = scene.world()
			.showIndependentSection(toBarrel, class_2350.field_11039);
		scene.world()
			.moveSection(toBarrelE, util.vector()
				.of(-1, 0, 0), 0);
		scene.idle(20);

		scene.overlay()
			.showOutlineWithText(util.select()
				.position(fromFrog.method_10074())
				.add(fromFrogS), 70)
			.attachKeyFrame()
			.colored(PonderPalette.BLUE)
			.text("Frogports can directly interface with inventories below them")
			.pointAt(util.vector()
				.topOf(fromFrog.method_10074()))
			.placeNearTarget();

		scene.idle(70);

		scene.world()
			.hideIndependentSection(fromBarrelE, class_2350.field_11039);
		scene.world()
			.hideIndependentSection(toBarrelE, class_2350.field_11034);
		scene.idle(15);

		scene.world()
			.showIndependentSection(fromPackager, class_2350.field_11039);
		ElementLink<WorldSectionElement> toPackagerE = scene.world()
			.showIndependentSection(toPackager, class_2350.field_11034);
		scene.world()
			.moveSection(toPackagerE, util.vector()
				.of(0, 0, 1), 0);
		ElementLink<WorldSectionElement> leverE = scene.world()
			.showIndependentSection(util.select()
				.position(lever), class_2350.field_11033);
		scene.world()
			.moveSection(leverE, util.vector()
				.of(-1, 0, 0), 0);
		scene.idle(15);

		scene.overlay()
			.showText(90)
			.attachKeyFrame()
			.text("This also works with packagers. Items can be packed and shipped directly")
			.pointAt(util.vector()
				.blockSurface(fromFrog.method_10074(), class_2350.field_11039))
			.placeNearTarget();
		scene.idle(100);

		scene.world()
			.showSection(sign, class_2350.field_11034);
		scene.idle(10);

		scene.overlay()
			.showText(80)
			.colored(PonderPalette.BLUE)
			.text("Albert")
			.pointAt(util.vector()
				.topOf(fromFrog))
			.placeNearTarget();
		scene.overlay()
			.showText(80)
			.colored(PonderPalette.BLUE)
			.text("Peter")
			.pointAt(util.vector()
				.topOf(toFrog))
			.placeNearTarget();
		scene.idle(20);

		scene.overlay()
			.showOutlineWithText(util.select()
				.position(fromFrog.method_10074())
				.add(util.select()
					.position(fromFrog.method_10074()
						.method_10067())),
				70)
			.colored(PonderPalette.OUTPUT)
			.text("Addresses packages to 'Peter'")
			.pointAt(util.vector()
				.blockSurface(fromFrog.method_10074()
					.method_10067(), class_2350.field_11043))
			.placeNearTarget();
		scene.idle(80);

		scene.overlay()
			.showControls(util.vector()
				.blockSurface(util.grid()
					.at(6, 1, 2), class_2350.field_11036)
				.method_1031(0.5, 0, 0), Pointing.DOWN, 40)
			.withItem(new class_1799(class_1802.field_8477));
		scene.idle(25);

		scene.addKeyframe();

		scene.effects()
			.indicateRedstone(util.grid()
				.at(5, 1, 1));
		scene.world()
			.toggleRedstonePower(util.select()
				.fromTo(5, 1, 2, 6, 1, 1));
		scene.idle(5);

		PonderHilo.packagerCreate(scene, util.grid()
			.at(5, 1, 2), box);
		scene.idle(30);

		scene.world()
			.modifyBlockEntity(util.grid()
				.at(5, 1, 2), PackagerBlockEntity.class, be -> {
					be.heldBox = class_1799.field_8037;
				});
		scene.world()
			.modifyBlockEntity(fromFrog, FrogportBlockEntity.class, be -> be.startAnimation(box, true));

		scene.idle(40);

		scene.world()
			.modifyBlockEntity(conv2, ChainConveyorBlockEntity.class, be -> boxTransfer(conv1, conv2, be));
		scene.idle(50);

		PonderHilo.packagerUnpack(scene, util.grid()
			.at(2, 1, 4), box);
		scene.idle(20);

		scene.overlay()
			.showControls(util.vector()
				.blockSurface(util.grid()
					.at(0, 1, 5), class_2350.field_11036)
				.method_1031(0.5, 0, 0), Pointing.DOWN, 40)
			.withItem(new class_1799(class_1802.field_8477));
		scene.idle(60);

		scene.overlay()
			.showControls(util.vector()
				.centerOf(util.grid()
					.at(2, 2, 5)),
				Pointing.RIGHT, 40)
			.rightClick()
			.withItem(AllBlocks.CLIPBOARD.asStack());
		scene.idle(10);

		scene.overlay()
			.showText(90)
			.attachKeyFrame()
			.text("Right-click Frogports with a clipboard to collect their address")
			.pointAt(util.vector()
				.blockSurface(toFrog, class_2350.field_11039))
			.placeNearTarget();
		scene.idle(70);

		scene.world()
			.showSection(logistics, class_2350.field_11033);
		scene.idle(30);

		scene.overlay()
			.showText(120)
			.text("Clipboards with collected names can help auto-complete address inputs in other UIs")
			.pointAt(util.vector()
				.topOf(util.grid()
					.at(2, 1, 2)))
			.placeNearTarget();
		scene.idle(70);
	}

	public static void boxTransfer(class_2338 to, class_2338 from, ChainConveyorBlockEntity be) {
		for (Iterator<ChainConveyorPackage> iterator = be.getLoopingPackages()
			.iterator(); iterator.hasNext();) {
			ChainConveyorPackage chainConveyorPackage = iterator.next();
			chainConveyorPackage.chainPosition = 0;
			be.addTravellingPackage(chainConveyorPackage, to.method_10059(from));
			iterator.remove();
		}
	}

}
