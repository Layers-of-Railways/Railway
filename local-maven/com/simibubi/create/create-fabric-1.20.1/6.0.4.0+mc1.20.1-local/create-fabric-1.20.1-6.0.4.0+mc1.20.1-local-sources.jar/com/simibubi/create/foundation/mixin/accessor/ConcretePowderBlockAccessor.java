package com.simibubi.create.foundation.mixin.accessor;

import net.minecraft.class_2292;
import net.minecraft.class_2680;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_2292.class)
public interface ConcretePowderBlockAccessor {
	@Accessor("concrete")
	class_2680 create$getConcrete();
}
