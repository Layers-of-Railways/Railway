package com.simibubi.create.foundation.item;

import net.minecraft.class_1268;
import net.minecraft.class_1799;
import net.minecraft.class_572.class_573;
import net.minecraft.class_742;
import org.jetbrains.annotations.Nullable;

public interface CustomArmPoseItem {
	@Nullable
	class_573 getArmPose(class_1799 stack, class_742 player, class_1268 hand);
}
