package com.simibubi.create.foundation.gui.widget;

import java.util.List;

import net.createmod.catnip.gui.widget.AbstractSimiWidget;
import net.minecraft.class_2561;
import net.minecraft.class_332;

public class TooltipArea extends AbstractSimiWidget {

	public TooltipArea(int x, int y, int width, int height) {
		super(x, y, width, height);
	}

	@Override
	public void method_48579(class_332 graphics, int mouseX, int mouseY, float partialTicks) {
		if (field_22764)
			field_22762 = mouseX >= method_46426() && mouseY >= method_46427() && mouseX < method_46426() + field_22758 && mouseY < method_46427() + field_22759;
	}

	public TooltipArea withTooltip(List<class_2561> tooltip) {
		this.toolTip = tooltip;
		return this;
	}

}
