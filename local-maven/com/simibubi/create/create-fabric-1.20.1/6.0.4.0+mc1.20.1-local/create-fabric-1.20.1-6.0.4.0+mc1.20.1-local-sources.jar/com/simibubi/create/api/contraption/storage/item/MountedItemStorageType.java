package com.simibubi.create.api.contraption.storage.item;

import org.jetbrains.annotations.Nullable;

import com.mojang.serialization.Codec;
import com.simibubi.create.api.registry.CreateBuiltInRegistries;
import com.simibubi.create.api.registry.CreateRegistries;
import com.simibubi.create.api.registry.SimpleRegistry;
import com.tterrag.registrate.builders.BlockBuilder;
import com.tterrag.registrate.util.entry.RegistryEntry;
import com.tterrag.registrate.util.nullness.NonNullUnaryOperator;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_6862;
import net.minecraft.class_6880;

public abstract class MountedItemStorageType<T extends MountedItemStorage> {
	public static final Codec<MountedItemStorageType<?>> CODEC = CreateBuiltInRegistries.MOUNTED_ITEM_STORAGE_TYPE.method_39673();
	public static final SimpleRegistry<class_2248, MountedItemStorageType<?>> REGISTRY = SimpleRegistry.create();

	public final Codec<? extends T> codec;
	public final class_6880.class_6883<MountedItemStorageType<?>> holder;

	protected MountedItemStorageType(Codec<? extends T> codec) {
		this.codec = codec;
		this.holder = CreateBuiltInRegistries.MOUNTED_ITEM_STORAGE_TYPE.method_40269(this);
	}

	public final boolean is(class_6862<MountedItemStorageType<?>> tag) {
		return this.holder.method_40220(tag);
	}

	@Nullable
	public abstract T mount(class_1937 level, class_2680 state, class_2338 pos, @Nullable class_2586 be);

	/**
	 * Utility for use with Registrate builders. Creates a builder transformer
	 * that will register the given MountedItemStorageType to a block when ready.
	 */
	public static <B extends class_2248, P> NonNullUnaryOperator<BlockBuilder<B, P>> mountedItemStorage(RegistryEntry<? extends MountedItemStorageType<?>> type) {
		return builder -> builder.onRegisterAfter(CreateRegistries.MOUNTED_ITEM_STORAGE_TYPE, block -> REGISTRY.register(block, type.get()));
	}
}
