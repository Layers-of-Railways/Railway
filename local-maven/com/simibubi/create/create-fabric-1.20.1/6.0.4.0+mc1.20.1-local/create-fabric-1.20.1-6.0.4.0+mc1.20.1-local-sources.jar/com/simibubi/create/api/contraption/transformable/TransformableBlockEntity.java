package com.simibubi.create.api.contraption.transformable;

import com.simibubi.create.content.contraptions.StructureTransform;
import net.minecraft.class_2586;

public interface TransformableBlockEntity {
	void transform(class_2586 blockEntity, StructureTransform transform);
}
