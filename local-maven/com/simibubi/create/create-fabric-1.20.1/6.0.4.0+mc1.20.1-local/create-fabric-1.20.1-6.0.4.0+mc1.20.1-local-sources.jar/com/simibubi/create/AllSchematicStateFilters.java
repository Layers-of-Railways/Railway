package com.simibubi.create;

import com.simibubi.create.api.schematic.state.SchematicStateFilterRegistry;
import net.minecraft.class_2246;
import net.minecraft.class_2746;
import net.minecraft.class_7714;

public class AllSchematicStateFilters {
	public static void registerDefaults() {
		SchematicStateFilterRegistry.REGISTRY.register(class_2246.field_40276, (blockEntity, state) -> {
			for (class_2746 p : class_7714.field_41308)
				state = state.method_11657(p, false);

			return state;
		});
	}
}
