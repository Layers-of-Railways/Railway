package com.simibubi.create.foundation.render.fabric;

import java.util.function.Supplier;
import net.fabricmc.fabric.api.renderer.v1.model.ForwardingBakedModel;
import net.fabricmc.fabric.api.renderer.v1.render.RenderContext;
import net.minecraft.class_1087;
import net.minecraft.class_1920;
import net.minecraft.class_1921;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_4696;
import net.minecraft.class_5819;

public class LayerFilteringBakedModel extends ForwardingBakedModel {
	private static final ThreadLocal<LayerFilteringBakedModel> THREAD_LOCAL = ThreadLocal.withInitial(LayerFilteringBakedModel::new);

	protected class_1921 targetLayer;

	public static class_1087 wrap(class_1087 model, class_1921 layer) {
		LayerFilteringBakedModel wrapper = THREAD_LOCAL.get();
		wrapper.wrapped = model;
		wrapper.targetLayer = layer;
		return wrapper;
	}

	protected LayerFilteringBakedModel() {
	}

	@Override
	public boolean isVanillaAdapter() {
		return false;
	}

	@Override
	public void emitBlockQuads(class_1920 blockView, class_2680 state, class_2338 pos, Supplier<class_5819> randomSupplier, RenderContext context) {
		class_1921 defaultLayer = class_4696.method_23679(state);
		if (super.isVanillaAdapter()) {
			if (defaultLayer == targetLayer) {
				super.emitBlockQuads(blockView, state, pos, randomSupplier, context);
			}
		} else {
			context.pushTransform(quad -> {
				class_1921 quadLayer = quad.material().blendMode().blockRenderLayer;
				if (quadLayer == null) {
					quadLayer = defaultLayer;
				}
				return quadLayer == targetLayer;
			});
			super.emitBlockQuads(blockView, state, pos, randomSupplier, context);
			context.popTransform();
		}
	}
}
