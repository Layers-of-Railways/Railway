package com.simibubi.create.foundation.networking;

import com.simibubi.create.foundation.events.CommonEvents;
import net.minecraft.class_2540;

public class LeftClickPacket extends SimplePacketBase {

	public LeftClickPacket() {}

	public LeftClickPacket(class_2540 buffer) {}

	@Override
	public void write(class_2540 buffer) {}

	@Override
	public boolean handle(Context context) {
		if (context.getDirection() != NetworkDirection.PLAY_TO_SERVER)
			return false;
		context.enqueueWork(() -> CommonEvents.leftClickEmpty(context.getSender()));
		return true;
	}

}
