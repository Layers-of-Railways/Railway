package com.simibubi.create.foundation.recipe;

import net.minecraft.class_1662;
import net.minecraft.class_1715;
import net.minecraft.class_1799;
import net.minecraft.class_2371;
import org.jetbrains.annotations.NotNull;

public class DummyCraftingContainer extends class_1715 {

	private final class_2371<class_1799> inv;

	public DummyCraftingContainer(class_2371<class_1799> stacks) {
		super(null, 0, 0);
		this.inv = stacks;
	}

	@Override
	public int method_5439() {
		return this.inv.size();
	}

	@Override
	public boolean method_5442() {
		for (int slot = 0; slot < this.method_5439(); slot++) {
			if (!this.method_5438(slot).method_7960())
				return false;
		}

		return true;
	}

	@Override
	public @NotNull class_1799 method_5438(int slot) {
		return slot >= this.method_5439() ? class_1799.field_8037 : this.inv.get(slot);
	}

	@Override
	public @NotNull class_1799 method_5441(int slot) {
		return class_1799.field_8037;
	}

	@Override
	public @NotNull class_1799 method_5434(int slot, int count) {
		return class_1799.field_8037;
	}

	@Override
	public void method_5447(int slot, @NotNull class_1799 stack) {}

	@Override
	public void method_5448() {}

	@Override
	public void method_7683(@NotNull class_1662 helper) {}
}
