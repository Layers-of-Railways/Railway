package com.simibubi.create.api.contraption.train;

import java.util.function.BiFunction;
import java.util.function.Function;

import org.jetbrains.annotations.Nullable;

import com.simibubi.create.api.registry.SimpleRegistry;
import com.simibubi.create.content.contraptions.glue.SuperGlueEntity;
import com.simibubi.create.content.trains.track.AllPortalTracks;

import net.createmod.catnip.math.BlockFace;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_5321;
import net.minecraft.class_5454;
import io.github.fabricators_of_create.porting_lib.entity.ITeleporter;

/**
 * A provider for portal track connections.
 * Takes a track inbound through a portal and finds the exit location for the outbound track.
 */
@FunctionalInterface
public interface PortalTrackProvider {
	SimpleRegistry<class_2248, PortalTrackProvider> REGISTRY = SimpleRegistry.create();

	/**
	 * Find the exit location for a track going through a portal.
	 * @param level the level of the inbound track
	 * @param face the face of the inbound track
	 */
	Exit findExit(class_3218 level, BlockFace face);

	/**
	 * Checks if a given {@link class_2680} represents a supported portal block.
	 * @param state The block state to check.
	 * @return {@code true} if the block state represents a supported portal; {@code false} otherwise.
	 */
	static boolean isSupportedPortal(class_2680 state) {
		return REGISTRY.get(state) != null;
	}

	/**
	 * Retrieves the corresponding outbound track on the other side of a portal.
	 * @param level        The current {@link class_3218}.
	 * @param inboundTrack The inbound track {@link BlockFace}.
	 * @return the found outbound track, or null if one wasn't found.
	 */
	@Nullable
	static Exit getOtherSide(class_3218 level, BlockFace inboundTrack) {
		class_2338 portalPos = inboundTrack.getConnectedPos();
		class_2680 portalState = level.method_8320(portalPos);
		PortalTrackProvider provider = REGISTRY.get(portalState);
		return provider == null ? null : provider.findExit(level, inboundTrack);
	}

	/**
	 * Find an exit location by using an {@link ITeleporter} instance.
	 * @param level              The level of the inbound track
	 * @param face				 The face of the inbound track
	 * @param firstDimension     The first dimension (typically the Overworld)
	 * @param secondDimension    The second dimension (e.g., Nether, Aether)
	 * @param customPortalForcer A function to obtain the {@link ITeleporter} for the target level
	 * @return A found exit, or null if one wasn't found
	 */
	static Exit fromTeleporter(class_3218 level, BlockFace face, class_5321<class_1937> firstDimension,
							   class_5321<class_1937> secondDimension, Function<class_3218, ITeleporter> customPortalForcer) {
		return AllPortalTracks.fromTeleporter(level, face, firstDimension, secondDimension, customPortalForcer);
	}

	/**
	 * Find an exit location by teleporting a probe entity to find a {@link class_5454}.
	 * @param level              The level of the inbound track
	 * @param face 				 The face of the inbound track
	 * @param firstDimension     The first dimension
	 * @param secondDimension    The second dimension
	 * @param portalInfoProvider A function that provides the {@link class_5454} given the target level and probe entity.
	 * @return A found exit, or null if one wasn't found
	 */
	static Exit fromProbe(class_3218 level, BlockFace face, class_5321<class_1937> firstDimension,
						  class_5321<class_1937> secondDimension, BiFunction<class_3218, SuperGlueEntity, class_5454> portalInfoProvider) {
		return AllPortalTracks.fromProbe(level, face, firstDimension, secondDimension, portalInfoProvider);
	}

	record Exit(class_3218 level, BlockFace face) {
	}
}
