package com.simibubi.create.foundation.blockEntity.behaviour;

import java.util.function.Function;
import net.minecraft.class_2561;
import net.minecraft.class_5250;
import com.simibubi.create.foundation.blockEntity.behaviour.ValueSettingsBehaviour.ValueSettings;
import com.simibubi.create.foundation.blockEntity.behaviour.scrollValue.INamedIconOptions;
import com.simibubi.create.foundation.gui.AllIcons;

public class ValueSettingsFormatter {
	private final Function<ValueSettings, class_5250> formatter;

	public ValueSettingsFormatter(Function<ValueSettings, class_5250> formatter) {
		this.formatter = formatter;
	}

	public class_5250 format(ValueSettings valueSettings) {
		return formatter.apply(valueSettings);
	}

	public static class ScrollOptionSettingsFormatter extends ValueSettingsFormatter {

		private final INamedIconOptions[] options;

		public ScrollOptionSettingsFormatter(INamedIconOptions[] options) {
			super(v -> class_2561.method_43471(options[v.value()].getTranslationKey()));
			this.options = options;
		}

		public AllIcons getIcon(ValueSettings valueSettings) {
			return options[valueSettings.value()].getIcon();
		}

	}
}
