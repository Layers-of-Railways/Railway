package com.simibubi.create.api.data;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import net.minecraft.class_1299;
import net.minecraft.class_2405;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_7403;
import net.minecraft.class_7784;
import net.minecraft.class_7923;
import com.mojang.serialization.JsonOps;
import com.simibubi.create.Create;
import com.simibubi.create.content.trains.schedule.hat.TrainHatInfo;
import com.simibubi.create.content.trains.schedule.hat.TrainHatInfoReloadListener;

public abstract class TrainHatInfoProvider implements class_2405 {
	protected final Map<class_2960, TrainHatInfo> trainHatOffsets = new HashMap<>();
	private final class_7784.class_7489 path;

	public TrainHatInfoProvider(class_7784 output) {
		this.path = output.method_45973(class_7784.class_7490.field_39368, TrainHatInfoReloadListener.HAT_INFO_DIRECTORY);
	}

	protected abstract void createOffsets();

	protected void makeInfoFor(class_1299<?> type, class_243 offset) {
		this.makeInfoFor(type, offset, "", 0, 1.0F);
	}

	protected void makeInfoFor(class_1299<?> type, class_243 offset, String part) {
		this.makeInfoFor(type, offset, part, 0, 1.0F);
	}

	protected void makeInfoFor(class_1299<?> type, class_243 offset, float scale) {
		this.makeInfoFor(type, offset, "", 0, scale);
	}

	protected void makeInfoFor(class_1299<?> type, class_243 offset, String part, float scale) {
		this.makeInfoFor(type, offset, part, 0, scale);
	}

	protected void makeInfoFor(class_1299<?> type, class_243 offset, String part, int cubeIndex, float scale) {
		this.trainHatOffsets.put(class_7923.field_41177.method_10221(type), new TrainHatInfo(part, cubeIndex, offset, scale));
	}

	@Override
	public CompletableFuture<?> method_10319(class_7403 output) {
		this.trainHatOffsets.clear();
		this.createOffsets();
		return CompletableFuture.allOf(
			this.trainHatOffsets.entrySet().stream().map(entry ->
				class_2405.method_10320(output,
					TrainHatInfo.CODEC.encodeStart(JsonOps.INSTANCE, entry.getValue()).resultOrPartial(Create.LOGGER::error).orElseThrow(),
					this.path.method_44107(entry.getKey()))
			).toArray(CompletableFuture[]::new));
	}

	@Override
	public String method_10321() {
		return "Create Train Hat Information";
	}
}
