package com.simibubi.create.foundation.blockEntity.behaviour;

import java.util.function.BiPredicate;

import net.createmod.catnip.math.VecHelper;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2680;

public class CenteredSideValueBoxTransform extends ValueBoxTransform.Sided {

	private BiPredicate<class_2680, class_2350> allowedDirections;

	public CenteredSideValueBoxTransform() {
		this((b, d) -> true);
	}

	public CenteredSideValueBoxTransform(BiPredicate<class_2680, class_2350> allowedDirections) {
		this.allowedDirections = allowedDirections;
	}

	@Override
	protected class_243 getSouthLocation() {
		return VecHelper.voxelSpace(8, 8, 15.5);
	}

	@Override
	protected boolean isSideActive(class_2680 state, class_2350 direction) {
		return allowedDirections.test(state, direction);
	}

}
