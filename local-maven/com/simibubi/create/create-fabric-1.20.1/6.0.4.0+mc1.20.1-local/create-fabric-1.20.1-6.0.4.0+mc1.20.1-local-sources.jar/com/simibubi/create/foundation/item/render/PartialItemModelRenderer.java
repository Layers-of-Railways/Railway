package com.simibubi.create.foundation.item.render;

import com.simibubi.create.foundation.render.RenderTypes;

import net.createmod.catnip.data.Iterate;
import net.minecraft.class_1087;
import net.minecraft.class_1799;
import net.minecraft.class_1921;
import net.minecraft.class_2350;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4722;
import net.minecraft.class_5819;
import net.minecraft.class_811;
import net.minecraft.class_918;
import io.github.fabricators_of_create.porting_lib.util.ItemRendererHelper;

public class PartialItemModelRenderer {

	private static final PartialItemModelRenderer INSTANCE = new PartialItemModelRenderer();

	private final class_5819 random = class_5819.method_43047();

	private class_1799 stack;
	private class_811 transformType;
	private class_4587 ms;
	private class_4597 buffer;
	private int overlay;

	public static PartialItemModelRenderer of(class_1799 stack, class_811 transformType,
		class_4587 ms, class_4597 buffer, int overlay) {
		PartialItemModelRenderer instance = INSTANCE;
		instance.stack = stack;
		instance.transformType = transformType;
		instance.ms = ms;
		instance.buffer = buffer;
		instance.overlay = overlay;
		return instance;
	}

	public void render(class_1087 model, int light) {
		render(model, class_4722.method_24076(), light);
	}

	public void renderSolid(class_1087 model, int light) {
		render(model, class_4722.method_24073(), light);
	}

	public void renderGlowing(class_1087 model, int light) {
		render(model, RenderTypes.itemGlowingTranslucent(), light);
	}

	public void renderSolidGlowing(class_1087 model, int light) {
		render(model, RenderTypes.itemGlowingSolid(), light);
	}

	public void render(class_1087 model, class_1921 type, int light) {
		if (stack.method_7960())
			return;

		ms.method_22903();
		ms.method_22904(-0.5D, -0.5D, -0.5D);

		if (!model.method_4713())
			// FIXME FRAPI COMPAT
			renderBakedItemModel(model, light, ms,
				class_918.method_29711(buffer, type, true, stack.method_7958()));
		else
			class_310.method_1551().method_1480()
					.method_23179(stack, transformType, false, ms, buffer, light, overlay, model);

		ms.method_22909();
	}

	private void renderBakedItemModel(class_1087 model, int light, class_4587 ms, class_4588 buffer) {
		class_918 ir = class_310.method_1551()
				.method_1480();
//		IModelData data = EmptyModelData.INSTANCE;

		for (class_2350 direction : Iterate.directions) {
			random.method_43052(42L);
			ItemRendererHelper.renderQuadList(ir, ms, buffer, model.method_4707(null, direction, random), stack, light, overlay);
		}

		random.method_43052(42L);
		ItemRendererHelper.renderQuadList(ir, ms, buffer, model.method_4707(null, null, random), stack, light, overlay);
	}

}
