package com.simibubi.create.foundation.data.recipe;

import com.simibubi.create.AllBlocks;
import com.simibubi.create.Create;
import com.simibubi.create.api.data.recipe.BaseRecipeProvider.GeneratedRecipe;
import com.simibubi.create.api.data.recipe.HauntingRecipeGen;
import io.github.fabricators_of_create.porting_lib.tags.Tags;
import net.minecraft.class_1802;
import net.minecraft.class_1856;
import net.minecraft.class_2246;
import net.minecraft.class_3489;
import net.minecraft.class_7784;

/**
 * Create's own Data Generation for Haunting recipes
 * @see HauntingRecipeGen
 */
@SuppressWarnings("unused")
public final class CreateHauntingRecipeGen extends HauntingRecipeGen {

	GeneratedRecipe

	BRASS_BELL = convert(() -> class_1856.method_8091(AllBlocks.PECULIAR_BELL.get()), AllBlocks.HAUNTED_BELL::get),

	HAUNT_STONE = convert(class_1802.field_20391, class_1802.field_8225),
	HAUNT_DEEPSLATE = convert(class_1802.field_28866, class_1802.field_29213),
	HAUNT_STONE_BRICKS = convert(class_1802.field_20395, class_1802.field_8541),
	HAUNT_MOSSY_STONE_BRICKS = convert(class_1802.field_20396, class_1802.field_8596),
	HAUNT_CRACKED_STONE_BRICKS = convert(class_1802.field_8343, class_1802.field_8292),
	HAUNT_CHISELED_STONE_BRICKS = convert(class_1802.field_8525, class_1802.field_8148),

	SOUL_TORCH = convert(class_1802.field_8810, class_1802.field_22001),
	SOUL_CAMPFIRE = convert(class_1802.field_17346, class_1802.field_23842),
	SOUL_LANTERN = convert(class_1802.field_16539, class_1802.field_22016),

	POISON_POTATO = convert(class_1802.field_8567, class_1802.field_8635),
	GLOW_INK = convert(class_1802.field_8794, class_1802.field_28410),
	GLOW_BERRIES = convert(class_1802.field_16998, class_1802.field_28659),
	NETHER_BRICK = convert(class_1802.field_8621, class_1802.field_8729),

	PRISMARINE = create(Create.asResource("lapis_recycling"), b -> b.require(Tags.Items.GEMS_LAPIS)
		.output(.75f, class_1802.field_8662)
		.output(.125f, class_1802.field_8434)),

	SOUL_SAND = convert(() -> class_1856.method_8106(class_3489.field_15532), () -> class_2246.field_10114),
	SOUL_DIRT = convert(() -> class_1856.method_8106(class_3489.field_36269), () -> class_2246.field_22090),
	BLACK_STONE = convert(() -> class_1856.method_8106(Tags.Items.COBBLESTONE), () -> class_2246.field_23869),
	CRIMSON_FUNGUS = convert(class_1802.field_17517, class_1802.field_21987),
	WARPED_FUNGUS = convert(class_1802.field_17516, class_1802.field_21988),

	// Farmer's Delight
	FD = moddedConversion(Mods.FD, "tomato", "rotten_tomato"),

	// Haunted Harvest
	HH = create(Mods.HH.recipeId("rotten_apple"), b -> b.require(class_1802.field_8279)
		.output(Mods.HH, "rotten_apple")
		.whenModLoaded(Mods.HH.getId()))

	;

	public CreateHauntingRecipeGen(class_7784 output) {
		super(output, Create.ID);
	}

	public GeneratedRecipe moddedConversion(Mods mod, String input, String output) {
		return create("compat/" + mod.getId() + "/" + output, p -> p.require(mod, input)
				.output(mod, output)
				.whenModLoaded(mod.getId()));
	}
}
