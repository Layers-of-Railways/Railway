package com.simibubi.create.foundation.sound;

import net.createmod.catnip.animation.AnimationTickHolder;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3414;
import net.minecraft.class_3419;
import net.minecraft.class_638;

public class RepeatingSound {

	private class_3414 event;
	private float sharedPitch;
	private int repeatDelay;
	private SoundScape scape;
	private float relativeVolume;

	public RepeatingSound(class_3414 event, SoundScape scape, float sharedPitch, float relativeVolume,
		int repeatDelay) {
		this.event = event;
		this.scape = scape;
		this.sharedPitch = sharedPitch;
		this.relativeVolume = relativeVolume;
		this.repeatDelay = Math.max(1, repeatDelay);
	}

	public void tick() {
		if (AnimationTickHolder.getTicks() % repeatDelay != 0)
			return;

		class_638 world = class_310.method_1551().field_1687;
		class_243 meanPos = scape.getMeanPos();

		world.method_8486(meanPos.field_1352, meanPos.field_1351, meanPos.field_1350, event, class_3419.field_15256,
			scape.getVolume() * relativeVolume, sharedPitch, true);
	}

}
