package com.simibubi.create.foundation.mixin.accessor;

import net.minecraft.class_2385;
import net.minecraft.class_7923;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_7923.class)
public interface BuiltInRegistriesAccessor {
	@Accessor("WRITABLE_REGISTRY")
	static class_2385<class_2385<?>> create$getWRITABLE_REGISTRY() {
		throw new AssertionError();
	}
}
