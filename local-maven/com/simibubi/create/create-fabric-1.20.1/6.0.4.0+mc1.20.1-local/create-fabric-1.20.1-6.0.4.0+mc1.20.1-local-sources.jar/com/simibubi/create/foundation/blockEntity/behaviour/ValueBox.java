package com.simibubi.create.foundation.blockEntity.behaviour;

import java.lang.ref.WeakReference;
import com.simibubi.create.content.logistics.filter.FilterItem;
import com.simibubi.create.foundation.blockEntity.behaviour.ValueBoxTransform.Sided;
import com.simibubi.create.foundation.blockEntity.behaviour.scrollValue.INamedIconOptions;
import com.simibubi.create.foundation.gui.AllIcons;

import net.createmod.catnip.outliner.ChasingAABBOutline;
import net.createmod.catnip.render.SuperRenderTypeBuffer;
import net.minecraft.class_1087;
import net.minecraft.class_1799;
import net.minecraft.class_1936;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5244;
import net.minecraft.class_5250;
import net.minecraft.class_765;
import net.minecraft.class_918;

public class ValueBox extends ChasingAABBOutline {

	protected class_2561 label;
	protected class_2561 sublabel = class_5244.field_39003;
	protected class_2561 scrollTooltip = class_5244.field_39003;
	protected class_243 labelOffset = class_243.field_1353;

	public int overrideColor = -1;

	public boolean isPassive;

	protected ValueBoxTransform transform;

	protected WeakReference<class_1936> level;
	protected class_2338 pos;
	protected class_2680 blockState;

	protected AllIcons outline = AllIcons.VALUE_BOX_HOVER_4PX;

	public ValueBox(class_2561 label, class_238 bb, class_2338 pos) {
		this(label, bb, pos, class_310.method_1551().field_1687.method_8320(pos));
	}

	public ValueBox(class_2561 label, class_238 bb, class_2338 pos, class_2680 state) {
		super(bb);
		this.label = label;
		this.pos = pos;
		this.blockState = state;
		this.level = new WeakReference<>(class_310.method_1551().field_1687);
	}

	public ValueBox transform(ValueBoxTransform transform) {
		this.transform = transform;
		return this;
	}

	public ValueBox wideOutline() {
		this.outline = AllIcons.VALUE_BOX_HOVER_6PX;
		return this;
	}

	public ValueBox passive(boolean passive) {
		this.isPassive = passive;
		return this;
	}

	public ValueBox withColor(int color) {
		this.overrideColor = color;
		return this;
	}

	@Override
	public void render(class_4587 ms, SuperRenderTypeBuffer buffer, class_243 camera, float pt) {
		boolean hasTransform = transform != null;
		if (transform instanceof Sided && params.getHighlightedFace() != null)
			((Sided) transform).fromSide(params.getHighlightedFace());

		class_1936 levelAccessor = level.get();
		if (hasTransform && !transform.shouldRender(levelAccessor, pos, blockState))
			return;

		ms.method_22903();
		ms.method_22904(pos.method_10263() - camera.field_1352, pos.method_10264() - camera.field_1351, pos.method_10260() - camera.field_1350);
		if (hasTransform)
			transform.transform(levelAccessor, pos, blockState, ms);

		if (!isPassive) {
			ms.method_22903();
			ms.method_22905(-2.01f, -2.01f, 2.01f);
			ms.method_22904(-8 / 16.0, -8 / 16.0, -.5 / 16.0);
			getOutline().render(ms, buffer, 0xffffff);
			ms.method_22909();
		}

		float fontScale = hasTransform ? -transform.getFontScale() : -1 / 64f;
		ms.method_22905(fontScale, fontScale, fontScale);
		renderContents(ms, buffer);

		ms.method_22909();
	}

	public AllIcons getOutline() {
		return outline;
	}

	public void renderContents(class_4587 ms, class_4597 buffer) {
	}

	public static class ItemValueBox extends ValueBox {
		class_1799 stack;
		class_5250 count;

		public ItemValueBox(class_2561 label, class_238 bb, class_2338 pos, class_1799 stack, class_5250 count) {
			super(label, bb, pos);
			this.stack = stack;
			this.count = count;
		}

		@Override
		public AllIcons getOutline() {
			if (!stack.method_7960())
				return AllIcons.VALUE_BOX_HOVER_6PX;
			return super.getOutline();
		}

		@Override
		public void renderContents(class_4587 ms, class_4597 buffer) {
			super.renderContents(ms, buffer);
			if (count == null)
				return;

			class_327 font = class_310.method_1551().field_1772;
			ms.method_46416(17.5f, -5f, 7f);

			boolean isFilter = stack.method_7909() instanceof FilterItem;
			boolean isEmpty = stack.method_7960();

			class_918 itemRenderer = class_310.method_1551()
				.method_1480();
			class_1087 modelWithOverrides = itemRenderer.method_4019(stack, null, null, 0);
			boolean blockItem =
				modelWithOverrides.method_4712();

			float scale = 1.5f;
			ms.method_46416(-font.method_27525(count), 0, 0);

			if (isFilter)
				ms.method_46416(-5, 8, 7.25f);
			else if (isEmpty) {
				ms.method_46416(-15, -1f, -2.75f);
				scale = 1.65f;
			} else
				ms.method_46416(-7, 10, blockItem ? 10 + 1 / 4f : 0);

			if (count.getString()
				.equals("*"))
				ms.method_46416(-1, 3f, 0);

			ms.method_22905(scale, scale, scale);
			drawString8x(ms, buffer, count, 0, 0, isFilter ? 0xFFFFFF : 0xEDEDED);
		}

	}

	public static class TextValueBox extends ValueBox {
		class_2561 text;

		public TextValueBox(class_2561 label, class_238 bb, class_2338 pos, class_2561 text) {
			super(label, bb, pos);
			this.text = text;
		}

		public TextValueBox(class_2561 label, class_238 bb, class_2338 pos, class_2680 state, class_2561 text) {
			super(label, bb, pos, state);
			this.text = text;
		}

		@Override
		public void renderContents(class_4587 ms, class_4597 buffer) {
			super.renderContents(ms, buffer);
			class_327 font = class_310.method_1551().field_1772;
			float scale = 3;
			ms.method_22905(scale, scale, 1);
			ms.method_22904(-4, -3.75, 5);

			int stringWidth = font.method_27525(text);
			float numberScale = (float) font.field_2000 / stringWidth;
			boolean singleDigit = stringWidth < 10;
			if (singleDigit)
				numberScale = numberScale / 2;
			float verticalMargin = (stringWidth - font.field_2000) / 2f;

			ms.method_22905(numberScale, numberScale, numberScale);
			ms.method_46416(singleDigit ? stringWidth / 2 : 0, singleDigit ? -verticalMargin : verticalMargin, 0);

			int overrideColor = transform.getOverrideColor();
			if (overrideColor == -1)
				drawString8x(ms, buffer, text, 0, 0, 0xEDEDED);
			else
				drawString(ms, buffer, text, 0, 0, overrideColor);
		}

	}

	public static class IconValueBox extends ValueBox {
		AllIcons icon;

		public IconValueBox(class_2561 label, INamedIconOptions iconValue, class_238 bb, class_2338 pos) {
			super(label, bb, pos);
			icon = iconValue.getIcon();
		}

		@Override
		public void renderContents(class_4587 ms, class_4597 buffer) {
			super.renderContents(ms, buffer);
			float scale = 2 * 16;
			ms.method_22905(scale, scale, scale);
			ms.method_46416(-.5f, -.5f, 5 / 32f);

			int overrideColor = transform.getOverrideColor();
			icon.render(ms, buffer, overrideColor != -1 ? overrideColor : 0xFFFFFF);
		}

	}

	private static void drawString(class_4587 ms, class_4597 buffer, class_2561 text, float x, float y,
								   int color) {
		class_310.method_1551().field_1772.method_30882(text, x, y, color, false, ms.method_23760()
			.method_23761(), buffer, class_327.class_6415.field_33993, 0, class_765.field_32767);
	}

	private static void drawString8x(class_4587 ms, class_4597 buffer, class_2561 text, float x, float y,
									 int color) {
		class_310.method_1551().field_1772.method_37296(text.method_30937(), x, y, color, 0xff333333, ms.method_23760()
			.method_23761(), buffer, class_765.field_32767);
	}

}
