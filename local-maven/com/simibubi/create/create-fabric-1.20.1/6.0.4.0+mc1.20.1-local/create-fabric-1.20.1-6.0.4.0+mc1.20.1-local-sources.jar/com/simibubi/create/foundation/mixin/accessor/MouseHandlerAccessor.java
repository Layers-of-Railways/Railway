package com.simibubi.create.foundation.mixin.accessor;

import net.minecraft.class_312;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_312.class)
public interface MouseHandlerAccessor {
	@Accessor("xpos")
	void create$setXPos(double xPos);

	@Accessor("ypos")
	void create$setYPos(double yPos);
}
