package com.simibubi.create.foundation.utility;

import java.util.function.BiConsumer;
import java.util.function.Consumer;

import javax.annotation.Nullable;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;

public abstract class AbstractBlockBreakQueue {
	protected Consumer<class_2338> makeCallbackFor(class_1937 world, float effectChance, class_1799 toDamage,
		@Nullable class_1657 playerEntity, BiConsumer<class_2338, class_1799> drop) {
		return pos -> {
			class_1799 usedTool = toDamage.method_7972();
			BlockHelper.destroyBlockAs(world, pos, playerEntity, toDamage, effectChance,
				stack -> drop.accept(pos, stack));
//			if (toDamage.isEmpty() && !usedTool.isEmpty())
//				ForgeEventFactory.onPlayerDestroyItem(playerEntity, usedTool, InteractionHand.MAIN_HAND);
		};
	}

	public void destroyBlocks(class_1937 world, @Nullable class_1309 entity, BiConsumer<class_2338, class_1799> drop) {
		class_1657 playerEntity = entity instanceof class_1657 ? ((class_1657) entity) : null;
		class_1799 toDamage =
			playerEntity != null && !playerEntity.method_7337() ? playerEntity.method_6047() : class_1799.field_8037;
		destroyBlocks(world, toDamage, playerEntity, drop);
	}

	public abstract void destroyBlocks(class_1937 world, class_1799 toDamage, @Nullable class_1657 playerEntity,
		BiConsumer<class_2338, class_1799> drop);
}
