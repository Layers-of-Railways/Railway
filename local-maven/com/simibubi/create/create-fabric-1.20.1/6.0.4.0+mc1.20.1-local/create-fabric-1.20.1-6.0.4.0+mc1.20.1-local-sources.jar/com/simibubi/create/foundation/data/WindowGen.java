package com.simibubi.create.foundation.data;

import static com.simibubi.create.foundation.data.CreateRegistrate.connectedTextures;

import java.util.function.Function;
import java.util.function.Supplier;
import net.minecraft.class_1299;
import net.minecraft.class_1747;
import net.minecraft.class_1921;
import net.minecraft.class_1922;
import net.minecraft.class_1935;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2447;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3481;
import net.minecraft.class_3620;
import net.minecraft.class_4719;
import net.minecraft.class_4970.class_2251;
import net.minecraft.class_7800;
import com.simibubi.create.AllSpriteShifts;
import com.simibubi.create.Create;
import com.simibubi.create.content.decoration.palettes.ConnectedGlassBlock;
import com.simibubi.create.content.decoration.palettes.ConnectedGlassPaneBlock;
import com.simibubi.create.content.decoration.palettes.GlassPaneBlock;
import com.simibubi.create.content.decoration.palettes.WindowBlock;
import com.simibubi.create.foundation.block.connected.CTSpriteShiftEntry;
import com.simibubi.create.foundation.block.connected.ConnectedTextureBehaviour;
import com.simibubi.create.foundation.block.connected.GlassPaneCTBehaviour;
import com.simibubi.create.foundation.block.connected.HorizontalCTBehaviour;
import com.tterrag.registrate.builders.BlockBuilder;
import com.tterrag.registrate.builders.ItemBuilder;
import com.tterrag.registrate.providers.DataGenContext;
import com.tterrag.registrate.providers.RegistrateBlockstateProvider;
import com.tterrag.registrate.providers.RegistrateRecipeProvider;
import com.tterrag.registrate.util.DataIngredient;
import com.tterrag.registrate.util.entry.BlockEntry;
import com.tterrag.registrate.util.nullness.NonNullBiConsumer;
import com.tterrag.registrate.util.nullness.NonNullConsumer;
import com.tterrag.registrate.util.nullness.NonNullFunction;
import io.github.fabricators_of_create.porting_lib.models.generators.ConfiguredModel;
import io.github.fabricators_of_create.porting_lib.models.generators.ModelFile;
import io.github.fabricators_of_create.porting_lib.tags.Tags;

public class WindowGen {
	private static final CreateRegistrate REGISTRATE = Create.registrate();

	private static class_2251 glassProperties(class_2251 p) {
		return p.method_26235(WindowGen::never)
			.method_26236(WindowGen::never)
			.method_26243(WindowGen::never)
			.method_26245(WindowGen::never);
	}

	private static boolean never(class_2680 p_235436_0_, class_1922 p_235436_1_, class_2338 p_235436_2_) {
		return false;
	}

	private static Boolean never(class_2680 p_235427_0_, class_1922 p_235427_1_, class_2338 p_235427_2_,
								 class_1299<?> p_235427_3_) {
		return false;
	}

	public static BlockEntry<WindowBlock> woodenWindowBlock(class_4719 woodType, class_2248 planksBlock) {
		return woodenWindowBlock(woodType, planksBlock, () -> class_1921::method_23579, false);
	}

	public static BlockBuilder<WindowBlock, CreateRegistrate> randomisedWindowBlock(String name,
																					Supplier<? extends class_1935> ingredient, Supplier<Supplier<class_1921>> renderType, boolean translucent,
																					Supplier<class_3620> color) {
		class_2960 end_texture = Create.asResource(palettesDir() + name + "_end");
		class_2960 side_texture = Create.asResource(palettesDir() + name);
		Function<Integer, class_2960> ends = i -> Create.asResource(palettesDir() + name + "_" + i + "_end");
		return windowBlock(name, ingredient, null, renderType, translucent, n -> end_texture, n -> side_texture, color)
			.blockstate((c, p) -> p.simpleBlock(c.get(), ConfiguredModel.builder()
				.modelFile(p.models()
					.cubeColumn(c.getName() + "_1", side_texture, ends.apply(1)))
				.nextModel()
				.modelFile(p.models()
					.cubeColumn(c.getName() + "_2", side_texture, ends.apply(2)))
				.nextModel()
				.modelFile(p.models()
					.cubeColumn(c.getName() + "_3", side_texture, ends.apply(3)))
				.nextModel()
				.modelFile(p.models()
					.cubeColumn(c.getName() + "_4", side_texture, ends.apply(4)))
				.build()))
			.item()
			.model((c, p) -> p.cubeColumn(c.getName(), side_texture, ends.apply(1)))
			.build();
	}

	public static BlockEntry<WindowBlock> customWindowBlock(String name, Supplier<? extends class_1935> ingredient,
															Supplier<CTSpriteShiftEntry> ct, Supplier<Supplier<class_1921>> renderType, boolean translucent,
															Supplier<class_3620> color) {
		NonNullFunction<String, class_2960> end_texture = n -> Create.asResource(palettesDir() + name + "_end");
		NonNullFunction<String, class_2960> side_texture = n -> Create.asResource(palettesDir() + n);
		return windowBlock(name, ingredient, ct, renderType, translucent, end_texture, side_texture, color).register();
	}

	public static BlockEntry<WindowBlock> woodenWindowBlock(class_4719 woodType, class_2248 planksBlock,
															Supplier<Supplier<class_1921>> renderType, boolean translucent) {
		String woodName = woodType.comp_1299();
		String name = woodName + "_window";
		NonNullFunction<String, class_2960> end_texture =
			$ -> new class_2960("block/" + woodName + "_planks");
		NonNullFunction<String, class_2960> side_texture = n -> Create.asResource(palettesDir() + n);
		return windowBlock(name, () -> planksBlock, () -> AllSpriteShifts.getWoodenWindow(woodType), renderType,
			translucent, end_texture, side_texture, planksBlock::method_26403).register();
	}

	public static BlockBuilder<WindowBlock, CreateRegistrate> windowBlock(String name,
																		  Supplier<? extends class_1935> ingredient, Supplier<CTSpriteShiftEntry> ct,
																		  Supplier<Supplier<class_1921>> renderType, boolean translucent,
																		  NonNullFunction<String, class_2960> endTexture, NonNullFunction<String, class_2960> sideTexture,
																		  Supplier<class_3620> color) {
		return REGISTRATE.block(name, p -> new WindowBlock(p, translucent))
			.onRegister(ct == null ? $ -> {
			} : connectedTextures(() -> new HorizontalCTBehaviour(ct.get())))
			.addLayer(renderType)
			.recipe((c, p) -> class_2447.method_10436(class_7800.field_40634, c.get(), 2)
				.method_10439(" # ")
				.method_10439("#X#")
				.method_10434('#', ingredient.get())
				.method_10428('X', DataIngredient.tag(Tags.Items.GLASS_COLORLESS))
				.method_10429("has_ingredient", RegistrateRecipeProvider.method_10426(ingredient.get()))
				.method_10431(p::accept))
			.initialProperties(() -> class_2246.field_10033)
			.properties(WindowGen::glassProperties)
			.properties(p -> p.method_31710(color.get()))
			.loot((t, g) -> t.method_46024(g))
			.blockstate((c, p) -> p.simpleBlock(c.get(), p.models()
				.cubeColumn(c.getName(), sideTexture.apply(c.getName()), endTexture.apply(c.getName()))))
			.tag(class_3481.field_15490)
			.simpleItem();
	}

	public static BlockEntry<ConnectedGlassBlock> framedGlass(String name,
															  Supplier<ConnectedTextureBehaviour> behaviour) {
		return REGISTRATE.block(name, ConnectedGlassBlock::new)
			.onRegister(connectedTextures(behaviour))
			.addLayer(() -> class_1921::method_23581)
			.initialProperties(() -> class_2246.field_10033)
			.properties(WindowGen::glassProperties)
			.loot((t, g) -> t.method_46024(g))
			.recipe((c, p) -> p.stonecutting(DataIngredient.tag(Tags.Items.GLASS_COLORLESS),
				class_7800.field_40634, c::get))
			.blockstate((c, p) -> BlockStateGen.cubeAll(c, p, "palettes/", "framed_glass"))
			.tag(Tags.Blocks.GLASS_COLORLESS, class_3481.field_15490)
			.item()
			.tag(Tags.Items.GLASS_COLORLESS)
			.model((c, p) -> p.cubeColumn(c.getName(), p.modLoc(palettesDir() + c.getName()),
				p.modLoc("block/palettes/framed_glass")))
			.build()
			.register();
	}

	public static BlockEntry<ConnectedGlassPaneBlock> framedGlassPane(String name, Supplier<? extends class_2248> parent,
																	  Supplier<CTSpriteShiftEntry> ctshift) {
		class_2960 sideTexture = Create.asResource(palettesDir() + "framed_glass");
		class_2960 itemSideTexture = Create.asResource(palettesDir() + name);
		class_2960 topTexture = Create.asResource(palettesDir() + "framed_glass_pane_top");
		Supplier<Supplier<class_1921>> renderType = () -> class_1921::method_23579;
		return connectedGlassPane(name, parent, ctshift, sideTexture, itemSideTexture, topTexture, renderType, true)
			.register();
	}

	public static BlockBuilder<ConnectedGlassPaneBlock, CreateRegistrate> customWindowPane(String name,
																						   Supplier<? extends class_2248> parent, Supplier<CTSpriteShiftEntry> ctshift,
																						   Supplier<Supplier<class_1921>> renderType) {
		class_2960 topTexture = Create.asResource(palettesDir() + name + "_pane_top");
		class_2960 sideTexture = Create.asResource(palettesDir() + name);
		return connectedGlassPane(name, parent, ctshift, sideTexture, sideTexture, topTexture, renderType, false);
	}

	public static BlockEntry<ConnectedGlassPaneBlock> woodenWindowPane(class_4719 woodType,
																	   Supplier<? extends class_2248> parent) {
		return woodenWindowPane(woodType, parent, () -> class_1921::method_23579);
	}

	public static BlockEntry<ConnectedGlassPaneBlock> woodenWindowPane(class_4719 woodType,
																	   Supplier<? extends class_2248> parent, Supplier<Supplier<class_1921>> renderType) {
		String woodName = woodType.comp_1299();
		String name = woodName + "_window";
		class_2960 topTexture = new class_2960("block/" + woodName + "_planks");
		class_2960 sideTexture = Create.asResource(palettesDir() + name);
		return connectedGlassPane(name, parent, () -> AllSpriteShifts.getWoodenWindow(woodType), sideTexture,
			sideTexture, topTexture, renderType, false).register();
	}

	public static BlockEntry<GlassPaneBlock> standardGlassPane(String name, Supplier<? extends class_2248> parent,
															   class_2960 sideTexture, class_2960 topTexture, Supplier<Supplier<class_1921>> renderType) {
		NonNullBiConsumer<DataGenContext<class_2248, GlassPaneBlock>, RegistrateBlockstateProvider> stateProvider =
			(c, p) -> p.paneBlock(c.get(), sideTexture, topTexture);
		return glassPane(name, parent, sideTexture, topTexture, GlassPaneBlock::new, renderType, $ -> {
		}, stateProvider, true).register();
	}

	private static BlockBuilder<ConnectedGlassPaneBlock, CreateRegistrate> connectedGlassPane(String name,
																							  Supplier<? extends class_2248> parent, Supplier<CTSpriteShiftEntry> ctshift, class_2960 sideTexture,
																							  class_2960 itemSideTexture, class_2960 topTexture, Supplier<Supplier<class_1921>> renderType, boolean colorless) {
		NonNullConsumer<? super ConnectedGlassPaneBlock> connectedTextures = ctshift == null ? $ -> {
		} : connectedTextures(() -> new GlassPaneCTBehaviour(ctshift.get()));
		String CGPparents = "block/connected_glass_pane/";
		String prefix = name + "_pane_";

		Function<RegistrateBlockstateProvider, ModelFile> post =
			getPaneModelProvider(CGPparents, prefix, "post", sideTexture, topTexture),
			side = getPaneModelProvider(CGPparents, prefix, "side", sideTexture, topTexture),
			sideAlt = getPaneModelProvider(CGPparents, prefix, "side_alt", sideTexture, topTexture),
			noSide = getPaneModelProvider(CGPparents, prefix, "noside", sideTexture, topTexture),
			noSideAlt = getPaneModelProvider(CGPparents, prefix, "noside_alt", sideTexture, topTexture);

		NonNullBiConsumer<DataGenContext<class_2248, ConnectedGlassPaneBlock>, RegistrateBlockstateProvider> stateProvider =
			(c, p) -> p.paneBlock(c.get(), post.apply(p), side.apply(p), sideAlt.apply(p), noSide.apply(p),
				noSideAlt.apply(p));

		return glassPane(name, parent, itemSideTexture, topTexture, ConnectedGlassPaneBlock::new, renderType,
			connectedTextures, stateProvider, colorless);
	}

	private static Function<RegistrateBlockstateProvider, ModelFile> getPaneModelProvider(String CGPparents,
																						  String prefix, String partial, class_2960 sideTexture, class_2960 topTexture) {
		return p -> p.models()
			.withExistingParent(prefix + partial, Create.asResource(CGPparents + partial))
			.texture("pane", sideTexture)
			.texture("edge", topTexture);
	}

	private static <G extends GlassPaneBlock> BlockBuilder<G, CreateRegistrate> glassPane(String name,
																						  Supplier<? extends class_2248> parent, class_2960 sideTexture, class_2960 topTexture,
																						  NonNullFunction<class_2251, G> factory, Supplier<Supplier<class_1921>> renderType,
																						  NonNullConsumer<? super G> connectedTextures,
																						  NonNullBiConsumer<DataGenContext<class_2248, G>, RegistrateBlockstateProvider> stateProvider, boolean colorless) {
		name += "_pane";


		ItemBuilder<class_1747, BlockBuilder<G, CreateRegistrate>> itemBuilder = REGISTRATE.block(name, factory)
			.onRegister(connectedTextures)
			.addLayer(renderType)
			.initialProperties(() -> class_2246.field_10285)
			.properties(p -> p.method_31710(parent.get()
				.method_26403()))
			.blockstate(stateProvider)
			.recipe((c, p) -> {
				class_2447.method_10436(class_7800.field_40634, c.get(), 16)
					.method_10439("###")
					.method_10439("###")
					.method_10434('#', parent.get())
					.method_10429("has_ingredient", RegistrateRecipeProvider.method_10426(parent.get()))
					.method_10431(p::accept);
				if (colorless)
					p.stonecutting(DataIngredient.tag(Tags.Items.GLASS_PANES_COLORLESS), class_7800.field_40634,
						c::get);
			})
			.loot((t, g) -> t.method_46024(g))
			.item();

		if (colorless)
			itemBuilder.tag(Tags.Items.GLASS_PANES, Tags.Items.GLASS_PANES_COLORLESS);
		else
			itemBuilder.tag(Tags.Items.GLASS_PANES);

		BlockBuilder<G, CreateRegistrate> blockBuilder = itemBuilder
			.model((c, p) -> p.generated(c, sideTexture))
			.build();

		if (colorless)
			blockBuilder.tag(Tags.Blocks.GLASS_PANES, Tags.Blocks.GLASS_PANES_COLORLESS);
		else
			blockBuilder.tag(Tags.Blocks.GLASS_PANES);

		return blockBuilder;
	}

	private static String palettesDir() {
		return "block/palettes/";
	}

}
