package com.simibubi.create.foundation.block.connected;

import java.util.Arrays;
import java.util.function.Supplier;

import com.simibubi.create.content.decoration.copycat.CopycatBlock;
import com.simibubi.create.foundation.block.connected.ConnectedTextureBehaviour.CTContext;

import net.createmod.catnip.data.Iterate;
import net.fabricmc.fabric.api.renderer.v1.model.ForwardingBakedModel;
import net.fabricmc.fabric.api.renderer.v1.model.SpriteFinder;
import net.fabricmc.fabric.api.renderer.v1.render.RenderContext;
import net.minecraft.class_1058;
import net.minecraft.class_1087;
import net.minecraft.class_1723;
import net.minecraft.class_1920;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2338.class_2339;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_5819;

public class CTModel extends ForwardingBakedModel {

	private final ConnectedTextureBehaviour behaviour;

	public CTModel(class_1087 originalModel, ConnectedTextureBehaviour behaviour) {
		wrapped = originalModel;
		this.behaviour = behaviour;
	}

	protected CTData createCTData(class_1920 world, class_2338 pos, class_2680 state) {
		CTData data = new CTData();
		class_2339 mutablePos = new class_2339();
		for (class_2350 face : Iterate.directions) {
			class_2680 actualState = world.method_8320(pos);
			if (!behaviour.buildContextForOccludedDirections()
				&& !class_2248.method_9607(state, world, pos, face, mutablePos.method_25505(pos, face))
				&& !(actualState.method_26204()instanceof CopycatBlock ufb
					&& !ufb.canFaceBeOccluded(actualState, face)))
				continue;
			CTType dataType = behaviour.getDataType(world, pos, state, face);
			if (dataType == null)
				continue;
			CTContext context = behaviour.buildContext(world, pos, state, face, dataType.getContextRequirement());
			data.put(face, dataType.getTextureIndex(context));
		}
		return data;
	}

	@Override
	public boolean isVanillaAdapter() {
		return false;
	}

	@Override
	public void emitBlockQuads(class_1920 blockView, class_2680 state, class_2338 pos, Supplier<class_5819> randomSupplier, RenderContext context) {
		CTData data = createCTData(blockView, pos, state);

		SpriteFinder spriteFinder = SpriteFinder.get(class_310.method_1551().method_1554().method_24153(class_1723.field_21668));
		context.pushTransform(quad -> {
			int index = data.get(quad.lightFace());
			if (index != -1) {
				class_1058 sprite = spriteFinder.find(quad, 0);
				CTSpriteShiftEntry spriteShift = behaviour.getShift(state, randomSupplier.get(), quad.lightFace(), sprite);
				if (spriteShift != null) {
					if (sprite == spriteShift.getOriginal()) {
						for (int vertex = 0; vertex < 4; vertex++) {
							float u = quad.spriteU(vertex, 0);
							float v = quad.spriteV(vertex, 0);
							quad.sprite(vertex, 0,
									spriteShift.getTargetU(u, index),
									spriteShift.getTargetV(v, index)
							);
						}
					}
				}
			}
			return true;
		});
		super.emitBlockQuads(blockView, state, pos, randomSupplier, context);
		context.popTransform();
	}

	private static class CTData {
		private final int[] indices;

		public CTData() {
			indices = new int[6];
			Arrays.fill(indices, -1);
		}

		public void put(class_2350 face, int texture) {
			indices[face.method_10146()] = texture;
		}

		public int get(class_2350 face) {
			return indices[face.method_10146()];
		}
	}

}
