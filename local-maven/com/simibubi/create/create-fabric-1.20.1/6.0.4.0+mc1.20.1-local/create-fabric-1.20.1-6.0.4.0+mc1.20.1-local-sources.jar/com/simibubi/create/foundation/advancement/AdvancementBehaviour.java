package com.simibubi.create.foundation.advancement;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

import com.simibubi.create.foundation.blockEntity.SmartBlockEntity;
import com.simibubi.create.foundation.blockEntity.behaviour.BehaviourType;
import com.simibubi.create.foundation.blockEntity.behaviour.BlockEntityBehaviour;
import net.fabricmc.fabric.api.entity.FakePlayer;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_3222;

public class AdvancementBehaviour extends BlockEntityBehaviour {

	public static final BehaviourType<AdvancementBehaviour> TYPE = new BehaviourType<>();

	private UUID playerId;
	private Set<CreateAdvancement> advancements;

	public AdvancementBehaviour(SmartBlockEntity be, CreateAdvancement... advancements) {
		super(be);
		this.advancements = new HashSet<>();
		add(advancements);
	}

	public void add(CreateAdvancement... advancements) {
		for (CreateAdvancement advancement : advancements)
			this.advancements.add(advancement);
	}

	public boolean isOwnerPresent() {
		return playerId != null;
	}

	public void setPlayer(UUID id) {
		class_1657 player = getWorld().method_18470(id);
		if (player == null)
			return;
		playerId = id;
		removeAwarded();
		blockEntity.method_5431();
	}

	@Override
	public void initialize() {
		super.initialize();
		removeAwarded();
	}

	private void removeAwarded() {
		class_1657 player = getPlayer();
		if (player == null)
			return;
		advancements.removeIf(c -> c.isAlreadyAwardedTo(player));
		if (advancements.isEmpty()) {
			playerId = null;
			blockEntity.method_5431();
		}
	}

	public void awardPlayerIfNear(CreateAdvancement advancement, int maxDistance) {
		class_1657 player = getPlayer();
		if (player == null)
			return;
		if (player.method_5707(class_243.method_24953(getPos())) > maxDistance * maxDistance)
			return;
		award(advancement, player);
	}

	public void awardPlayer(CreateAdvancement advancement) {
		class_1657 player = getPlayer();
		if (player == null)
			return;
		award(advancement, player);
	}

	private void award(CreateAdvancement advancement, class_1657 player) {
		if (advancements.contains(advancement))
			advancement.awardTo(player);
		removeAwarded();
	}

	private class_1657 getPlayer() {
		if (playerId == null)
			return null;
		return getWorld().method_18470(playerId);
	}

	@Override
	public void write(class_2487 nbt, boolean clientPacket) {
		super.write(nbt, clientPacket);
		if (playerId != null)
			nbt.method_25927("Owner", playerId);
	}

	@Override
	public void read(class_2487 nbt, boolean clientPacket) {
		super.read(nbt, clientPacket);
		if (nbt.method_10545("Owner"))
			playerId = nbt.method_25926("Owner");
	}

	@Override
	public BehaviourType<?> getType() {
		return TYPE;
	}

	public static void tryAward(class_1922 reader, class_2338 pos, CreateAdvancement advancement) {
		AdvancementBehaviour behaviour = BlockEntityBehaviour.get(reader, pos, AdvancementBehaviour.TYPE);
		if (behaviour != null)
			behaviour.awardPlayer(advancement);
	}

	public static void setPlacedBy(class_1937 worldIn, class_2338 pos, class_1309 placer) {
		AdvancementBehaviour behaviour = BlockEntityBehaviour.get(worldIn, pos, TYPE);
		if (behaviour == null)
			return;
		if (placer instanceof class_3222 player && !(player instanceof FakePlayer))
			behaviour.setPlayer(placer.method_5667());
	}

}
