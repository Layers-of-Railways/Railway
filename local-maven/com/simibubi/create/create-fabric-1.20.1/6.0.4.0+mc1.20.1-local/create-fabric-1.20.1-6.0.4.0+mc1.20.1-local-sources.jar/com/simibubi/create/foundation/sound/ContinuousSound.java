package com.simibubi.create.foundation.sound;

import net.minecraft.class_1101;
import net.minecraft.class_1113;
import net.minecraft.class_3414;
import net.minecraft.class_3419;

public class ContinuousSound extends class_1101 {

	private float sharedPitch;
	private SoundScape scape;
	private float relativeVolume;

	protected ContinuousSound(class_3414 event, SoundScape scape, float sharedPitch, float relativeVolume) {
		super(event, class_3419.field_15256, class_1113.method_43221());
		this.scape = scape;
		this.sharedPitch = sharedPitch;
		this.relativeVolume = relativeVolume;
		this.field_5446 = true;
		this.field_5451 = 0;
		this.field_18936 = false;
	}

	public void remove() {
		method_24876();
	}

	@Override
	public float method_4781() {
		return scape.getVolume() * relativeVolume;
	}

	@Override
	public float method_4782() {
		return sharedPitch;
	}

	@Override
	public double method_4784() {
		return scape.getMeanPos().field_1352;
	}

	@Override
	public double method_4779() {
		return scape.getMeanPos().field_1351;
	}

	@Override
	public double method_4778() {
		return scape.getMeanPos().field_1350;
	}

	@Override
	public void method_16896() {}

}
