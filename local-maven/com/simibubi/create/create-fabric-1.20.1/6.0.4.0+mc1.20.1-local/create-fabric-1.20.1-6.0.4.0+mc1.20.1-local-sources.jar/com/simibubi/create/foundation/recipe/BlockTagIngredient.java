package com.simibubi.create.foundation.recipe;

import java.util.List;

import com.google.common.collect.ImmutableList;
import com.google.gson.JsonObject;
import com.simibubi.create.Create;
import net.fabricmc.fabric.api.recipe.v1.ingredient.CustomIngredient;
import net.fabricmc.fabric.api.recipe.v1.ingredient.CustomIngredientSerializer;
import net.minecraft.class_1799;
import net.minecraft.class_2248;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_3518;
import net.minecraft.class_6862;
import net.minecraft.class_6880;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

public class BlockTagIngredient implements CustomIngredient {
	protected final class_6862<class_2248> tag;

	protected BlockTagIngredient(class_6862<class_2248> tag) {
		this.tag = tag;
	}

	public static BlockTagIngredient create(class_6862<class_2248> tag) {
		return new BlockTagIngredient(tag);
	}

	public class_6862<class_2248> getTag() {
		return tag;
	}

	@Override
	public boolean requiresTesting() {
		return false;
	}

	@Override
	public List<class_1799> getMatchingStacks() {
		ImmutableList.Builder<class_1799> stacks = ImmutableList.builder();
		for (class_6880<class_2248> block : class_7923.field_41175.method_40286(tag)) {
			stacks.add(new class_1799(block.comp_349().method_8389()));
		}
		return stacks.build();
	}

	@Override
	public boolean test(class_1799 stack) {
		return class_2248.method_9503(stack.method_7909()).method_9564().method_26164(tag);
	}

	@Override
	public CustomIngredientSerializer<?> getSerializer() {
		return Serializer.INSTANCE;
	}

	public static class Serializer implements CustomIngredientSerializer<BlockTagIngredient> {
		public static final class_2960 ID = Create.asResource("block_tag_ingredient");
		public static final Serializer INSTANCE = new Serializer();

		@Override
		public class_2960 getIdentifier() {
			return ID;
		}

		@Override
		public BlockTagIngredient read(JsonObject json) {
			class_2960 rl = new class_2960(class_3518.method_15265(json, "tag"));
			class_6862<class_2248> tag = class_6862.method_40092(class_7924.field_41254, rl);
			return new BlockTagIngredient(tag);
		}

		@Override
		public void write(JsonObject json, BlockTagIngredient ingredient) {
			json.addProperty("tag", ingredient.tag.comp_327().toString());
		}

		@Override
		public BlockTagIngredient read(class_2540 buffer) {
			class_2960 rl = buffer.method_10810();
			class_6862<class_2248> tag = class_6862.method_40092(class_7924.field_41254, rl);
			return new BlockTagIngredient(tag);
		}

		@Override
		public void write(class_2540 buf, BlockTagIngredient ingredient) {
			buf.method_10812(ingredient.tag.comp_327());
		}
	}
}
