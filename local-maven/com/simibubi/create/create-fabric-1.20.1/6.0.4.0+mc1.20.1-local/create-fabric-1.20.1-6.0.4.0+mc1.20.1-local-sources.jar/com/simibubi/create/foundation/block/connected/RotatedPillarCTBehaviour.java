package com.simibubi.create.foundation.block.connected;

import com.simibubi.create.content.decoration.copycat.CopycatBlock;
import com.simibubi.create.content.decoration.palettes.ConnectedPillarBlock;
import com.simibubi.create.content.decoration.palettes.LayeredBlock;
import net.minecraft.class_1058;
import net.minecraft.class_1920;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2350.class_2351;
import net.minecraft.class_2350.class_2352;
import net.minecraft.class_2680;

public class RotatedPillarCTBehaviour extends HorizontalCTBehaviour {

	public RotatedPillarCTBehaviour(CTSpriteShiftEntry layerShift, CTSpriteShiftEntry topShift) {
		super(layerShift, topShift);
	}

	@Override
	public boolean connectsTo(class_2680 state, class_2680 other, class_1920 reader, class_2338 pos,
		class_2338 otherPos, class_2350 face, class_2350 primaryOffset, class_2350 secondaryOffset) {
		if (other.method_26204() != state.method_26204())
			return false;
		class_2351 stateAxis = state.method_11654(LayeredBlock.field_11459);
		if (other.method_11654(LayeredBlock.field_11459) != stateAxis)
			return false;
		if (isBeingBlocked(state, reader, pos, otherPos, face))
			return false;
		if (reader.method_8320(pos).method_26204() instanceof CopycatBlock)
			return true;
		if (reader.method_8320(otherPos).method_26204() instanceof CopycatBlock)
			return true;
		if (primaryOffset != null && primaryOffset.method_10166() != stateAxis
			&& !ConnectedPillarBlock.getConnection(state, primaryOffset))
			return false;
		if (secondaryOffset != null && secondaryOffset.method_10166() != stateAxis) {
			if (!ConnectedPillarBlock.getConnection(state, secondaryOffset))
				return false;
			if (!ConnectedPillarBlock.getConnection(other, secondaryOffset.method_10153()))
				return false;
		}
		return true;
	}

	@Override
	protected boolean isBeingBlocked(class_2680 state, class_1920 reader, class_2338 pos, class_2338 otherPos,
		class_2350 face) {
		return state.method_11654(LayeredBlock.field_11459) == face.method_10166()
			&& super.isBeingBlocked(state, reader, pos, otherPos, face);
	}

	@Override
	protected boolean reverseUVs(class_2680 state, class_2350 face) {
		class_2351 axis = state.method_11654(LayeredBlock.field_11459);
		if (axis == class_2351.field_11048)
			return face.method_10171() == class_2352.field_11060 && face.method_10166() != class_2351.field_11048;
		if (axis == class_2351.field_11051)
			return face != class_2350.field_11043 && face.method_10171() != class_2352.field_11056;
		return super.reverseUVs(state, face);
	}

	@Override
	protected boolean reverseUVsHorizontally(class_2680 state, class_2350 face) {
		return super.reverseUVsHorizontally(state, face);
	}

	@Override
	protected boolean reverseUVsVertically(class_2680 state, class_2350 face) {
		class_2351 axis = state.method_11654(LayeredBlock.field_11459);
		if (axis == class_2351.field_11048 && face == class_2350.field_11043)
			return false;
		if (axis == class_2351.field_11051 && face == class_2350.field_11039)
			return false;
		return super.reverseUVsVertically(state, face);
	}

	@Override
	protected class_2350 getUpDirection(class_1920 reader, class_2338 pos, class_2680 state, class_2350 face) {
		class_2351 axis = state.method_11654(LayeredBlock.field_11459);
		if (axis == class_2351.field_11052)
			return super.getUpDirection(reader, pos, state, face);
		boolean alongX = axis == class_2351.field_11048;
		if (face.method_10166()
			.method_10178() && alongX)
			return super.getUpDirection(reader, pos, state, face).method_10170();
		if (face.method_10166() == axis || face.method_10166()
			.method_10178())
			return super.getUpDirection(reader, pos, state, face);
		return class_2350.method_10169(axis, alongX ? class_2352.field_11056 : class_2352.field_11060);
	}

	@Override
	protected class_2350 getRightDirection(class_1920 reader, class_2338 pos, class_2680 state, class_2350 face) {
		class_2351 axis = state.method_11654(LayeredBlock.field_11459);
		if (axis == class_2351.field_11052)
			return super.getRightDirection(reader, pos, state, face);
		if (face.method_10166()
			.method_10178() && axis == class_2351.field_11048)
			return super.getRightDirection(reader, pos, state, face).method_10170();
		if (face.method_10166() == axis || face.method_10166()
			.method_10178())
			return super.getRightDirection(reader, pos, state, face);
		return class_2350.method_10169(class_2351.field_11052, face.method_10171());
	}

	@Override
	public CTSpriteShiftEntry getShift(class_2680 state, class_2350 direction, class_1058 sprite) {
		return super.getShift(state,
			direction.method_10166() == state.method_11654(LayeredBlock.field_11459) ? class_2350.field_11036 : class_2350.field_11035, sprite);
	}

}
