package com.simibubi.create.foundation.recipe;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1542;
import net.minecraft.class_1799;
import net.minecraft.class_1860;
import net.minecraft.class_1937;
import com.simibubi.create.content.kinetics.deployer.ManualApplicationRecipe;
import com.simibubi.create.content.processing.recipe.ProcessingOutput;
import com.simibubi.create.content.processing.recipe.ProcessingRecipe;
import com.simibubi.create.foundation.item.ItemHelper;
import io.github.fabricators_of_create.porting_lib.transfer.item.ItemHandlerHelper;

public class RecipeApplier {
	public static void applyRecipeOn(class_1542 entity, class_1860<?> recipe) {
		List<class_1799> stacks = applyRecipeOn(entity.method_37908(), entity.method_6983(), recipe);
		if (stacks == null)
			return;
		if (stacks.isEmpty()) {
			entity.method_31472();
			return;
		}
		entity.method_6979(stacks.remove(0));
		for (class_1799 additional : stacks) {
			class_1542 entityIn = new class_1542(entity.method_37908(), entity.method_23317(), entity.method_23318(), entity.method_23321(), additional);
			entityIn.method_18799(entity.method_18798());
			entity.method_37908().method_8649(entityIn);
		}
	}

	public static List<class_1799> applyRecipeOn(class_1937 level, class_1799 stackIn, class_1860<?> recipe) {
		List<class_1799> stacks;

		if (recipe instanceof ProcessingRecipe<?> pr) {
			stacks = new ArrayList<>();
			for (int i = 0; i < stackIn.method_7947(); i++) {
				List<ProcessingOutput> outputs =
					pr instanceof ManualApplicationRecipe mar ? mar.getRollableResults() : pr.getRollableResults();
				for (class_1799 stack : pr.rollResults(outputs)) {
					for (class_1799 previouslyRolled : stacks) {
						if (stack.method_7960())
							continue;
						if (!ItemHandlerHelper.canItemStacksStack(stack, previouslyRolled))
							continue;
						int amount = Math.min(previouslyRolled.method_7914() - previouslyRolled.method_7947(),
							stack.method_7947());
						previouslyRolled.method_7933(amount);
						stack.method_7934(amount);
					}

					if (stack.method_7960())
						continue;

					stacks.add(stack);
				}
			}
		} else {
			class_1799 out = recipe.method_8110(level.method_30349())
				.method_7972();
			stacks = ItemHelper.multipliedOutput(stackIn, out);
		}

		return stacks;
	}
}
