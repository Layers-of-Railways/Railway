package com.simibubi.create.foundation.advancement;

import java.util.List;
import java.util.function.Supplier;

import javax.annotation.Nullable;
import javax.annotation.ParametersAreNonnullByDefault;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_5257;
import net.minecraft.class_5258;
import net.minecraft.class_6328;
import com.google.gson.JsonObject;

@class_6328
@ParametersAreNonnullByDefault
public class SimpleCreateTrigger extends CriterionTriggerBase<SimpleCreateTrigger.Instance> {

	public SimpleCreateTrigger(String id) {
		super(id);
	}

	@Override
	public com.simibubi.create.foundation.advancement.SimpleCreateTrigger.Instance method_795(JsonObject json, class_5257 context) {
		return new com.simibubi.create.foundation.advancement.SimpleCreateTrigger.Instance(method_794());
	}

	public void trigger(class_3222 player) {
		super.trigger(player, null);
	}

	public com.simibubi.create.foundation.advancement.SimpleCreateTrigger.Instance instance() {
		return new com.simibubi.create.foundation.advancement.SimpleCreateTrigger.Instance(method_794());
	}

	public static class Instance extends CriterionTriggerBase.Instance {

		public Instance(class_2960 idIn) {
			super(idIn, class_5258.field_24388);
		}

		@Override
		protected boolean test(@Nullable List<Supplier<Object>> suppliers) {
			return true;
		}
	}
}
