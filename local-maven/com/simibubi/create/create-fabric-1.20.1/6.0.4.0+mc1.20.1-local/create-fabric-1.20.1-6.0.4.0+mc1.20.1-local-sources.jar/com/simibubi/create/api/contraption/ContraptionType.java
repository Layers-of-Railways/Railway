package com.simibubi.create.api.contraption;

import java.util.function.Supplier;

import javax.annotation.Nullable;
import net.minecraft.class_2960;
import net.minecraft.class_6862;
import net.minecraft.class_6880;
import com.simibubi.create.AllContraptionTypes;
import com.simibubi.create.api.registry.CreateBuiltInRegistries;
import com.simibubi.create.content.contraptions.Contraption;

public final class ContraptionType {
	public final Supplier<? extends Contraption> factory;
	public final class_6880.class_6883<ContraptionType> holder;

	public ContraptionType(Supplier<? extends Contraption> factory) {
		this.factory = factory;
		this.holder = CreateBuiltInRegistries.CONTRAPTION_TYPE.method_40269(this);
	}

	public boolean is(class_6862<ContraptionType> tag) {
		return this.holder.method_40220(tag);
	}

	/**
	 * Lookup the ContraptionType with the given ID, and create a new Contraption from it if present.
	 * If it doesn't exist, returns null.
	 */
	@Nullable
	public static Contraption fromType(String typeId) {
		ContraptionType legacy = AllContraptionTypes.BY_LEGACY_NAME.get(typeId);
		if (legacy != null) {
			return legacy.factory.get();
		}

		class_2960 id = class_2960.method_12829(typeId);
		ContraptionType type = CreateBuiltInRegistries.CONTRAPTION_TYPE.method_10223(id);
		return type == null ? null : type.factory.get();
	}
}
