package com.simibubi.create.foundation.ponder.element;

import java.util.function.Supplier;

import net.createmod.ponder.api.element.ParrotPose;
import net.createmod.ponder.foundation.PonderScene;
import net.createmod.ponder.foundation.element.ParrotElementImpl;
import net.minecraft.class_243;
import net.minecraft.class_2487;

public class ExpandedParrotElement extends ParrotElementImpl {

	protected boolean deferConductor = false;

	protected ExpandedParrotElement(class_243 location, Supplier<? extends ParrotPose> pose) {
		super(location, pose);
	}

	@Override
	public void reset(PonderScene scene) {
		super.reset(scene);
		entity.getCustomData().method_10551("TrainHat");
		deferConductor = false;
	}

	@Override
	public void tick(PonderScene scene) {
		boolean wasNull = entity == null;
		super.tick(scene);
		if (wasNull) {
			if (deferConductor) {
				setConductor(true);
			}
			deferConductor = false;
		}
	}

	public void setConductor(boolean isConductor) {
		if (entity == null) {
			deferConductor = isConductor;
			return;
		}
		class_2487 data = entity.getCustomData();
		if (isConductor)
			data.method_10556("TrainHat", true);
		else
			data.method_10551("TrainHat");
	}
}
