package com.simibubi.create.foundation.mixin.fabric.infra;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import com.simibubi.create.infrastructure.fabric.RenderItemDecorationsCallback;
import net.minecraft.class_1799;
import net.minecraft.class_327;
import net.minecraft.class_332;

@Mixin(class_332.class)
public class GuiGraphicsMixin {
	@Inject(
		method = "renderItemDecorations(Lnet/minecraft/client/gui/Font;Lnet/minecraft/world/item/ItemStack;IILjava/lang/String;)V",
		at = @At(
			value = "INVOKE",
			target = "Lcom/mojang/blaze3d/vertex/PoseStack;popPose()V"
		)
	)
	private void renderAdditionalDecorations(class_327 font, class_1799 stack, int x, int y, String text, CallbackInfo ci) {
		RenderItemDecorationsCallback.EVENT.invoker().render((class_332) (Object) this, font, stack, x, y);
	}
}
