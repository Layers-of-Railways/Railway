package com.simibubi.create.foundation.mixin.client;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import com.simibubi.create.foundation.render.PlayerSkyhookRenderer;
import net.minecraft.class_1309;
import net.minecraft.class_572;
import net.minecraft.class_630;
import net.minecraft.class_742;

@Mixin(class_572.class)
public class HumanoidModelMixin<T extends class_1309> {
	@Shadow
	@Final
	public class_630 body;

	@Inject(method = "setupAnim*", at = @At("RETURN"))
	private void create$afterSetupAnim(T pEntity, float pLimbSwing, float pLimbSwingAmount, float pAgeInTicks, float pNetHeadYaw, float pHeadPitch, CallbackInfo callbackInfo) {
		if (!(pEntity instanceof class_742 player))
			return;

		PlayerSkyhookRenderer.afterSetupAnim(player, (class_572<?>) (Object) this);
	}

	@Inject(method = "setupAnim*", at = @At("HEAD"))
	private void create$beforeSetupAnim(T pEntity, float pLimbSwing, float pLimbSwingAmount, float pAgeInTicks, float pNetHeadYaw, float pHeadPitch, CallbackInfo callbackInfo) {
		if (!(pEntity instanceof class_742 player))
			return;

		PlayerSkyhookRenderer.beforeSetupAnim(player, (class_572<?>) (Object) this);
	}
}
