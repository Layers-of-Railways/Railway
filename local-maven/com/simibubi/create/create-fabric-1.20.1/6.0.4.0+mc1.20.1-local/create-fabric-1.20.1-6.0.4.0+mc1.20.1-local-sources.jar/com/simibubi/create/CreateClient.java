package com.simibubi.create;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import com.simibubi.create.compat.Mods;
import com.simibubi.create.compat.ftb.FTBIntegration;
import com.simibubi.create.compat.pojav.PojavChecker;
import com.simibubi.create.compat.sodium.SodiumCompat;
import com.simibubi.create.compat.trinkets.Trinkets;
import com.simibubi.create.content.contraptions.glue.SuperGlueSelectionHandler;
import com.simibubi.create.content.contraptions.render.ContraptionRenderInfo;
import com.simibubi.create.content.contraptions.render.ContraptionRenderInfoManager;
import com.simibubi.create.content.decoration.encasing.CasingConnectivity;
import com.simibubi.create.content.equipment.armor.RemainingAirOverlay;
import com.simibubi.create.content.equipment.bell.SoulPulseEffectHandler;
import com.simibubi.create.content.equipment.blueprint.BlueprintOverlayRenderer;
import com.simibubi.create.content.equipment.goggles.GoggleOverlayRenderer;
import com.simibubi.create.content.equipment.potatoCannon.PotatoCannonRenderHandler;
import com.simibubi.create.content.equipment.toolbox.ToolboxHandlerClient;
import com.simibubi.create.content.equipment.zapper.ZapperRenderHandler;
import com.simibubi.create.content.kinetics.base.KineticBlockEntityRenderer;
import com.simibubi.create.content.kinetics.simpleRelays.CogWheelBlock;
import com.simibubi.create.content.kinetics.waterwheel.WaterWheelRenderer;
import com.simibubi.create.content.redstone.link.controller.LinkedControllerClientHandler;
import com.simibubi.create.content.schematics.client.ClientSchematicLoader;
import com.simibubi.create.content.schematics.client.SchematicAndQuillHandler;
import com.simibubi.create.content.schematics.client.SchematicHandler;
import com.simibubi.create.content.trains.GlobalRailwayManager;
import com.simibubi.create.content.trains.TrainHUD;
import com.simibubi.create.content.trains.track.TrackPlacementOverlay;
import com.simibubi.create.foundation.ClientResourceReloadListener;
import com.simibubi.create.foundation.blockEntity.behaviour.ValueSettingsClient;
import com.simibubi.create.foundation.events.ClientEvents;
import com.simibubi.create.foundation.events.InputEvents;
import com.simibubi.create.foundation.model.ModelSwapper;
import com.simibubi.create.foundation.ponder.CreatePonderPlugin;
import com.simibubi.create.foundation.render.AllInstanceTypes;
import com.simibubi.create.foundation.render.RenderTypes;
import com.simibubi.create.infrastructure.config.AllConfigs;
import com.simibubi.create.infrastructure.gui.CreateMainMenuScreen;

import net.createmod.catnip.config.ui.BaseConfigScreen;
import net.createmod.catnip.config.ui.ConfigScreen;
import net.createmod.catnip.render.CachedBuffers;
import net.createmod.catnip.render.SuperByteBufferCache;
import net.createmod.ponder.foundation.PonderIndex;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.class_1041;
import net.minecraft.class_124;
import net.minecraft.class_2350;
import net.minecraft.class_2558;
import net.minecraft.class_2561;
import net.minecraft.class_2564;
import net.minecraft.class_2568;
import net.minecraft.class_310;
import net.minecraft.class_329;
import net.minecraft.class_5250;
import net.minecraft.class_5365;

public class CreateClient implements ClientModInitializer {

	public static final ModelSwapper MODEL_SWAPPER = new ModelSwapper();
	public static final CasingConnectivity CASING_CONNECTIVITY = new CasingConnectivity();

	public static final ClientSchematicLoader SCHEMATIC_SENDER = new ClientSchematicLoader();
	public static final SchematicHandler SCHEMATIC_HANDLER = new SchematicHandler();
	public static final SchematicAndQuillHandler SCHEMATIC_AND_QUILL_HANDLER = new SchematicAndQuillHandler();
	public static final SuperGlueSelectionHandler GLUE_HANDLER = new SuperGlueSelectionHandler();

	public static final ZapperRenderHandler ZAPPER_RENDER_HANDLER = new ZapperRenderHandler();
	public static final PotatoCannonRenderHandler POTATO_CANNON_RENDER_HANDLER = new PotatoCannonRenderHandler();
	public static final SoulPulseEffectHandler SOUL_PULSE_EFFECT_HANDLER = new SoulPulseEffectHandler();
	public static final GlobalRailwayManager RAILWAYS = new GlobalRailwayManager();
	public static final ValueSettingsClient VALUE_SETTINGS_HANDLER = new ValueSettingsClient();

	public static final ClientResourceReloadListener RESOURCE_RELOAD_LISTENER = new ClientResourceReloadListener();

	@Override
	public void onInitializeClient() {
		AllInstanceTypes.init();

		MODEL_SWAPPER.registerListeners();

		ZAPPER_RENDER_HANDLER.registerListeners();
		POTATO_CANNON_RENDER_HANDLER.registerListeners();

		Mods.FTBLIBRARY.executeIfInstalled(() -> () -> FTBIntegration.init());
		PojavChecker.init();

		// clientInit start

		//BUFFER_CACHE.registerCompartment(CachedBufferer.GENERIC_BLOCK);
		//BUFFER_CACHE.registerCompartment(CachedPartialBuffers.partial);
		//BUFFER_CACHE.registerCompartment(CachedBufferer.DIRECTIONAL_PARTIAL);
		//BUFFER_CACHE.registerCompartment(KineticBlockEntityRenderer.KINETIC_BLOCK);
		//BUFFER_CACHE.registerCompartment(WaterWheelRenderer.WATER_WHEEL);
		//BUFFER_CACHE.registerCompartment(ContraptionRenderInfo.CONTRAPTION, 20);
		//BUFFER_CACHE.registerCompartment(WorldSectionElement.DOC_WORLD_SECTION, 20);

		SuperByteBufferCache.getInstance().registerCompartment(CachedBuffers.PARTIAL);
		SuperByteBufferCache.getInstance().registerCompartment(CachedBuffers.DIRECTIONAL_PARTIAL);
		SuperByteBufferCache.getInstance().registerCompartment(KineticBlockEntityRenderer.KINETIC_BLOCK);
		SuperByteBufferCache.getInstance().registerCompartment(WaterWheelRenderer.WATER_WHEEL);
		SuperByteBufferCache.getInstance().registerCompartment(ContraptionRenderInfo.CONTRAPTION, 20);

		AllKeys.register();
		AllPartialModels.init();


		//AllPonderTags.register();
		//PonderIndex.register();
		PonderIndex.addPlugin(new CreatePonderPlugin());

		setupConfigUIBackground();

		// fabric exclusive
		registerOverlays();
		ClientEvents.register();
		InputEvents.register();
		AllPackets.getChannel().initClientListener();
		RenderTypes.init();
//		ArmorTextureRegistry.register(AllArmorMaterials.COPPER, CopperArmorItem.TEXTURE);
		AllFluids.initRendering();
		initCompat();
	}

	@SuppressWarnings("Convert2MethodRef") // may cause class loading issues if changed
	private static void initCompat() {
		Mods.TRINKETS.executeIfInstalled(() -> () -> Trinkets.clientInit());
		Mods.SODIUM.executeIfInstalled(() -> () -> SodiumCompat.init());
		Mods.FTBCHUNKS.executeIfInstalled(() -> () -> FTBIntegration.init());
	}

	private static void registerOverlays() {
		HudRenderCallback.EVENT.register((graphics, partialTicks) -> {
			class_1041 window = class_310.method_1551().method_22683();
			class_329 gui = class_310.method_1551().field_1705;

			RemainingAirOverlay.render(graphics, window.method_4486(), window.method_4502()); // Create's Remaining Air
			TrainHUD.renderOverlay(graphics, partialTicks, window); // Create's Train Driver HUD
			GoggleOverlayRenderer.renderOverlay(graphics, partialTicks, window.method_4486(), window.method_4502()); // Create's Goggle Information
			BlueprintOverlayRenderer.renderOverlay(gui, graphics, partialTicks, window); // Create's Blueprints
			LinkedControllerClientHandler.renderOverlay(graphics, partialTicks, window); // Create's Linked Controller
			SCHEMATIC_HANDLER.renderOverlay(graphics, partialTicks, window); // Create's Schematics
			ToolboxHandlerClient.renderOverlay(graphics, partialTicks, window); // Create's Toolboxes
			VALUE_SETTINGS_HANDLER.render(graphics, window.method_4486(), window.method_4502()); // Create's Value Settings
			TrackPlacementOverlay.renderOverlay(gui, graphics); // Create's Track Placement
		});
	}

	private static void setupConfigUIBackground() {
		ConfigScreen.backgrounds.put(Create.ID, (screen, graphics, partialTicks) -> {
			CreateMainMenuScreen.PANORAMA.method_3317(class_310.method_1551().method_1534(), 1);

			//RenderSystem.setShaderTexture(0, CreateMainMenuScreen.PANORAMA_OVERLAY_TEXTURES);
			RenderSystem.enableBlend();
			RenderSystem.blendFunc(GlStateManager.class_4535.SRC_ALPHA, GlStateManager.class_4534.ONE_MINUS_SRC_ALPHA);
			graphics.method_25293(CreateMainMenuScreen.PANORAMA_OVERLAY_TEXTURES, 0, 0, screen.field_22789, screen.field_22790, 0.0F, 0.0F, 16, 128, 16, 128);

			graphics.method_25294(0, 0, screen.field_22789, screen.field_22790, 0x90_282c34);
		});

		ConfigScreen.shadowState = AllBlocks.LARGE_COGWHEEL.getDefaultState().method_11657(CogWheelBlock.AXIS, class_2350.class_2351.field_11052);

		BaseConfigScreen.setDefaultActionFor(Create.ID, base -> base
				.withButtonLabels("Client Settings", "World Generation Settings", "Gameplay Settings")
				.withSpecs(AllConfigs.client().specification, AllConfigs.common().specification, AllConfigs.server().specification)
		);
	}

	public static void invalidateRenderers() {
		SCHEMATIC_HANDLER.updateRenderers();
		ContraptionRenderInfoManager.resetAll();
	}

	public static void checkGraphicsFanciness() {
		class_310 mc = class_310.method_1551();
		if (mc.field_1724 == null)
			return;

		if (mc.field_1690.method_42534().method_41753() != class_5365.field_25429)
			return;

		if (AllConfigs.client().ignoreFabulousWarning.get())
			return;

        class_5250 text = class_2564.method_10885(class_2561.method_43470("WARN"))
			.method_27692(class_124.field_1065)
			.method_10852(class_2561.method_43470(" Some of Create's visual features will not be available while Fabulous graphics are enabled!"))
			.method_27694(style -> {
                return style
                    .method_10958(new class_2558(class_2558.class_2559.field_11750, "/create dismissFabulousWarning"))
                    .method_10949(new class_2568(class_2568.class_5247.field_24342,
                            class_2561.method_43470("Click here to disable this warning")));
            });

		mc.field_1724.method_7353(text, false);
	}

}
