package com.simibubi.create.foundation.item;

import net.minecraft.class_1792;
import net.minecraft.class_6862;
import net.minecraft.class_6880;
import net.minecraft.class_7923;

public class TagDependentIngredientItem extends class_1792 {

	private class_6862<class_1792> tag;

	public TagDependentIngredientItem(class_1793 properties, class_6862<class_1792> tag) {
		super(properties);
		this.tag = tag;
	}

	public boolean shouldHide() {
		for (class_6880<class_1792> ignored : class_7923.field_41178.method_40286(this.tag)) {
			return false; // at least 1 present
		}
		return true; // none present
	}

}
