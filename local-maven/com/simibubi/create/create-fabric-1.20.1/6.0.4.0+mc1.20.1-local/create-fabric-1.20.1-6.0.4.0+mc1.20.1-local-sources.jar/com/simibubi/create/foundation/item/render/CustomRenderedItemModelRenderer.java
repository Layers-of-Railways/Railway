package com.simibubi.create.foundation.item.render;

import net.fabricmc.fabric.api.client.rendering.v1.BuiltinItemRendererRegistry.DynamicItemRenderer;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_811;

public abstract class CustomRenderedItemModelRenderer implements DynamicItemRenderer {

	@Override
	public void render(class_1799 stack, class_811 transformType, class_4587 ms, class_4597 buffer, int light, int overlay) {
		if(!(class_310.method_1551()
				.method_1480()
				.method_4019(stack, null, null, 0) instanceof CustomRenderedItemModel)) return; // insure we are only casting CustomRenderedItemModel incase another mod's messes with models
		CustomRenderedItemModel mainModel = (CustomRenderedItemModel) class_310.method_1551()
			.method_1480()
			.method_4019(stack, null, null, 0);
		PartialItemModelRenderer renderer = PartialItemModelRenderer.of(stack, transformType, ms, buffer, overlay);

		ms.method_22903();
		ms.method_46416(0.5F, 0.5F, 0.5F);
		render(stack, mainModel, renderer, transformType, ms, buffer, light, overlay);
		ms.method_22909();
	}

	protected abstract void render(class_1799 stack, CustomRenderedItemModel model, PartialItemModelRenderer renderer, class_811 transformType,
		class_4587 ms, class_4597 buffer, int light, int overlay);

}
