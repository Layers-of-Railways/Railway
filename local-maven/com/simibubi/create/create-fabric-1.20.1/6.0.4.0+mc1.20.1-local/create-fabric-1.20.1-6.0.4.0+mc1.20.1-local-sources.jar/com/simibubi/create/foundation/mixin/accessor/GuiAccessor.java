package com.simibubi.create.foundation.mixin.accessor;

import net.minecraft.class_329;
import net.minecraft.class_359;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_329.class)
public interface GuiAccessor {
	@Accessor("subtitleOverlay")
	class_359 create$getSubtitleOverlay();
}
