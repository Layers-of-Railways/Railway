package com.simibubi.create.foundation.item;

import net.createmod.catnip.data.TriState;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_5819;

public interface CustomUseEffectsItem {
	/**
	 * Called to determine if use effects should be applied for this item.
	 *
	 * @param stack  The ItemStack being used.
	 * @param entity The LivingEntity using the item.
	 * @return {@link TriState#DEFAULT} for default behavior, or {@link TriState#TRUE}/{@link TriState#FALSE} to override default behavior
	 */
	default TriState shouldTriggerUseEffects(class_1799 stack, class_1309 entity) {
		return TriState.DEFAULT;
	}

	/**
	 * Called when use effects should be applied for this item.
	 *
	 * @param stack  The ItemStack being used.
	 * @param entity The LivingEntity using the item.
	 * @param count  The amount of times effects should be applied. Can safely be ignored.
	 * @param random The LivingEntity's RandomSource.
	 * @return if the default behavior should be cancelled or not
	 */
	boolean triggerUseEffects(class_1799 stack, class_1309 entity, int count, class_5819 random);
}
