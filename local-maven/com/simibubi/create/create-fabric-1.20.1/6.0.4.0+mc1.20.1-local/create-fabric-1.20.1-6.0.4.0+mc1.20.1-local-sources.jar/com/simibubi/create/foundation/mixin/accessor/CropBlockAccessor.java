package com.simibubi.create.foundation.mixin.accessor;

import net.minecraft.class_2302;
import net.minecraft.class_2758;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_2302.class)
public interface CropBlockAccessor {

	@Invoker("getAgeProperty")
	class_2758 create$callGetAgeProperty();

}
