package com.simibubi.create;

import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;

import io.github.fabricators_of_create.porting_lib.util.EnvExecutor;

import net.fabricmc.api.EnvType;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.class_1087;
import net.minecraft.class_1747;
import net.minecraft.class_1761;
import net.minecraft.class_1761.class_7704;
import net.minecraft.class_1761.class_7705;
import net.minecraft.class_1761.class_7914;
import net.minecraft.class_1761.class_8128;
import net.minecraft.class_1767;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.class_918;
import org.apache.commons.lang3.mutable.MutableObject;

import com.simibubi.create.content.contraptions.actors.seat.SeatBlock;
import com.simibubi.create.content.decoration.palettes.AllPaletteBlocks;
import com.simibubi.create.content.equipment.armor.BacktankUtil;
import com.simibubi.create.content.equipment.toolbox.ToolboxBlock;
import com.simibubi.create.content.kinetics.crank.ValveHandleBlock;
import com.simibubi.create.content.logistics.box.PackageStyles;
import com.simibubi.create.content.logistics.packagePort.postbox.PostboxBlock;
import com.simibubi.create.content.logistics.tableCloth.TableClothBlock;
import com.simibubi.create.foundation.data.CreateRegistrate;
import com.simibubi.create.foundation.item.TagDependentIngredientItem;
import com.tterrag.registrate.util.entry.BlockEntry;
import com.tterrag.registrate.util.entry.ItemEntry;
import com.tterrag.registrate.util.entry.ItemProviderEntry;
import com.tterrag.registrate.util.entry.RegistryEntry;

import it.unimi.dsi.fastutil.objects.Reference2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.objects.Reference2ReferenceOpenHashMap;
import it.unimi.dsi.fastutil.objects.ReferenceArrayList;
import it.unimi.dsi.fastutil.objects.ReferenceLinkedOpenHashSet;
import it.unimi.dsi.fastutil.objects.ReferenceOpenHashSet;
import net.createmod.catnip.platform.CatnipServices;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;

import io.github.fabricators_of_create.porting_lib.util.EnvExecutor;

public class AllCreativeModeTabs {

	public static final TabInfo BASE_CREATIVE_TAB = register("base",
		() -> FabricItemGroup.builder()
			.method_47321(class_2561.method_43471("itemGroup.create.base"))
			.method_47320(() -> AllBlocks.COGWHEEL.asStack())
			.method_47317(new RegistrateDisplayItemsGenerator(true, () -> AllCreativeModeTabs.BASE_CREATIVE_TAB))
			.method_47324());

	public static final TabInfo PALETTES_CREATIVE_TAB = register("palettes",
		() -> FabricItemGroup.builder()
			.method_47321(class_2561.method_43471("itemGroup.create.palettes"))
			.method_47320(() -> AllPaletteBlocks.ORNATE_IRON_WINDOW.asStack())
			.method_47317(new RegistrateDisplayItemsGenerator(false, () -> AllCreativeModeTabs.PALETTES_CREATIVE_TAB))
			.method_47324());

	private static TabInfo register(String name, Supplier<class_1761> supplier) {
		class_2960 id = Create.asResource(name);
		class_5321<class_1761> key = class_5321.method_29179(class_7924.field_44688, id);
		class_1761 tab = supplier.get();
		class_2378.method_39197(class_7923.field_44687, key, tab);
		return new TabInfo(key, tab);
	}

	public static void register() {
		// fabric: just load the class
	}

	private static class RegistrateDisplayItemsGenerator implements class_7914 {
		private static final Predicate<class_1792> IS_ITEM_3D_PREDICATE;

		static {
			MutableObject<Predicate<class_1792>> isItem3d = new MutableObject<>(item -> false);
			EnvExecutor.runWhenOn(EnvType.CLIENT, () -> () -> {
				isItem3d.setValue(item -> {
					class_918 itemRenderer = class_310.method_1551()
						.method_1480();
					class_1087 model = itemRenderer.method_4019(new class_1799(item), null, null, 0);
					return model.method_4712();
				});
			});
			IS_ITEM_3D_PREDICATE = isItem3d.getValue();
		}

		private final boolean addItems;
		private final Supplier<TabInfo> tabFilter;

		public RegistrateDisplayItemsGenerator(boolean addItems, Supplier<TabInfo> tabFilter) {
			this.addItems = addItems;
			this.tabFilter = tabFilter;
		}

		private static Predicate<class_1792> makeExclusionPredicate() {
			Set<class_1792> exclusions = new ReferenceOpenHashSet<>();

			List<ItemProviderEntry<?>> simpleExclusions = List.of(
				AllItems.INCOMPLETE_PRECISION_MECHANISM,
				AllItems.INCOMPLETE_REINFORCED_SHEET,
				AllItems.INCOMPLETE_TRACK,
				AllItems.CHROMATIC_COMPOUND,
				AllItems.SHADOW_STEEL,
				AllItems.REFINED_RADIANCE,
				AllItems.COPPER_BACKTANK_PLACEABLE,
				AllItems.NETHERITE_BACKTANK_PLACEABLE,
				AllItems.MINECART_CONTRAPTION,
				AllItems.FURNACE_MINECART_CONTRAPTION,
				AllItems.CHEST_MINECART_CONTRAPTION,
				AllItems.SCHEMATIC,
				AllItems.SHOPPING_LIST,
				AllBlocks.ANDESITE_ENCASED_SHAFT,
				AllBlocks.BRASS_ENCASED_SHAFT,
				AllBlocks.ANDESITE_ENCASED_COGWHEEL,
				AllBlocks.BRASS_ENCASED_COGWHEEL,
				AllBlocks.ANDESITE_ENCASED_LARGE_COGWHEEL,
				AllBlocks.BRASS_ENCASED_LARGE_COGWHEEL,
				AllBlocks.MYSTERIOUS_CUCKOO_CLOCK,
				AllBlocks.ELEVATOR_CONTACT,
				AllBlocks.SHADOW_STEEL_CASING,
				AllBlocks.REFINED_RADIANCE_CASING
			);

			List<ItemEntry<TagDependentIngredientItem>> tagDependentExclusions = List.of(
				AllItems.CRUSHED_OSMIUM,
				AllItems.CRUSHED_PLATINUM,
				AllItems.CRUSHED_SILVER,
				AllItems.CRUSHED_TIN,
				AllItems.CRUSHED_LEAD,
				AllItems.CRUSHED_QUICKSILVER,
				AllItems.CRUSHED_BAUXITE,
				AllItems.CRUSHED_URANIUM,
				AllItems.CRUSHED_NICKEL
			);

			exclusions.addAll(PackageStyles.RARE_BOXES);

			for (ItemProviderEntry<?> entry : simpleExclusions) {
				exclusions.add(entry.method_8389());
			}

			for (ItemEntry<TagDependentIngredientItem> entry : tagDependentExclusions) {
				TagDependentIngredientItem item = entry.get();
				if (item.shouldHide()) {
					exclusions.add(entry.method_8389());
				}
			}

			return exclusions::contains;
		}



		private static List<ItemOrdering> makeOrderings() {
			List<ItemOrdering> orderings = new ReferenceArrayList<>();

			Map<ItemProviderEntry<?>, ItemProviderEntry<?>> simpleBeforeOrderings = Map.of(
				AllItems.EMPTY_BLAZE_BURNER, AllBlocks.BLAZE_BURNER,
				AllItems.SCHEDULE, AllBlocks.TRACK_STATION
			);

			Map<ItemProviderEntry<?>, ItemProviderEntry<?>> simpleAfterOrderings = Map.of(
				AllItems.VERTICAL_GEARBOX, AllBlocks.GEARBOX
			);

			simpleBeforeOrderings.forEach((entry, otherEntry) -> {
				orderings.add(ItemOrdering.before(entry.method_8389(), otherEntry.method_8389()));
			});

			simpleAfterOrderings.forEach((entry, otherEntry) -> {
				orderings.add(ItemOrdering.after(entry.method_8389(), otherEntry.method_8389()));
			});

			PackageStyles.STANDARD_BOXES.forEach(item -> {
				if (CatnipServices.REGISTRIES.getKeyOrThrow(item).method_12836().equals(Create.ID))
					orderings.add(ItemOrdering.after(item, AllBlocks.PACKAGER.method_8389()));
			});

			return orderings;
		}

		private static Function<class_1792, class_1799> makeStackFunc() {
			Map<class_1792, Function<class_1792, class_1799>> factories = new Reference2ReferenceOpenHashMap<>();

			Map<ItemProviderEntry<?>, Function<class_1792, class_1799>> simpleFactories = Map.of(
				AllItems.COPPER_BACKTANK, item -> {
					class_1799 stack = new class_1799(item);
					stack.method_7948().method_10569("Air", BacktankUtil.maxAirWithoutEnchants());
					return stack;
				},
				AllItems.NETHERITE_BACKTANK, item -> {
					class_1799 stack = new class_1799(item);
					stack.method_7948().method_10569("Air", BacktankUtil.maxAirWithoutEnchants());
					return stack;
				}
			);

			simpleFactories.forEach((entry, factory) -> {
				factories.put(entry.method_8389(), factory);
			});

			return item -> {
				Function<class_1792, class_1799> factory = factories.get(item);
				if (factory != null) {
					return factory.apply(item);
				}
				return new class_1799(item);
			};
		}

		private static Function<class_1792, class_7705> makeVisibilityFunc() {
			Map<class_1792, class_7705> visibilities = new Reference2ObjectOpenHashMap<>();

			Map<ItemProviderEntry<?>, class_7705> simpleVisibilities = Map.of(
				AllItems.BLAZE_CAKE_BASE, class_7705.field_40193
			);

			simpleVisibilities.forEach((entry, factory) -> {
				visibilities.put(entry.method_8389(), factory);
			});

			for (BlockEntry<ValveHandleBlock> entry : AllBlocks.DYED_VALVE_HANDLES) {
				visibilities.put(entry.method_8389(), class_7705.field_40193);
			}

			for (BlockEntry<SeatBlock> entry : AllBlocks.SEATS) {
				SeatBlock block = entry.get();
				if (block.getColor() != class_1767.field_7964) {
					visibilities.put(entry.method_8389(), class_7705.field_40193);
				}
			}

			for (BlockEntry<TableClothBlock> entry : AllBlocks.TABLE_CLOTHS) {
				TableClothBlock block = entry.get();
				if (block.getColor() != class_1767.field_7964) {
					visibilities.put(entry.method_8389(), class_7705.field_40193);
				}
			}

			for (BlockEntry<PostboxBlock> entry : AllBlocks.PACKAGE_POSTBOXES) {
				PostboxBlock block = entry.get();
				if (block.getColor() != class_1767.field_7952) {
					visibilities.put(entry.method_8389(), class_7705.field_40193);
				}
			}

			for (BlockEntry<ToolboxBlock> entry : AllBlocks.TOOLBOXES) {
				ToolboxBlock block = entry.get();
				if (block.getColor() != class_1767.field_7957) {
					visibilities.put(entry.method_8389(), class_7705.field_40193);
				}
			}

			return item -> {
				class_7705 visibility = visibilities.get(item);
				if (visibility != null) {
					return visibility;
				}
				return class_7705.field_40191;
			};
		}

		@Override
		public void accept(class_8128 parameters, class_7704 output) {
			Predicate<class_1792> exclusionPredicate = makeExclusionPredicate();
			List<ItemOrdering> orderings = makeOrderings();
			Function<class_1792, class_1799> stackFunc = makeStackFunc();
			Function<class_1792, class_7705> visibilityFunc = makeVisibilityFunc();

			List<class_1792> items = new LinkedList<>();
			if (addItems) {
				items.addAll(collectItems(exclusionPredicate.or(IS_ITEM_3D_PREDICATE.negate())));
			}
			items.addAll(collectBlocks(exclusionPredicate));
			if (addItems) {
				items.addAll(collectItems(exclusionPredicate.or(IS_ITEM_3D_PREDICATE)));
			}

			applyOrderings(items, orderings);
			outputAll(output, items, stackFunc, visibilityFunc);
		}

		private List<class_1792> collectBlocks(Predicate<class_1792> exclusionPredicate) {
			List<class_1792> items = new ReferenceArrayList<>();
			for (RegistryEntry<class_2248> entry : Create.registrate().getAll(class_7924.field_41254)) {
				if (!CreateRegistrate.isInCreativeTab(entry, tabFilter.get().key()))
					continue;
				class_1792 item = entry.get()
					.method_8389();
				if (item == class_1802.field_8162)
					continue;
				if (!exclusionPredicate.test(item))
					items.add(item);
			}
			items = new ReferenceArrayList<>(new ReferenceLinkedOpenHashSet<>(items));
			return items;
		}

		private List<class_1792> collectItems(Predicate<class_1792> exclusionPredicate) {
			List<class_1792> items = new ReferenceArrayList<>();
			for (RegistryEntry<class_1792> entry : Create.registrate().getAll(class_7924.field_41197)) {
				if (!CreateRegistrate.isInCreativeTab(entry, tabFilter.get().key()))
					continue;
				class_1792 item = entry.get();
				if (item instanceof class_1747)
					continue;
				if (!exclusionPredicate.test(item))
					items.add(item);
			}
			return items;
		}

		private static void applyOrderings(List<class_1792> items, List<ItemOrdering> orderings) {
			for (ItemOrdering ordering : orderings) {
				int anchorIndex = items.indexOf(ordering.anchor());
				if (anchorIndex != -1) {
					class_1792 item = ordering.item();
					int itemIndex = items.indexOf(item);
					if (itemIndex != -1) {
						items.remove(itemIndex);
						if (itemIndex < anchorIndex) {
							anchorIndex--;
						}
					}
					if (ordering.type() == ItemOrdering.Type.AFTER) {
						items.add(anchorIndex + 1, item);
					} else {
						items.add(anchorIndex, item);
					}
				}
			}
		}

		private static void outputAll(class_7704 output, List<class_1792> items, Function<class_1792, class_1799> stackFunc, Function<class_1792, class_7705> visibilityFunc) {
			for (class_1792 item : items) {
				output.method_45417(stackFunc.apply(item), visibilityFunc.apply(item));
			}
		}

		private record ItemOrdering(class_1792 item, class_1792 anchor, Type type) {
			public static ItemOrdering before(class_1792 item, class_1792 anchor) {
				return new ItemOrdering(item, anchor, Type.BEFORE);
			}

			public static ItemOrdering after(class_1792 item, class_1792 anchor) {
				return new ItemOrdering(item, anchor, Type.AFTER);
			}

			public enum Type {
				BEFORE,
				AFTER;
			}
		}
	}

	public record TabInfo(class_5321<class_1761> key, class_1761 tab) {
	}
}
