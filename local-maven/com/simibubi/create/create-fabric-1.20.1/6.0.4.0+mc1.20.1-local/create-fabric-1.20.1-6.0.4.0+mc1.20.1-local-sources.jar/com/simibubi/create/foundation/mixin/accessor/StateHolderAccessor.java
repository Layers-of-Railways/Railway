package com.simibubi.create.foundation.mixin.accessor;

import net.minecraft.class_2688;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_2688.class)
public interface StateHolderAccessor<O, S> {
	@Accessor
	O getOwner();
}
