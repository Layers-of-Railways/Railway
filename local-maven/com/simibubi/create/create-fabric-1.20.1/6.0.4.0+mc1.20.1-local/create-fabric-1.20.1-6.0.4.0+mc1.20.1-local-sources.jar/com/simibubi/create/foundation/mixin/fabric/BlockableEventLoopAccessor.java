package com.simibubi.create.foundation.mixin.fabric;

import java.util.concurrent.CompletableFuture;
import net.minecraft.class_1255;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_1255.class)
public interface BlockableEventLoopAccessor {
	@Invoker
	CompletableFuture<Void> callSubmitAsync(Runnable task);
}
