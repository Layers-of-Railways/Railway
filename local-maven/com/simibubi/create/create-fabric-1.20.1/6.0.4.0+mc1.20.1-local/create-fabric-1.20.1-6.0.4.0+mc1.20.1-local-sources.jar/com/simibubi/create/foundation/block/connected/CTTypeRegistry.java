package com.simibubi.create.foundation.block.connected;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.Nullable;
import net.minecraft.class_2960;

public class CTTypeRegistry {
	private static final Map<class_2960, CTType> TYPES = new HashMap<>();

	public static void register(CTType type) {
		class_2960 id = type.getId();
		if (TYPES.containsKey(id))
			throw new IllegalArgumentException("Tried to override CTType registration for id '" + id + "'. This is not supported!");
		TYPES.put(id, type);
	}

	@Nullable
	public static CTType get(class_2960 id) {
		return TYPES.get(id);
	}
}
