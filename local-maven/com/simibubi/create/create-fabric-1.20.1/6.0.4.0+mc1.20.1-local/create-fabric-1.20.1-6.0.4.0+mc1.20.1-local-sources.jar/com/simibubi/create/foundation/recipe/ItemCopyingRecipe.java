package com.simibubi.create.foundation.recipe;

import javax.annotation.Nullable;

import com.simibubi.create.AllRecipeTypes;

import net.createmod.catnip.data.IntAttached;
import net.minecraft.class_1799;
import net.minecraft.class_1852;
import net.minecraft.class_1865;
import net.minecraft.class_1937;
import net.minecraft.class_2371;
import net.minecraft.class_2960;
import net.minecraft.class_5455;
import net.minecraft.class_7710;
import net.minecraft.class_8566;

public class ItemCopyingRecipe extends class_1852 {

	public static interface SupportsItemCopying {

		public default class_1799 createCopy(class_1799 original, int count) {
			class_1799 copyWithCount = original.method_46651(count);
			copyWithCount.method_7983("Enchantments");
			return copyWithCount;
		}

		public default boolean canCopyFromItem(class_1799 item) {
			return item.method_7985();
		}

		public default boolean canCopyToItem(class_1799 item) {
			return !item.method_7985();
		}

	}

	public ItemCopyingRecipe(class_2960 id, class_7710 category) {
		super(id, category);
	}

	@Override
	public boolean matches(class_8566 inv, class_1937 level) {
		return copyCheck(inv) != null;
	}

	@Override
	public class_1799 assemble(class_8566 container, class_5455 registryAccess) {
		IntAttached<class_1799> copyCheck = copyCheck(container);
		if (copyCheck == null)
			return class_1799.field_8037;
		
		class_1799 itemToCopy = copyCheck.getValue();
		if (!(itemToCopy.method_7909() instanceof SupportsItemCopying sic))
			return class_1799.field_8037;
		
		return sic.createCopy(itemToCopy, copyCheck.getFirst() + 1);
	}

	@Nullable
	private IntAttached<class_1799> copyCheck(class_8566 inv) {
		class_1799 itemToCopy = class_1799.field_8037;
		int copyTargets = 0;

		for (int j = 0; j < inv.method_5439(); ++j) {
			class_1799 itemInSlot = inv.method_5438(j);
			if (itemInSlot.method_7960())
				continue;
			if (!itemToCopy.method_7960() && itemToCopy.method_7909() != itemInSlot.method_7909())
				return null;
			if (!(itemInSlot.method_7909() instanceof SupportsItemCopying sic))
				continue;

			if (sic.canCopyFromItem(itemInSlot)) {
				if (!itemToCopy.method_7960())
					return null;
				itemToCopy = itemInSlot;
				continue;
			}

			if (sic.canCopyToItem(itemInSlot))
				copyTargets++;
		}

		if (itemToCopy.method_7960() || copyTargets == 0)
			return null;

		return IntAttached.with(copyTargets, itemToCopy);
	}

	public class_2371<class_1799> getRemainingItems(class_8566 inv) {
		class_2371<class_1799> nonnulllist = class_2371.method_10213(inv.method_5439(), class_1799.field_8037);
		return nonnulllist;
	}

	public class_1865<?> method_8119() {
		return AllRecipeTypes.ITEM_COPYING.getSerializer();
	}

	public boolean method_8113(int width, int height) {
		return width >= 2 && height >= 2;
	}
}
