package com.simibubi.create.foundation.mixin.accessor;

import net.minecraft.class_5341;
import net.minecraft.class_7788;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_7788.class)
public interface BlockLootSubProviderAccessor {
	@Accessor("HAS_SILK_TOUCH")
	static class_5341.class_210 create$HAS_SILK_TOUCH() {
		throw new AssertionError();
	}
}
