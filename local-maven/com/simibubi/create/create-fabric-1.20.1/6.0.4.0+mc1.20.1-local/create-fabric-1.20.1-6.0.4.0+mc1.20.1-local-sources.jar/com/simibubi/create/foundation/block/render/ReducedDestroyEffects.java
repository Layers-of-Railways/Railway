package com.simibubi.create.foundation.block.render;

import org.apache.commons.lang3.mutable.MutableInt;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2338;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_3532;
import net.minecraft.class_638;
import net.minecraft.class_702;
import net.minecraft.class_727;
import io.github.fabricators_of_create.porting_lib.block.CustomDestroyEffectsBlock;

public interface ReducedDestroyEffects extends CustomDestroyEffectsBlock {

	@Override
	@Environment(EnvType.CLIENT)
	default boolean addDestroyEffects(class_2680 state, class_638 world, class_2338 pos, class_702 manager) {
		class_265 voxelshape = state.method_26218(world, pos);
		MutableInt amtBoxes = new MutableInt(0);
		voxelshape.method_1089((x1, y1, z1, x2, y2, z2) -> amtBoxes.increment());
		double chance = 1d / amtBoxes.getValue();

		if (state.method_26215())
			return true;

		voxelshape.method_1089((x1, y1, z1, x2, y2, z2) -> {
			handleBox(x1, y1, z1, x2, y2, z2, chance, state, world, pos, manager);
		});

		return true;
	}

	@Environment(EnvType.CLIENT)
	default void handleBox(double x1, double y1, double z1, double x2, double y2, double z2, double chance,
						   class_2680 state, class_638 world, class_2338 pos, class_702 manager) {
		double w = x2 - x1;
		double h = y2 - y1;
		double l = z2 - z1;
		int xParts = Math.max(2, class_3532.method_15384(Math.min(1, w) * 4));
		int yParts = Math.max(2, class_3532.method_15384(Math.min(1, h) * 4));
		int zParts = Math.max(2, class_3532.method_15384(Math.min(1, l) * 4));

		for (int xIndex = 0; xIndex < xParts; ++xIndex) {
			for (int yIndex = 0; yIndex < yParts; ++yIndex) {
				for (int zIndex = 0; zIndex < zParts; ++zIndex) {
					if (world.field_9229.method_43058() > chance)
						continue;

					double d4 = (xIndex + .5) / xParts;
					double d5 = (yIndex + .5) / yParts;
					double d6 = (zIndex + .5) / zParts;
					double x = pos.method_10263() + d4 * w + x1;
					double y = pos.method_10264() + d5 * h + y1;
					double z = pos.method_10260() + d6 * l + z1;

					manager.method_3058(new class_727(world, x, y, z, d4 - 0.5D, d5 - 0.5D, d6 - 0.5D, state, pos)
							.updateSprite(state, pos));
				}
			}
		}
	}

}
