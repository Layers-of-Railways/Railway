package com.simibubi.create.foundation.utility;

import java.util.List;
import java.util.function.Consumer;

import javax.annotation.Nullable;

import com.simibubi.create.AllBlocks;
import com.simibubi.create.AllTags.AllBlockTags;
import com.simibubi.create.api.schematic.nbt.PartialSafeNBT;
import com.simibubi.create.api.schematic.nbt.SafeNbtWriterRegistry;
import com.simibubi.create.api.schematic.nbt.SafeNbtWriterRegistry.SafeNbtWriter;
import com.simibubi.create.api.schematic.state.SchematicStateFilter;
import com.simibubi.create.api.schematic.state.SchematicStateFilterRegistry;
import com.simibubi.create.api.schematic.state.SchematicStateFilterRegistry.StateFilter;
import com.simibubi.create.compat.Mods;
import com.simibubi.create.compat.framedblocks.FramedBlocksInSchematics;
import com.simibubi.create.content.kinetics.base.KineticBlockEntity;
import com.simibubi.create.content.processing.burner.BlazeBurnerBlock;
import com.simibubi.create.content.processing.burner.BlazeBurnerBlock.HeatLevel;
import com.simibubi.create.foundation.blockEntity.IMergeableBE;
import com.simibubi.create.foundation.blockEntity.IMultiBlockEntityContainer;

import net.createmod.catnip.nbt.NBTProcessors;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.fabricmc.fabric.api.transfer.v1.item.ItemVariant;
import net.fabricmc.fabric.api.transfer.v1.item.PlayerInventoryStorage;
import net.fabricmc.fabric.api.transfer.v1.transaction.Transaction;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1890;
import net.minecraft.class_1893;
import net.minecraft.class_1922;
import net.minecraft.class_1928;
import net.minecraft.class_1937;
import net.minecraft.class_2241;
import net.minecraft.class_2244;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2386;
import net.minecraft.class_2398;
import net.minecraft.class_2487;
import net.minecraft.class_2490;
import net.minecraft.class_2512;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_2758;
import net.minecraft.class_2769;
import net.minecraft.class_2771;
import net.minecraft.class_2818;
import net.minecraft.class_2826;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3468;
import net.minecraft.class_3481;
import net.minecraft.class_3486;
import net.minecraft.class_3610;
import net.minecraft.class_3922;
import net.minecraft.class_4076;
import net.minecraft.class_7924;
import io.github.fabricators_of_create.porting_lib.common.util.IPlantable;
import io.github.fabricators_of_create.porting_lib.transfer.TransferUtil;

public class BlockHelper {
	private static final List<class_2758> COUNT_STATES = List.of(
		class_2741.field_12509,
		class_2741.field_12543,
		class_2741.field_27220
	);

	private static final List<class_2248> VINELIKE_BLOCKS = List.of(
		class_2246.field_10597, class_2246.field_28411
	);

	private static final List<class_2746> VINELIKE_STATES = List.of(
		class_2741.field_12519,
		class_2741.field_12489,
		class_2741.field_12487,
		class_2741.field_12540,
		class_2741.field_12527,
		class_2741.field_12546
	);

	public static class_2680 setZeroAge(class_2680 blockState) {
		if (blockState.method_28498(class_2741.field_12521))
			return blockState.method_11657(class_2741.field_12521, 0);
		if (blockState.method_28498(class_2741.field_12556))
			return blockState.method_11657(class_2741.field_12556, 0);
		if (blockState.method_28498(class_2741.field_12497))
			return blockState.method_11657(class_2741.field_12497, 0);
		if (blockState.method_28498(class_2741.field_12482))
			return blockState.method_11657(class_2741.field_12482, 0);
		if (blockState.method_28498(class_2741.field_12550))
			return blockState.method_11657(class_2741.field_12550, 0);
		if (blockState.method_28498(class_2741.field_12498))
			return blockState.method_11657(class_2741.field_12498, 0);
		if (blockState.method_28498(class_2741.field_12517))
			return blockState.method_11657(class_2741.field_12517, 0);
		if (blockState.method_28498(class_2741.field_20432))
			return blockState.method_11657(class_2741.field_20432, 0);
		if (blockState.method_28498(class_2741.field_12530))
			return blockState.method_11657(class_2741.field_12530, 0);
		if (blockState.method_28498(class_2741.field_12549))
			return blockState.method_11657(class_2741.field_12549, 0);
		if (blockState.method_26164(class_3481.field_26985))
			return class_2246.field_10593
				.method_9564();
		if (blockState.method_28498(class_2741.field_17586))
			return blockState.method_11657(class_2741.field_17586, 0);
		if (blockState.method_28498(class_2741.field_12552))
			return blockState.method_11657(class_2741.field_12552, false);
		return blockState;
	}

	public static int simulateFindAndRemoveInInventory(class_2680 block, class_1657 player, long amount) {
		try (Transaction t = TransferUtil.getTransaction()) {
			return findAndRemoveInInventory(block, player, amount);
		}
	}

	public static int findAndRemoveInInventory(class_2680 block, class_1657 player, long amount) {
		ItemVariant required = ItemVariant.of(getRequiredItem(block));

		boolean needsTwo = block.method_28498(class_2741.field_12485)
			&& block.method_11654(class_2741.field_12485) == class_2771.field_12682;

		if (needsTwo)
			amount *= 2;

		for (class_2758 property : COUNT_STATES)
			if (block.method_28498(property))
				amount *= block.method_11654(property);

		if (VINELIKE_BLOCKS.contains(block.method_26204())) {
			int vineCount = 0;

			for (class_2746 vineState : VINELIKE_STATES) {
				if (block.method_28498(vineState) && block.method_11654(vineState)) {
					vineCount++;
				}
			}

			amount += vineCount - 1;
		}

		try (Transaction t = TransferUtil.getTransaction()) {
			PlayerInventoryStorage storage = PlayerInventoryStorage.of(player);
			int amountFound = (int) storage.extract(required, amount, t);

			if (needsTwo) {
				// Give back 1 if uneven amount was removed
				if (amountFound % 2 != 0)
					storage.insert(required, 1, t);
				amountFound /= 2;
			}

			t.commit();
			return amountFound;
		}
	}

	public static class_1799 getRequiredItem(class_2680 state) {
		class_1799 itemStack = new class_1799(state.method_26204());
		class_1792 item = itemStack.method_7909();
		if (item == class_1802.field_8365 || item == class_1802.field_8519)
			itemStack = new class_1799(class_1802.field_8831);
		return itemStack;
	}

	public static void destroyBlock(class_1937 world, class_2338 pos, float effectChance) {
		destroyBlock(world, pos, effectChance, stack -> class_2248.method_9577(world, pos, stack));
	}

	public static void destroyBlock(class_1937 world, class_2338 pos, float effectChance,
									Consumer<class_1799> droppedItemCallback) {
		destroyBlockAs(world, pos, null, class_1799.field_8037, effectChance, droppedItemCallback);
	}

	public static void destroyBlockAs(class_1937 world, class_2338 pos, @Nullable class_1657 player, class_1799 usedTool,
									  float effectChance, Consumer<class_1799> droppedItemCallback) {
		class_3610 fluidState = world.method_8316(pos);
		class_2680 state = world.method_8320(pos);

		if (world.field_9229.method_43057() < effectChance)
			world.method_20290(2001, pos, class_2248.method_9507(state));
		class_2586 blockEntity = state.method_31709() ? world.method_8321(pos) : null;

		if (player != null) {
			boolean allowed = PlayerBlockBreakEvents.BEFORE.invoker().beforeBlockBreak(world, player, pos, state, blockEntity);
			if (!allowed) {
				PlayerBlockBreakEvents.CANCELED.invoker().onBlockBreakCanceled(world, player, pos, state, blockEntity);
				return;
			}

			// fabric: exp handed in state.spawnAfterBreak

			usedTool.method_7952(world, state, pos, player);
			player.method_7259(class_3468.field_15427.method_14956(state.method_26204()));
		}

		if (world instanceof class_3218 && world.method_8450()
			.method_8355(class_1928.field_19392)
			&& (player == null || !player.method_7337())) {
			for (class_1799 itemStack : class_2248.method_9609(state, (class_3218) world, pos, blockEntity, player, usedTool)) {
				if (itemStack.method_7960())
					continue;
				droppedItemCallback.accept(itemStack);
			}

			// Simulating IceBlock#playerDestroy. Not calling method directly as
			// it would roll the loot table (or crash if the player is null)
			if (state.method_26204() instanceof class_2386 && class_1890.method_8225(class_1893.field_9099, usedTool) == 0) {
				if (!world.method_8597().comp_644()) {
					class_2680 below = world.method_8320(pos.method_10074());
					if (below.method_51366() || below.method_51176()) {
						fluidState = class_2386.method_51170().method_26227();
					}
				}
			}

			state.method_26180((class_3218) world, pos, class_1799.field_8037, true);
		}

		world.method_8501(pos, fluidState.method_15759());
		afterBreak(world, player, pos, state, blockEntity);
	}

	// fabric: after break event
	private static void afterBreak(class_1937 level, @Nullable class_1657 player, class_2338 pos, class_2680 state, @Nullable class_2586 be) {
		if (player != null)
			PlayerBlockBreakEvents.AFTER.invoker().afterBlockBreak(level, player, pos, state, be);
	}

	public static boolean isSolidWall(class_1922 reader, class_2338 fromPos, class_2350 toDirection) {
		return hasBlockSolidSide(reader.method_8320(fromPos.method_10093(toDirection)), reader,
			fromPos.method_10093(toDirection), toDirection.method_10153());
	}

	public static boolean noCollisionInSpace(class_1922 reader, class_2338 pos) {
		return reader.method_8320(pos)
			.method_26220(reader, pos)
			.method_1110();
	}

	private static void placeRailWithoutUpdate(class_1937 world, class_2680 state, class_2338 target) {
		class_2818 chunk = world.method_8500(target);
		int idx = chunk.method_31602(target.method_10264());
		class_2826 chunksection = chunk.method_38259(idx);
		if (chunksection == null) {
			chunksection = new class_2826(world.method_30349()
				.method_30530(class_7924.field_41236));
			chunk.method_12006()[idx] = chunksection;
		}
		class_2680 old = chunksection.method_16675(class_4076.method_18684(target.method_10263()),
			class_4076.method_18684(target.method_10264()), class_4076.method_18684(target.method_10260()), state);
		chunk.method_12008(true);
		world.markAndNotifyBlock(target, chunk, old, state, 82, 512);

		world.method_8652(target, state, 82);
		world.method_8492(target, world.method_8320(target.method_10074())
			.method_26204(), target.method_10074());
	}

	public static class_2487 prepareBlockEntityData(class_2680 blockState, class_2586 blockEntity) {
		class_2487 data = null;
		if (blockEntity == null)
			return null;

		SafeNbtWriter writer = SafeNbtWriterRegistry.REGISTRY.get(blockEntity.method_11017());
		if (AllBlockTags.SAFE_NBT.matches(blockState)) {
			data = blockEntity.method_38242();
		} else if (writer != null) {
			data = new class_2487();
			writer.writeSafe(blockEntity, data);
		} else if (blockEntity instanceof PartialSafeNBT safeNbtBE) {
			data = new class_2487();
safeNbtBE.writeSafe(data);
		} else if (Mods.FRAMEDBLOCKS.contains(blockState.method_26204())) {
			data = FramedBlocksInSchematics.prepareBlockEntityData(blockState, blockEntity);
}
		return NBTProcessors.process(blockState, blockEntity, data, true);
	}

	public static void placeSchematicBlock(class_1937 world, class_2680 state, class_2338 target, class_1799 stack,
										   @Nullable class_2487 data) {
		class_2248 block = state.method_26204();
		class_2586 existingBlockEntity = world.method_8321(target);

		StateFilter filter = SchematicStateFilterRegistry.REGISTRY.get(state);
		if (filter != null) {
			state = filter.filterStates(existingBlockEntity, state);
		} else if (block instanceof SchematicStateFilter schematicStateFilter) {
			state = schematicStateFilter.filterStates(existingBlockEntity, state);
		}

		// Piston
		if (state.method_28498(class_2741.field_12552))
			state = state.method_11657(class_2741.field_12552, Boolean.FALSE);
		if (state.method_28498(class_2741.field_12508))
			state = state.method_11657(class_2741.field_12508, Boolean.FALSE);

		if (block == class_2246.field_17563)
			state = class_2246.field_17563.method_9564();
		else if (block != class_2246.field_10476 && block instanceof IPlantable)
			state = ((IPlantable) block).getPlant(world, target);
		else if (state.method_26164(class_3481.field_26985))
			state = class_2246.field_10593.method_9564();

		if (world.method_8597()
			.comp_644() && state.method_26227().method_15767(class_3486.field_15517)) {
			int i = target.method_10263();
			int j = target.method_10264();
			int k = target.method_10260();
			world.method_8396(null, target, class_3417.field_15102, class_3419.field_15245, 0.5F,
				2.6F + (world.field_9229.method_43057() - world.field_9229.method_43057()) * 0.8F);

			for (int l = 0; l < 8; ++l) {
				world.method_8406(class_2398.field_11237, i + Math.random(), j + Math.random(), k + Math.random(),
					0.0D, 0.0D, 0.0D);
			}
			class_2248.method_9497(state, world, target);
			return;
		}

		if (state.method_26204() instanceof class_2241) {
			placeRailWithoutUpdate(world, state, target);
		} else if (AllBlocks.BELT.has(state)) {
			world.method_8652(target, state, 2);
		} else {
			world.method_8652(target, state, 18);
		}

		if (data != null) {
			if (existingBlockEntity instanceof IMergeableBE mergeable) {
				class_2586 loaded = class_2586.method_11005(target, state, data);
				if (loaded != null) {
					if (existingBlockEntity.method_11017()
						.equals(loaded.method_11017())) {
						mergeable.accept(loaded);
						return;
					}
				}
			}
			class_2586 blockEntity = world.method_8321(target);
			if (blockEntity != null) {
				data.method_10569("x", target.method_10263());
				data.method_10569("y", target.method_10264());
				data.method_10569("z", target.method_10260());
				if (blockEntity instanceof KineticBlockEntity kbe)
					kbe.warnOfMovement();
				if (blockEntity instanceof IMultiBlockEntityContainer imbe)
					if (!imbe.isController())
						data.method_10566("Controller", class_2512.method_10692(imbe.getController()));
				blockEntity.method_11014(data);
			}
		}

		try {
			state.method_26204()
				.method_9567(world, target, state, null, stack);
		} catch (Exception ignored) {
		}
	}

	public static double getBounceMultiplier(class_2248 block) {
		if (block instanceof class_2490)
			return 0.8D;
		if (block instanceof class_2244)
			return 0.66 * 0.8D;
		return 0;
	}

	public static boolean hasBlockSolidSide(class_2680 p_220056_0_, class_1922 p_220056_1_, class_2338 p_220056_2_,
											class_2350 p_220056_3_) {
		return !p_220056_0_.method_26164(class_3481.field_15503)
			&& class_2248.method_9501(p_220056_0_.method_26220(p_220056_1_, p_220056_2_), p_220056_3_);
	}

	public static boolean extinguishFire(class_1937 world, @Nullable class_1657 p_175719_1_, class_2338 p_175719_2_,
										 class_2350 p_175719_3_) {
		p_175719_2_ = p_175719_2_.method_10093(p_175719_3_);
		if (world.method_8320(p_175719_2_)
			.method_26204() == class_2246.field_10036) {
			world.method_8444(p_175719_1_, 1009, p_175719_2_, 0);
			world.method_8650(p_175719_2_, false);
			return true;
		} else {
			return false;
		}
	}

	public static class_2680 copyProperties(class_2680 fromState, class_2680 toState) {
		for (class_2769<?> property : fromState.method_28501()) {
			toState = copyProperty(property, fromState, toState);
		}
		return toState;
	}

	public static <T extends Comparable<T>> class_2680 copyProperty(class_2769<T> property, class_2680 fromState,
																	class_2680 toState) {
		if (fromState.method_28498(property) && toState.method_28498(property)) {
			return toState.method_11657(property, fromState.method_11654(property));
		}
		return toState;
	}

	public static boolean isNotUnheated(class_2680 state) {
		if (state.method_26164(class_3481.field_23799) && state.method_28498(class_3922.field_17352)) {
			return state.method_11654(class_3922.field_17352);
		}
		if (state.method_28498(BlazeBurnerBlock.HEAT_LEVEL)) {
			return state.method_11654(BlazeBurnerBlock.HEAT_LEVEL) != HeatLevel.NONE;
		}
		return true;
	}

	public static void runWithBreakEvents(class_1937 level, class_2338 pos, class_2680 state, @Nullable class_2586 be, class_1657 player, Runnable runnable) {
		boolean shouldBreak = PlayerBlockBreakEvents.BEFORE.invoker().beforeBlockBreak(level, player, pos, state, be);
		if (shouldBreak) {
			runnable.run();
			PlayerBlockBreakEvents.AFTER.invoker().afterBlockBreak(level, player, pos, state, be);
		} else {
			PlayerBlockBreakEvents.CANCELED.invoker().onBlockBreakCanceled(level, player, pos, state, be);
		}
	}
}
