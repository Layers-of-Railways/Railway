package com.simibubi.create.foundation.data.recipe;

import com.simibubi.create.AllFluids;
import com.simibubi.create.AllItems;
import com.simibubi.create.Create;
import com.simibubi.create.api.data.recipe.BaseRecipeProvider.GeneratedRecipe;
import com.simibubi.create.api.data.recipe.EmptyingRecipeGen;

import io.github.tropheusj.milk.Milk;
import net.minecraft.class_1802;
import net.minecraft.class_3612;
import net.minecraft.class_7784;

/**
 * Create's own Data Generation for Emptying recipes
 * @see EmptyingRecipeGen
 */
@SuppressWarnings("unused")
public final class CreateEmptyingRecipeGen extends EmptyingRecipeGen {

	/*
	 * potion/water bottles are handled internally
	 */

	GeneratedRecipe

	HONEY_BOTTLE = create("honey_bottle", b -> b.require(class_1802.field_20417)
		.output(AllFluids.HONEY.get(), 250)
		.output(class_1802.field_8469)),

	BUILDERS_TEA = create("builders_tea", b -> b.require(AllItems.BUILDERS_TEA.get())
		.output(AllFluids.TEA.get(), 250)
		.output(class_1802.field_8469)),

	FD_MILK = create(Mods.FD.recipeId("milk_bottle"), b -> b.require(Mods.FD, "milk_bottle")
		.output(Milk.STILL_MILK, 250)
		.output(class_1802.field_8469)
		.whenModLoaded(Mods.FD.getId())),

	AM_LAVA = create(Mods.AM.recipeId("lava_bottle"), b -> b.require(Mods.AM, "lava_bottle")
		.output(class_1802.field_8469)
		.output(class_3612.field_15908, 250)
		.whenModLoaded(Mods.AM.getId())),

	NEO_MILK = create(Mods.NEA.recipeId("milk_bottle"), b -> b.require(Mods.FD, "milk_bottle")
		.output(Milk.STILL_MILK, 250)
		.output(class_1802.field_8469)
		.whenModLoaded(Mods.NEA.getId()))

	;

	public CreateEmptyingRecipeGen(class_7784 output) {
		super(output, Create.ID);
	}
}
