package com.simibubi.create.foundation.recipe;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.function.Predicate;

import javax.annotation.Nullable;

import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import com.simibubi.create.Create;
import net.fabricmc.fabric.api.resource.IdentifiableResourceReloadListener;
import net.fabricmc.fabric.api.resource.SimpleSynchronousResourceReloadListener;
import net.minecraft.class_1860;
import net.minecraft.class_1937;
import net.minecraft.class_2960;
import net.minecraft.class_3300;

/**
 * Utility for searching through a level's recipe collection.
 * Non-dynamic conditions can be split off into an initial search for caching intermediate results.
 *
 * @author simibubi
 */
public class RecipeFinder {

	private static final Cache<Object, List<class_1860<?>>> CACHED_SEARCHES = CacheBuilder.newBuilder().build();

	public static final IdentifiableResourceReloadListener LISTENER = new SimpleSynchronousResourceReloadListener() {
		@Override
		public class_2960 getFabricId() {
			return Create.asResource("recipe_finder");
		}

		@Override
		public void method_14491(class_3300 resourceManager) {
			CACHED_SEARCHES.invalidateAll();
		}
	};

	/**
	 * Find all recipes matching the condition predicate.
	 * If this search is made more than once,
	 * using the same object instance as the cacheKey will retrieve the cached result from the first search.
	 *
	 * @param cacheKey (can be null to prevent the caching)
	 * @return A started search to continue with more specific conditions.
	 */
	public static List<class_1860<?>> get(@Nullable Object cacheKey, class_1937 level, Predicate<class_1860<?>> conditions) {
		if (cacheKey == null)
			return startSearch(level, conditions);

		try {
			return CACHED_SEARCHES.get(cacheKey, () -> startSearch(level, conditions));
		} catch (ExecutionException e) {
			Create.LOGGER.error("Encountered a exception while searching for recipes", e);
		}

		return Collections.emptyList();
	}

	private static List<class_1860<?>> startSearch(class_1937 level, Predicate<? super class_1860<?>> conditions) {
		List<class_1860<?>> recipes = new ArrayList<>();
		for (class_1860<?> r : level.method_8433().method_8126())
			if (conditions.test(r))
				recipes.add(r);
		return recipes;
	}
}
