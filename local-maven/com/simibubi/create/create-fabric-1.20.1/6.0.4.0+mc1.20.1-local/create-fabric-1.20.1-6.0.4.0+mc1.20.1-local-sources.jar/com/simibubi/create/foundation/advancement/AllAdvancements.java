package com.simibubi.create.foundation.advancement;

import static com.simibubi.create.foundation.advancement.CreateAdvancement.TaskType.EXPERT;
import static com.simibubi.create.foundation.advancement.CreateAdvancement.TaskType.NOISY;
import static com.simibubi.create.foundation.advancement.CreateAdvancement.TaskType.SECRET;
import static com.simibubi.create.foundation.advancement.CreateAdvancement.TaskType.SILENT;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.UnaryOperator;

import com.google.common.collect.Sets;
import com.simibubi.create.AllBlocks;
import com.simibubi.create.AllFluids;
import com.simibubi.create.AllItems;
import com.simibubi.create.AllTags.AllItemTags;
import com.simibubi.create.content.logistics.box.PackageStyles;
import com.simibubi.create.foundation.advancement.CreateAdvancement.Builder;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.minecraft.class_161;
import net.minecraft.class_1767;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2405;
import net.minecraft.class_2487;
import net.minecraft.class_2960;
import net.minecraft.class_7403;
import net.minecraft.class_7784;
import net.minecraft.class_7784.class_7489;

public class AllAdvancements implements class_2405 {

	public static final List<CreateAdvancement> ENTRIES = new ArrayList<>();
	public static final CreateAdvancement START = null,

	/*
	 * Some ids have trailing 0's to modify their vertical position on the tree
	 * (Advancement ordering seems to be deterministic but hash based)
	 */

	ROOT = create("root", b -> b.icon(AllItems.BRASS_HAND)
		.title("Welcome to Create")
		.description("Here Be Contraptions")
		.awardedForFree()
		.special(SILENT)),

	// Andesite - Central Branch

	ANDESITE = create("andesite_alloy", b -> b.icon(AllItems.ANDESITE_ALLOY)
		.title("Sturdier Rocks")
		.description("Obtain some Andesite Alloy, Create's most important resource")
		.after(ROOT)
		.whenIconCollected()),

	ANDESITE_CASING = create("andesite_casing", b -> b.icon(AllBlocks.ANDESITE_CASING)
		.title("The Andesite Age")
		.description("Apply Andesite Alloy to stripped wood, creating a basic casing for your machines")
		.after(ANDESITE)
		.special(NOISY)),

	PRESS = create("mechanical_press", b -> b.icon(AllBlocks.MECHANICAL_PRESS)
		.title("Bonk!")
		.description("Create some sheets in a Mechanical Press")
		.after(ANDESITE_CASING)
		.special(NOISY)),

	ENCASED_FAN = create("encased_fan", b -> b.icon(AllBlocks.ENCASED_FAN)
		.title("Wind Maker")
		.description("Place and power an Encased Fan")
		.after(PRESS)),

	FAN_PROCESSING = create("fan_processing", b -> b.icon(AllItems.PROPELLER)
		.title("Processing by Particle")
		.description("Use an Encased Fan to process materials")
		.after(ENCASED_FAN)),

	SAW_PROCESSING = create("saw_processing", b -> b.icon(AllBlocks.MECHANICAL_SAW)
		.title("Workshop's Most Feared")
		.description("Use an upright Mechanical Saw to process materials")
		.after(FAN_PROCESSING)),

	COMPACTING = create("compacting", b -> b.icon(class_2246.field_10085)
		.title("Compactification")
		.description("Use a Mechanical Press and a Basin to create fewer items from more")
		.after(SAW_PROCESSING)),

	BELT = create("belt", b -> b.icon(AllItems.BELT_CONNECTOR)
		.title("Kelp Drive")
		.description("Connect two Shafts with a Mechanical Belt")
		.after(COMPACTING)),

	FUNNEL = create("funnel", b -> b.icon(AllBlocks.ANDESITE_FUNNEL)
		.title("Airport Aesthetic")
		.description("Extract or insert items into a container using a Funnel")
		.after(BELT)),

	CHUTE = create("chute", b -> b.icon(AllBlocks.CHUTE)
		.title("Vertical Logistics")
		.description("Transport some items by Chute")
		.after(FUNNEL)),

	MIXER = create("mechanical_mixer", b -> b.icon(AllBlocks.MECHANICAL_MIXER)
		.title("Mixing It Up")
		.description("Combine ingredients in a Mechanical Mixer")
		.after(CHUTE)),

	BLAZE_BURNER = create("burner", b -> b.icon(AllBlocks.BLAZE_BURNER)
		.title("Sentient Fireplace")
		.description("Obtain a Blaze Burner")
		.whenIconCollected()
		.after(MIXER)),

	// Andesite - Top Branch

	WATER_WHEEL = create("water_wheel", b -> b.icon(AllBlocks.WATER_WHEEL)
		.title("Harnessed Hydraulics")
		.description("Place a Water Wheel and use it to generate torque")
		.after(ANDESITE)),

	WINDMILL = create("windmill", b -> b.icon(AllBlocks.SAIL_FRAME)
		.title("A mild Breeze")
		.description("Assemble a windmill and use it to generate torque")
		.after(WATER_WHEEL)),

	COGS = create("shifting_gears", b -> b.icon(AllBlocks.COGWHEEL)
		.title("Shifting Gears")
		.description(
			"Connect a Large Cogwheel to a Small Cogwheel, allowing you to change the speed of your Contraption")
		.after(WINDMILL)),

	MILLSTONE = create("millstone", b -> b.icon(AllBlocks.MILLSTONE)
		.title("Embrace the Grind")
		.description("Use a Millstone to pulverise materials")
		.after(COGS)),

	SUPER_GLUE = create("super_glue", b -> b.icon(AllItems.SUPER_GLUE)
		.title("Area of Connect")
		.description("Super Glue some blocks into a group")
		.after(MILLSTONE)),

	CONTRAPTION_ACTORS = create("contraption_actors", b -> b.icon(AllBlocks.MECHANICAL_HARVESTER)
		.title("Moving with Purpose")
		.description("Create a Contraption with drills, saws, or harvesters on board")
		.after(SUPER_GLUE)),

	PSI = create("portable_storage_interface", b -> b.icon(AllBlocks.PORTABLE_STORAGE_INTERFACE)
		.title("Drive-by Exchange")
		.description("Use a Portable Storage Interface to take or insert items into a Contraption")
		.after(CONTRAPTION_ACTORS)),

	WRENCH_GOGGLES = create("wrench_goggles", b -> b.icon(AllItems.WRENCH)
		.title("Kitted Out")
		.description("Equip Engineer's Goggles and a Wrench")
		.whenIconCollected()
		.whenItemCollected(AllItems.GOGGLES)
		.after(PSI)),

	STRESSOMETER = create("stressometer", b -> b.icon(AllBlocks.STRESSOMETER)
		.title("Stress for Nerds")
		.description("Get an exact readout with the help of Engineer's Goggles and a Stressometer")
		.after(WRENCH_GOGGLES)),

	CUCKOO_CLOCK = create("cuckoo_clock", b -> b.icon(AllBlocks.CUCKOO_CLOCK)
		.title("Is it Time?")
		.description("Witness your Cuckoo Clock announce bedtime")
		.after(STRESSOMETER)
		.special(NOISY)),

	// Andesite - Expert Branch

	WINDMILL_MAXED = create("windmill_maxed", b -> b.icon(AllBlocks.SAIL)
		.title("A strong Breeze")
		.description("Assemble a windmill of maximum strength")
		.after(ANDESITE)
		.special(EXPERT)),

	EJECTOR_MAXED = create("ejector_maxed", b -> b.icon(AllBlocks.WEIGHTED_EJECTOR)
		.title("Springboard Champion")
		.description("Get launched more than 30 blocks by a Weighted Ejector")
		.after(WINDMILL_MAXED)
		.special(EXPERT)),

	PULLEY_MAXED = create("pulley_maxed", b -> b.icon(AllBlocks.ROPE_PULLEY)
		.title("Rope to Nowhere")
		.description("Extend a Rope Pulley over 200 blocks deep")
		.after(EJECTOR_MAXED)
		.special(EXPERT)),

	CART_PICKUP = create("cart_pickup", b -> b.icon(AllItems.CHEST_MINECART_CONTRAPTION)
		.title("Strong Arms")
		.description("Pick up a Minecart Contraption with at least 200 attached blocks")
		.after(PULLEY_MAXED)
		.special(EXPERT)),

	ANVIL_PLOUGH = create("anvil_plough", b -> b.icon(class_2246.field_10105)
		.title("Blacksmith Artillery")
		.description("Launch an Anvil with Mechanical Ploughs")
		.after(CART_PICKUP)
		.special(EXPERT)),

	// Andesite - Hidden

	LAVA_WHEEL = create("lava_wheel_00000", b -> b.icon(AllBlocks.WATER_WHEEL)
		.title("Magma Wheel")
		.description("This shouldn't have worked")
		.after(MIXER)
		.special(SECRET)),

	HAND_CRANK = create("hand_crank_000", b -> b.icon(AllBlocks.HAND_CRANK)
		.title("Workout Session")
		.description("Use a Hand Crank until fully exhausted")
		.after(MIXER)
		.special(SECRET)),

	FUNNEL_KISS = create("belt_funnel_kiss", b -> b.icon(AllBlocks.BRASS_FUNNEL)
		.title("The Parrots and the Flaps")
		.description("Make two Belt-mounted Funnels kiss")
		.after(MIXER)
		.special(SECRET)),

	STRESSOMETER_MAXED = create("stressometer_maxed", b -> b.icon(AllBlocks.STRESSOMETER)
		.title("Perfectly Stressed")
		.description("Get a 100% readout from a Stressometer")
		.after(MIXER)
		.special(SECRET)),

	// Logistics

	CARDBOARD = create("cardboard", b -> b.icon(AllItems.CARDBOARD)
		.title("Part and Parcel")
		.description("Produce or obtain your first Cardboard")
		.whenIconCollected()
		.after(MIXER)),

	PACKAGER = create("packager", b -> b.icon(AllBlocks.PACKAGER)
		.title("Post Production")
		.description("Package items from an inventory using the Packager")
		.after(CARDBOARD)),

	STOCK_TICKER = create("stock_ticker", b -> b.icon(AllBlocks.STOCK_TICKER)
		.title("Order Up!")
		.description("Employ a mob at your stock ticker and make your first requests")
		.special(NOISY)
		.after(PACKAGER)),

	FROGPORT = create("frogport", b -> b.icon(AllBlocks.PACKAGE_FROGPORT)
		.title("Hungry hoppers")
		.description("Catch packages from your Chain Conveyor using a Frogport")
		.special(NOISY)
		.after(STOCK_TICKER)),

	TABLE_CLOTH_SHOP = create("table_cloth_shop", b -> b.icon(AllBlocks.TABLE_CLOTHS.get(class_1767.field_7964))
		.title("Open for business")
		.description("Put items up for sale using a Table Cloth")
		.special(NOISY)
		.after(FROGPORT)),

	FACTORY_GAUGE = create("factory_gauge", b -> b.icon(AllBlocks.FACTORY_GAUGE)
		.title("High Logistics")
		.description("Trigger an automatic package request using Factory Gauges")
		.special(NOISY)
		.after(TABLE_CLOTH_SHOP)),

	CARDBOARD_ARMOR = create("cardboard_armor", b -> b.icon(AllItems.CARDBOARD_CHESTPLATE)
		.title("Full Stealth")
		.description("Sneak around in full Cardboard Armor")
		.after(FACTORY_GAUGE)),

	// Logistics - Secret

	PACKAGE_CHUTE_THROW = create("package_chute_throw", b -> b.icon(PackageStyles.getDefaultBox())
		.title("Nothing but net")
		.description("Land your cardboard package throw in an item chute")
		.after(CARDBOARD_ARMOR)
		.special(SECRET)),

	CARDBOARD_ARMOR_TRIM = create("cardboard_armor_trim",
		b -> b.icon(createArmorTrimmedCardboardChestplate())
			.title("Arts and Crafts")
			.description("Decorate your cardboard equipment with armor trims")
			.after(CARDBOARD_ARMOR)
			.special(SECRET)),

	// Copper - Central Branch

	COPPER = create("copper", b -> b.icon(class_1802.field_27022)
		.title("Cuprum Bokum")
		.description("Amass some Copper Ingots for your exploits in fluid manipulation")
		.whenIconCollected()
		.after(BLAZE_BURNER)
		.special(SILENT)),

	COPPER_CASING = create("copper_casing", b -> b.icon(AllBlocks.COPPER_CASING)
		.title("The Copper Age")
		.description("Apply Copper Ingots to stripped wood, creating a waterproof casing for your machines")
		.after(COPPER)),

	SPOUT = create("spout", b -> b.icon(AllBlocks.SPOUT)
		.title("Sploosh")
		.description("Watch a fluid-containing item be filled by a Spout")
		.after(COPPER_CASING)),

	DRAIN = create("drain", b -> b.icon(AllBlocks.ITEM_DRAIN)
		.title("Tumble Draining")
		.description("Watch a fluid-containing item be emptied by an Item Drain")
		.after(SPOUT)),

	STEAM_ENGINE = create("steam_engine", b -> b.icon(AllBlocks.STEAM_ENGINE)
		.title("The Powerhouse")
		.description("Use a Steam Engine to generate torque")
		.after(DRAIN)),

	STEAM_WHISTLE = create("steam_whistle", b -> b.icon(AllBlocks.STEAM_WHISTLE)
		.title("Voice of an Angel")
		.description("Activate a Steam Whistle")
		.after(STEAM_ENGINE)),

	BACKTANK = create("backtank", b -> b.icon(AllItems.COPPER_BACKTANK)
		.title("Pressure to Go")
		.description("Create a Copper Backtank and make it accumulate air pressure")
		.after(STEAM_WHISTLE)),

	DIVING_SUIT = create("diving_suit", b -> b.icon(AllItems.COPPER_DIVING_HELMET)
		.title("Ready for the Depths")
		.description("Equip a Diving Helmet and a Copper Backtank, then jump into water")
		.after(BACKTANK)),

	// Copper - Top Branch

	PUMP = create("mechanical_pump_0", b -> b.icon(AllBlocks.MECHANICAL_PUMP)
		.title("Under Pressure")
		.description("Place and power a Mechanical Pump")
		.after(COPPER)),

	GLASS_PIPE = create("glass_pipe", b -> b.icon(AllBlocks.FLUID_PIPE)
		.title("Flow Discovery")
		.description("Use your Wrench on a pipe that contains a fluid")
		.after(PUMP)),

	WATER_SUPPLY = create("water_supply", b -> b.icon(class_1802.field_8705)
		.title("Puddle Collector")
		.description("Use the pulling end of a Fluid Pipe or Mechanical Pump to collect water")
		.after(GLASS_PIPE)),

	HOSE_PULLEY = create("hose_pulley", b -> b.icon(AllBlocks.HOSE_PULLEY)
		.title("Industrial Spillage")
		.description("Lower a Hose Pulley and watch it drain or fill a body of fluid")
		.after(WATER_SUPPLY)),

	CHOCOLATE_BUCKET = create("chocolate_bucket", b -> b.icon(AllFluids.CHOCOLATE.get()
			.method_15774())
		.title("A World of Imagination")
		.description("Obtain a bucket of molten chocolate")
		.whenIconCollected()
		.after(HOSE_PULLEY)),

	HONEY_DRAIN = create("honey_drain", b -> b.icon(class_1802.field_20416)
		.title("Autonomous Bee-Keeping")
		.description("Use pipes to pull honey from a Bee Nest or Beehive")
		.after(CHOCOLATE_BUCKET)),

	// Copper - Expert Branch

	HOSE_PULLEY_LAVA = create("hose_pulley_lava", b -> b.icon(AllBlocks.HOSE_PULLEY)
		.title("Tapping the Mantle")
		.description("Pump from a body of lava large enough to be considered infinite")
		.after(COPPER)
		.special(EXPERT)),

	STEAM_ENGINE_MAXED = create("steam_engine_maxed", b -> b.icon(AllBlocks.STEAM_ENGINE)
		.title("Full Steam")
		.description("Run a boiler at the maximum level of power")
		.after(HOSE_PULLEY_LAVA)
		.special(EXPERT)),

	FOODS = create("foods", b -> b.icon(AllItems.CHOCOLATE_BERRIES)
		.title("Balanced Diet")
		.description("Create Chocolate Glazed Berries, a Honeyed Apple, and a Sweet Roll all from the same Spout")
		.after(STEAM_ENGINE_MAXED)
		.special(EXPERT)),

	DIVING_SUIT_LAVA = create("diving_suit_lava", b -> b.icon(AllItems.NETHERITE_DIVING_HELMET)
		.title("Swimming with the Striders")
		.description("Attempt to take a dive in lava with your netherite diving gear")
		.after(FOODS)
		.special(EXPERT)),

	// Copper - Hidden

	CHAINED_DRAIN = create("chained_drain", b -> b.icon(AllBlocks.ITEM_DRAIN)
		.title("On a Roll")
		.description("Watch an item move across a row of Item Drains")
		.after(BACKTANK)
		.special(SECRET)),

	CROSS_STREAMS = create("cross_streams", b -> b.icon(class_2246.field_10445)
		.title("Don't Cross the Streams!")
		.description("Watch two fluids meet in your pipe network")
		.after(BACKTANK)
		.special(SECRET)),

	PIPE_ORGAN = create("pipe_organ", b -> b.icon(AllBlocks.STEAM_WHISTLE)
		.title("The Pipe Organ")
		.description("Attach 12 uniquely pitched Steam Whistles to a single Fluid Tank")
		.after(BACKTANK)
		.special(SECRET)),

	// Brass - Central Branch

	BRASS = create("brass", b -> b.icon(AllItems.BRASS_INGOT)
		.title("Real Alloys")
		.description("Create Brass Ingots by alloying Copper and Zinc Ingots in your Blaze-heated Mechanical Mixer")
		.whenIconCollected()
		.after(DIVING_SUIT)),

	BRASS_CASING = create("brass_casing", b -> b.icon(AllBlocks.BRASS_CASING)
		.title("The Brass Age")
		.description("Apply Brass Ingots to stripped wood, creating a casing for more sophisticated machines")
		.after(BRASS)
		.special(NOISY)),

	ROSE_QUARTZ = create("rose_quartz", b -> b.icon(AllItems.POLISHED_ROSE_QUARTZ)
		.title("Supercharged")
		.description("Polish some Rose Quartz")
		.whenIconCollected()
		.after(BRASS_CASING)),

	DEPLOYER = create("deployer", b -> b.icon(AllBlocks.DEPLOYER)
		.title("Artificial Intelligence")
		.description("Place and power a Deployer, the perfect reflection of yourself")
		.after(ROSE_QUARTZ)),

	MECHANISM = create("precision_mechanism", b -> b.icon(AllItems.PRECISION_MECHANISM)
		.title("Complex Curiosities")
		.description("Assemble a Precision Mechanism")
		.whenIconCollected()
		.after(DEPLOYER)
		.special(NOISY)),

	SPEED_CONTROLLER = create("speed_controller", b -> b.icon(AllBlocks.ROTATION_SPEED_CONTROLLER)
		.title("Engineers hate this simple trick!")
		.description("Fine-tune your Contraption with a Rotation Speed Controller")
		.after(MECHANISM)),

	MECHANICAL_ARM = create("mechanical_arm", b -> b.icon(AllBlocks.MECHANICAL_ARM)
		.title("Busy Hands")
		.description("Watch your Mechanical Arm transport its first item")
		.after(SPEED_CONTROLLER)
		.special(NOISY)),

	CRAFTER = create("mechanical_crafter", b -> b.icon(AllBlocks.MECHANICAL_CRAFTER)
		.title("Automated Assembly")
		.description("Place and power some Mechanical Crafters")
		.after(MECHANICAL_ARM)),

	CRUSHING_WHEEL = create("crushing_wheel", b -> b.icon(AllBlocks.CRUSHING_WHEEL)
		.title("Wheels of Destruction")
		.description("Place and power a set of Crushing Wheels")
		.after(CRAFTER)
		.special(NOISY)),

	// Brass - Top Branch

	HAUNTED_BELL = create("haunted_bell", b -> b.icon(AllBlocks.HAUNTED_BELL)
		.title("Shadow Sense")
		.description("Toll a Haunted Bell")
		.after(BRASS)
		.special(NOISY)),

	CLOCKWORK_BEARING = create("clockwork_bearing", b -> b.icon(AllBlocks.CLOCKWORK_BEARING)
		.title("Contraption o'Clock")
		.description("Assemble a structure mounted on a Clockwork Bearing")
		.after(HAUNTED_BELL)
		.special(NOISY)),

	DISPLAY_LINK = create("display_link", b -> b.icon(AllBlocks.DISPLAY_LINK)
		.title("Big Data")
		.description("Use a Display Link to visualise information")
		.after(CLOCKWORK_BEARING)),

	POTATO_CANNON = create("potato_cannon", b -> b.icon(AllItems.POTATO_CANNON)
		.title("Fwoomp!")
		.description("Defeat an enemy with your Potato Cannon")
		.after(DISPLAY_LINK)
		.special(NOISY)),

	EXTENDO_GRIP = create("extendo_grip", b -> b.icon(AllItems.EXTENDO_GRIP)
		.title("Boioioing!")
		.description("Get hold of an Extendo Grip")
		.after(POTATO_CANNON)),

	LINKED_CONTROLLER = create("linked_controller", b -> b.icon(AllItems.LINKED_CONTROLLER)
		.title("Remote Activation")
		.description("Activate a Redstone Link using a Linked Controller")
		.after(EXTENDO_GRIP)),

	ARM_BLAZE_BURNER = create("arm_blaze_burner", b -> b.icon(AllBlocks.BLAZE_BURNER)
		.title("Combust-o-Tron")
		.description("Instruct a Mechanical Arm to feed your Blaze Burner")
		.after(LINKED_CONTROLLER)),

	// Brass - Expert Branch

	CRUSHER_MAXED = create("crusher_maxed_0000", b -> b.icon(AllBlocks.CRUSHING_WHEEL)
		.title("Crushing It")
		.description("Operate a pair of Crushing Wheels at maximum speed")
		.after(BRASS)
		.special(EXPERT)),

	ARM_MANY_TARGETS = create("arm_many_targets", b -> b.icon(AllBlocks.MECHANICAL_ARM)
		.title("Organize-o-Tron")
		.description("Program a Mechanical Arm with 10 or more output locations")
		.after(CRUSHER_MAXED)
		.special(EXPERT)),

	POTATO_CANNON_COLLIDE = create("potato_cannon_collide", b -> b.icon(class_1802.field_8179)
		.title("Veggie Fireworks")
		.description("Cause Potato Cannon projectiles of different types to collide with each other")
		.after(ARM_MANY_TARGETS)
		.special(EXPERT)),

	SELF_DEPLOYING = create("self_deploying", b -> b.icon(class_1802.field_8129)
		.title("Self-Driving Cart")
		.description("Create a Minecart Contraption that places tracks in front of itself")
		.after(POTATO_CANNON_COLLIDE)
		.special(EXPERT)),

	// Brass - Hidden

	FIST_BUMP = create("fist_bump", b -> b.icon(AllBlocks.DEPLOYER)
		.title("Pound It, Bro!")
		.description("Make two Deployers fist-bump")
		.after(CRAFTER)
		.special(SECRET)),

	CRAFTER_LAZY = create("crafter_lazy_000", b -> b.icon(AllBlocks.MECHANICAL_CRAFTER)
		.title("Desperate Measures")
		.description("Drastically slow down a Mechanical Crafter to procrastinate on proper infrastructure")
		.after(CRAFTER)
		.special(SECRET)),

	EXTENDO_GRIP_DUAL = create("extendo_grip_dual", b -> b.icon(AllItems.EXTENDO_GRIP)
		.title("To Full Extent")
		.description("Dual-wield Extendo Grips for superhuman reach")
		.after(CRAFTER)
		.special(SECRET)),

	MUSICAL_ARM = create("musical_arm", b -> b.icon(class_2246.field_10223)
		.title("DJ Mechanico")
		.description("Watch a Mechanical Arm operate your Jukebox")
		.after(CRAFTER)
		.special(SECRET)),

	// Trains - Central Branch

	STURDY_SHEET = create("sturdy_sheet", b -> b.icon(AllItems.STURDY_SHEET)
		.title("The Sturdiest Rocks")
		.description("Assemble a Sturdy Sheet by refining Powdered Obsidian")
		.whenIconCollected()
		.after(CRUSHING_WHEEL)),

	TRAIN_CASING = create("train_casing_00", b -> b.icon(AllBlocks.RAILWAY_CASING)
		.title("The Locomotive Age")
		.description("Use Sturdy Sheets to create a casing for railway components")
		.after(STURDY_SHEET)),

	TRAIN = create("train", b -> b.icon(AllBlocks.TRACK_STATION)
		.title("All Aboard!")
		.description("Assemble your first Train")
		.after(TRAIN_CASING)
		.special(NOISY)),

	CONDUCTOR = create("conductor", b -> b.icon(AllItems.SCHEDULE)
		.title("Conductor Instructor")
		.description("Instruct a Train driver with a Train Schedule")
		.after(TRAIN)),

	SIGNAL = create("track_signal", b -> b.icon(AllBlocks.TRACK_SIGNAL)
		.title("Traffic Control")
		.description("Place a Train Signal")
		.after(CONDUCTOR)),

	DISPLAY_BOARD = create("display_board_0", b -> b.icon(AllBlocks.DISPLAY_BOARD)
		.title("Dynamic Timetables")
		.description("Forecast a Train's arrival on your Display Board with the help of Display Links")
		.after(SIGNAL)
		.special(NOISY)),

	// Trains - Top Branch

	TRAIN_TRACK = create("track_0", b -> b.icon(AllBlocks.TRACK)
		.title("A New Gauge")
		.description("Obtain some Train Tracks")
		.whenItemCollected(AllItemTags.TRACKS.tag)
		.after(STURDY_SHEET)),

	TRAIN_WHISTLE = create("train_whistle", b -> b.icon(AllBlocks.STEAM_WHISTLE)
		.title("Choo Choo!")
		.description("Assemble a Steam Whistle to your Train and activate it while driving")
		.after(TRAIN_TRACK)),

	TRAIN_PORTAL = create("train_portal", b -> b.icon(class_2246.field_27159)
		.title("Dimensional Commuter")
		.description("Ride a Train through a portal")
		.after(TRAIN_WHISTLE)
		.special(NOISY)),

	// Trains - Expert Branch

	TRACK_CRAFTING = create("track_crafting_factory", b -> b.icon(AllBlocks.MECHANICAL_PRESS)
		.title("Track Factory")
		.description("Produce more than 1000 Train Tracks with the same Mechanical Press")
		.after(STURDY_SHEET)
		.special(EXPERT)),

	LONG_TRAIN = create("long_train", b -> b.icon(class_1802.field_8045)
		.title("Ambitious Endeavours")
		.description("Create a Train with at least 6 carriages")
		.after(TRACK_CRAFTING)
		.special(EXPERT)),

	LONG_TRAVEL = create("long_travel", b -> b.icon(AllBlocks.SEATS.get(class_1767.field_7942))
		.title("Field Trip")
		.description("Leave a Train Seat over 5000 blocks away from where you started travelling")
		.after(LONG_TRAIN)
		.special(EXPERT)),

	// Trains - Hidden

	TRAIN_ROADKILL = create("train_roadkill", b -> b.icon(class_1802.field_8802)
		.title("Road Kill")
		.description("Run over an enemy with your Train")
		.after(SIGNAL)
		.special(SECRET)),

	RED_SIGNAL = create("red_signal", b -> b.icon(AllBlocks.TRACK_SIGNAL)
		.title("Expert Driver")
		.description("Run a red Train Signal")
		.after(SIGNAL)
		.special(SECRET)),

	TRAIN_CRASH = create("train_crash", b -> b.icon(AllItems.INCOMPLETE_TRACK)
		.title("Terrible Service")
		.description("Witness a Train crash as a passenger")
		.after(SIGNAL)
		.special(SECRET)),

	TRAIN_CRASH_BACKWARDS = create("train_crash_backwards", b -> b.icon(AllItems.INCOMPLETE_TRACK)
		.title("Blind Spot")
		.description("Crash into another Train while driving backwards")
		.after(SIGNAL)
		.special(SECRET)),

	//
	END = null;

	private static class_1799 createArmorTrimmedCardboardChestplate() {
		class_1799 asStack = AllItems.CARDBOARD_CHESTPLATE.asStack();
		class_2487 tag = new class_2487();
		class_2487 trimTag = new class_2487();
		trimTag.method_10582("material", "minecraft:diamond");
		trimTag.method_10582("pattern", "minecraft:sentry");
		tag.method_10566("Trim", trimTag);
		asStack.method_7980(tag);
		return asStack;
	}

	private static CreateAdvancement create(String id, UnaryOperator<Builder> b) {
		return new CreateAdvancement(id, b);
	}

	// Datagen

	private final class_7784 output;

	public AllAdvancements(FabricDataOutput output) {
		this.output = output;
	}

	@Override
	public CompletableFuture<?> method_10319(class_7403 cache) {
		class_7489 pathProvider = output.method_45973(class_7784.class_7490.field_39367, "advancements");
		List<CompletableFuture<?>> futures = new ArrayList<>();

		Set<class_2960> set = Sets.newHashSet();
		Consumer<class_161> consumer = (advancement) -> {
			class_2960 id = advancement.method_688();
			if (!set.add(id))
				throw new IllegalStateException("Duplicate advancement " + id);
			Path path = pathProvider.method_44107(id);
			futures.add(class_2405.method_10320(cache, advancement.method_689()
				.method_698(), path));
		};

		for (CreateAdvancement advancement : ENTRIES)
			advancement.save(consumer);

		return CompletableFuture.allOf(futures.toArray(CompletableFuture[]::new));
	}

	@Override
	public String method_10321() {
		return "Create's Advancements";
	}

	public static void provideLang(BiConsumer<String, String> consumer) {
		for (CreateAdvancement advancement : ENTRIES)
			advancement.provideLang(consumer);
	}

	public static void register() {
	}

}
