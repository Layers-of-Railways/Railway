package com.simibubi.create.foundation.mixin.fabric;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import com.simibubi.create.content.contraptions.minecart.capability.CapabilityMinecartController;
import com.simibubi.create.content.contraptions.minecart.capability.MinecartController;
import com.simibubi.create.foundation.utility.fabric.AbstractMinecartExtensions;
import net.minecraft.class_1299;
import net.minecraft.class_1688;
import net.minecraft.class_1937;
import net.minecraft.class_2487;
import net.minecraft.class_2520;

@Mixin(class_1688.class)
public abstract class AbstractMinecartMixin implements AbstractMinecartExtensions {
	@Unique
	private MinecartController controller;

	@Inject(method = "<init>(Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/level/Level;)V", at = @At("RETURN"))
	private void initController(class_1299<?> entityType, class_1937 level, CallbackInfo ci) {
		this.controller = new MinecartController((class_1688) (Object) this);
		if (level != null) { // don't trust modders
			CapabilityMinecartController.attach((class_1688) (Object) this);
		}
	}

	@Inject(method = "readAdditionalSaveData", at = @At("HEAD"))
	private void loadController(class_2487 compound, CallbackInfo ci) {
		if (compound.method_10573(CAP_KEY, class_2520.field_33260))
			controller.deserializeNBT(compound.method_10562(CAP_KEY));
	}

	@Inject(method = "addAdditionalSaveData", at = @At("HEAD"))
	private void saveController(class_2487 compound, CallbackInfo ci) {
		compound.method_10566(CAP_KEY, controller.serializeNBT());
	}

	@Override
	public MinecartController create$getController() {
		return controller;
	}
}
