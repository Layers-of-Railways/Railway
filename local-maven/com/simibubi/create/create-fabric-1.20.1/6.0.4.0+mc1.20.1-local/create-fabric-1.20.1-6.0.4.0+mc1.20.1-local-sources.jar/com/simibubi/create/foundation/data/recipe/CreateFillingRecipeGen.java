package com.simibubi.create.foundation.data.recipe;

import com.simibubi.create.AllFluids;
import com.simibubi.create.AllItems;
import com.simibubi.create.AllTags;
import com.simibubi.create.AllTags.AllFluidTags;
import com.simibubi.create.Create;
import com.simibubi.create.api.data.recipe.BaseRecipeProvider.GeneratedRecipe;
import com.simibubi.create.api.data.recipe.FillingRecipeGen;
import com.simibubi.create.content.fluids.potion.PotionFluidHandler;
import io.github.fabricators_of_create.porting_lib.tags.Tags;
import net.minecraft.class_1802;
import net.minecraft.class_1847;
import net.minecraft.class_3612;
import net.minecraft.class_7784;

/**
 * Create's own Data Generation for Filling recipes
 * @see FillingRecipeGen
 */
@SuppressWarnings("unused")
public final class CreateFillingRecipeGen extends FillingRecipeGen {

	GeneratedRecipe

	HONEY_BOTTLE = create("honey_bottle", b -> b.require(AllFluidTags.HONEY.tag, 250)
		.require(class_1802.field_8469)
		.output(class_1802.field_20417)),

	BUILDERS_TEA = create("builders_tea", b -> b.require(AllFluids.TEA.get(), 250)
		.require(class_1802.field_8469)
		.output(AllItems.BUILDERS_TEA.get())),

	FD_MILK = create(Mods.FD.recipeId("milk_bottle"), b -> b.require(Tags.Fluids.MILK, 250)
		.require(class_1802.field_8469)
		.output(1, Mods.FD, "milk_bottle", 1)
		.whenModLoaded(Mods.FD.getId())),

	BLAZE_CAKE = create("blaze_cake", b -> b.require(class_3612.field_15908, 250)
		.require(AllItems.BLAZE_CAKE_BASE.get())
		.output(AllItems.BLAZE_CAKE.get())),

	HONEYED_APPLE = create("honeyed_apple", b -> b.require(AllFluidTags.HONEY.tag, 250)
		.require(class_1802.field_8279)
		.output(AllItems.HONEYED_APPLE.get())),

	SWEET_ROLL = create("sweet_roll", b -> b.require(Tags.Fluids.MILK, 250)
		.require(class_1802.field_8229)
		.output(AllItems.SWEET_ROLL.get())),

	CHOCOLATE_BERRIES = create("chocolate_glazed_berries", b -> b.require(AllFluids.CHOCOLATE.get(), 250)
		.require(class_1802.field_16998)
		.output(AllItems.CHOCOLATE_BERRIES.get())),

	GRASS_BLOCK = create("grass_block", b -> b.require(class_3612.field_15910, 500)
		.require(class_1802.field_8831)
		.output(class_1802.field_8270)),

	GUNPOWDER = create("gunpowder", b -> b.require(PotionFluidHandler.potionIngredient(class_1847.field_9004, 25))
		.require(AllItems.CINDER_FLOUR.get())
		.output(class_1802.field_8054)),

	REDSTONE = create("redstone", b -> b.require(PotionFluidHandler.potionIngredient(class_1847.field_8978, 25))
		.require(AllItems.CINDER_FLOUR.get())
		.output(class_1802.field_8725)),

	GLOWSTONE = create("glowstone", b -> b.require(PotionFluidHandler.potionIngredient(class_1847.field_8968, 25))
		.require(AllItems.CINDER_FLOUR.get())
		.output(class_1802.field_8601)),


	AM_LAVA = create(Mods.AM.recipeId("lava_bottle"), b -> b.require(class_3612.field_15908, 250)
		.require(class_1802.field_8469)
		.output(1, Mods.AM, "lava_bottle", 1)
		.whenModLoaded(Mods.AM.getId())),

	BYG_LUSH_GRASS = create(Mods.BYG.recipeId("lush_grass_block"), b -> b.require(Mods.BYG, "lush_dirt")
		.require(class_3612.field_15910, 500)
		.output(Mods.BYG, "lush_grass_block")
		.whenModLoaded(Mods.BYG.getId())),

	NEA_MILK = create(Mods.NEA.recipeId("milk_bottle"), b -> b.require(Tags.Fluids.MILK, 250)
		.require(class_1802.field_8469)
		.output(1, Mods.NEA, "milk_bottle", 1)
		.whenModLoaded(Mods.NEA.getId())),

	AET_GRASS = moddedGrass(Mods.AET, "aether"),

	RU_PEAT_GRAS = moddedGrass(Mods.RU, "peat"),

	RU_SILT_GRAS = moddedGrass(Mods.RU, "silt"),

	// Vampirism

	VMP_CURSED_GRASS = create(Mods.VMP.recipeId("cursed_grass"), b -> b.require(class_3612.field_15910, 500)
		.require(Mods.VMP, "cursed_earth")
		.output(Mods.VMP, "cursed_grass")
		.whenModLoaded(Mods.VMP.getId())),

	// IE

	IE_TREATED_WOOD = create(Mods.IE.recipeId("treated_wood_in_spout"),
		b -> b.require(AllTags.forgeFluidTag("creosote"), 125)
			.require(CreateRecipeProvider.I.planks())
			.output(Mods.IE, "treated_wood_horizontal")
			.whenModLoaded(Mods.IE.getId()));


	public CreateFillingRecipeGen(class_7784 output) {
		super(output, Create.ID);
	}

	public GeneratedRecipe moddedGrass(Mods mod, String name) {
		String grass = name + "_grass_block";
		return create(mod.recipeId(grass), b -> b.require(class_3612.field_15910, 500)
				.require(mod, name + "_dirt")
				.output(mod, grass)
				.whenModLoaded(mod.getId()));
	}
}
