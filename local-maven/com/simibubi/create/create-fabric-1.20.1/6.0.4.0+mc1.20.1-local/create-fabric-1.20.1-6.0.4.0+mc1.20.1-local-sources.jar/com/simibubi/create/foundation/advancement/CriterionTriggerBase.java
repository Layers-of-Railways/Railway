package com.simibubi.create.foundation.advancement;

import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Supplier;

import javax.annotation.Nullable;
import javax.annotation.ParametersAreNonnullByDefault;
import net.minecraft.class_179;
import net.minecraft.class_195;
import net.minecraft.class_2960;
import net.minecraft.class_2985;
import net.minecraft.class_3222;
import net.minecraft.class_5258;
import net.minecraft.class_6328;
import com.google.common.collect.Maps;
import com.simibubi.create.Create;

@ParametersAreNonnullByDefault
@class_6328
public abstract class CriterionTriggerBase<T extends CriterionTriggerBase.Instance> implements class_179<T> {

	public CriterionTriggerBase(String id) {
		this.id = Create.asResource(id);
	}

	private final class_2960 id;
	protected final Map<class_2985, Set<class_180<T>>> listeners = Maps.newHashMap();

	@Override
	public void method_792(class_2985 playerAdvancementsIn, class_180<T> listener) {
		Set<class_180<T>> playerListeners = this.listeners.computeIfAbsent(playerAdvancementsIn, k -> new HashSet<>());

		playerListeners.add(listener);
	}

	@Override
	public void method_793(class_2985 playerAdvancementsIn, class_180<T> listener) {
		Set<class_180<T>> playerListeners = this.listeners.get(playerAdvancementsIn);
		if (playerListeners != null) {
			playerListeners.remove(listener);
			if (playerListeners.isEmpty()) {
				this.listeners.remove(playerAdvancementsIn);
			}
		}
	}

	@Override
	public void method_791(class_2985 playerAdvancementsIn) {
		this.listeners.remove(playerAdvancementsIn);
	}

	@Override
	public class_2960 method_794() {
		return id;
	}

	protected void trigger(class_3222 player, @Nullable List<Supplier<Object>> suppliers) {
		class_2985 playerAdvancements = player.method_14236();
		Set<class_180<T>> playerListeners = this.listeners.get(playerAdvancements);
		if (playerListeners != null) {
			List<class_180<T>> list = new LinkedList<>();

			for (class_180<T> listener : playerListeners) {
				if (listener.method_797()
					.test(suppliers)) {
					list.add(listener);
				}
			}

			list.forEach(listener -> listener.method_796(playerAdvancements));

		}
	}

	public abstract static class Instance extends class_195 {

		public Instance(class_2960 idIn, class_5258 predicate) {
			super(idIn, predicate);
		}

		protected abstract boolean test(@Nullable List<Supplier<Object>> suppliers);
	}

}
