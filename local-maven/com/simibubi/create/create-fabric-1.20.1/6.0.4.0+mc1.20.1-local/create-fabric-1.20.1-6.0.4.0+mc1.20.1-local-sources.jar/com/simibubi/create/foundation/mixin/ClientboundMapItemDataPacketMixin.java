package com.simibubi.create.foundation.mixin;

import java.util.Collection;
import java.util.List;

import javax.annotation.Nullable;
import net.minecraft.class_20;
import net.minecraft.class_22;
import net.minecraft.class_2540;
import net.minecraft.class_2683;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import com.simibubi.create.content.trains.station.StationMarker;

import it.unimi.dsi.fastutil.ints.IntArrayList;
import it.unimi.dsi.fastutil.ints.IntList;

// random priority to prevent networking conflicts
@Mixin(value = class_2683.class, priority = 426)
public class ClientboundMapItemDataPacketMixin {
	@Shadow
	@Final
	private List<class_20> decorations;

	@Unique
	private int[] create$stationIndices;

	@Inject(method = "<init>(IBZLjava/util/Collection;Lnet/minecraft/world/level/saveddata/maps/MapItemSavedData$MapPatch;)V", at = @At("RETURN"))
	private void create$onInit(int mapId, byte scale, boolean locked, @Nullable Collection<class_20> decorations, @Nullable class_22.class_5637 colorPatch, CallbackInfo ci) {
		create$stationIndices = create$getStationIndices(this.decorations);
	}

	@Unique
	private static int[] create$getStationIndices(List<class_20> decorations) {
		if (decorations == null) {
			return new int[0];
		}

		IntList indices = new IntArrayList();
		for (int i = 0; i < decorations.size(); i++) {
			class_20 decoration = decorations.get(i);
			if (decoration instanceof StationMarker.Decoration) {
				indices.add(i);
			}
		}
		return indices.toIntArray();
	}

	@Inject(method = "<init>(Lnet/minecraft/network/FriendlyByteBuf;)V", at = @At("RETURN"))
	private void create$onInit(class_2540 buf, CallbackInfo ci) {
		create$stationIndices = buf.method_10787();

		if (decorations != null) {
			for (int i : create$stationIndices) {
				if (i >= 0 && i < decorations.size()) {
					class_20 decoration = decorations.get(i);
					decorations.set(i, StationMarker.Decoration.from(decoration));
				}
			}
		}
	}

	@Inject(method = "write(Lnet/minecraft/network/FriendlyByteBuf;)V", at = @At("RETURN"))
	private void create$onWrite(class_2540 buf, CallbackInfo ci) {
		buf.method_10806(create$stationIndices);
	}
}
