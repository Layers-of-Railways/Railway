package com.simibubi.create.foundation.blockEntity.behaviour.simple;

import java.util.function.Supplier;
import net.minecraft.class_2487;
import com.simibubi.create.foundation.blockEntity.SmartBlockEntity;
import com.simibubi.create.foundation.blockEntity.behaviour.BehaviourType;
import com.simibubi.create.foundation.blockEntity.behaviour.BlockEntityBehaviour;

public class DeferralBehaviour extends BlockEntityBehaviour {

	public static final BehaviourType<DeferralBehaviour> TYPE = new BehaviourType<>();

	private boolean needsUpdate;
	private Supplier<Boolean> callback;

	public DeferralBehaviour(SmartBlockEntity be, Supplier<Boolean> callback) {
		super(be);
		this.callback = callback;
	}

	@Override
	public boolean isSafeNBT() { return true; }

	@Override
	public void write(class_2487 nbt, boolean clientPacket) {
		nbt.method_10556("NeedsUpdate", needsUpdate);
		super.write(nbt, clientPacket);
	}

	@Override
	public void read(class_2487 nbt, boolean clientPacket) {
		needsUpdate = nbt.method_10577("NeedsUpdate");
		super.read(nbt, clientPacket);
	}

	@Override
	public void tick() {
		super.tick();
		if (needsUpdate && callback.get())
			needsUpdate = false;
	}

	public void scheduleUpdate() {
		needsUpdate = true;
	}

	@Override
	public BehaviourType<?> getType() {
		return TYPE;
	}

}
