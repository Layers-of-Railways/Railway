package com.simibubi.create.api.data.recipe;

import java.util.function.Supplier;
import java.util.function.UnaryOperator;

import com.simibubi.create.AllItems;
import com.simibubi.create.AllRecipeTypes;
import com.simibubi.create.AllTags;
import com.simibubi.create.api.data.recipe.BaseRecipeProvider.GeneratedRecipe;
import com.simibubi.create.content.decoration.palettes.AllPaletteStoneTypes;
import com.simibubi.create.content.processing.recipe.ProcessingRecipe;
import com.simibubi.create.content.processing.recipe.ProcessingRecipeBuilder;
import com.simibubi.create.foundation.data.recipe.CompatMetals;

import net.createmod.catnip.lang.Lang;
import net.fabricmc.fabric.api.resource.conditions.v1.DefaultResourceConditions;
import net.minecraft.class_1792;
import net.minecraft.class_1935;
import net.minecraft.class_2246;
import net.minecraft.class_3532;
import net.minecraft.class_6862;
import net.minecraft.class_7784;

/**
 * The base class for Crushing recipe generation.
 * Addons should extend this and use the {@link ProcessingRecipeGen#create} methods
 * or the helper methods contained in this class to make recipes.
 * For an example of how you might do this, see Create's implementation: {@link com.simibubi.create.foundation.data.recipe.CreateCrushingRecipeGen}.
 * Needs to be added to a registered recipe provider to do anything, see {@link com.simibubi.create.foundation.data.recipe.CreateRecipeProvider}
 */
public abstract class CrushingRecipeGen extends ProcessingRecipeGen {

	protected GeneratedRecipe mineralRecycling(AllPaletteStoneTypes type, Supplier<class_1935> crushed,
																		  Supplier<class_1935> nugget, float chance) {
		return mineralRecycling(type, b -> b.duration(250)
			.output(chance, crushed.get(), 1)
			.output(chance, nugget.get(), 1));
	}

	protected GeneratedRecipe mineralRecycling(AllPaletteStoneTypes type,
																		  UnaryOperator<ProcessingRecipeBuilder<ProcessingRecipe<?>>> transform) {
		create(Lang.asId(type.name()) + "_recycling", b -> transform.apply(b.require(type.materialTag)));
		return create(type.getBaseBlock()::get, transform);
	}

	protected GeneratedRecipe stoneOre(Supplier<class_1935> ore, Supplier<class_1935> raw, float expectedAmount,
																  int duration) {
		return ore(class_2246.field_10445, ore, raw, expectedAmount, duration);
	}

	protected GeneratedRecipe deepslateOre(Supplier<class_1935> ore, Supplier<class_1935> raw, float expectedAmount,
																	  int duration) {
		return ore(class_2246.field_29031, ore, raw, expectedAmount, duration);
	}

	protected GeneratedRecipe netherOre(Supplier<class_1935> ore, Supplier<class_1935> raw, float expectedAmount,
										int duration) {
		return ore(class_2246.field_10515, ore, raw, expectedAmount, duration);
	}

	protected GeneratedRecipe ore(class_1935 stoneType, Supplier<class_1935> ore, Supplier<class_1935> raw,
								  float expectedAmount, int duration) {
		return create(ore, b -> {
			b.duration(duration)
				.output(raw.get(), class_3532.method_15375(expectedAmount));
			float extra = expectedAmount - class_3532.method_15375(expectedAmount);
			if (extra > 0)
				b.output(extra, raw.get(), 1);
			b.output(.75f, AllItems.EXP_NUGGET.get(), raw.get() == AllItems.CRUSHED_GOLD.get() ? 2 : 1);
			return b.output(.125f, stoneType);
		});
	}

	protected GeneratedRecipe moddedOre(CompatMetals metal, Supplier<class_1935> result) {
		String name = metal.getName();
		return create(name + "_ore", b -> {
			String suffix = "_ores";
			return b.duration(400)
				.withCondition(DefaultResourceConditions.tagsPopulated(AllTags.forgeItemTag(name + suffix)))
				.require(AllTags.forgeItemTag(name + suffix))
				.output(result.get(), 1)
				.output(.75f, result.get(), 1)
				.output(.75f, AllItems.EXP_NUGGET.get());
		});
	}

	protected GeneratedRecipe rawOre(String metalName, Supplier<class_6862<class_1792>> input, Supplier<class_1935> result, int xpMult) {
		return rawOre(metalName, input, result, false, xpMult);
	}

	protected GeneratedRecipe rawOreBlock(String metalName, Supplier<class_6862<class_1792>> input, Supplier<class_1935> result, int xpMult) {
		return rawOre(metalName, input, result, true, xpMult);
	}

	protected GeneratedRecipe rawOre(String metalName, Supplier<class_6862<class_1792>> input, Supplier<class_1935> result, boolean block, int xpMult) {
		return create("raw_" + metalName + (block ? "_block" : ""), b -> {
			int amount = block ? 9 : 1;
			return b.duration(400)
				.require(input.get())
				.output(result.get(), amount)
				.output(.75f, AllItems.EXP_NUGGET.get(), amount * xpMult);
		});
	}

	protected GeneratedRecipe moddedRawOre(CompatMetals metal, Supplier<class_1935> result) {
		return moddedRawOre(metal, result, false);
	}

	protected GeneratedRecipe moddedRawOreBlock(CompatMetals metal, Supplier<class_1935> result) {
		return moddedRawOre(metal, result, true);
	}

	protected GeneratedRecipe moddedRawOre(CompatMetals metal, Supplier<class_1935> result, boolean block) {
		String name = metal.getName();
		return create("raw_" + name + (block ? "_block" : ""), b -> {
			int amount = block ? 9 : 1;
			String tagPath = block ? "raw_" + name + "_blocks" : "raw_" + name;
			return b.duration(400)
				.withCondition(DefaultResourceConditions.tagsPopulated(AllTags.forgeItemTag(tagPath)))
				.require(AllTags.forgeItemTag(tagPath))
				.output(result.get(), amount)
				.output(.75f, AllItems.EXP_NUGGET.get(), amount);
		});
	}

	public CrushingRecipeGen(class_7784 generator, String defaultNamespace) {
		super(generator, defaultNamespace);
	}

	@Override
	protected AllRecipeTypes getRecipeType() {
		return AllRecipeTypes.CRUSHING;
	}

}
