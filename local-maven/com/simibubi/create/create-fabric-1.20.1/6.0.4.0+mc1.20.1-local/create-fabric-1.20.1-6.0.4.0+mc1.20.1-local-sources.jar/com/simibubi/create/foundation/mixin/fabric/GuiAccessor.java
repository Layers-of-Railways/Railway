package com.simibubi.create.foundation.mixin.fabric;

import net.minecraft.class_329;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_329.class)
public interface GuiAccessor {
	@Accessor
	int getToolHighlightTimer();
}
