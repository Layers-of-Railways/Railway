package com.simibubi.create.foundation.utility;

import java.util.Vector;
import com.simibubi.create.AllKeys;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_315;
import net.minecraft.class_3675;

public class ControlsUtil {

	private static Vector<class_304> standardControls;

	public static Vector<class_304> getControls() {
		if (standardControls == null) {
			class_315 gameSettings = class_310.method_1551().field_1690;
			standardControls = new Vector<>(6);
			standardControls.add(gameSettings.field_1894);
			standardControls.add(gameSettings.field_1881);
			standardControls.add(gameSettings.field_1913);
			standardControls.add(gameSettings.field_1849);
			standardControls.add(gameSettings.field_1903);
			standardControls.add(gameSettings.field_1832);
		}
		return standardControls;
	}

	public static boolean isActuallyPressed(class_304 kb) {
		class_3675.class_306 key = KeyBindingHelper.getBoundKeyOf(kb);
		if (key.method_1442() == class_3675.class_307.field_1672) {
			return AllKeys.isMouseButtonDown(key.method_1444());
		} else {
			return AllKeys.isKeyDown(key.method_1444());
		}
	}

}
