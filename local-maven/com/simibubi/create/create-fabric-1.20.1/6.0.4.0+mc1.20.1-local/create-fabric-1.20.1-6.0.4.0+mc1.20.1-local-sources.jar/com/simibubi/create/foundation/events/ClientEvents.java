package com.simibubi.create.foundation.events;

import java.util.List;
import com.mojang.blaze3d.systems.RenderSystem;
import com.simibubi.create.AllFluids;
import com.simibubi.create.AllKeys;
import com.simibubi.create.AllPackets;
import com.simibubi.create.AllParticleTypes;
import com.simibubi.create.Create;
import com.simibubi.create.CreateClient;
import com.simibubi.create.compat.trainmap.TrainMapEvents;
import com.simibubi.create.content.contraptions.ContraptionHandler;
import com.simibubi.create.content.contraptions.ContraptionHandlerClient;
import com.simibubi.create.content.contraptions.actors.seat.ContraptionPlayerPassengerRotation;
import com.simibubi.create.content.contraptions.actors.trainControls.ControlsHandler;
import com.simibubi.create.content.contraptions.chassis.ChassisRangeDisplay;
import com.simibubi.create.content.contraptions.minecart.CouplingHandlerClient;
import com.simibubi.create.content.contraptions.minecart.CouplingPhysics;
import com.simibubi.create.content.contraptions.minecart.CouplingRenderer;
import com.simibubi.create.content.contraptions.minecart.capability.CapabilityMinecartController;
import com.simibubi.create.content.contraptions.render.ContraptionRenderInfoManager;
import com.simibubi.create.content.contraptions.wrench.RadialWrenchHandler;
import com.simibubi.create.content.decoration.girder.GirderWrenchBehavior;
import com.simibubi.create.content.equipment.armor.BacktankArmorLayer;
import com.simibubi.create.content.equipment.armor.CardboardArmorHandlerClient;
import com.simibubi.create.content.equipment.armor.CardboardArmorStealthOverlay;
import com.simibubi.create.content.equipment.armor.DivingHelmetItem;
import com.simibubi.create.content.equipment.armor.NetheriteBacktankFirstPersonRenderer;
import com.simibubi.create.content.equipment.armor.NetheriteDivingHandler;
import com.simibubi.create.content.equipment.blueprint.BlueprintOverlayRenderer;
import com.simibubi.create.content.equipment.clipboard.ClipboardValueSettingsHandler;
import com.simibubi.create.content.equipment.extendoGrip.ExtendoGripRenderHandler;
import com.simibubi.create.content.equipment.hats.CreateHatArmorLayer;
import com.simibubi.create.content.equipment.potatoCannon.PotatoCannonItemRenderer;
import com.simibubi.create.content.equipment.symmetryWand.SymmetryHandler;
import com.simibubi.create.content.equipment.toolbox.ToolboxHandlerClient;
import com.simibubi.create.content.equipment.zapper.ZapperItem;
import com.simibubi.create.content.equipment.zapper.terrainzapper.WorldshaperRenderHandler;
import com.simibubi.create.content.kinetics.KineticDebugger;
import com.simibubi.create.content.kinetics.belt.item.BeltConnectorHandler;
import com.simibubi.create.content.kinetics.chainConveyor.ChainConveyorConnectionHandler;
import com.simibubi.create.content.kinetics.chainConveyor.ChainConveyorInteractionHandler;
import com.simibubi.create.content.kinetics.chainConveyor.ChainConveyorRidingHandler;
import com.simibubi.create.content.kinetics.fan.AirCurrent;
import com.simibubi.create.content.kinetics.mechanicalArm.ArmInteractionPointHandler;
import com.simibubi.create.content.kinetics.turntable.TurntableHandler;
import com.simibubi.create.content.logistics.box.PackageClientInteractionHandler;
import com.simibubi.create.content.logistics.depot.EjectorTargetHandler;
import com.simibubi.create.content.logistics.factoryBoard.FactoryPanelConnectionHandler;
import com.simibubi.create.content.logistics.packagePort.PackagePortTargetSelectionHandler;
import com.simibubi.create.content.logistics.packagerLink.LogisticallyLinkedClientHandler;
import com.simibubi.create.content.logistics.tableCloth.TableClothOverlayRenderer;
import com.simibubi.create.content.processing.sequenced.SequencedAssemblyRecipe;
import com.simibubi.create.content.redstone.displayLink.ClickToLinkBlockItem;
import com.simibubi.create.content.redstone.link.LinkRenderer;
import com.simibubi.create.content.redstone.link.controller.LinkedControllerClientHandler;
import com.simibubi.create.content.trains.CameraDistanceModifier;
import com.simibubi.create.content.trains.TrainHUD;
import com.simibubi.create.content.trains.entity.CarriageContraptionEntity;
import com.simibubi.create.content.trains.entity.CarriageCouplingRenderer;
import com.simibubi.create.content.trains.entity.TrainRelocator;
import com.simibubi.create.content.trains.schedule.hat.TrainHatInfoReloadListener;
import com.simibubi.create.content.trains.track.CurvedTrackInteraction;
import com.simibubi.create.content.trains.track.TrackBlockItem;
import com.simibubi.create.content.trains.track.TrackBlockOutline;
import com.simibubi.create.content.trains.track.TrackPlacement;
import com.simibubi.create.content.trains.track.TrackTargetingClient;
import com.simibubi.create.foundation.blockEntity.behaviour.edgeInteraction.EdgeInteractionRenderer;
import com.simibubi.create.foundation.blockEntity.behaviour.filtering.FilteringRenderer;
import com.simibubi.create.foundation.blockEntity.behaviour.scrollValue.ScrollValueHandler;
import com.simibubi.create.foundation.blockEntity.behaviour.scrollValue.ScrollValueRenderer;
import com.simibubi.create.foundation.fluid.FluidHelper;
import com.simibubi.create.foundation.item.TooltipModifier;
import com.simibubi.create.foundation.networking.LeftClickPacket;
import com.simibubi.create.foundation.sound.SoundScapes;
import com.simibubi.create.foundation.utility.CameraAngleAnimationService;
import com.simibubi.create.foundation.utility.ServerSpeedProvider;
import com.simibubi.create.foundation.utility.TickBasedCache;
import com.simibubi.create.infrastructure.config.AllConfigs;
import com.simibubi.create.infrastructure.fabric.RenderItemDecorationsCallback;
import com.simibubi.create.infrastructure.gui.OpenCreateMenuButton;

import dev.engine_room.flywheel.api.event.ReloadLevelRendererCallback;
import net.createmod.catnip.animation.AnimationTickHolder;
import net.createmod.catnip.levelWrappers.WrappedClientLevel;
import net.createmod.catnip.render.DefaultSuperRenderTypeBuffer;
import net.createmod.catnip.render.StitchedSprite;
import net.createmod.catnip.render.SuperRenderTypeBuffer;
import net.createmod.ponder.foundation.PonderTooltipHandler;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientChunkEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientEntityEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.item.v1.ItemTooltipCallback;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.rendering.v1.LivingEntityFeatureRendererRegistrationCallback;
import net.fabricmc.fabric.api.client.rendering.v1.LivingEntityFeatureRendererRegistrationCallback.RegistrationHelper;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.player.AttackBlockCallback;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.networking.v1.PacketSender;
import net.fabricmc.fabric.api.resource.ResourceManagerHelper;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3264;
import net.minecraft.class_3610;
import net.minecraft.class_3611;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_5617;
import net.minecraft.class_5636;
import net.minecraft.class_634;
import net.minecraft.class_638;
import net.minecraft.class_6854;
import net.minecraft.class_746;
import net.minecraft.class_758;
import net.minecraft.class_922;
import io.github.fabricators_of_create.porting_lib.client_events.event.client.RenderArmCallback;
import io.github.fabricators_of_create.porting_lib.entity.events.EntityMountEvents;
import io.github.fabricators_of_create.porting_lib.entity.events.PlayerTickEvents;
import io.github.fabricators_of_create.porting_lib.entity.events.player.AttackEntityEvent;
import io.github.fabricators_of_create.porting_lib.event.client.CameraSetupCallback;
import io.github.fabricators_of_create.porting_lib.event.client.CameraSetupCallback.CameraInfo;
import io.github.fabricators_of_create.porting_lib.event.client.ClientWorldEvents;
import io.github.fabricators_of_create.porting_lib.event.client.DrawSelectionEvents;
import io.github.fabricators_of_create.porting_lib.event.client.FogEvents;
import io.github.fabricators_of_create.porting_lib.event.client.FogEvents.ColorData;
import io.github.fabricators_of_create.porting_lib.event.client.InteractEvents;
import io.github.fabricators_of_create.porting_lib.event.client.ParticleManagerRegistrationCallback;
import io.github.fabricators_of_create.porting_lib.event.client.RenderHandCallback;
import io.github.fabricators_of_create.porting_lib.event.client.RenderPlayerEvents;
import io.github.fabricators_of_create.porting_lib.event.client.RenderTickStartCallback;
import io.github.fabricators_of_create.porting_lib.event.client.TextureStitchCallback;
import io.github.fabricators_of_create.porting_lib.event.common.AttackAirCallback;

public class ClientEvents {

	public static void onTickStart(class_310 client) {
		LinkedControllerClientHandler.tick();
		ControlsHandler.tick();
		AirCurrent.tickClientPlayerSounds();
		// fabric: fix #608
		// This tracks the current held item. Because of event order differences from forge, it gets changed too
		// quickly for the update packet to work properly. Move to here to fix.
		ArmInteractionPointHandler.tick();
	}

	public static void onTick(class_310 client) {
		if (!isGameActive())
			return;

		class_1937 world = class_310.method_1551().field_1687;

		SoundScapes.tick();

		CreateClient.SCHEMATIC_SENDER.tick();
		CreateClient.SCHEMATIC_AND_QUILL_HANDLER.tick();
		CreateClient.GLUE_HANDLER.tick();
		CreateClient.SCHEMATIC_HANDLER.tick();
		CreateClient.ZAPPER_RENDER_HANDLER.tick();
		CreateClient.POTATO_CANNON_RENDER_HANDLER.tick();
		CreateClient.SOUL_PULSE_EFFECT_HANDLER.tick(world);
		CreateClient.RAILWAYS.clientTick();

		ContraptionHandler.tick(world);
		CapabilityMinecartController.tick(world);
		CouplingPhysics.tick(world);

		PonderTooltipHandler.tick();
		// ScreenOpener.tick();
		ServerSpeedProvider.clientTick();
		BeltConnectorHandler.tick();
//		BeltSlicer.tickHoveringInformation();
		FilteringRenderer.tick();
		LinkRenderer.tick();
		ScrollValueRenderer.tick();
		ChassisRangeDisplay.tick();
		EdgeInteractionRenderer.tick();
		GirderWrenchBehavior.tick();
		WorldshaperRenderHandler.tick();
		CouplingHandlerClient.tick();
		CouplingRenderer.tickDebugModeRenders();
		KineticDebugger.tick();
		ExtendoGripRenderHandler.tick();
		// CollisionDebugger.tick();
		// fabric: fix #608, see above
//		ArmInteractionPointHandler.tick();
		EjectorTargetHandler.tick();
		ContraptionRenderInfoManager.tickFor(world);
		BlueprintOverlayRenderer.tick();
		ToolboxHandlerClient.clientTick();
		RadialWrenchHandler.clientTick();
		TrackTargetingClient.clientTick();
		TrackPlacement.clientTick();
		TrainRelocator.clientTick();
		ClickToLinkBlockItem.clientTick();
		CurvedTrackInteraction.clientTick();
		CameraDistanceModifier.tick();
		CameraAngleAnimationService.tick();
		TrainHUD.tick();
		ClipboardValueSettingsHandler.clientTick();
		CreateClient.VALUE_SETTINGS_HANDLER.tick();
		ScrollValueHandler.tick();
		NetheriteBacktankFirstPersonRenderer.clientTick();
		ContraptionPlayerPassengerRotation.tick();
		ChainConveyorInteractionHandler.clientTick();
		ChainConveyorRidingHandler.clientTick();
		ChainConveyorConnectionHandler.clientTick();
		PackagePortTargetSelectionHandler.tick();
		LogisticallyLinkedClientHandler.tick();
		TableClothOverlayRenderer.tick();
		CardboardArmorStealthOverlay.clientTick();
		FactoryPanelConnectionHandler.clientTick();
		TickBasedCache.clientTick();
		// fabric: see comment
		AllKeys.fixBinds();
	}

	public static void onJoin(class_634 handler, PacketSender sender, class_310 client) {
		CreateClient.checkGraphicsFanciness();
	}

	public static void onLeave(class_634 handler, class_310 client) {
		CreateClient.RAILWAYS.cleanUp();
	}

	public static void onLoadWorld(class_310 client, class_638 world) {
		if (world.method_8608() && world instanceof class_638 && !(world instanceof WrappedClientLevel)) {
			CreateClient.invalidateRenderers();
			AnimationTickHolder.reset();
		}
	}

	public static void onUnloadWorld(class_310 client, class_638 world) {
		if (world
			.method_8608()) {
			CreateClient.invalidateRenderers();
			CreateClient.SOUL_PULSE_EFFECT_HANDLER.refresh();
			AnimationTickHolder.reset();
			ControlsHandler.levelUnloaded(world);
		}
	}

	public static void onRenderWorld(WorldRenderContext event) {
		class_4587 ms = event.matrixStack();
		ms.method_22903();
		SuperRenderTypeBuffer buffer = DefaultSuperRenderTypeBuffer.getInstance();
		class_243 camera = class_310.method_1551().field_1773.method_19418()
			.method_19326();

		TrackBlockOutline.drawCurveSelection(ms, buffer, camera);
		TrackTargetingClient.render(ms, buffer, camera);
		CouplingRenderer.renderAll(ms, buffer, camera);
		CarriageCouplingRenderer.renderAll(ms, buffer, camera);
		CreateClient.SCHEMATIC_HANDLER.render(ms, buffer, camera);
		ChainConveyorInteractionHandler.drawCustomBlockSelection(ms, buffer, camera);

		buffer.draw();
		RenderSystem.enableCull();
		ms.method_22909();

		ContraptionPlayerPassengerRotation.frame();
	}

	public static boolean onCameraSetup(CameraInfo info) {
		float partialTicks = AnimationTickHolder.getPartialTicks();

		if (CameraAngleAnimationService.isYawAnimating())
			info.yaw = CameraAngleAnimationService.getYaw(partialTicks);

		if (CameraAngleAnimationService.isPitchAnimating())
			info.pitch = CameraAngleAnimationService.getPitch(partialTicks);
		return false;
	}

	public static void addToItemTooltip(class_1799 stack, class_1836 iTooltipFlag, List<class_2561> itemTooltip) {
		if (!AllConfigs.client().tooltips.get())
			return;
		class_1657 player = class_310.method_1551().field_1724;
		if (player == null)
			return;

		class_1792 item = stack.method_7909();
		TooltipModifier modifier = TooltipModifier.REGISTRY.get(item);
		if (modifier != null && modifier != TooltipModifier.EMPTY) {
			modifier.modify(stack, player, iTooltipFlag, itemTooltip);
		}

		SequencedAssemblyRecipe.addToTooltip(stack, itemTooltip);
	}

	public static void onRenderTick() {
		if (!isGameActive())
			return;
		TurntableHandler.gameRenderTick();
	}

	public static boolean onMount(class_1297 vehicle, class_1297 passenger) {
		if (passenger == class_310.method_1551().field_1724 && vehicle instanceof CarriageContraptionEntity)
			CameraDistanceModifier.zoomOut();
		return true;
	}

	public static boolean onDismount(class_1297 vehicle, class_1297 passenger) {
		CameraDistanceModifier.reset();
		return true;
	}

	protected static boolean isGameActive() {
		return !(class_310.method_1551().field_1687 == null || class_310.method_1551().field_1724 == null);
	}

	public static boolean getFogDensity(class_758.class_4596 mode, class_5636 type, class_4184 camera, float partialTick, float renderDistance, float nearDistance, float farDistance, class_6854 shape, FogEvents.FogData fogData) {
		class_1937 level = class_310.method_1551().field_1687;
		class_2338 blockPos = camera.method_19328();
		class_3610 fluidState = level.method_8316(blockPos);
		if (camera.method_19326().field_1351 >= blockPos.method_10264() + fluidState.method_15763(level, blockPos))
			return false;
		class_3611 fluid = fluidState.method_15772();
		class_1297 entity = camera.method_19331();

		if (AllFluids.CHOCOLATE.get()
			.method_15780(fluid)) {
			fogData.scaleFarPlaneDistance(1f / 32f * AllConfigs.client().chocolateTransparencyMultiplier.getF());
			return true;
		}

		if (AllFluids.HONEY.get()
			.method_15780(fluid)) {
			fogData.scaleFarPlaneDistance(1f / 8f * AllConfigs.client().honeyTransparencyMultiplier.getF());
			return true;
		}

		if (entity.method_7325())
			return false;

		class_1799 divingHelmet = DivingHelmetItem.getWornItem(entity);
		if (!divingHelmet.method_7960()) {
			if (FluidHelper.isWater(fluid)) {
				fogData.scaleFarPlaneDistance(6.25f);
				return true;
			} else if (FluidHelper.isLava(fluid) && NetheriteDivingHandler.isNetheriteDivingHelmet(divingHelmet)) {
				fogData.setNearPlaneDistance(-4.0f);
				fogData.setFarPlaneDistance(20.0f);
				return true;
			}
		}
		return false;
	}

	public static void getFogColor(ColorData event, float partialTicks) {
		class_4184 info = event.getCamera();
		class_1937 level = class_310.method_1551().field_1687;
		class_2338 blockPos = info.method_19328();
		class_3610 fluidState = level.method_8316(blockPos);
		if (info.method_19326().field_1351 > blockPos.method_10264() + fluidState.method_15763(level, blockPos))
			return;

		class_3611 fluid = fluidState.method_15772();

		if (AllFluids.CHOCOLATE.get()
			.method_15780(fluid)) {
			event.setRed(98 / 255f);
			event.setGreen(32 / 255f);
			event.setBlue(32 / 255f);
			return;
		}

		if (AllFluids.HONEY.get()
			.method_15780(fluid)) {
			event.setRed(234 / 255f);
			event.setGreen(174 / 255f);
			event.setBlue(47 / 255f);
			return;
		}
	}

	public static void leftClickEmpty(class_746 player) {
		class_1799 stack = player.method_6047();
		if (stack.method_7909() instanceof ZapperItem) {
			AllPackets.getChannel().sendToServer(new LeftClickPacket());
		}
	}

	public static class ModBusEvents {

		public static void registerClientReloadListeners() {
			ResourceManagerHelper.get(class_3264.field_14188).registerReloadListener(CreateClient.RESOURCE_RELOAD_LISTENER);
			ResourceManagerHelper.get(class_3264.field_14188).registerReloadListener(TrainHatInfoReloadListener.LISTENER);
		}
	}

	public static void addEntityRendererLayers(class_1299<? extends class_1309> entityType, class_922<?, ?> entityRenderer,
											   RegistrationHelper registrationHelper, class_5617.class_5618 context) {
		BacktankArmorLayer.registerOn(entityRenderer, registrationHelper);
		CreateHatArmorLayer.registerOn(entityRenderer, registrationHelper);
	}

	public static void registerItemDecorations() {
		RenderItemDecorationsCallback.EVENT.register(PotatoCannonItemRenderer.DECORATOR);
	}

	public static void register() {
//		ModBusEvents.registerClientReloadListeners();
		registerItemDecorations();

		ClientTickEvents.END_CLIENT_TICK.register(ClientEvents::onTick);
		ClientTickEvents.START_CLIENT_TICK.register(ClientEvents::onTickStart);
		ClientWorldEvents.LOAD.register(ClientEvents::onLoadWorld);
		ClientWorldEvents.UNLOAD.register(ClientEvents::onUnloadWorld);
		ClientWorldEvents.LOAD.register(CommonEvents::onLoadWorld);
		ClientWorldEvents.UNLOAD.register(CommonEvents::onUnloadWorld);
		ClientChunkEvents.CHUNK_UNLOAD.register(CommonEvents::onChunkUnloaded);
		ClientPlayConnectionEvents.JOIN.register(ClientEvents::onJoin);
		ClientEntityEvents.ENTITY_LOAD.register(CommonEvents::onEntityAdded);
		WorldRenderEvents.AFTER_TRANSLUCENT.register(ClientEvents::onRenderWorld);
		ItemTooltipCallback.EVENT.register(ClientEvents::addToItemTooltip);
		FogEvents.RENDER_FOG.register(ClientEvents::getFogDensity);
		FogEvents.SET_COLOR.register(ClientEvents::getFogColor);
		RenderTickStartCallback.EVENT.register(ClientEvents::onRenderTick);
		AttackAirCallback.EVENT.register(ClientEvents::leftClickEmpty);
		UseBlockCallback.EVENT.register(TrackBlockItem::sendExtenderPacket);
		EntityMountEvents.MOUNT.register(ClientEvents::onMount);
		EntityMountEvents.DISMOUNT.register(ClientEvents::onDismount);
		LivingEntityFeatureRendererRegistrationCallback.EVENT.register(ClientEvents::addEntityRendererLayers);
		CameraSetupCallback.EVENT.register(ClientEvents::onCameraSetup);
		DrawSelectionEvents.BLOCK.register(ClipboardValueSettingsHandler::drawCustomBlockSelection);
		TextureStitchCallback.POST.register(StitchedSprite::onTextureStitchPost);

		// External Events

		ClientTickEvents.END_CLIENT_TICK.register(SymmetryHandler::onClientTick);
		WorldRenderEvents.AFTER_TRANSLUCENT.register(SymmetryHandler::render);
		UseBlockCallback.EVENT.register(ArmInteractionPointHandler::rightClickingBlocksSelectsThem);
		UseBlockCallback.EVENT.register(EjectorTargetHandler::rightClickingBlocksSelectsThem);
		AttackBlockCallback.EVENT.register(ArmInteractionPointHandler::leftClickingBlocksDeselectsThem);
		AttackBlockCallback.EVENT.register(EjectorTargetHandler::leftClickingBlocksDeselectsThem);
		ParticleManagerRegistrationCallback.EVENT.register(AllParticleTypes::registerFactories);
		RenderHandCallback.EVENT.register(ExtendoGripRenderHandler::onRenderPlayerHand);
		InteractEvents.USE.register(ContraptionHandlerClient::rightClickingOnContraptionsGetsHandledLocally);
		RenderArmCallback.EVENT.register(NetheriteBacktankFirstPersonRenderer::onRenderPlayerHand);
		PlayerTickEvents.END.register(ContraptionHandlerClient::preventRemotePlayersWalkingAnimations);
		PlayerTickEvents.END.register(CardboardArmorHandlerClient::keepCacheAliveDesignDespiteNotRendering);
		RenderPlayerEvents.PRE.register(CardboardArmorHandlerClient::playerRendersAsBoxWhenSneaking);
		ClientPlayConnectionEvents.DISCONNECT.register(ClientEvents::onLeave);
		DrawSelectionEvents.BLOCK.register(TrackBlockOutline::drawCustomBlockSelection);
		AttackEntityEvent.ATTACK_ENTITY.register(PackageClientInteractionHandler::onPlayerPunchPackage);
		WorldRenderEvents.BEFORE_BLOCK_OUTLINE.register(ChainConveyorInteractionHandler::hideVanillaBlockSelection);

		// we need to add our config button after mod menu, so we register our event with a phase that comes later
		class_2960 latePhase = Create.asResource("late");
		ScreenEvents.AFTER_INIT.addPhaseOrdering(Event.DEFAULT_PHASE, latePhase);
		ScreenEvents.AFTER_INIT.register(latePhase, OpenCreateMenuButton.OpenConfigButtonHandler::onGuiInit);

		TrainMapEvents.init();

		// Flywheel Events
		ReloadLevelRendererCallback.EVENT.register(ContraptionRenderInfoManager::onReloadLevelRenderer);
	}

}
