package com.simibubi.create.foundation.block;

import java.util.EnumMap;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.function.Supplier;

import org.apache.commons.lang3.ArrayUtils;

import com.simibubi.create.foundation.data.TagGen;
import com.tterrag.registrate.AbstractRegistrate;
import com.tterrag.registrate.builders.BlockBuilder;
import com.tterrag.registrate.providers.DataGenContext;
import com.tterrag.registrate.providers.RegistrateBlockstateProvider;
import com.tterrag.registrate.providers.RegistrateRecipeProvider;
import com.tterrag.registrate.providers.loot.RegistrateBlockLootTables;
import com.tterrag.registrate.util.DataIngredient;
import com.tterrag.registrate.util.entry.BlockEntry;
import com.tterrag.registrate.util.nullness.NonNullBiConsumer;
import com.tterrag.registrate.util.nullness.NonNullFunction;

import net.createmod.catnip.data.Iterate;
import net.createmod.catnip.lang.Lang;
import net.createmod.catnip.platform.CatnipServices;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2450;
import net.minecraft.class_2482;
import net.minecraft.class_2510;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3481;
import net.minecraft.class_4970.class_2251;
import net.minecraft.class_5812;
import net.minecraft.class_5813;
import net.minecraft.class_5814;
import net.minecraft.class_5955.class_5811;
import net.minecraft.class_7800;
import io.github.fabricators_of_create.porting_lib.models.generators.ModelProvider;

public class CopperBlockSet {
	protected static final class_5811[] WEATHER_STATES = class_5811.values();
	protected static final int WEATHER_STATE_COUNT = WEATHER_STATES.length;

	protected static final Map<class_5811, class_2248> BASE_BLOCKS = new EnumMap<>(class_5811.class);

	static {
		BASE_BLOCKS.put(class_5811.field_28704, class_2246.field_27119);
		BASE_BLOCKS.put(class_5811.field_28705, class_2246.field_27118);
		BASE_BLOCKS.put(class_5811.field_28706, class_2246.field_27117);
		BASE_BLOCKS.put(class_5811.field_28707, class_2246.field_27116);
	}

	public static final Variant<?>[] DEFAULT_VARIANTS =
		new Variant<?>[]{BlockVariant.INSTANCE, SlabVariant.INSTANCE, StairVariant.INSTANCE};

	protected final String name;
	protected final String generalDirectory; // Leave empty for root folder
	protected final Variant<?>[] variants;
	protected final Map<Variant<?>, BlockEntry<?>[]> entries = new HashMap<>();
	protected final NonNullBiConsumer<DataGenContext<class_2248, ?>, RegistrateRecipeProvider> mainBlockRecipe;
	protected final String endTextureName;
	protected final NonNullBiConsumer<class_5811, class_2248> onRegister;

	public CopperBlockSet(AbstractRegistrate<?> registrate, String name, String endTextureName, Variant<?>[] variants) {
		this(registrate, name, endTextureName, variants, NonNullBiConsumer.noop(), "copper/", NonNullBiConsumer.noop());
	}

	public CopperBlockSet(AbstractRegistrate<?> registrate, String name, String endTextureName, Variant<?>[] variants, String generalDirectory) {
		this(registrate, name, endTextureName, variants, NonNullBiConsumer.noop(), generalDirectory, NonNullBiConsumer.noop());
	}

	public CopperBlockSet(AbstractRegistrate<?> registrate, String name, String endTextureName, Variant<?>[] variants, NonNullBiConsumer<DataGenContext<class_2248, ?>, RegistrateRecipeProvider> mainBlockRecipe) {
		this(registrate, name, endTextureName, variants, mainBlockRecipe, "copper/", NonNullBiConsumer.noop());
	}

	public CopperBlockSet(AbstractRegistrate<?> registrate, String name, String endTextureName, Variant<?>[] variants, NonNullBiConsumer<DataGenContext<class_2248, ?>, RegistrateRecipeProvider> mainBlockRecipe, NonNullBiConsumer<class_5811, class_2248> onRegister) {
		this(registrate, name, endTextureName, variants, mainBlockRecipe, "copper/", onRegister);
	}

	public CopperBlockSet(AbstractRegistrate<?> registrate, String name, String endTextureName, Variant<?>[] variants,
						  NonNullBiConsumer<DataGenContext<class_2248, ?>, RegistrateRecipeProvider> mainBlockRecipe, String generalDirectory, NonNullBiConsumer<class_5811, class_2248> onRegister) {
		this.name = name;
		this.generalDirectory = generalDirectory;
		this.endTextureName = endTextureName;
		this.variants = variants;
		this.mainBlockRecipe = mainBlockRecipe;
		this.onRegister = onRegister;

		for (boolean waxed : Iterate.falseAndTrue) {
			for (Variant<?> variant : this.variants) {
				BlockEntry<?>[] entries =
					waxed ? this.entries.get(variant) : new BlockEntry<?>[WEATHER_STATE_COUNT * 2];
				for (class_5811 state : WEATHER_STATES) {
					int index = getIndex(state, waxed);
					BlockEntry<?> entry = createEntry(registrate, variant, state, waxed);
					entries[index] = entry;

					if (waxed) {
						CopperRegistries.addWaxable(() -> entries[getIndex(state, false)].get(), () -> entry.get());
					} else if (state != class_5811.field_28704) {
						CopperRegistries.addWeathering(
							() -> entries[getIndex(WEATHER_STATES[state.ordinal() - 1], false)].get(),
							() -> entry.get());
					}
				}
				if (!waxed)
					this.entries.put(variant, entries);
			}
		}
	}

	protected <T extends class_2248> BlockEntry<?> createEntry(AbstractRegistrate<?> registrate, Variant<T> variant,
														  class_5811 state, boolean waxed) {
		String name = "";
		if (waxed) {
			name += "waxed_";
		}
		name += getWeatherStatePrefix(state);
		name += this.name;

		String suffix = variant.getSuffix();
		if (!suffix.equals(""))
			name = Lang.nonPluralId(name);

		name += suffix;

		class_2248 baseBlock = BASE_BLOCKS.get(state);
		BlockBuilder<T, ?> builder = registrate.block(name, variant.getFactory(this, state, waxed))
			.initialProperties(() -> baseBlock)
			.loot((lt, block) -> variant.generateLootTable(lt, block, this, state, waxed))
			.blockstate((ctx, prov) -> variant.generateBlockState(ctx, prov, this, state, waxed))
			.recipe((c, p) -> variant.generateRecipes(entries.get(BlockVariant.INSTANCE)[state.ordinal()], c, p))
			.transform(TagGen.pickaxeOnly())
			.onRegister(block -> onRegister.accept(state, block))
			.tag(class_3481.field_33719)
			.simpleItem();

		if (variant == BlockVariant.INSTANCE && state == class_5811.field_28704)
			builder.recipe(mainBlockRecipe::accept);

		if (variant == StairVariant.INSTANCE)
			builder.tag(class_3481.field_15459);

		if (variant == SlabVariant.INSTANCE)
			builder.tag(class_3481.field_15469);

		if (waxed) {
			builder.recipe((ctx, prov) -> {
				class_2248 unwaxed = get(variant, state, false).get();
				class_2450.method_10447(class_7800.field_40634, ctx.get())
					.method_10454(unwaxed)
					.method_10454(class_1802.field_20414)
					.method_10442("has_unwaxed", RegistrateRecipeProvider.method_10426(unwaxed))
					.method_17972(prov, new class_2960(ctx.getId()
						.method_12836(), "crafting/" + generalDirectory + ctx.getName() + "_from_honeycomb"));
			});
		}

		return builder.register();
	}

	protected int getIndex(class_5811 state, boolean waxed) {
		return state.ordinal() + (waxed ? WEATHER_STATE_COUNT : 0);
	}

	public String getName() {
		return name;
	}

	public String getEndTextureName() {
		return endTextureName;
	}

	public Variant<?>[] getVariants() {
		return variants;
	}

	public boolean hasVariant(Variant<?> variant) {
		return ArrayUtils.contains(variants, variant);
	}

	public BlockEntry<?> get(Variant<?> variant, class_5811 state, boolean waxed) {
		BlockEntry<?>[] entries = this.entries.get(variant);
		if (entries != null) {
			return entries[getIndex(state, waxed)];
		}
		return null;
	}

	public BlockEntry<?> getStandard() {
		return get(BlockVariant.INSTANCE, class_5811.field_28704, false);
	}

	public static String getWeatherStatePrefix(class_5811 state) {
		if (state != class_5811.field_28704) {
			return state.name()
				.toLowerCase(Locale.ROOT) + "_";
		}
		return "";
	}

	public interface Variant<T extends class_2248> {
		String getSuffix();

		NonNullFunction<class_2251, T> getFactory(CopperBlockSet blocks, class_5811 state, boolean waxed);

		default void generateLootTable(RegistrateBlockLootTables lootTable, T block, CopperBlockSet blocks,
									   class_5811 state, boolean waxed) {
			lootTable.method_46025(block);
		}

		void generateRecipes(BlockEntry<?> blockVariant, DataGenContext<class_2248, T> ctx, RegistrateRecipeProvider prov);

		void generateBlockState(DataGenContext<class_2248, T> ctx, RegistrateBlockstateProvider prov, CopperBlockSet blocks,
								class_5811 state, boolean waxed);
	}

	public static class BlockVariant implements Variant<class_2248> {
		public static final BlockVariant INSTANCE = new BlockVariant();

		protected BlockVariant() {
		}

		@Override
		public String getSuffix() {
			return "";
		}

		@Override
		public NonNullFunction<class_2251, class_2248> getFactory(CopperBlockSet blocks, class_5811 state, boolean waxed) {
			if (waxed) {
				return class_2248::new;
			} else {
				return p -> new class_5812(state, p);
			}
		}

		@Override
		public void generateBlockState(DataGenContext<class_2248, class_2248> ctx, RegistrateBlockstateProvider prov,
									   CopperBlockSet blocks, class_5811 state, boolean waxed) {
			class_2248 block = ctx.get();
			String path = CatnipServices.REGISTRIES.getKeyOrThrow(block)
				.method_12832();
			String baseLoc = ModelProvider.BLOCK_FOLDER + "/" + blocks.generalDirectory + getWeatherStatePrefix(state);

			class_2960 texture = prov.modLoc(baseLoc + blocks.getName());
			if (Objects.equals(blocks.getName(), blocks.getEndTextureName())) {
				// End texture and base texture are equal, so we should use cube_all.
				prov.simpleBlock(block, prov.models().cubeAll(path, texture));
			} else {
				// End texture and base texture aren't equal, so we should use cube_column.
				class_2960 endTexture = prov.modLoc(baseLoc + blocks.getEndTextureName());
				prov.simpleBlock(block, prov.models()
					.cubeColumn(path, texture, endTexture));
			}

		}

		@Override
		public void generateRecipes(BlockEntry<?> blockVariant, DataGenContext<class_2248, class_2248> ctx,
									RegistrateRecipeProvider prov) {
		}

	}

	public static class SlabVariant implements Variant<class_2482> {
		public static final SlabVariant INSTANCE = new SlabVariant();

		protected SlabVariant() {
		}

		@Override
		public String getSuffix() {
			return "_slab";
		}

		@Override
		public NonNullFunction<class_2251, class_2482> getFactory(CopperBlockSet blocks, class_5811 state,
																 boolean waxed) {
			if (waxed) {
				return class_2482::new;
			} else {
				return p -> new class_5813(state, p);
			}
		}

		@Override
		public void generateLootTable(RegistrateBlockLootTables lootTable, class_2482 block, CopperBlockSet blocks,
									  class_5811 state, boolean waxed) {
			lootTable.method_45988(block, lootTable.method_45980(block));
		}

		@Override
		public void generateBlockState(DataGenContext<class_2248, class_2482> ctx, RegistrateBlockstateProvider prov,
									   CopperBlockSet blocks, class_5811 state, boolean waxed) {
			class_2960 fullModel =
				prov.modLoc(ModelProvider.BLOCK_FOLDER + "/" + getWeatherStatePrefix(state) + blocks.getName());

			String baseLoc = ModelProvider.BLOCK_FOLDER + "/" + blocks.generalDirectory + getWeatherStatePrefix(state);
			class_2960 texture = prov.modLoc(baseLoc + blocks.getName());
			class_2960 endTexture = prov.modLoc(baseLoc + blocks.getEndTextureName());

			prov.slabBlock(ctx.get(), fullModel, texture, endTexture, endTexture);
		}

		@Override
		public void generateRecipes(BlockEntry<?> blockVariant, DataGenContext<class_2248, class_2482> ctx,
									RegistrateRecipeProvider prov) {
			prov.slab(DataIngredient.items(blockVariant.get()), class_7800.field_40634, ctx::get, null, true);
		}
	}

	public static class StairVariant implements Variant<class_2510> {
		public static final StairVariant INSTANCE = new StairVariant(BlockVariant.INSTANCE);

		protected final Variant<?> parent;

		protected StairVariant(Variant<?> parent) {
			this.parent = parent;
		}

		@Override
		public String getSuffix() {
			return "_stairs";
		}

		@Override
		public NonNullFunction<class_2251, class_2510> getFactory(CopperBlockSet blocks, class_5811 state,
																  boolean waxed) {
			if (!blocks.hasVariant(parent)) {
				throw new IllegalStateException(
					"Cannot add StairVariant '" + toString() + "' without parent Variant '" + parent.toString() + "'!");
			}
			Supplier<class_2680> defaultStateSupplier = () -> blocks.get(parent, state, waxed)
				.getDefaultState();
			if (waxed) {
				return p -> new class_2510(defaultStateSupplier.get(), p);
			} else {
				return p -> {
					class_5814 block =
						new class_5814(state, class_2246.field_10124.method_9564(), p);
					// WeatheringCopperStairBlock does not have a constructor that takes a Supplier,
					// so setting the field directly is the easiest solution
					// fabric: unnecessary
//					ObfuscationReflectionHelper.setPrivateValue(StairBlock.class, block, defaultStateSupplier,
//						"stateSupplier");
					return block;
				};
			}
		}

		@Override
		public void generateBlockState(DataGenContext<class_2248, class_2510> ctx, RegistrateBlockstateProvider prov,
									   CopperBlockSet blocks, class_5811 state, boolean waxed) {
			String baseLoc = ModelProvider.BLOCK_FOLDER + "/" + blocks.generalDirectory + getWeatherStatePrefix(state);
			class_2960 texture = prov.modLoc(baseLoc + blocks.getName());
			class_2960 endTexture = prov.modLoc(baseLoc + blocks.getEndTextureName());
			prov.stairsBlock(ctx.get(), texture, endTexture, endTexture);
		}

		@Override
		public void generateRecipes(BlockEntry<?> blockVariant, DataGenContext<class_2248, class_2510> ctx,
									RegistrateRecipeProvider prov) {
			prov.stairs(DataIngredient.items(blockVariant.get()), class_7800.field_40634, ctx::get, null, true);
		}
	}
}
