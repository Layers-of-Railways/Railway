package com.simibubi.create.foundation.data;

import com.simibubi.create.Create;
import com.tterrag.registrate.builders.ItemBuilder;
import com.tterrag.registrate.providers.DataGenContext;
import com.tterrag.registrate.util.nullness.NonNullFunction;
import io.github.fabricators_of_create.porting_lib.models.generators.ModelFile;
import io.github.fabricators_of_create.porting_lib.models.generators.block.BlockStateProvider;
import net.minecraft.class_1747;
import net.minecraft.class_2248;
import net.minecraft.class_2960;

public class ModelGen {

	public static ModelFile createOvergrown(DataGenContext<class_2248, ? extends class_2248> ctx, BlockStateProvider prov,
											class_2960 block, class_2960 overlay) {
		return createOvergrown(ctx, prov, block, block, block, overlay);
	}

	public static ModelFile createOvergrown(DataGenContext<class_2248, ? extends class_2248> ctx, BlockStateProvider prov,
		class_2960 side, class_2960 top, class_2960 bottom, class_2960 overlay) {
		return prov.models()
			.withExistingParent(ctx.getName(), Create.asResource("block/overgrown"))
			.texture("particle", side)
			.texture("side", side)
			.texture("top", top)
			.texture("bottom", bottom)
			.texture("overlay", overlay);
	}

	public static <I extends class_1747, P> NonNullFunction<ItemBuilder<I, P>, P> customItemModel() {
		return b -> b.model(AssetLookup::customItemModel)
			.build();
	}

	public static <I extends class_1747, P> NonNullFunction<ItemBuilder<I, P>, P> customItemModel(String... path) {
		return b -> b.model(AssetLookup.customBlockItemModel(path))
			.build();
	}

}
