package com.simibubi.create.foundation.mixin.client;

import java.util.Iterator;
import net.minecraft.class_20;
import net.minecraft.class_22;
import net.minecraft.class_330;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import com.google.common.collect.Iterators;
import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.sugar.Local;
import com.simibubi.create.foundation.map.CustomRenderedMapDecoration;

// fabric: we have an AW for it, and compiler complains if specified by string
@Mixin(class_330.class_331.class)
public class MapRendererMapInstanceMixin {
	@Shadow
	private class_22 data;

	// fabric: completely redone

	@ModifyExpressionValue(
		method = "draw",
		at = @At(
				value = "INVOKE",
				target = "Ljava/lang/Iterable;iterator()Ljava/util/Iterator;"
		)
	)
	private Iterator<class_20> wrapIterator(Iterator<class_20> original) {
		// skip rendering custom ones in the main loop
		return Iterators.filter(original, decoration -> !(decoration instanceof CustomRenderedMapDecoration));
	}

	@Inject(method = "draw", at = @At("TAIL"))
	private void renderCustomDecorations(class_4587 poseStack, class_4597 bufferSource, boolean active,
										 int packedLight, CallbackInfo ci, @Local(ordinal = 3) int index) { // ignore error, works
		// render custom ones in second loop
		for (class_20 decoration : this.data.method_32373()) {
			if (decoration instanceof CustomRenderedMapDecoration renderer) {
				renderer.render(poseStack, bufferSource, active, packedLight, data, index);
			}
		}
	}
}
