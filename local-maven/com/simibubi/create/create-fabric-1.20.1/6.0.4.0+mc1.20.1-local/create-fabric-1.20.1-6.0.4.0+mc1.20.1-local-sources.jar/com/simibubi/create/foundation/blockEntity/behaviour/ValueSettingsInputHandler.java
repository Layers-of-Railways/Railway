package com.simibubi.create.foundation.blockEntity.behaviour;

import org.apache.commons.lang3.mutable.MutableBoolean;

import com.simibubi.create.AllBlocks;
import com.simibubi.create.AllTags.AllItemTags;
import com.simibubi.create.CreateClient;
import com.simibubi.create.foundation.blockEntity.SmartBlockEntity;
import com.simibubi.create.foundation.blockEntity.behaviour.filtering.SidedFilteringBehaviour;
import com.simibubi.create.foundation.utility.AdventureUtil;
import net.fabricmc.api.EnvType;
import net.fabricmc.fabric.api.entity.FakePlayer;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_3965;
import io.github.fabricators_of_create.porting_lib.util.EnvExecutor;

public class ValueSettingsInputHandler {

	public static class_1269 onBlockActivated(class_1657 player, class_1937 world, class_1268 hand, class_3965 ray) {
		class_2338 pos = ray.method_17777();

		if (!canInteract(player))
			return class_1269.field_5811;
		if (AllBlocks.CLIPBOARD.isIn(player.method_6047()))
			return class_1269.field_5811;
		if (!(world.method_8321(pos)instanceof SmartBlockEntity sbe))
			return class_1269.field_5811;

		MutableBoolean cancelled = new MutableBoolean(false);
		if (world.field_9236)
			EnvExecutor.runWhenOn(EnvType.CLIENT,
				() -> () -> CreateClient.VALUE_SETTINGS_HANDLER.cancelIfWarmupAlreadyStarted(pos, cancelled));

		if (cancelled.booleanValue())
			return class_1269.field_5814;

		for (BlockEntityBehaviour behaviour : sbe.getAllBehaviours()) {
			if (!(behaviour instanceof ValueSettingsBehaviour valueSettingsBehaviour))
				continue;
			if (valueSettingsBehaviour.bypassesInput(player.method_6047()))
				continue;
			if (!valueSettingsBehaviour.mayInteract(player))
				continue;

			if (ray == null)
				return class_1269.field_5811;
			if (behaviour instanceof SidedFilteringBehaviour) {
				behaviour = ((SidedFilteringBehaviour) behaviour).get(ray.method_17780());
				if (behaviour == null)
					continue;
			}

			if (!valueSettingsBehaviour.isActive())
				continue;
			if (valueSettingsBehaviour.onlyVisibleWithWrench()
				&& !AllItemTags.WRENCH.matches(player.method_5998(hand)))
				continue;
			if (valueSettingsBehaviour.getSlotPositioning()instanceof ValueBoxTransform.Sided sidedSlot) {
				if (!sidedSlot.isSideActive(sbe.method_11010(), ray.method_17780()))
					continue;
				sidedSlot.fromSide(ray.method_17780());
			}

			boolean fakePlayer = player instanceof FakePlayer;
			if (!valueSettingsBehaviour.testHit(ray.method_17784()) && !fakePlayer)
				continue;

			if (!valueSettingsBehaviour.acceptsValueSettings() || fakePlayer) {
				valueSettingsBehaviour.onShortInteract(player, hand, ray.method_17780(), ray);
				// fabric: https://github.com/Fabricators-of-Create/Create/issues/1553
				// Fabric api doesn't have a replacement for Forge's Event.Result so we need to hackily set this
				// to fail so that other code isn't run, this just simulates the same behavior as create forge since we
				// skip running further stuff if InteractionResult is FAIL
				return fakePlayer ? class_1269.field_5814 : class_1269.field_5812;
			}

			if (world.field_9236) {
				BehaviourType<?> type = behaviour.getType();
				EnvExecutor.runWhenOn(EnvType.CLIENT, () -> () -> CreateClient.VALUE_SETTINGS_HANDLER
					.startInteractionWith(pos, type, hand, ray.method_17780()));
			}

			return class_1269.field_5812;
		}
		return class_1269.field_5811;
	}

	public static boolean canInteract(class_1657 player) {
		return player != null && !player.method_7325() && !player.method_5715() && !AdventureUtil.isAdventure(player);
	}
}
