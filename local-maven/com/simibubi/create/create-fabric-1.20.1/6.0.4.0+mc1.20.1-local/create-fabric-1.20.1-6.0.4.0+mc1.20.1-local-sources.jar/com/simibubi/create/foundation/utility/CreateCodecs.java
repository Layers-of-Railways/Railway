package com.simibubi.create.foundation.utility;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.stream.Stream;
import net.minecraft.class_1293;
import net.minecraft.class_1293.class_7247;
import net.minecraft.class_2487;
import net.minecraft.class_2509;
import net.minecraft.class_2520;
import net.minecraft.class_4174;
import net.minecraft.class_5699;
import net.minecraft.class_7923;
import com.google.common.base.Suppliers;
import com.google.common.primitives.UnsignedBytes;
import com.mojang.datafixers.util.Pair;
import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import com.mojang.serialization.Dynamic;
import com.mojang.serialization.DynamicOps;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.MapLike;
import com.mojang.serialization.RecordBuilder;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.simibubi.create.foundation.item.ItemSlots;
import com.simibubi.create.foundation.mixin.accessor.MobEffectInstanceAccessor;
import io.github.fabricators_of_create.porting_lib.fluids.FluidStack;
import io.github.fabricators_of_create.porting_lib.transfer.item.ItemStackHandler;

public class CreateCodecs {
	public static final Codec<Long> NON_NEGATIVE_LONG = class_5699.method_48112(
		Codec.LONG,
		value -> value < 0 ? DataResult.error(() -> "Value is negative: " + value) : DataResult.success(value)
	);

	public static final Codec<Integer> INT_STR = Codec.STRING.comapFlatMap(
		string -> {
			try {
				return DataResult.success(Integer.parseInt(string));
			} catch (NumberFormatException ignored) {
				return DataResult.error(() -> "Not an integer: " + string);
			}
		},
		String::valueOf
	);

	public static final Codec<ItemStackHandler> ITEM_STACK_HANDLER = ItemSlots.CODEC.xmap(
		slots -> slots.toHandler(ItemStackHandler::new), ItemSlots::fromHandler
	);

	public static final Codec<class_2487> COMPOUND_TAG = Codec.PASSTHROUGH.comapFlatMap(
		dynamic -> {
			class_2520 converted = dynamic.convert(class_2509.field_11560).getValue();
			return converted instanceof class_2487 compound ? DataResult.success(compound) : DataResult.error(() -> "Not a compound: " + converted);
		},
		tag -> new Dynamic<>(class_2509.field_11560, tag)
	);

	// the codec included in PortingLib is causing some absurd errors with its null default for nbt
	public static final Codec<FluidStack> FLUID_STACK = COMPOUND_TAG.xmap(
		FluidStack::loadFluidStackFromNBT,
		stack -> stack.writeToNBT(new class_2487())
	);

	public static Codec<Integer> boundedIntStr(int min) {
		return class_5699.method_48112(
			INT_STR,
			i -> i >= min ? DataResult.success(i) : DataResult.error(() -> "Value under minimum of " + min)
		);
	}

	public static final Codec<Double> NON_NEGATIVE_DOUBLE = doubleRangeWithMessage(0, Double.MAX_VALUE,
		i -> "Value must be non-negative: " + i);
	public static final Codec<Double> POSITIVE_DOUBLE = doubleRangeWithMessage(1, Double.MAX_VALUE,
		i -> "Value must be positive: " + i);

	private static Codec<Double> doubleRangeWithMessage(double min, double max, Function<Double, String> errorMessage) {
		return class_5699.method_48112(Codec.DOUBLE, i ->
			i.compareTo(min) >= 0 && i.compareTo(max) <= 0 ? DataResult.success(i) : DataResult.error(() ->
				errorMessage.apply(i)
			)
		);
	}

	public static final Codec<Integer> UNSIGNED_BYTE = Codec.BYTE
		.flatComapMap(
			UnsignedBytes::toInt,
			p_324632_ -> p_324632_ > 255
				? DataResult.error(() -> "Unsigned byte was too large: " + p_324632_ + " > 255")
				: DataResult.success(p_324632_.byteValue())
		);

	public static final MapCodec<class_1293> MOB_EFFECT_INSTANCE = recursive(
		"MobEffectInstance",
		codec -> RecordCodecBuilder.mapCodec(
			instance -> instance.group(
					class_7923.field_41174.method_39673().fieldOf("effect").forGetter(class_1293::method_5579),
					Codec.INT.optionalFieldOf("duration", 0).forGetter(class_1293::method_5584),
					UNSIGNED_BYTE.optionalFieldOf("amplifier", 0).forGetter(class_1293::method_5578),
					Codec.BOOL.optionalFieldOf("ambient", false).forGetter(class_1293::method_5591),
					Codec.BOOL.optionalFieldOf("show_particles", true).forGetter(class_1293::method_5581),
					Codec.BOOL.optionalFieldOf("show_icon", true).forGetter(class_1293::method_5592),
					codec.optionalFieldOf("hidden_effect").forGetter(i -> Optional.ofNullable(((MobEffectInstanceAccessor) i).create$getHiddenEffect())),
					class_7247.field_38085.optionalFieldOf("factor_data").forGetter(class_1293::method_42129)
				)
				.apply(instance, (effect, duration, amplifier, isAmbient, showParticles, showIcon, hiddenEffect, factorData) ->
					new class_1293(effect, duration, amplifier, isAmbient, showParticles, showIcon, hiddenEffect.orElse(null), factorData))
		)
	);

	public static final Codec<class_4174> FOOD_PROPERTIES = RecordCodecBuilder.create(instance -> instance.group(
		class_5699.field_33441.fieldOf("nutrition").forGetter(class_4174::method_19230),
		Codec.FLOAT.fieldOf("saturation_modifier").forGetter(class_4174::method_19231),
		Codec.BOOL.optionalFieldOf("is_meat", false).forGetter(class_4174::method_19232),
		Codec.BOOL.optionalFieldOf("can_always_eat", false).forGetter(class_4174::method_19233),
		Codec.BOOL.optionalFieldOf("is_fast_food", false).forGetter(class_4174::method_19234),
		FoodEffect.CODEC.listOf().optionalFieldOf("effects", List.of()).forGetter(i -> {
			List<FoodEffect> effects = new ArrayList<>();
			for (Pair<class_1293, Float> pair : i.method_19235())
				effects.add(new FoodEffect(pair.getFirst(), pair.getSecond()));
			return effects;
		})
	).apply(instance, (nutrition, saturationModifier, isMeat, canAlwaysEat, isFastFood, effects) -> {
		class_4174.class_4175 builder = new class_4174.class_4175()
			.method_19238(nutrition)
			.method_19237(saturationModifier);

		if (isMeat) builder.method_19236();
		if (canAlwaysEat) builder.method_19240();
		if (isFastFood) builder.method_19241();
		for (FoodEffect effect : effects) builder.method_19239(effect.effect(), effect.probability());

		return builder.method_19242();
	}));

	public record FoodEffect(Supplier<class_1293> effectSupplier, float probability) {
		public static final Codec<FoodEffect> CODEC = RecordCodecBuilder.create(instance -> instance.group(
			MOB_EFFECT_INSTANCE.fieldOf("effect").forGetter(FoodEffect::effect),
			Codec.FLOAT.fieldOf("probability").forGetter(FoodEffect::probability)
		).apply(instance, FoodEffect::new));

		private FoodEffect(class_1293 effect, float probability) {
			this(() -> effect, probability);
		}

		public class_1293 effect() {
			return new class_1293(this.effectSupplier.get());
		}
	}

	public static <A> MapCodec<A> recursive(final String name, final Function<Codec<A>, MapCodec<A>> wrapped) {
		return new RecursiveMapCodec<>(name, wrapped);
	}

	private static class RecursiveMapCodec<A> extends MapCodec<A> {
		private final String name;
		private final Supplier<MapCodec<A>> wrapped;

		private RecursiveMapCodec(final String name, final Function<Codec<A>, MapCodec<A>> wrapped) {
			this.name = name;
			this.wrapped = Suppliers.memoize(() -> wrapped.apply(codec()));
		}

		@Override
		public <T> RecordBuilder<T> encode(final A input, final DynamicOps<T> ops, final RecordBuilder<T> prefix) {
			return wrapped.get().encode(input, ops, prefix);
		}

		@Override
		public <T> DataResult<A> decode(final DynamicOps<T> ops, final MapLike<T> input) {
			return wrapped.get().decode(ops, input);
		}

		@Override
		public <T> Stream<T> keys(final DynamicOps<T> ops) {
			return wrapped.get().keys(ops);
		}

		@Override
		public String toString() {
			return "RecursiveMapCodec[" + name + ']';
		}
	}
}
