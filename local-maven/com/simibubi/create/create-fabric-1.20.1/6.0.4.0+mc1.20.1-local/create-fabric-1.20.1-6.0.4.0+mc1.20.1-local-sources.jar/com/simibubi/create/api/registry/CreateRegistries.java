package com.simibubi.create.api.registry;

import com.mojang.serialization.Codec;
import com.simibubi.create.Create;
import com.simibubi.create.api.behaviour.display.DisplaySource;
import com.simibubi.create.api.behaviour.display.DisplayTarget;
import com.simibubi.create.api.contraption.ContraptionType;
import com.simibubi.create.api.contraption.storage.fluid.MountedFluidStorageType;
import com.simibubi.create.api.contraption.storage.item.MountedItemStorageType;
import com.simibubi.create.api.equipment.potatoCannon.PotatoCannonProjectileType;
import com.simibubi.create.api.equipment.potatoCannon.PotatoProjectileBlockHitAction;
import com.simibubi.create.api.equipment.potatoCannon.PotatoProjectileEntityHitAction;
import com.simibubi.create.api.equipment.potatoCannon.PotatoProjectileRenderMode;
import com.simibubi.create.content.kinetics.fan.processing.FanProcessingType;
import com.simibubi.create.content.kinetics.mechanicalArm.ArmInteractionPointType;
import com.simibubi.create.content.logistics.item.filter.attribute.ItemAttributeType;
import net.minecraft.class_2378;
import net.minecraft.class_5321;

/**
 * Keys for registries added by Create.
 *
 * @see CreateBuiltInRegistries
 */
public class CreateRegistries {
	public static final class_5321<class_2378<ArmInteractionPointType>> ARM_INTERACTION_POINT_TYPE = key("arm_interaction_point_type");
	public static final class_5321<class_2378<FanProcessingType>> FAN_PROCESSING_TYPE = key("fan_processing_type");
	public static final class_5321<class_2378<ItemAttributeType>> ITEM_ATTRIBUTE_TYPE = key("item_attribute_type");
	public static final class_5321<class_2378<DisplaySource>> DISPLAY_SOURCE = key("display_source");
	public static final class_5321<class_2378<DisplayTarget>> DISPLAY_TARGET = key("display_target");
	public static final class_5321<class_2378<MountedItemStorageType<?>>> MOUNTED_ITEM_STORAGE_TYPE = key("mounted_item_storage_type");
	public static final class_5321<class_2378<MountedFluidStorageType<?>>> MOUNTED_FLUID_STORAGE_TYPE = key("mounted_fluid_storage_type");
	public static final class_5321<class_2378<ContraptionType>> CONTRAPTION_TYPE = key("contraption_type");
	public static final class_5321<class_2378<PotatoCannonProjectileType>> POTATO_PROJECTILE_TYPE = key("potato_projectile/type");
	public static final class_5321<class_2378<Codec<? extends PotatoProjectileRenderMode>>> POTATO_PROJECTILE_RENDER_MODE = key("potato_projectile/render_mode");
	public static final class_5321<class_2378<Codec<? extends PotatoProjectileEntityHitAction>>> POTATO_PROJECTILE_ENTITY_HIT_ACTION = key("potato_projectile/entity_hit_action");
	public static final class_5321<class_2378<Codec<? extends PotatoProjectileBlockHitAction>>> POTATO_PROJECTILE_BLOCK_HIT_ACTION = key("potato_projectile/block_hit_action");

	private static <T> class_5321<class_2378<T>> key(String name) {
		return class_5321.method_29180(Create.asResource(name));
	}
}
