package com.simibubi.create.foundation.mixin.fabric;

import net.minecraft.class_1309;
import net.minecraft.class_3887;
import net.minecraft.class_583;
import net.minecraft.class_922;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_922.class)
public interface LivingEntityRendererAccessor {
	@Invoker("addLayer")
	<T extends class_1309, M extends class_583<T>> boolean create$addLayer(class_3887<T, M> layer);
}
