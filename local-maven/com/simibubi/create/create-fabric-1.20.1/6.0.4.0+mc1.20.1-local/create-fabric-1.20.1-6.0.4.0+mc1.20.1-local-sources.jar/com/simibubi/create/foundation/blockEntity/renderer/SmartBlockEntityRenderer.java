package com.simibubi.create.foundation.blockEntity.renderer;

import org.joml.Matrix4f;
import com.simibubi.create.content.redstone.link.LinkRenderer;
import com.simibubi.create.foundation.blockEntity.SmartBlockEntity;
import com.simibubi.create.foundation.blockEntity.behaviour.filtering.FilteringRenderer;
import net.minecraft.class_239;
import net.minecraft.class_239.class_240;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_3965;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5614;

public class SmartBlockEntityRenderer<T extends SmartBlockEntity> extends SafeBlockEntityRenderer<T> {

	public SmartBlockEntityRenderer(class_5614.class_5615 context) {
	}
	
	@Override
	protected void renderSafe(T blockEntity, float partialTicks, class_4587 ms, class_4597 buffer, int light,
			int overlay) {
		FilteringRenderer.renderOnBlockEntity(blockEntity, partialTicks, ms, buffer, light, overlay);
		LinkRenderer.renderOnBlockEntity(blockEntity, partialTicks, ms, buffer, light, overlay);
	}

	protected void renderNameplateOnHover(T blockEntity, class_2561 tag, float yOffset, class_4587 ms,
		class_4597 buffer, int light) {
		class_310 mc = class_310.method_1551();
		if (blockEntity.isVirtual())
			return;
		if (mc.field_1724.method_5707(class_243.method_24953(blockEntity.method_11016())) > 4096.0f)
			return;
		class_239 hitResult = mc.field_1765;
		if (!(hitResult instanceof class_3965 bhr) || bhr.method_17783() == class_240.field_1333 || !bhr.method_17777()
			.equals(blockEntity.method_11016()))
			return;

		float f = yOffset + 0.25f;
		ms.method_22903();
		ms.method_22904(0.5, f, 0.5);
		ms.method_22907(mc.method_1561()
			.method_24197());
		ms.method_22905(-0.025F, -0.025F, 0.025F);
		Matrix4f matrix4f = ms.method_23760()
			.method_23761();
		float f1 = mc.field_1690.method_19343(0.25F);
		int j = (int) (f1 * 255.0F) << 24;
		float f2 = (float) (-mc.field_1772.method_27525(tag) / 2);
		mc.field_1772.method_30882(tag, f2, 0, 553648127, false, matrix4f, buffer, class_327.class_6415.field_33994, j, light);
		mc.field_1772.method_30882(tag, f2, 0, -1, false, matrix4f, buffer, class_327.class_6415.field_33993, 0, light);
		ms.method_22909();
	}

}
