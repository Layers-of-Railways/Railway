package com.simibubi.create.foundation.item;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_572;
import net.minecraft.class_970;

public interface CustomRenderedArmorItem {
	@Environment(EnvType.CLIENT)
	void renderArmorPiece(class_970<?, ?, ?> layer, class_4587 poseStack, class_4597 bufferSource, class_1309 entity, class_1304 slot, int light, class_572<?> originalModel, class_1799 stack);
}
