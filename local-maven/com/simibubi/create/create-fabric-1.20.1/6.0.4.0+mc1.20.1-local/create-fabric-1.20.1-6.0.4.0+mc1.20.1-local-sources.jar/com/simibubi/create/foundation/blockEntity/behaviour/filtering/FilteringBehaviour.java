package com.simibubi.create.foundation.blockEntity.behaviour.filtering;

import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.function.Supplier;

import com.simibubi.create.AllBlocks;
import com.simibubi.create.AllItems;
import com.simibubi.create.AllSoundEvents;
import com.simibubi.create.content.logistics.filter.FilterItem;
import com.simibubi.create.content.logistics.filter.FilterItemStack;
import com.simibubi.create.content.schematics.requirement.ItemRequirement;
import com.simibubi.create.foundation.blockEntity.SmartBlockEntity;
import com.simibubi.create.foundation.blockEntity.behaviour.BehaviourType;
import com.simibubi.create.foundation.blockEntity.behaviour.BlockEntityBehaviour;
import com.simibubi.create.foundation.blockEntity.behaviour.ValueBoxTransform;
import com.simibubi.create.foundation.blockEntity.behaviour.ValueSettingsBehaviour;
import com.simibubi.create.foundation.blockEntity.behaviour.ValueSettingsBoard;
import com.simibubi.create.foundation.blockEntity.behaviour.ValueSettingsFormatter;
import com.simibubi.create.foundation.item.ItemHelper;
import com.simibubi.create.foundation.utility.CreateLang;
import com.simibubi.create.infrastructure.config.AllConfigs;

import net.createmod.catnip.data.Iterate;
import net.createmod.catnip.math.VecHelper;
import net.fabricmc.fabric.api.transfer.v1.item.ItemVariant;
import net.fabricmc.fabric.api.transfer.v1.item.PlayerInventoryStorage;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3532;
import net.minecraft.class_3965;
import net.minecraft.class_5250;
import io.github.fabricators_of_create.porting_lib.fluids.FluidStack;
import io.github.fabricators_of_create.porting_lib.transfer.item.ItemHandlerHelper;
import io.github.fabricators_of_create.porting_lib.util.NBTSerializer;

public class FilteringBehaviour extends BlockEntityBehaviour implements ValueSettingsBehaviour {

	public static final BehaviourType<FilteringBehaviour> TYPE = new BehaviourType<>();

	public class_5250 customLabel;
	ValueBoxTransform slotPositioning;
	boolean showCount;

	protected FilterItemStack filter;
	public int count;
	public boolean upTo;
	private Predicate<class_1799> predicate;
	private Consumer<class_1799> callback;
	private Supplier<Boolean> isActive;
	private Supplier<Boolean> showCountPredicate;

	boolean recipeFilter;
	boolean fluidFilter;

	public FilteringBehaviour(SmartBlockEntity be, ValueBoxTransform slot) {
		super(be);
		filter = FilterItemStack.empty();
		slotPositioning = slot;
		showCount = false;
		callback = stack -> {
		};
		predicate = stack -> true;
		isActive = () -> true;
		count = 64;
		showCountPredicate = () -> showCount;
		recipeFilter = false;
		fluidFilter = false;
		upTo = true;
	}

	@Override
	public boolean isSafeNBT() {
		return true;
	}

	@Override
	public void write(class_2487 nbt, boolean clientPacket) {
		nbt.method_10566("Filter", NBTSerializer.serializeNBT(getFilter()));
		nbt.method_10569("FilterAmount", count);
		nbt.method_10556("UpTo", upTo);
		super.write(nbt, clientPacket);
	}

	@Override
	public void read(class_2487 nbt, boolean clientPacket) {
		filter = FilterItemStack.of(nbt.method_10562("Filter"));
		count = nbt.method_10550("FilterAmount");
		upTo = nbt.method_10577("UpTo");

		// Migrate from previous behaviour
		if (count == 0) {
			upTo = true;
			count = filter.item()
				.method_7914();
		}

		super.read(nbt, clientPacket);
	}

	public FilteringBehaviour withCallback(Consumer<class_1799> filterCallback) {
		callback = filterCallback;
		return this;
	}

	public FilteringBehaviour withPredicate(Predicate<class_1799> filterPredicate) {
		predicate = filterPredicate;
		return this;
	}

	public FilteringBehaviour forRecipes() {
		recipeFilter = true;
		return this;
	}

	public FilteringBehaviour forFluids() {
		fluidFilter = true;
		return this;
	}

	public FilteringBehaviour onlyActiveWhen(Supplier<Boolean> condition) {
		isActive = condition;
		return this;
	}

	public FilteringBehaviour showCountWhen(Supplier<Boolean> condition) {
		showCountPredicate = condition;
		return this;
	}

	public FilteringBehaviour showCount() {
		showCount = true;
		return this;
	}

	public boolean setFilter(class_2350 face, class_1799 stack) {
		return setFilter(stack);
	}

	public void setLabel(class_5250 label) {
		this.customLabel = label;
	}

	public boolean setFilter(class_1799 stack) {
		class_1799 filter = stack.method_7972();
		if (!filter.method_7960() && !predicate.test(filter))
			return false;
		this.filter = FilterItemStack.of(filter);
		if (!upTo)
			count = Math.min(count, stack.method_7914());
		callback.accept(filter);
		blockEntity.method_5431();
		blockEntity.sendData();
		return true;
	}

	@Override
	public void setValueSettings(class_1657 player, ValueSettings settings, boolean ctrlDown) {
		if (getValueSettings().equals(settings))
			return;
		count = class_3532.method_15340(settings.value(), 1, filter.item()
			.method_7914());
		upTo = settings.row() == 0;
		blockEntity.method_5431();
		blockEntity.sendData();
		playFeedbackSound(this);
	}

	@Override
	public ValueSettings getValueSettings() {
		return new ValueSettings(upTo ? 0 : 1, count == 0 ? filter.item()
			.method_7914() : count);
	}

	@Override
	public void destroy() {
		if (filter.isFilterItem()) {
			class_243 pos = VecHelper.getCenterOf(getPos());
			class_1937 world = getWorld();
			world.method_8649(new class_1542(world, pos.field_1352, pos.field_1351, pos.field_1350, filter.item()
				.method_7972()));
		}
		super.destroy();
	}

	@Override
	public ItemRequirement getRequiredItems() {
		if (filter.isFilterItem())
			return new ItemRequirement(ItemRequirement.ItemUseType.CONSUME, filter.item());

		return ItemRequirement.NONE;
	}

	public class_1799 getFilter(class_2350 side) {
		return getFilter();
	}

	public class_1799 getFilter() {
		return filter.item();
	}

	public boolean isCountVisible() {
		return showCountPredicate.get() && filter.item()
			.method_7914() > 1;
	}

	public boolean test(class_1799 stack) {
		return !isActive() || filter.test(blockEntity.method_10997(), stack);
	}

	public boolean test(ItemVariant variant) {
		return !isActive() || filter.test(blockEntity.method_10997(), variant.toStack());
	}

	public boolean test(FluidStack stack) {
		return !isActive() || filter.test(blockEntity.method_10997(), stack);
	}

	@Override
	public BehaviourType<?> getType() {
		return TYPE;
	}

	@Override
	public boolean testHit(class_243 hit) {
		class_2680 state = blockEntity.method_11010();
		class_243 localHit = hit.method_1020(class_243.method_24954(blockEntity.method_11016()));
		return slotPositioning.testHit(getWorld(), getPos(), state, localHit);
	}

	public int getAmount() {
		return count;
	}

	public boolean anyAmount() {
		return count == 0;
	}

	@Override
	public boolean acceptsValueSettings() {
		return isCountVisible();
	}

	@Override
	public boolean isActive() {
		return isActive.get();
	}

	@Override
	public ValueBoxTransform getSlotPositioning() {
		return slotPositioning;
	}

	@Override
	public ValueSettingsBoard createBoard(class_1657 player, class_3965 hitResult) {
		class_1799 filter = getFilter(hitResult.method_17780());
		int maxAmount = (filter.method_7909() instanceof FilterItem) ? 64 : filter.method_7914();
		return new ValueSettingsBoard(CreateLang.translateDirect("logistics.filter.extracted_amount"), maxAmount, 16,
			CreateLang.translatedOptions("logistics.filter", "up_to", "exactly"),
			new ValueSettingsFormatter(this::formatValue));
	}

	public class_5250 formatValue(ValueSettings value) {
		if (value.row() == 0 && value.value() == filter.item()
			.method_7914())
			return CreateLang.translateDirect("logistics.filter.any_amount_short");
        return class_2561.method_43470(((value.row() == 0) ? "\u2264" : "=") + Math.max(1, value.value()));
    }

	@Override
	public void onShortInteract(class_1657 player, class_1268 hand, class_2350 side, class_3965 hitResult) {
		class_1937 level = getWorld();
		class_2338 pos = getPos();
		class_1799 itemInHand = player.method_5998(hand);
		class_1799 toApply = itemInHand.method_7972();

		if (!canShortInteract(toApply))
			return;
		if (level.method_8608())
			return;

		if (getFilter(side).method_7909() instanceof FilterItem) {
			if (!player.method_7337() || ItemHelper
				.extract(PlayerInventoryStorage.of(player),
					stack -> ItemHandlerHelper.canItemStacksStack(stack, getFilter(side)), true)
				.method_7960())
				player.method_31548()
					.method_7398(getFilter(side).method_7972());
		}

		if (toApply.method_7909() instanceof FilterItem)
			toApply.method_7939(1);

		if (!setFilter(side, toApply)) {
			player.method_7353(CreateLang.translateDirect("logistics.filter.invalid_item"), true);
			AllSoundEvents.DENY.playOnServer(player.method_37908(), player.method_24515(), 1, 1);
			return;
		}

		if (!player.method_7337()) {
			if (toApply.method_7909() instanceof FilterItem) {
				if (itemInHand.method_7947() == 1)
					player.method_6122(hand, class_1799.field_8037);
				else
					itemInHand.method_7934(1);
			}
		}

		level.method_8396(null, pos, class_3417.field_14667, class_3419.field_15245, .25f, .1f);
	}

	public boolean canShortInteract(class_1799 toApply) {
		if (AllItems.WRENCH.isIn(toApply))
			return false;
		if (AllBlocks.MECHANICAL_ARM.isIn(toApply))
			return false;
		return true;
	}

	public class_5250 getLabel() {
		if (customLabel != null)
			return customLabel;
		return CreateLang.translateDirect(
			recipeFilter ? "logistics.recipe_filter" : fluidFilter ? "logistics.fluid_filter" : "logistics.filter");
	}

	public class_5250 getTip() {
		return CreateLang
			.translateDirect(filter.isEmpty() ? "logistics.filter.click_to_set" : "logistics.filter.click_to_replace");
	}

	public class_5250 getAmountTip() {
		return CreateLang.translateDirect("logistics.filter.hold_to_set_amount");
	}

	public class_5250 getCountLabelForValueBox() {
        return class_2561.method_43470(isCountVisible() ? upTo && filter.item()
            .method_7914() == count ? "*" : String.valueOf(count) : "");
    }

	@Override
	public String getClipboardKey() {
		return "Filtering";
	}

	@Override
	public boolean writeToClipboard(class_2487 tag, class_2350 side) {
		ValueSettingsBehaviour.super.writeToClipboard(tag, side);
		class_1799 filter = getFilter(side);
		tag.method_10566("Filter", NBTSerializer.serializeNBT(filter));
		return true;
	}

	@Override
	public boolean readFromClipboard(class_2487 tag, class_1657 player, class_2350 side, boolean simulate) {
		if (!mayInteract(player))
			return false;
		boolean upstreamResult = ValueSettingsBehaviour.super.readFromClipboard(tag, player, side, simulate);
		if (!tag.method_10545("Filter"))
			return upstreamResult;
		if (simulate)
			return true;
		if (getWorld().field_9236)
			return true;

		class_1799 refund = class_1799.field_8037;
		if (getFilter(side).method_7909() instanceof FilterItem && !player.method_7337())
			refund = getFilter(side).method_7972();

		class_1799 copied = class_1799.method_7915(tag.method_10562("Filter"));

		if (copied.method_7909() instanceof FilterItem filterType && !player.method_7337()) {
			PlayerInventoryStorage inv = PlayerInventoryStorage.of(player);

			for (boolean preferStacksWithoutData : Iterate.trueAndFalse) {
				if (refund.method_7909() != filterType && ItemHelper
					.extract(inv, stack -> stack.method_7909() == filterType && preferStacksWithoutData != stack.method_7985(),
						1, false)
					.method_7960())
					continue;

				if (!refund.method_7960() && refund.method_7909() != filterType)
					player.method_31548()
						.method_7398(refund);

				setFilter(side, copied);
				return true;
			}

			player.method_7353(CreateLang
				.translate("logistics.filter.requires_item_in_inventory", copied.method_7964()
					.method_27661()
					.method_27692(class_124.field_1068))
				.style(class_124.field_1061)
				.component(), true);
			AllSoundEvents.DENY.playOnServer(player.method_37908(), player.method_24515(), 1, 1);
			return false;
		}

		if (!refund.method_7960())
			player.method_31548()
				.method_7398(refund);

		return setFilter(side, copied);
	}

	public boolean isRecipeFilter() {
		return recipeFilter;
	}

	@Override
	public boolean bypassesInput(class_1799 mainhandItem) {
		return false;
	}

	@Override
	public int netId() {
		return 1;
	}

	public float getRenderDistance() {
		return AllConfigs.client().filterItemRenderDistance.getF();
	}

}
