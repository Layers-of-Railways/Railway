package com.simibubi.create.foundation.networking;

import java.util.HashSet;
import net.minecraft.class_1297;
import net.minecraft.class_2487;
import net.minecraft.class_2540;
import net.minecraft.class_310;
import com.simibubi.create.AllPackets;

public interface ISyncPersistentData {

	void onPersistentDataUpdated();

	default void syncPersistentDataWithTracking(class_1297 self) {
		AllPackets.getChannel().sendToClientsTracking(new PersistentDataPacket(self), self);
	}

	public static class PersistentDataPacket extends SimplePacketBase {

		private int entityId;
		private class_1297 entity;
		private class_2487 readData;

		public PersistentDataPacket(class_1297 entity) {
			this.entity = entity;
			this.entityId = entity.method_5628();
		}

		public PersistentDataPacket(class_2540 buffer) {
			entityId = buffer.readInt();
			readData = buffer.method_10798();
		}

		@Override
		public void write(class_2540 buffer) {
			buffer.writeInt(entityId);
			buffer.method_10794(entity.getCustomData());
		}

		@Override
		public boolean handle(Context context) {
			context.enqueueWork(() -> {
				class_1297 entityByID = class_310.method_1551().field_1687.method_8469(entityId);
				class_2487 data = entityByID.getCustomData();
				new HashSet<>(data.method_10541()).forEach(data::method_10551);
				data.method_10543(readData);
				if (!(entityByID instanceof ISyncPersistentData))
					return;
				((ISyncPersistentData) entityByID).onPersistentDataUpdated();
			});
			return true;
		}

	}

}
