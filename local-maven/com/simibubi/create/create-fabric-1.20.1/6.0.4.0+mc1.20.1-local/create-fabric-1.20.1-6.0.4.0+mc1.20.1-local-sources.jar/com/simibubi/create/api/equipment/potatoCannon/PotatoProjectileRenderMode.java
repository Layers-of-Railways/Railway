package com.simibubi.create.api.equipment.potatoCannon;

import java.util.function.Function;
import com.mojang.serialization.Codec;
import com.simibubi.create.api.registry.CreateBuiltInRegistries;
import com.simibubi.create.content.equipment.potatoCannon.PotatoProjectileEntity;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_4587;

public interface PotatoProjectileRenderMode {
	Codec<PotatoProjectileRenderMode> CODEC = CreateBuiltInRegistries.POTATO_PROJECTILE_RENDER_MODE.method_39673()
		.dispatch(PotatoProjectileRenderMode::codec, Function.identity());

	@Environment(EnvType.CLIENT)
	void transform(class_4587 ms, PotatoProjectileEntity entity, float pt);

	Codec<? extends PotatoProjectileRenderMode> codec();
}
