package com.simibubi.create.foundation.particle;

import com.mojang.serialization.Codec;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.particle.v1.ParticleFactoryRegistry;
import net.minecraft.class_2394;
import net.minecraft.class_2394.class_2395;
import net.minecraft.class_2396;
import net.minecraft.class_702;
import net.minecraft.class_707;

public interface ICustomParticleData<T extends class_2394> {

	class_2395<T> getDeserializer();

	Codec<T> getCodec(class_2396<T> type);

	public default class_2396<T> createType() {
		return new class_2396<>(false, getDeserializer()) {

			@Override
			public Codec<T> method_29138() {
				return ICustomParticleData.this.getCodec(this);
			}
		};
	}

	@Environment(EnvType.CLIENT)
	public class_707<T> getFactory();

	@Environment(EnvType.CLIENT)
	public default void register(class_2396<T> type, class_702 particles) {
		ParticleFactoryRegistry.getInstance().register(type, getFactory());
	}

}
