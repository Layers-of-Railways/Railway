package com.simibubi.create.foundation.mixin.accessor;

import net.minecraft.class_1293;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_1293.class)
public interface MobEffectInstanceAccessor {
	@Accessor("hiddenEffect")
	class_1293 create$getHiddenEffect();
}
